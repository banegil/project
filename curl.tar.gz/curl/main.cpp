//g++ -std=c++11 -L. main.cpp -lpthread -ljsoncpp -o main -lcurl
#include <thread>
#include <iostream>
#include <vector>
#include <string>
#include <queue>
#include <curl/curl.h>
#include <fstream>
#include <jsoncpp/json/json.h>
using namespace std;

#include "exchanges.h"
#include "curlHttp.h"

#define MAX_EXCHANGES 1


void spawnThreads() {
    vector<bool> v(MAX_EXCHANGES, false);
    int n = exchangesIni(v, "ETHUSDT");
    
    vector<pair<int, string>> ex(n); // id, url
    vector<thread> threads(n);
    
    int j = 0;
    for(int i = 0; i < MAX_EXCHANGES; i++)
        if(v[i])
            ex[j++] = { i, urls[i] };


    for (int i = 0; i < n; ++i) 
        threads[i] = thread(doSomething, ex[i]); //curlHttp.h

    for (int i = 0; i < n; ++i) 
        threads[i].join();
}

int main() 
{
    spawnThreads();
}
