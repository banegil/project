//g++ -std=c++11 -L. main.cpp -lpthread -ljsoncpp -o main -lcurl
#include <iostream>
#include <fstream>
#include <thread>
#include <vector>
#include <string>
#include <queue>
#include <mutex>
#include <curl/curl.h>
#include <jsoncpp/json/json.h>
using namespace std;

mutex mtxErr, mtxCmp;

#include "exchanges.h"
#include "curlHttp.h"

void spawnThreads() {
    vector<pair<int, string>> ex(0); // id, url
    exchangesIni(ex, "ETHUSDT");
    int n = ex.size();
    vector<thread> threads(n);
            
    // for(...){

        for (int i = 0; i < n; ++i) 
            threads[i] = thread(doSomething, ex[i]); //curlHttp.h

        for (int i = 0; i < n; ++i) 
            threads[i].join();
           
            
        for(auto i: asks.top().v)
            cout << i.second << '\n';
        for(auto i: bids.top().v)
            cout << i.second << '\n';
            
        cout << asks.top().id << ' ' << bids.top().id << endl;
            
            
        if(actExErr > 0){
            for(int i = 0; i < actExErr; ++i) {
                int index = exErr[i];
                auto it = ex.begin();
                auto it2 = threads.begin();
                ex.erase(it + index);
                threads.erase(it2 + index);
            }
            actExErr = 0;
        }
    // }
}

int main() 
{
    spawnThreads();
    return 0;
}
