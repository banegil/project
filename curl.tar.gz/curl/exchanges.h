
// EXCHANGES URLS

vector<string> urls = {
    "https://api.binance.com/api/v3/depth?symbol=ETHUSDT" // BINANCE
};

// EXCHANGES PARSER

void binanceParser(const unique_ptr<string>& httpData){
    Json::Value jsonData;
    Json::Reader jsonReader;
         
    if (jsonReader.parse(*httpData.get(), jsonData)) {
    float k = atof(&jsonData["asks"][0][0]) ;
        cout << k << endl;
    }
}

void parser(const int& id, const unique_ptr<string>& data) {
    switch(id) {
        case 0:  binanceParser(data);
                 break;
        case 1:
                 break;
        default: 
                 break;
    }
}

// EXCHANGES INI

int exchangesIni(vector<bool>& v, const string& cryptoPair){
    int id, i = 0;
    string trash;
    
    ifstream in("ETHUSDT.txt");
    auto cinbuf = cin.rdbuf(in.rdbuf());
    
    while(id != -1){
        cin >> id;
        if(id != -1){
            cin >> trash;
            v[id] = true;
            i++;
        }
    }

    cin.rdbuf(cinbuf);

    return i;
}


