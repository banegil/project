
#define MAX_EXCHANGES 1
#define MAX_BINANCE_DEPTH 100

// ----------EXCHANGES URLS------------
vector<string> urls = {
    "https://api.binance.com/api/v3/depth?symbol=XVSUSDT" // Binance
};
// ----------EXCHANGES ERRORS----------
int actExErr = 0;
vector<int> exErr(MAX_EXCHANGES);
void handle_errorEx(const int& id, const string& s){
    cout << s << '\n';
    // deleting exchange from list
    mtxErr.lock();
    exErr[actExErr] = id;
    actExErr++;
    mtxErr.unlock();
}
// ----------PRICES COMPARATOR---------
struct prc{
    vector<pair<float,float>> v;
    int id;
};
struct prcAsk{
    bool operator()(const prc& a, const prc& b){
        return a.v[0].first < b.v[0].first
            || (a.v[0].first == b.v[0].first && a.v[0].second > b.v[0].second);
    }
};
struct prcBid{
    bool operator()(const prc& a, const prc& b){
        return a.v[0].first > b.v[0].first
            || (a.v[0].first == b.v[0].first && a.v[0].second > b.v[0].second);
    }
};
priority_queue<prc,vector<prc>,prcAsk> asks; // min ask possible
priority_queue<prc,vector<prc>,prcBid> bids; // max bid possible
//-------------------------------------

// EXCHANGES PARSER

void binanceParser(const int& id, const unique_ptr<string>& httpData){
    Json::Value jsonData;
    Json::Reader jsonReader;
         
    if (jsonReader.parse(*httpData.get(), jsonData)) {
        if(jsonData.isMember("lastUpdateId")){
            int i = 0;
            vector<pair<float,float>> v1(MAX_BINANCE_DEPTH); // price, quantity
            vector<pair<float,float>> v2(MAX_BINANCE_DEPTH); // price, quantity
            for(auto it : jsonData["asks"]){
                v1[i].first = stof(it[0].asString());
                v1[i].second = stof(it[1].asString());
                i++;
            }
            i = 0;
            for(auto it : jsonData["bids"]){
                v2[i].first = stof(it[0].asString());
                v2[i].second = stof(it[1].asString());
                i++;
            }
            mtxCmp.lock();
                asks.push({ v1, id });
                bids.push({ v2, id });
            mtxCmp.unlock();
        }
        else if(jsonData.isMember("code")) 
            handle_errorEx(id, "Binance ERROR, code: " + jsonData["code"].asString() + ", msg: " + jsonData["msg"].asString());
        else 
            handle_errorEx(id, "1.Error reading Binance Json");
    }
    else
        handle_errorEx(id, "2.Error reading Binance Json");

}

void parser(const int& id, const unique_ptr<string>& data) {
    switch(id) {
        case 0:  binanceParser(id, data);
                 break;
        case 1:
                 break;
        default: 
                 break;
    }
}

// EXCHANGES INI

void exchangesIni(vector<pair<int,string>>& v, const string& cryptoPair){
    int id = 0;
    string trash;
    
    ifstream in("ETHUSDT.txt");
    auto cinbuf = cin.rdbuf(in.rdbuf());
    
    while(id != -1){
        cin >> id;
        if(id != -1){
            cin >> trash;
            v.push_back({ id, urls[id] });
        }
    }

    cin.rdbuf(cinbuf);
}


