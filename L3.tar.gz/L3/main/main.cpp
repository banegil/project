#include <map>
#include "include.h"

#include <chrono>
#include <thread>
#include <future> 

#define MAX_EXCHANGES 23

using namespace std;

vector<Exchange*> ex;

string symba = "ATOM-USDT";

bool vCandidates(string s, vector<bool>& v, int &num){
    ifstream file;
    string cent = "-1", word;
    bool ok = false;
    string s1 = s.substr(0, s.find('-'));
    string s2 = s.substr(s.find('-') + 1, s.length() - 1);
    
    file.open (s2);
    if (!file.is_open()) {
        cout << "File couldn't open" << endl;
        return 0;
    }
    
    for(int i = 0; i < MAX_EXCHANGES; i++)
        file >> word;

    while (word != "-1" && !ok) {
        file >> word;
        if(word == s1){
            ok = true;
            for(int i = 0; i < MAX_EXCHANGES; i++){
                file >> word;
                    if(i == 3 || i == 4 || i == 5 || i == 15 || i == 21) // BITFINEX, BITRUE, BTCEX, LATOKEN, PROBITGLOBAL
                        v[i] = 0;
                    else
                        v[i] = stoi(word);
                if(v[i]) num++;
            }
        }
        else 
            for(int i = 0; i < MAX_EXCHANGES; i++)
                file >> word;
    }
    
    file.close();
    return ok;
}

void doSomething(int i, string symbol){
    ex[i]->wesbsocketInit_depth(symbol);
}

multimap < double, pair < string, map <double,double> > > checkFunction (string symbol, int indx){
    multimap < double, pair < string, map <double,double> > > minAsks; 
    map < string, map <double,double> > depth = ex[indx]->getget(symbol);
    
    if(!depth["asks"].empty()) {
        minAsks.insert( pair< double, pair < string, map <double,double> > >(depth["asks"].begin()->first, pair< string, map <double,double> >(ex[indx]->get_id(), depth["asks"])) );
    }
    else{
        string err = "ERROR: depth[] map is empty! try to buy in exchange " + ex[indx]->get_id();
        writte_log(err);
    }
    
    return minAsks;
}

void init(string symbol, vector<bool> v, const int n){  
    int i = 0, cont = 0;
    vector<bool> vD(n, 1);
    ex.resize(n);
    map < string, double > comission;
    map < string, int > index;
    
    Aax aax(0.001, "aax", "", "");
    comission["aax"] = 0.0006;
    if(v[i++]) {
        index["aax"] = cont;
        ex[cont++] = &aax;
    }
    Ascendex ascendex(0.001, "ascendex", "", "");
    comission["ascendex"] = 0.001;
    if(v[i++]){
        index["ascendex"] = cont;
        ex[cont++] = &ascendex;
    }
    Binance binance(0.001, "binance", "", "");
    comission["binance"] = 0.00075;
    if(v[i++]) {
        index["binance"] = cont;
        ex[cont++] = &binance;
    }
    Bitfinex bitfinex(0.001, "bitfinex", "", "");
    comission["bitfinex"] = 0.00075;
    if(v[i++]) {
        index["bitfinex"] = cont;
        ex[cont++] = &bitfinex;
    }
    Bitrue bitrue(0.001, "bitrue", "", "");
    comission["bitrue"] = 0.001;
    if(v[i++]){
        index["bitrue"] = cont;
        ex[cont++] = &bitrue;
    }
    Btcex btcex(0.001, "btcex", "", "");
    comission["btcex"] = 0.001;
    if(v[i++]){
        index["btcex"] = cont;
        ex[cont++] = &btcex;
    }
    Bybit bybit(0.001, "bybit", "", "");
    comission["bybit"] = 0.001;
    if(v[i++]) {
        index["bybit"] = cont;
        ex[cont++] = &bybit;
    }
    Coinex coinex(0.001, "coinex", "", "");
    comission["coinex"] = 0.00128;
    if(v[i++]) {
        index["coinex"] = cont;
        ex[cont++] = &coinex;
    }
    Cryptocom cryptocom(0.001, "cryptocom", "", "");
    comission["cryptocom"] = 0.001;
    if(v[i++]) {
        index["cryptocom"] = cont;
        ex[cont++] = &cryptocom;
    }
    Exmo exmo(0.001, "exmo", "", "");
    comission["exmo"] = 0.001;
    if(v[i++]) {
        index["exmo"] = cont;
        ex[cont++] = &exmo;
    }
    Fmfw fmfw(0.002, "fmfw", "", "");
    comission["fmfw"] = 0.002;
    if(v[i++]) {
        index["fmfw"] = cont;
        ex[cont++] = &fmfw;
    }
    Gateio gateio(0.0006, "gateio", "", "");
    comission["gateio"] = 0.0006;
    if(v[i++]) {
        index["gateio"] = cont;
        ex[cont++] = &gateio;
    }
    Hitbtc hitbtc(0.002, "hitbtc", "", "");
    comission["hitbtc"] = 0.002;
    if(v[i++]) {
        index["hitbtc"] = cont;
        ex[cont++] = &hitbtc;
    }
    Huobi huobi(0.002, "huobi", "", "");
    comission["huobi"] = 0.001;
    if(v[i++]) {
        index["huobi"] = cont;
        ex[cont++] = &huobi;
    }
    Kucoin kucoin(0.001, "kucoin", "", "");
    comission["kucoin"] = 0.001;
    if(v[i++]) {
        index["kucoin"] = cont;
        ex[cont++] = &kucoin;
    }
    Latoken latoken(0.001, "latoken", "", "");
    comission["latoken"] = 0.001;
    if(v[i++]){
        index["latoken"] = cont;
        ex[cont++] = &latoken;
    }
    Lbank lbank(0.001, "lbank", "", "");
    comission["lbank"] = 0.001;
    if(v[i++]) {
        index["lbank"] = cont;
        ex[cont++] = &lbank;
    }
    Mexc mexc(0.0005, "mexc", "", "");
    comission["mexc"] = 0.001;
    if(v[i++]) {
        index["mexc"] = cont;
        ex[cont++] = &mexc;
    }
    Nominex nominex(0.001, "nominex", "", "");
    comission["nominex"] = 0.0008;
    if(v[i++]){
        index["nominex"] = cont;
        ex[cont++] = &nominex;
    }
    Okx okx(0.0005, "okx", "", "");
    comission["okx"] = 0.001;
    if(v[i++]) {
        index["okx"] = cont;
        ex[cont++] = &okx;
    }
    Poloniex poloniex(0.0012, "poloniex", "", "");
    comission["poloniex"] = 0.0012;
    if(v[i++]) {
        index["poloniex"] = cont;
        ex[cont++] = &poloniex;
    }
    Probitglobal probitglobal(0.002, "probitglobal", "", "");
    comission["probitglobal"] = 0.002;
    if(v[i++]) {
        index["probitglobal"] = cont;
        ex[cont++] = &probitglobal;
    }
    Whitebit whitebit(0.001, "whitebit", "", "");
    comission["whitebit"] = 0.001;
    if(v[i++]){
        index["whitebit"] = cont;
        ex[cont++] = &whitebit;
    }

    //ex[0]->curl_depth("ETH-USDT");
    //ex[0]->wesbsocketInit_depth("ETH-USDT"); 
    //ex[0]->send_order("ETH-USDT", "buy", 1.1, 10); 
    //ex[0]->withdraw("ETH", "0x8dDD3FE2D9eb8E1f7fCdb603eC5c9c25cbD0108C", 1.2, "ERC20"); 
        
    vector<thread> ths(n);    
    for(i = 0; i < n; i++) 
        ths[i] = thread (doSomething, i, symbol);

    std::this_thread::sleep_for(std::chrono::milliseconds(23000));
    
    map <string, int> vecesC, vecesV;
    int contWin = 0, contLose = 0;
    double past = 0, totalpq = 0, volume = 0;
    string arb;
    map < string, map <double,double> > depth;
    multimap < double, pair < string, map <double,double> > > minAsks; 
    multimap < double, pair < string, map <double,double,greater<double> > >, greater<double> > maxBids;
    map <double,double,greater<double > > bidsmap;
    while(1){
        string iC, iV;
        minAsks.clear();
        maxBids.clear();

        for(i = 0; i < n; i++) {
            if(vD[i]) {
                depth = ex[i]->get_socketDepth();
                if(!depth["bids"].empty() && !depth["asks"].empty()) {
                
                    minAsks.insert( pair< double, pair < string, map <double,double> > >(depth["asks"].begin()->first, pair< string, map <double,double> >(ex[i]->get_id(), depth["asks"])) );
                    
                    bidsmap.clear();
                    bidsmap.insert(depth["bids"].begin(), depth["bids"].end());
                    auto it = depth["bids"].end(); --it;
                    maxBids.insert( pair< double, pair < string, map <double,double,greater<double > > > >(it->first, pair < string, map <double,double,greater<double > > >(ex[i]->get_id(), bidsmap)) );
                }
                else{
                    string err = "ERROR: depth[] map is empty! in exchange " + ex[i]->get_id();
                    writte_log(err);
                    vD[i] = 0;
                }
            }
        }
        
        /*cout << "ASKS:" << endl;
        for(auto ita = minAsks.begin(); ita != minAsks.end(); ++ita)
            cout << ita->first << " in exchange " << ita->second.first << endl;           
        cout << "BIDS:" << endl;
        for(auto itb = maxBids.begin(); itb != maxBids.end(); ++itb)
            cout << itb->first << " in exchange " << itb->second.first << endl;
        
        cout << "diff pair: " << (1 - ( minAsks.begin()->first / maxBids.begin()->first )) * 100 << "%" << endl;
        cout << endl;*/
           
           
        double diff = (1 - (  (minAsks.begin()->first + minAsks.begin()->first * comission[minAsks.begin()->second.first]) 
                            / (maxBids.begin()->first - maxBids.begin()->first * comission[maxBids.begin()->second.first]) ) );
                            
        iV = maxBids.begin()->second.first;
        iC = minAsks.begin()->second.first;
        // Compare 2 Exchanges, need to compare all Exchanges
        if(diff > 0 && iV != iC) { // && need to consider Exchange's minimum quantity       
            
            auto ita = minAsks.begin()->second.second.begin();
            auto itb = maxBids.begin()->second.second.begin();
            double profitQuantity = 0, buyQuantity = 0, sellQuantity = 0;
            while( diff > 0 && ita != minAsks.begin()->second.second.end() && itb != maxBids.begin()->second.second.end() ){
                double buy, sell;
                if(ita->second <= itb->second){
                    buy = ita->second;
                    sell = ita->second - ita->second * comission[iC];
                }
                else{
                    // se podria hilar ligeramente mas fino
                    buy = itb->second + itb->second * comission[iC];
                    sell = itb->second;
                }
                
                profitQuantity += ((itb->first - itb->first * comission[iV]) * sell) - (ita->first * buy);
                ita->second -= buy;
                itb->second -= sell;
                
                if(ita->second * ita->first <= 1)
                    ita++;
                if(itb->second * itb->first <= 1)
                    itb++;
                    
                buyQuantity += buy;
                sellQuantity += sell;
                
                diff = (1 - (  (ita->first + ita->first * comission[iC]) 
                             / (itb->first - itb->first * comission[iV]) ) ); 
            }
            
            if(buyQuantity * minAsks.begin()->second.second.begin()->first > 5 && buyQuantity != past) {
                past = buyQuantity;
                //arb = "PROFIT-simulation: " + to_string(profitQuantity) + "$, Buy: " + to_string(buyQuantity * minAsks.begin()->first) + "$, [compra en " + iC + "] [venta en " + iV + "]";
                //writte_arb(arb);

                //arb = "diff pair-simulation: " + to_string((1 - ( minAsks.begin()->first / maxBids.begin()->first )) * 100) + "%";
                //writte_arb(arb);
                // Si diff es mayor que 2% stop! si es probitglobal o alo asi tambien
                // Buy
                auto fut = std::async (launch::async, checkFunction, symbol, index[iC]);
                // Sell
                depth = ex[index[iV]]->getget(symbol);
                if(!depth["bids"].empty()) {
                    bidsmap.clear();
                    maxBids.clear();
                    bidsmap.insert(depth["bids"].begin(), depth["bids"].end());
                    auto it = depth["bids"].end(); --it;
                    maxBids.insert( pair< double, pair < string, map <double,double,greater<double > > > >(it->first, pair < string, map <double,double,greater<double > > >(ex[index[iV]]->get_id(), bidsmap)) );
                }
                else{
                    // CORTAR DE RAIZ!! STOP PROGRAM!!
                    string err = "ERROR: depth[] map is empty! try to sell in exchange " + ex[index[iV]]->get_id();
                    writte_log(err);
                }

                minAsks = fut.get();
                arb = "diff pair: " + to_string((1 - ( minAsks.begin()->first / maxBids.begin()->first )) * 100) + "%";
                writte_arb(arb);
                
                buyQuantity *= 0.9;
                sellQuantity *= 0.9;
                /*while(buyQuantity * minAsks.begin()->first > 500){
                    buyQuantity *= 0.7;
                    sellQuantity *= 0.7;
                }*/
                
                double saveQ = buyQuantity;
                double bPrice = 0;
                auto itaa = minAsks.begin()->second.second.begin();
                while(buyQuantity > 0){
                    if(itaa->second <= buyQuantity) {
                        buyQuantity -= itaa->second;
                        bPrice += itaa->first * itaa->second;
                        itaa++;
                    }
                    else{
                        bPrice += buyQuantity * itaa->first;
                        buyQuantity = 0;
                    }
                }
                
                double sPrice = 0;
                auto itbb = maxBids.begin()->second.second.begin();
                while(sellQuantity > 0){
                    if(itbb->second <= sellQuantity) {
                        sellQuantity -= itbb->second;
                        sPrice += itbb->first * itbb->second;
                        itbb++;
                    }
                    else{
                        sPrice += sellQuantity * itbb->first;
                        sellQuantity = 0;
                    }
                }
                
                profitQuantity = sPrice - sPrice * comission[iV] - bPrice;
                totalpq += profitQuantity;
                volume += saveQ * minAsks.begin()->first;
                int vcsV = ++vecesC[maxBids.begin()->second.first];
                int vcsC = ++vecesV[minAsks.begin()->second.first];
                
                arb = "[Buy in exchange: " + iC + " " + to_string(vcsC) + " times, Sell in exchange: " + iV + " " + to_string(vcsV) + " times]";
                writte_arb(arb);   
                
                if(profitQuantity > 0){ 
                    arb = "PROFIT: ";
                    contWin++;
                }
                else{
                    arb = "LOSS: ";
                    contLose++;
                }
                    
                arb += to_string(profitQuantity) + "$, Buy: " + to_string(saveQ * minAsks.begin()->first) + "$, totalProfit: " + to_string(totalpq) + "$, totalVolume: " + to_string(volume) +  "$ [win: " + to_string(contWin) + ", lose: " + to_string(contLose) + "]\n";
                writte_arb(arb);                
                std::this_thread::sleep_for(std::chrono::milliseconds(2000));
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    
    for(i = 0; i < n; i++)
        ths[i].join();
}

int main() {
    vector<bool> v(MAX_EXCHANGES);
    string symbol = symba;
    int num = 0;
    
    if(vCandidates(symbol, v, num))
        init(symbol, v, num);
    else
        cout << "Symbol not supported!" << endl;
    return 0;
}
