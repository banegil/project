#include <map>
#include "include.h"

#include <chrono>
#include <thread>
#include <future> 

#define MAX_EXCHANGES 18

using namespace std;

enum { AAX, ASCENDEX, BINANCE, BITSTAMP, BYBIT, COINEX, CRYPTOCOM, EXMO, FMFW, GATEIO, HITBTC, HUOBI, KUCOIN, LBANK, MEXC, OKX, POLONIEX, PROBITGLOBAL };

vector<Exchange*> ex;

void doSomething(int i, string symbol){
    ex[i]->wesbsocketInit_depth(symbol);
}

map < double, pair < string, map <double,double> > > checkFunction (string symbol, int indx){
    map < double, pair < string, map <double,double> > > minAsks; 
    map < string, map <double,double> > depth = ex[indx]->getget(symbol);
    
    if(!depth["asks"].empty()) {
        minAsks[depth["asks"].begin()->first].first = ex[indx]->get_id();
        minAsks[depth["asks"].begin()->first].second = depth["asks"];
    }
    else{
        string err = "ERROR: depth[] map is empty! (curl_get_depth) in exchange " + ex[indx]->get_id();
        writte_log(err);
    }
    
    return minAsks;
}

void init(string symbol, vector<bool> v, const int& n){  
    int i = 0, cont = 0;
    double profit = 0;
    vector<bool> vD(n, 1);
    ex.resize(n);
    map < string, map <double,double> > depth;
    map < string, double > comission;
    map < string, int > index;
    
    Aax aax(0.001, "aax", "", "");
    comission["aax"] = 0.0006;
    if(v[i++]) {
        index["aax"] = cont;
        ex[cont++] = &aax;
    }
    Ascendex ascendex(0.001, "ascendex", "", "");
    comission["ascendex"] = 0.001;
    if(v[i++]){
        index["ascendex"] = cont;
        ex[cont++] = &ascendex;
    }
    Binance binance(0.001, "binance", "", "");
    comission["binance"] = 0.0005;
    if(v[i++]) {
        index["binance"] = cont;
        ex[cont++] = &binance;
    }
    Bitstamp bitstamp(0.0025, "bitstamp", "", "");
    comission["bitstamp"] = 0.0025;
    if(v[i++]) {
        index["bitstamp"] = cont;
        ex[cont++] = &bitstamp;
    }
    Bybit bybit(0.001, "bybit", "", "");
    comission["bybit"] = 0.001;
    if(v[i++]) {
        index["bybit"] = cont;
        ex[cont++] = &bybit;
    }
    Coinex coinex(0.001, "coinex", "", "");
    comission["coinex"] = 0.002;
    if(v[i++]) {
        index["coinex"] = cont;
        ex[cont++] = &coinex;
    }
    Cryptocom cryptocom(0.001, "cryptocom", "", "");
    comission["cryptocom"] = 0.001;
    if(v[i++]) {
        index["cryptocom"] = cont;
        ex[cont++] = &cryptocom;
    }
    Exmo exmo(0.0026, "exmo", "", "");
    comission["exmo"] = 0.0026;
    if(v[i++]) {
        index["exmo"] = cont;
        ex[cont++] = &exmo;
    }
    Fmfw fmfw(0.002, "fmfw", "", "");
    comission["fmfw"] = 0.002;
    if(v[i++]) {
        index["fmfw"] = cont;
        ex[cont++] = &fmfw;
    }
    Gateio gateio(0.0006, "gateio", "", "");
    comission["gateio"] = 0.0006;
    if(v[i++]) {
        index["gateio"] = cont;
        ex[cont++] = &gateio;
    }
    Hitbtc hitbtc(0.002, "hitbtc", "", "");
    comission["hitbtc"] = 0.002;
    if(v[i++]) {
        index["hitbtc"] = cont;
        ex[cont++] = &hitbtc;
    }
    Huobi huobi(0.002, "huobi", "", "");
    comission["huobi"] = 0.001;
    if(v[i++]) {
        index["huobi"] = cont;
        ex[cont++] = &huobi;
    }
    Kucoin kucoin(0.001, "kucoin", "", "");
    comission["kucoin"] = 0.001;
    if(v[i++]) {
        index["kucoin"] = cont;
        ex[cont++] = &kucoin;
    }
    Lbank lbank(0.001, "lbank", "", "");
    comission["lbank"] = 0.001;
    if(v[i++]) {
        index["lbank"] = cont;
        ex[cont++] = &lbank;
    }
    Mexc mexc(0.0005, "mexc", "", "");
    comission["mexc"] = 0.001;
    if(v[i++]) {
        index["mexc"] = cont;
        ex[cont++] = &mexc;
    }
    Okx okx(0.0005, "okx", "", "");
    comission["okx"] = 0.001;
    if(v[i++]) {
        index["okx"] = cont;
        ex[cont++] = &okx;
    }
    Poloniex poloniex(0.0012, "poloniex", "", "");
    comission["poloniex"] = 0.0012;
    if(v[i++]) {
        index["poloniex"] = cont;
        ex[cont++] = &poloniex;
    }
    Probitglobal probitglobal(0.002, "probitglobal", "", "");
    comission["probitglobal"] = 0.002;
    if(v[i++]) {
        index["probitglobal"] = cont;
        ex[cont++] = &probitglobal;
    }

    /*long sum = 0, minimo = 10000, maximo = 0;
    long var = ex[0]->getServerTime();
    std::this_thread::sleep_for(std::chrono::milliseconds(3000));
    for(int c = 0; c < 10; c++){
        var = ex[0]->getServerTime();
        minimo = min(minimo, var);
        maximo = max(maximo, var);
        sum += var;
        cout << "ms: " << var << endl;

        std::this_thread::sleep_for(std::chrono::milliseconds(3000));
    }
    
    cout << " " << endl;
    cout << "Maximo: " << maximo << endl;
    cout << "Minimo: " << minimo << endl;
    cout << "Average: " << sum / 10 << endl;*/

    //ex[0]->curl_depth("ETH-USDT");
    //ex[0]->wesbsocketInit_depth("ETH-USDT"); 
    //ex[0]->send_order("ETH-USDT", "buy", 1.1, 10); 
    //ex[0]->withdraw("ETH", "0x8dDD3FE2D9eb8E1f7fCdb603eC5c9c25cbD0108C", 1.2, "ERC20"); 
        
    vector<thread> ths(n);    
    for(i = 0; i < n; i++) 
        ths[i] = thread (doSomething, i, symbol);

    std::this_thread::sleep_for(std::chrono::milliseconds(7000));
    
    
    bool check = false;
    double totalpq = 0, past = 0;
    map <string, int> vecesC, vecesV;
    string iC, iV, c;
    time_t current_time;
    time(&current_time);
    int ct = current_time;
    while(1){
        time(&current_time);
        int ct2 = current_time;
        map < double, pair < string, map <double,double> > > minAsks; 
        map < double, pair < string, map <double,double,greater<double > > >, greater<double> > maxBids;
        
        if(!check){
            for(i = 0; i < n; i++) {
                if(vD[i]) {
                    depth = ex[i]->get_socketDepth();
                    if(!depth["bids"].empty() && !depth["asks"].empty()) {
                    
                        minAsks[depth["asks"].begin()->first].first = ex[i]->get_id();
                        minAsks[depth["asks"].begin()->first].second = depth["asks"];
                        
                        auto it = depth["bids"].end(); --it;
                        maxBids[it->first].first = ex[i]->get_id();
                        maxBids[it->first].second.insert(depth["bids"].begin(), depth["bids"].end());
                    }
                    else{
                        string err = "ERROR: depth[] map is empty! in exchange " + ex[i]->get_id();
                        writte_log(err);
                        vD[i] = 0;
                    }
                }
            }
        }
        else{
            if(ct2 - ct >= 2){
                ct = ct2;
                // Buy
                auto fut = std::async (checkFunction, symbol, index[iC]);
                // Sell
                depth = ex[index[iV]]->getget(symbol);
                if(!depth["bids"].empty()) {
                    auto it = depth["bids"].end(); --it;
                    maxBids[it->first].first = ex[index[iV]]->get_id();
                    maxBids[it->first].second.insert(depth["bids"].begin(), depth["bids"].end());
                }
                else{
                    string err = "ERROR: depth[] map is empty! (curl_get_depth) in exchange " + ex[index[iV]]->get_id();
                    writte_log(err);
                }

                minAsks = fut.get();
                cout << (1 - ( minAsks.begin()->first / maxBids.begin()->first )) * 100 << "%" << endl;
            }
            else{
                string arb = "TOO FAST! wait some time ... ";
                writte_arb(arb);
            }
        }
        
        
        /*cout << "ASKS:" << endl;
        for(auto ita = minAsks.begin(); ita != minAsks.end(); ++ita)
            cout << ita->first << " in exchange " << minAsks[ita->first].first << endl;           
        cout << "BIDS:" << endl;
        for(auto itb = maxBids.begin(); itb != maxBids.end(); ++itb)
            cout << itb->first << " in exchange " << maxBids[itb->first].first << endl;
        
        cout << (1 - ( minAsks.begin()->first / maxBids.begin()->first )) * 100 << "%" << endl;*/
           
           
        double diff = (1 - (  (minAsks.begin()->first + minAsks.begin()->first * comission[minAsks.begin()->second.first]) 
                            / (maxBids.begin()->first - maxBids.begin()->first * comission[maxBids.begin()->second.first]) ) );
                            
        
        // Compare 2 Exchanges, need to compare all Exchanges
        if(diff > 0) { // && need to consider Exchange's minimum quantity
            if(check){
                c = "1º check ok!";
                writte_arb(c);
            }
        
            string nameV = maxBids.begin()->second.first;
            string nameC = minAsks.begin()->second.first;
            
            auto ita = minAsks.begin()->second.second.begin();
            auto itb = maxBids.begin()->second.second.begin();
            double profitQuantity = 0, buyQuantity = 0, sellQuantity = 0;
            while( diff > 0 && ita != minAsks.begin()->second.second.end() && itb != maxBids.begin()->second.second.end() ){
                double buy, sell;
                if(ita->second <= itb->second){
                    buy = ita->second;
                    sell = ita->second - ita->second * comission[nameC];
                }
                else{
                    // se podria hilar ligeramente mas fino
                    buy = itb->second + itb->second * comission[nameC];
                    sell = itb->second;
                }

                profitQuantity += ((itb->first - itb->first * comission[nameV]) - (ita->first + ita->first * comission[nameC])) * buyQuantity;
                ita->second -= buy;
                itb->second -= sell;
                
                if(ita->second * ita->first <= 5)
                    ita++;
                if(itb->second * itb->first <= 5)
                    itb++;
                    
                buyQuantity += buy;
                sellQuantity += sell;
                
                diff = (1 - (  (ita->first + ita->first * comission[nameC]) 
                             / (itb->first - itb->first * comission[nameV]) ) ); 
            }
            
            if( profitQuantity > 0.001 && ((!check && profitQuantity != past) || check )) {
                if(check){
                    c = "2º check ok!";
                    writte_arb(c);
                    totalpq += profitQuantity;
                    int vcsV = ++vecesC[maxBids.begin()->second.first];
                    int vcsC = ++vecesV[minAsks.begin()->second.first];
                    string arb = "PROFIT: " + to_string(profitQuantity) + "$, total: " + to_string(totalpq) + "$, Buy: " + to_string(buyQuantity * minAsks.begin()->first) + "$, [compra en " + nameC + ", veces: " + to_string(vcsC) + "] [venta en " + nameV + ", veces: " + to_string(vcsV) + "]";
                    writte_arb(arb);
                    cout << "\n";
                }
                else{
                    past = profitQuantity;
                    string arb = "PROFIT-simulation: " + to_string(profitQuantity) + "$, Buy: " + to_string(buyQuantity * minAsks.begin()->first) + "$, [compra en " + nameC + "] [venta en " + nameV + "]";
                    writte_arb(arb);
                    
                    iC = nameC;
                    iV = nameV;
                                    cout << (1 - ( minAsks.begin()->first / maxBids.begin()->first )) * 100 << "%" << endl;
                    if(iC == iV) check = true; 
                }
                
                check = !check;
            }
            else{
                if(check){
                    c = "2º check no pasado, se te han adelantado!";
                    writte_arb(c);
                    check = false;
                }
            }
        }
        else{
            if(check){
                c = "1º check no pasado, se te han adelantado! or TOO FAST!";
                writte_arb(c);
                check = false;
            }
        }
        
        if(!check) std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }
    
    for(i = 0; i < n; i++)
        ths[i].join();
}

void vCandidates(vector<bool>& v) {
    v[AAX] = 1;
    v[ASCENDEX] = 1;
    v[BINANCE] = 1;
    v[BITSTAMP] = 0;
    v[BYBIT] = 1;
    v[COINEX] = 1;
    v[CRYPTOCOM] = 0;
    v[EXMO] = 0;
    v[FMFW] = 0;
    v[GATEIO] = 1;
    v[HITBTC] = 0;
    v[HUOBI] = 1;
    v[KUCOIN] = 0;
    v[LBANK] = 0;
    v[MEXC] = 1;
    v[OKX] = 1;
    v[POLONIEX] = 0;
    v[PROBITGLOBAL] = 0;
}

int main() {
    vector<bool> v(MAX_EXCHANGES);
    
    vCandidates(v);
    init("APE-USDT", v, 9);

	return 0;
}
