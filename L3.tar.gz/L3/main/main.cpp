#include <map>
#include "include.h"

#include <chrono>
#include <thread>
#include <future> 


void init(string symbol, vector<bool> v, const int n){  
    int i = 0, cont = 0;
    vector<bool> vD(n, 1);
    ex.resize(n);
    map < string, double > comission;
    map < string, int > index;
    
    ini(comission, index, v);
        
    vector<thread> ths(n);    
    for(int i = 0; i < n; i++) 
        ths[i] = thread (doSomething, i, symbol);

    std::this_thread::sleep_for(std::chrono::milliseconds(13000));
    
    map <string, int> vecesC, vecesV;
    int contWin = 0, contLose = 0;
    double past = 0, totalpq = 0, volume = 0;
    string arb;
    map < string, map <double,double> > depth;
    multimap < double, pair < string, map <double,double> > > minAsks; 
    multimap < double, pair < string, map <double,double,greater<double> > >, greater<double> > maxBids;
    map <double,double,greater<double > > bidsmap;
    while(1){
        string iC, iV;
        minAsks.clear();
        maxBids.clear();

        for(int i = 0; i < n; i++) {
            if(vD[i]) {
                depth = ex[i]->get_socketDepth();
                if(!depth["bids"].empty() && !depth["asks"].empty()) {
                
                    minAsks.insert( pair< double, pair < string, map <double,double> > >(depth["asks"].begin()->first, pair< string, map <double,double> >(ex[i]->get_id(), depth["asks"])) );
                    
                    bidsmap.clear();
                    bidsmap.insert(depth["bids"].begin(), depth["bids"].end());
                    auto it = depth["bids"].end(); --it;
                    maxBids.insert( pair< double, pair < string, map <double,double,greater<double > > > >(it->first, pair < string, map <double,double,greater<double > > >(ex[i]->get_id(), bidsmap)) );
                }
                else{
                    string err = "ERROR: depth[] map is empty! in exchange " + ex[i]->get_id();
                    writte_log(err);
                    vD[i] = 0;
                }
            }
        }
 
        double diff = (1 - (  (minAsks.begin()->first + minAsks.begin()->first * comission[minAsks.begin()->second.first]) 
                            / (maxBids.begin()->first - maxBids.begin()->first * comission[maxBids.begin()->second.first]) ) );
        
        cout << "ASKS:" << endl;
        for(auto ita = minAsks.begin(); ita != minAsks.end(); ++ita)
            cout << ita->first << " in exchange " << ita->second.first << endl;           
        cout << "BIDS:" << endl;
        for(auto itb = maxBids.begin(); itb != maxBids.end(); ++itb)
            cout << itb->first << " in exchange " << itb->second.first << endl;
        
        cout << "diff pair: " << diff << "%" << endl;
        cout << endl;

                            
        iV = maxBids.begin()->second.first;
        iC = minAsks.begin()->second.first;
        // Compare 2 Exchanges, need to compare all Exchanges
        if(diff > 0 && iV != iC) { // && need to consider Exchange's minimum quantity       
            
            auto ita = minAsks.begin()->second.second.begin();
            auto itb = maxBids.begin()->second.second.begin();
            double profitQuantity = 0, totalQuantity = 0;
            while( diff > 0 && ita != minAsks.begin()->second.second.end() && itb != maxBids.begin()->second.second.end() ){
                double quantity;
                if(ita->second <= itb->second)
                    quantity = ita->second;
                else
                    quantity = itb->second;
                
                profitQuantity += ( (itb->first - itb->first * comission[iV]) - (ita->first + ita->first * comission[iC]) ) * quantity;
                ita->second -= quantity;
                itb->second -= quantity;
                
                if(ita->second * ita->first <= 1)
                    ita++;
                if(itb->second * itb->first <= 1)
                    itb++;
                    
                totalQuantity += quantity;
                
                diff = (1 - (  (ita->first + ita->first * comission[iC]) 
                             / (itb->first - itb->first * comission[iV]) ) ); 
            }
            
            if(totalQuantity * minAsks.begin()->second.second.begin()->first > 5 && totalQuantity != past) {
                past = totalQuantity;
                /*arb = "PROFIT-simulation: " + to_string(profitQuantity) + "$, Buy: " + to_string(totalQuantity * minAsks.begin()->first) + "$, [compra en " + iC + "] [venta en " + iV + "]";
                writte_arb(arb);

                diff = (1 - (  (minAsks.begin()->first + minAsks.begin()->first * comission[minAsks.begin()->second.first]) 
                            / (maxBids.begin()->first - maxBids.begin()->first * comission[maxBids.begin()->second.first]) ) );
                arb = "diff pair-simulation: " + to_string(diff) + "%";
                writte_arb(arb);*/
                //Si diff es mayor que 2% stop! si es probitglobal o algo asi tambien
                // Buy
                auto fut = std::async (launch::async, checkFunction, symbol, index[iC]);
                // Sell
                depth = ex[index[iV]]->getget(symbol);
                if(!depth["bids"].empty()) {
                    bidsmap.clear();
                    maxBids.clear();
                    bidsmap.insert(depth["bids"].begin(), depth["bids"].end());
                    auto it = depth["bids"].end(); --it;
                    maxBids.insert( pair< double, pair < string, map <double,double,greater<double > > > >(it->first, pair < string, map <double,double,greater<double > > >(ex[index[iV]]->get_id(), bidsmap)) );
                }
                else{
                    // CORTAR DE RAIZ!! STOP PROGRAM!!
                    string err = "ERROR: depth[] map is empty! try to sell in exchange " + ex[index[iV]]->get_id();
                    writte_log(err);
                }

                minAsks = fut.get();
                diff = (1 - (  (minAsks.begin()->first + minAsks.begin()->first * comission[minAsks.begin()->second.first]) 
                            / (maxBids.begin()->first - maxBids.begin()->first * comission[maxBids.begin()->second.first]) ) );
                arb = "diff pair: " + to_string(diff) + "%";
                writte_arb(arb);
                
                totalQuantity *= 0.9;
                /*while(totalQuantity * minAsks.begin()->first > 500)
                    totalQuantity *= 0.7;
                */
                
                double bPrice = 0, buyQuantity, sellQuantity;
                buyQuantity = sellQuantity = totalQuantity;
                auto itaa = minAsks.begin()->second.second.begin();
                while(buyQuantity > 0){
                    if(itaa->second <= buyQuantity) {
                        buyQuantity -= itaa->second;
                        bPrice += itaa->first * itaa->second;
                        itaa++;
                    }
                    else{
                        bPrice += buyQuantity * itaa->first;
                        buyQuantity = 0;
                    }
                }
                
                double sPrice = 0;
                auto itbb = maxBids.begin()->second.second.begin();
                while(sellQuantity > 0){
                    if(itbb->second <= sellQuantity) {
                        sellQuantity -= itbb->second;
                        sPrice += itbb->first * itbb->second;
                        itbb++;
                    }
                    else{
                        sPrice += sellQuantity * itbb->first;
                        sellQuantity = 0;
                    }
                }
                
                profitQuantity = (sPrice - sPrice * comission[iV]) - (bPrice + bPrice * comission[iC]);
                totalpq += profitQuantity;
                volume += totalQuantity * minAsks.begin()->first;
                int vcsV = ++vecesC[maxBids.begin()->second.first];
                int vcsC = ++vecesV[minAsks.begin()->second.first];
                
                arb = "[Buy in exchange: " + iC + " " + to_string(vcsC) + " times, Sell in exchange: " + iV + " " + to_string(vcsV) + " times]";
                writte_arb(arb);   
                
                if(profitQuantity > 0){ 
                    arb = "PROFIT: ";
                    contWin++;
                }
                else{
                    arb = "LOSS: ";
                    contLose++;
                }
                    
                arb += to_string(profitQuantity) + "$, Buy/Sell: " + to_string(totalQuantity * minAsks.begin()->first) + "$, totalProfit: " + to_string(totalpq) + "$, totalVolume: " + to_string(volume) +  "$ [win: " + to_string(contWin) + ", lose: " + to_string(contLose) + "]\n";
                writte_arb(arb);                
                std::this_thread::sleep_for(std::chrono::milliseconds(2000));
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
    
    for(int i = 0; i < n; i++)
        ths[i].join();
}

int main() {
    vector<bool> v(MAX_EXCHANGES);
    string symbol = symba;
    int num = 0;
    
    if(vCandidates(symbol, v, num))
        init(symbol, v, num);
    else
        cout << "Symbol not supported!" << endl;
    return 0;
}
