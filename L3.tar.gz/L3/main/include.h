
#include "../lib/myappcpp_logger.h"
#include "../lib/myappcpp_utils.h"
#include "md5.h"

#include "../src/exchange.h"
#include "../src/exchanges/aax.h"
#include "../src/exchanges/fAax.h"
#include "../src/exchanges/ascendex.h"
#include "../src/exchanges/fAscendex.h"
#include "../src/exchanges/binance.h"
#include "../src/exchanges/fBinance.h"
#include "../src/exchanges/fBitfinex.h"
#include "../src/exchanges/bitget.h"
#include "../src/exchanges/fBitget.h"
#include "../src/exchanges/bybit.h"
#include "../src/exchanges/fBybit.h"
#include "../src/exchanges/coinex.h"
#include "../src/exchanges/fCoinex.h"
#include "../src/exchanges/cryptocom.h"
#include "../src/exchanges/fCryptocom.h"
#include "../src/exchanges/fDelta.h"
#include "../src/exchanges/exmo.h"
#include "../src/exchanges/fmfw.h"
#include "../src/exchanges/ftx.h"
#include "../src/exchanges/fFtx.h"
#include "../src/exchanges/gateio.h"
#include "../src/exchanges/fGateio.h"
#include "../src/exchanges/hitbtc.h"
#include "../src/exchanges/huobi.h"
#include "../src/exchanges/fHuobi.h"
#include "../src/exchanges/fKraken.h"
#include "../src/exchanges/kucoin.h"
#include "../src/exchanges/fKucoin.h"
#include "../src/exchanges/lbank.h"
#include "../src/exchanges/fMexc.h"
#include "../src/exchanges/nominex.h"
#include "../src/exchanges/okx.h"
#include "../src/exchanges/fOkx.h"
#include "../src/exchanges/poloniex.h"
#include "../src/exchanges/whitebit.h"

#define MAX_EXCHANGES 35

using namespace std;

vector<Exchange*> ex;

string symba = "APE-USDT";

bool vCandidates(string s, vector<bool>& v, int &num){
    ifstream file;
    string cent = "-1", word;
    bool ok = false;
    string s1 = s.substr(0, s.find('-'));
    string s2 = s.substr(s.find('-') + 1, s.length() - 1);
    s2 += ".txt";
    
    file.open (s2);
    if (!file.is_open()) {
        cout << "File couldn't open" << endl;
        return 0;
    }
    
    for(int i = 0; i < MAX_EXCHANGES; i++)
        file >> word;

    while (word != "-1" && !ok) {
        file >> word;
        if(word == s1){
            ok = true;
            for(int i = 0; i < MAX_EXCHANGES; i++){
                file >> word;
                v[i] = stoi(word);
                if(v[i])
                    num++;
            }
        }
        else 
            for(int i = 0; i < MAX_EXCHANGES; i++)
                file >> word;
    }
    
    file.close();
    return ok;
}

void doSomething(int i, string symbol){
    ex[i]->wesbsocketInit_depth(symbol);
}

multimap < double, pair < string, map <double,double> > > checkFunction (string symbol, int indx){
    multimap < double, pair < string, map <double,double> > > minAsks; 
    map < string, map <double,double> > depth = ex[indx]->getget(symbol);
    
    if(!depth["asks"].empty()) {
        minAsks.insert( pair< double, pair < string, map <double,double> > >(depth["asks"].begin()->first, pair< string, map <double,double> >(ex[indx]->get_id(), depth["asks"])) );
    }
    else{
        string err = "ERROR: depth[] map is empty! try to buy in exchange " + ex[indx]->get_id();
        writte_log(err);
    }
    
    return minAsks;
}

void ini(map < string, double >& comission, map < string, int >& index, vector<bool> &v){
    int i = 0, cont = 0;
    
    comission["aax"] = 0.0012;
    if(v[i++]) {
        index["aax"] = cont;
        ex[cont++] = new Aax(0.0012, "aax", "", "");
    }
    comission["fAax"] = 0.00096;
    if(v[i++]) {
        index["fAaax"] = cont;
        ex[cont++] = new fAax(0.00096, "fAax", "", "");
    }
    comission["ascendex"] = 0.001;
    if(v[i++]) {
        index["ascendex"] = cont;
        ex[cont++] = new Ascendex(0.001, "ascendex", "", "");
    }
    comission["fAscendex"] = 0.0012;
    if(v[i++]) {
        index["fAscendex"] = cont;
        ex[cont++] = new fAscendex(0.0012, "fAscendex", "", "");
    }
    comission["binance"] = 0.00075;
    if(v[i++]) {
        index["binance"] = cont;
        ex[cont++] = new Binance(0.00075, "binance", "", "");
    }
    comission["fBinance"] = 0.000414;
    if(v[i++]) {
        index["fBinance"] = cont;
        ex[cont++] = new fBinance(0.000414, "fBinance", "", "");
    }
    comission["fBitfinex"] = 0.00130;
    if(v[i++]) {
        index["fBitifnex"] = cont;
        ex[cont++] = new fBitfinex(0.00130, "fBitfinex", "", "");
    }
    comission["bitget"] = 0.0008;
    if(v[i++]) {
        index["bitget"] = cont;
        ex[cont++] = new Bitget(0.0008, "bitget", "", "");
    }
    comission["fBitget"] = 0.0012;
    if(v[i++]) {
        index["fBitget"] = cont;
        ex[cont++] = new fBitget(0.0012, "fBitget", "", "");
    }
    comission["bybit"] = 0.001;
    if(v[i++]) {
        index["bybit"] = cont;
        ex[cont++] = new Bybit(0.001, "bybit", "", "");
    }
    comission["fBybit"] = 0.0012;
    if(v[i++]) {
        index["fBybit"] = cont;
        ex[cont++] = new fBybit(0.0012, "fBybit", "", "");
    }
    comission["coinex"] = 0.00112;
    if(v[i++]) {
        index["coinex"] = cont;
        ex[cont++] = new Coinex(0.00112, "coinex", "", "");
    }
    comission["fCoinex"] = 0.00088;
    if(v[i++]) {
        index["fCoinex"] = cont;
        ex[cont++] = new fCoinex(0.00088, "fCoinex", "", "");
    }
    comission["cryptocom"] = 0.0032;
    if(v[i++]) {
        index["cryptocom"] = cont;
        ex[cont++] = new Cryptocom(0.0032, "cryptocom", "", "");
    }
    comission["fCryptocom"] = 0.00112;
    if(v[i++]) {
        index["fCryptocom"] = cont;
        ex[cont++] = new fCryptocom(0.00112, "fCryptocom", "", "");
    }
    comission["fDelta"] = 0.001;
    if(v[i++]) {
        index["fDelta"] = cont;
        ex[cont++] = new fDelta(0.001, "fDelta", "", "");
    }
    comission["exmo"] = 0.0003;
    if(v[i++]) {
        index["exmo"] = cont;
        ex[cont++] = new Exmo(0.0003, "exmo", "", "");
    }
    comission["fmfw"] = 0.005;
    if(v[i++]) {
        index["fmfw"] = cont;
        ex[cont++] = new Fmfw(0.005, "fmfw", "", "");
    }
    comission["ftx"] = 0.000595;
    if(v[i++]) {
        index["ftx"] = cont;
        ex[cont++] = new Ftx(0.000595, "ftx", "", "");
    }
    comission["fFtx"] = 0.000595;
    if(v[i++]) {
        index["fFtx"] = cont;
        ex[cont++] = new fFtx(0.000595, "fFtx", "", "");
    }
    comission["gateio"] = 0.0006;
    if(v[i++]) {
        index["gateio"] = cont;
        ex[cont++] = new Gateio(0.0006, "gateio", "", "");
    }
    comission["fGateio"] = 0.0008;
    if(v[i++]) {
        index["fGateio"] = cont;
        ex[cont++] = new fGateio(0.0008, "fGateio", "", "");
    }
    comission["hitbtc"] = 0.002;
    if(v[i++]) {
        index["hitbtc"] = cont;
        ex[cont++] = new Hitbtc(0.002, "hitbtc", "", "");
    }
    comission["huobi"] = 0.0009;
    if(v[i++]) {
        index["huobi"] = cont;
        ex[cont++] = new Huobi(0.0009, "huobi", "", "");
    }
    comission["fHuobi"] = 0.0006;
    if(v[i++]) {
        index["fHuobi"] = cont;
        ex[cont++] = new fHuobi(0.0006, "fHuobi", "", "");
    }
    comission["fKraken"] = 0.001;
    if(v[i++]) {
        index["fKraken"] = cont;
        ex[cont++] = new fKraken(0.001, "fKraken", "", "");
    }
    comission["kucoin"] = 0.0008;
    if(v[i++]) {
        index["kucoin"] = cont;
        ex[cont++] = new Kucoin(0.0008, "kucoin", "", "");
    }
    comission["fKucoin"] = 0.0012;
    if(v[i++]) {
        index["fKucoin"] = cont;
        ex[cont++] = new fKucoin(0.0012, "fKucoin", "", "");
    }
    comission["lbank"] = 0.001;
    if(v[i++]) {
        index["lbank"] = cont;
        ex[cont++] = new Lbank(0.001, "lbank", "", "");
    }
    comission["fMexc"] = 0.0012;
    if(v[i++]) {
        index["fMexc"] = cont;
        ex[cont++] = new fMexc(0.0012, "fMexc", "", "");
    }
    comission["nominex"] = 0.0005;
    if(v[i++]) {
        index["nominex"] = cont;
        ex[cont++] = new Nominex(0.0005, "nominex", "", "");
    }
    comission["okx"] = 0.0006;
    if(v[i++]) {
        index["okx"] = cont;
        ex[cont++] = new Okx(0.0006, "okx", "", "");
    }
    comission["fOkx"] = 0.0006;
    if(v[i++]) {
        index["fOkx"] = cont;
        ex[cont++] = new fOkx(0.0006, "fOkx", "", "");
    }
    comission["poloniex"] = 0.000875;
    if(v[i++]) {
        index["poloniex"] = cont;
        ex[cont++] = new Poloniex(0.000875, "poloniex", "", "");
    }
    comission["whitebit"] = 0.001;
    if(v[i++]) {
        index["whitebit"] = cont;
        ex[cont++] = new Whitebit(0.001, "whitebit", "", "");
    }
}
