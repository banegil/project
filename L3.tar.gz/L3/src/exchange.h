
#ifndef EXCHANGE_H
#define EXCHANGE_H


#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <mutex>
#include <vector>
#include <ctime>
#include <exception>
#include <algorithm>

#include <ctype.h>
#include <curl/curl.h>
#include <json/json.h>

#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <boost/beast.hpp>
#include <boost/beast/ssl.hpp>

namespace net       = boost::asio;
namespace ssl       = net::ssl;
namespace beast     = boost::beast;
namespace http      = beast::http;
namespace websocket = beast::websocket;

using tcp      = net::ip::tcp;
using Request  = http::request<http::string_body>;
using Stream   = beast::ssl_stream<beast::tcp_stream>;
using Response = http::response<http::dynamic_body>;

#define TIME_REFRESH 10

using namespace std;

class Exchange {

    double fee;
    string id;
	string api_key;
	string secret_key;
	CURL* curl;

    // HTTP REQUEST SET //
    net::io_context ioc;
    ssl::context    ctx{ssl::context::tlsv12_client};
    tcp::resolver   resolver{ioc};
    Stream          stream{ioc, ctx};

    // WEB SOCKET SET //
    std::string        m_web_socket_host;
    std::string        m_web_socket_port;
    beast::flat_buffer buffer;
    net::io_context    ioc_webSocket;
    ssl::context       ctx_webSocket{ssl::context::tlsv12_client};
    tcp::resolver      resolver_webSocket{ioc_webSocket};
    websocket::stream<beast::ssl_stream<tcp::socket>> ws{ioc_webSocket,
                                                         ctx_webSocket};
	
	public:
    Exchange(const double& fee, const string& id, const string& api_key, const string& secret_key) :  fee(fee), id(id), api_key(api_key), secret_key(secret_key)
    {
        curl_global_init(CURL_GLOBAL_DEFAULT);
	    curl = curl_easy_init();
    }
    //---------------------------------

    void 
    get_curl( 
        string& url, 
	    Json::Value &json_result ) 
    {	
	    string str_result;
	    curl_api( url, str_result ) ;

	    if ( str_result.size() > 0 ) {
		    
		    try {
			    Json::Reader reader;
			    json_result.clear();	
	        		reader.parse( str_result , json_result );
	        		
		    } catch ( exception &e ) {
                string err = url + e.what();
		     	writte_log( "ERROR: <get_curl> exchange.h: " + err ); 
		    }   
	    
	    } else {
	        writte_log( "ERROR: <get_curl> exchange.h: " + url );
	    }
    }
    
    void 
    post_curl( 
        string& url, 
	    Json::Value &json_result , 
	    const string& post )
    {	
        vector <string> v;
	    string str_result, s=post, p="POST";
	    curl_api_with_header( url , str_result , v, s , p );

	    if ( str_result.size() > 0 ) {
		    
		    try {
			    Json::Reader reader;
			    json_result.clear();	
	        		reader.parse( str_result , json_result );
	        		
		    } catch ( exception &e ) {
                string err = url + e.what();
		     	writte_log( "ERROR: <get_curl> exchange.h: " + err ); 
		    }   
	    
	    } else {
	        writte_log( "ERROR: <post_curl> exchange.h: " + url );
	    }
    }

    string get_id(){
        return id;
    }
    
    virtual void curl_depth(string symbol) {}
    
    virtual void wesbsocketInit_depth(string symbol) {}
    
    virtual map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > m;
        return m;
    }
    
    virtual void send_order( string symbol, string side, double quantity, double price ) {}
    
    virtual void withdraw( string symbol, string address, double amount, string network ){}
    
    virtual map < string, map <double,double> > getget( string symbol ) {
        map < string, map <double,double> > m;
        return m;
    }
    
   virtual long getServerTime(){
        long d;
        return d;
   }

/***************************       CURL        ***************************/
    static size_t 
    curl_cb( void *content, size_t size, size_t nmemb, std::string *buffer ) 
    {	
	    buffer->append((char*)content, size*nmemb);
	    return size*nmemb;
    }

    void 
    curl_api( string &url, string &result_json ) {
	    vector <string> v;
	    string action = "GET";
	    string post_data = "";
	    curl_api_with_header( url , result_json , v, post_data , action );	
    } 

    void 
    curl_api_with_header( string &url, string &str_result, vector <string> &extra_http_header , string &post_data , string &action ) 
    {
	    CURLcode res;

	    if( curl ) {

		    curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
		    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
		    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );
		    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
		    curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");

		    if ( extra_http_header.size() > 0 ) {
			    
			    struct curl_slist *chunk = NULL;
			    for ( int i = 0 ; i < extra_http_header.size() ;i++ ) {
				    chunk = curl_slist_append(chunk, extra_http_header[i].c_str() );
			    }
			    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, chunk);
		    }

		    if ( post_data.size() > 0 || action == "POST" || action == "PUT" || action == "DELETE" ) {

			    if ( action == "PUT" || action == "DELETE" ) {
				    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, action.c_str() );
			    }
			    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data.c_str() );
     		}

		    res = curl_easy_perform(curl);

		    /* Check for errors */ 
		    if ( res != CURLE_OK ) {
		        string err = curl_easy_strerror(res) ;
			    writte_log( "ERROR: <curl_api_with_header> curl_easy_perform() failed: " + err ) ;
		    } 	
	    }
	 }

/***************************       CURL        ***************************/
    
 

/***************************     WEBSOCKET     ***************************/
    void init_http(std::string const& host)
    {
        const auto results{resolver.resolve(host, "443")};
        get_lowest_layer(stream).connect(results);
        // Set SNI Hostname (many hosts need this to handshake successfully)
        if (!SSL_set_tlsext_host_name(stream.native_handle(), host.c_str())) {
            boost::system::error_code ec{
                static_cast<int>(::ERR_get_error()),
                boost::asio::error::get_ssl_category()};
            throw boost::system::system_error{ec};
        }
        stream.handshake(ssl::stream_base::client);
    }

    void init_webSocket(std::string const& host, std::string const& port,
                        const char* p = "")
    {
        // Set SNI Hostname (many hosts need this to handshake successfully)
        if (!SSL_set_tlsext_host_name(ws.next_layer().native_handle(),
                                      host.c_str()))
            throw beast::system_error(
                beast::error_code(static_cast<int>(::ERR_get_error()),
                                  net::error::get_ssl_category()),
                "Failed to set SNI Hostname");
        //tcp::resolver::query query(host, PORT, boost::asio::ip::resolver_query_base::numeric_service);
        auto const results = resolver_webSocket.resolve(host, port); // sustituir (host, port) -> query
        net::connect(ws.next_layer().next_layer(), results.begin(),
                     results.end());
        ws.next_layer().handshake(ssl::stream_base::client);

        ws.handshake(host, p);
    }

    void read_Socket() { ws.read(buffer); }

    bool is_socket_open()
    {
        if (ws.is_open())
            return true;
        return false;
    }

    void write_Socket(const std::string& text) { ws.write(net::buffer(text)); }
    
    std::string get_socket_data()
    {
        return beast::buffers_to_string(buffer.data());
    }
    void buffer_clear() { buffer.clear(); }

    void webSocket_close() { ws.close(websocket::close_code::none); }
/***************************     WEBSOCKET     ***************************/
};


#endif
