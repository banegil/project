
#include "exchangeP.h"
#include "myappcpp_logger.h"
#include <chrono>

class Aax: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;

    
    public:
    Aax(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.aax.com/v2/market/orderbook?symbol=" + symbol + "FP&level=50";
        get_curl(s, result);
     	
     	if(result.isMember("asks")){	
	        for ( int i = 0 ; i < result["asks"].size(); i++ ) {
		        double price = atof( result["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["asks"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
		        double price = atof( result["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["bids"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Aax: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){ 
        time_t current_time; 
        init_http("realtime.aax.com");
        depth = curl_depth(symbol);
        
        try {
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            string s = "/marketdata/v2/" + symbol + "@book_50";
            init_webSocket("realtime.aax.com", "443", s.c_str());
            Json::Reader reader;
	        Json::Value result;
	        for(int i = 0; i < 2; i++){
	            read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
            }

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
	            Json::Value result;
                read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
                
                mtxDepth.lock();
                
             	if(result.isMember("asks")){	
             	
                 	if(ct2 - ct >= 70){
                        ct = ct2;
                        depth.clear();
                    }
             	
                    for ( int i = 0 ; i < result["asks"].size(); i++ ) {
	                    double price = atof( result["asks"][i][0].asString().c_str() );
	                    double qty   = atof( result["asks"][i][1].asString().c_str() );
	                    if ( qty == 0.0 ) 
	                        depth["asks"].erase(price);
                        else 
	                        depth["asks"][price] = qty;
                    }
                    for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
	                    double price = atof( result["bids"][i][0].asString().c_str() );
	                    double qty   = atof( result["bids"][i][1].asString().c_str() );
	                    if ( qty == 0.0 ) 
	                        depth["bids"].erase(price);
                        else 
	                        depth["bids"][price] = qty;
                    }
                }
                else
                    writte_log( "ERROR: <wss_depth> Aax: " + symbol );
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
	         	writte_log( err ); 
            return;
          }
    }
   
    void send_order( string symbol, string side, double price, double quantity ) {	
        Json::Value json_result;
        string err;

        if ( api_key.size() == 0 || secret_key.size() == 0 ) {
            err = "Aax: <send_order> API Key and Secret Key has not been set";
            writte_log(err);
            return ;
        }

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url("https://api.aax.com/v2/spot/orders?");
        string action = "POST";
        
        string post_data("orderType=MARKET");
        post_data.append("&symbol=");
        post_data.append( symbol );
        post_data.append("&orderQty=");
        post_data.append( quantity );
        post_data.append("&side=");
        post_data.append( side );
        post_data.append("&clOrdID=aax");
        
        string signature =  hmac_sha256( secret_key.c_str(), post_data.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk("X-ACCESS-NONCE: ");
        header_chunk.append( to_string( get_current_ms_epoch() ) );
        extra_http_header.push_back(header_chunk);
        header_chunk = "X-ACCESS-KEY: ");
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "X-ACCESS-SIGN: ";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Aax: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Aax: order.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};

int main(){
    string g = "", m="", id = "";
    double q = 0;
    Aax e(q, id, g, m);
    string symbol = "ETH-USDT";
    string side = "BUY";
    double quantity = 0.5; 
    e.send_order( symbol, side, quantity ); 
}
