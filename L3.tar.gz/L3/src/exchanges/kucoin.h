


class Kucoin: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "622788ead6e69d00019242dc";
    string secret_key = "1d592ee9-7f85-452a-ac45-e61e3985f11e";
    
    public:
    Kucoin(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        string s = "https://api.kucoin.com/api/v1/market/orderbook/level2_20?symbol=" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
            
            mtxDepth.lock();

            depth.clear(); 
            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	            double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	            double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	            
            mtxDepth.unlock();
        
      } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time;
        int pingInterval;
        string token, endpoints;
        string idC = "154591120590801";
        string s = "https://api.kucoin.com/api/v1/bullet-public";
        Json::Value result;
        post_curl(s, result, "");
        endpoints = result["data"]["instanceServers"][0]["endpoint"].asString();
        string endpoint = endpoints.substr(6,17);
        token = result["data"]["token"].asString();
        pingInterval = result["data"]["instanceServers"][0]["pingInterval"].asUInt64();
        pingInterval /= 1000;
        init_http(endpoint);
        string symbol2 = symbol;

        try {
            s = "/endpoint?token=" + token + "&[connectId=" + idC + "]";
            init_webSocket(endpoint, "443", s.c_str());
            Json::Reader reader;
		    Json::Value json_result;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();
            write_Socket(R"({"id":"154591120590801","type":"ping"})");
            s = "{\"id\": 154591120590801,\"type\": \"subscribe\",\"topic\": \"/spotMarket/level2Depth50:" + symbol + "\",\"response\": true}";
            write_Socket(s);
            s = "{\"id\": 154591120590801,\"type\": \"subscribe\",\"topic\": \"/market/ticker:" + symbol + "\",\"response\": true}";
            write_Socket(s);
            
            time(&current_time);
            int ct = current_time;
            int ct3 = ct;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                int ct4 = ct2;
                if(ct2 - ct >= pingInterval - 2){
                    ct = ct2;
                    write_Socket(R"({"id":"154591120590801","type":"ping"})");
                }
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
			    reader.parse( get_socket_data() , json_result );
                buffer_clear();

                mtxDepth.lock();
                
                if(ct4 - ct3 > TIME_REFRESH + 5){
                    ct3 = ct4;
                    depth.clear();
                }
                
                if(json_result.isMember("data")){
                    if(json_result["subject"].asString() == "level2"){                  
                        
                        for ( int i = 0 ; i < json_result["data"]["bids"].size() ; i++ ) {
                            double price = atof( json_result["data"]["bids"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["data"]["bids"][i][1].asString().c_str());
                            if ( qty == 0.0 ) 
                                depth["bids"].erase(price);
                            else 
                                depth["bids"][price] = qty;
                        }
                        for ( int i = 0 ; i < json_result["data"]["asks"].size() ; i++ ) {
                            double price = atof( json_result["data"]["asks"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["data"]["asks"][i][1].asString().c_str());
                            if ( qty == 0.0 ) 
                                depth["asks"].erase(price);
                            else 
                                depth["asks"][price] = qty;
                        }
                    }
                    else if(json_result["subject"].asString() == "trade.ticker"){
                            double price = atof( json_result["data"]["bestBid"].asString().c_str());
                            double qty 	 = atof( json_result["data"]["bestBidSize"].asString().c_str());
                            if ( qty == 0.0 ) 
                                depth["bids"].erase(price);
                            else 
                                depth["bids"][price] = qty;
                            
                            price = atof( json_result["data"]["bestAsk"].asString().c_str());
                            qty 	 = atof( json_result["data"]["bestAskSize"].asString().c_str());
                            if ( qty == 0.0 ) 
                                depth["asks"].erase(price);
                            else 
                                depth["asks"][price] = qty;
                    }
                 }
                 else if(!(json_result["type"].asString() == "pong" || json_result["type"].asString() == "ack"))
                    throw exception();  
	             
	             mtxDepth.unlock();	
                    
            }
            webSocket_close();

        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		     	//cout << json_result << endl;
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        Json::Value json_result;
        string err;

        string ep = to_string (get_current_ms_epoch());

        string url("https://api.kucoin.com/api/v1/orders");
        string action = "POST";
        
        string post_data = "{\"clientOid\":\"154591120590801\",\"side\":\"" + side + "\",\"symbol\":\"" + symbol + "\",\"type\":\"market\",\"size\":\"" + to_string(quantity) + "\"}";
        string msg = ep + action + "/api/v1/orders" + post_data;
        string ph = "tradingKucoin";
        
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        string phrase = hmac_sha256h( secret_key.c_str(), ph.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk = "KC-API-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-TIMESTAMP:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk="KC-API-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-PASSPHRASE:";
        header_chunk.append( phrase );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-KEY-VERSION:2";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Kucoin: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Kucoin: order.size() is 0";
            writte_log(err);
        }
   }
   
    void withdraw( string coin, string address, double amount, string network ) {	
        Json::Value json_result;
        string err;

        string ep = to_string (get_current_ms_epoch());

        string url("https://api.kucoin.com/api/v1/withdrawals");
        string action = "POST";
        
        string post_data = "{\"currency\":\"" + coin + "\",\"address\":\"" + address + "\",\"symbol\":" + to_string(amount) + "}";
        string msg = ep + action + "/api/v1/withdrawals" + post_data;
        string ph = "tradingKucoin";
        
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        string phrase = hmac_sha256h( secret_key.c_str(), ph.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk = "KC-API-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-TIMESTAMP:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk="KC-API-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-PASSPHRASE:";
        header_chunk.append( phrase );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-KEY-VERSION:2";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Kucoin: error reading withdraw response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Kucoin: withdraw.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
