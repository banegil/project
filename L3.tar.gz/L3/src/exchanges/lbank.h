#include <openssl/hmac.h>
#include <openssl/sha.h>


class Lbank: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "87d08852-98bd-490e-ab38-f8d8afce1ac3";
    string secret_key = "11ACA61802F75327A762CB2C99550AD6";
    
    public:
    Lbank(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol[symbol.find('-')] = '_';
        transform(symbol.begin(), symbol.end(), symbol.begin(),
        [](unsigned char c){ return tolower(c); });
        string s = "https://api.lbkex.com/v2/depth.do?symbol=" + symbol + "&size=20";
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	
         	mtxDepth.lock();
         	
         	depth.clear(); 
            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	            double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	            double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	        
            mtxDepth.unlock();
        
      } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time;
        Json::Reader reader;
	    Json::Value json_result;
        string j = "1";
        curl_depth(symbol);
        init_http("www.lbkex.net");
        
        try {
            string symbol2 = symbol;
            symbol[symbol.find('-')] = '_';
            transform(symbol.begin(), symbol.end(), symbol.begin(),
            [](unsigned char c){ return tolower(c); });
            init_webSocket("www.lbkex.net", "443", "/ws/V2/");
            string s = "{\"action\":\"subscribe\",\"subscribe\":\"depth\",\"depth\":\"100\",\"pair\":\"" + symbol + "\"}";
            write_Socket(s);
            
            time(&current_time);
            int ct = current_time;
            int ct3 = ct;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                int ct4 = ct2;
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                if(ct4 - ct3 > 30){
                    ct3 = ct4;
                    if(j != "1"){
                        s = "{\"action\":\"pong\",\"pong\":\"" + j + "\"}";
                        write_Socket(s);
                    }
                }
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (launch::async, &Lbank::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();

                if(json_result.isMember("depth")){
                    for ( int i = 0 ; i < json_result["depth"]["asks"].size() ; i++ ) {
                        double price = atof( json_result["depth"]["asks"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["depth"]["asks"][i][1].asString().c_str());
                        if ( qty == 0.0 ) {
                            depth["asks"].erase(price);
                        } else {
                            depth["asks"][price] = qty;
                        }
                    }
                    for ( int i = 0 ; i < json_result["depth"]["bids"].size() ; i++ ) {
                        double price = atof( json_result["depth"]["bids"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["depth"]["bids"][i][1].asString().c_str());
                        if ( qty == 0.0 ) {
                            depth["bids"].erase(price);
                        } else {
                            depth["bids"][price] = qty;
                        }
                    }
                }
                else if(json_result.isMember("ping")){
                    j = json_result["ping"].asString();
                    s = "{\"action\":\"pong\",\"pong\":\"" + j + "\"}";
                    write_Socket(s);
                }
                else 
                    throw exception();

                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		     	cout << json_result << endl;
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        Json::Value json_result;
        string err;
        string ep = to_string (get_current_ms_epoch());
        symbol[symbol.find('-')] = '_';
        transform(symbol.begin(), symbol.end(), symbol.begin(),
        [](unsigned char c){ return tolower(c); });
        
        // test: /create_order_test.do
        string url("https://api.lbkex.com/v2/supplement/create_order.do?");
        string action = "POST";
        
        string msg1 = "amount=" + to_string(quantity) + "&api_key=" + api_key + "&echostr=P3LHfw6tUIYWc8R2VQNy0ilKmdg5pjhbxC7&price=" + to_string(price) + "&signature_method=HmacSHA256&symbol=" + symbol + "t&timestamp=" +  ep + "&type=" + side;
        string msg = md5(msg1);
        string_toupper(msg);
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        string post_data = "amount=" + to_string(quantity) + "&api_key=" + api_key + "&echostr=P3LHfw6tUIYWc8R2VQNy0ilKmdg5pjhbxC7&price=" + to_string(price) + "&sign=" + signature + "&signature_method=HmacSHA256&symbol=" + symbol + "&timestamp=" +  ep + "&type=buy";

        vector <string> extra_http_header;
        string header_chunk="contentType:application/x-www-form-urlencoded";
        extra_http_header.push_back(header_chunk);
        header_chunk="timestamp:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "signature_method:HmacSHA256";
        extra_http_header.push_back(header_chunk);
        header_chunk = "echostr:P3LHfw6tUIYWc8R2VQNy0ilKmdg5pjhbxC7";
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Lbank: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Lbank: order.size() is 0";
            writte_log(err);
        }
   }
   
    void withdraw( string coin, string address, double amount, string network ) {	
        Json::Value json_result;
        string err;
        string ep = to_string (get_current_ms_epoch());

        string url("https://api.lbkex.com/v2/supplement/withdraw.do?");
        string action = "POST";
        
        string msg1 = "address=" + address + "&amount=" + to_string(amount) + "&api_key=" + api_key + "&coin=" + coin + "&echostr=P3LHfw6tUIYWc8R2VQNy0ilKmdg5pjhbxC7&fee=0.01&signature_method=HmacSHA256&timestamp=" +  ep;
        string msg = md5(msg1);
        string_toupper(msg);
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        string post_data = "address=" + address + "&amount=" + to_string(amount) + "&api_key=" + api_key + "&coin=" + coin + "&echostr=P3LHfw6tUIYWc8R2VQNy0ilKmdg5pjhbxC7&fee=0.01&sign=" + signature + "&signature_method=HmacSHA256&timestamp=" +  ep;

        vector <string> extra_http_header;
        string header_chunk="contentType:application/x-www-form-urlencoded";
        extra_http_header.push_back(header_chunk);
        header_chunk="timestamp:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "signature_method:HmacSHA256";
        extra_http_header.push_back(header_chunk);
        header_chunk = "echostr:P3LHfw6tUIYWc8R2VQNy0ilKmdg5pjhbxC7";
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Lbank: error reading withdraw response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Lbank: withdraw.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
