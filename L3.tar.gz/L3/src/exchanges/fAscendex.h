

class fAscendex: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "qdB0DS6HQfSHvD5pa46MVR85hD1RhYDj";
    string secret_key = "WXfHJkkNMovwJkftXnijTuF8FuwB8ecfQ9cCiJVCIQCa4uzjYwMkIH4hAdVEbgSL";
    
    public:
    fAscendex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        init_http("ascendex.com");
        pair<double,double> a, b;
        long ts = 0;
        
        try {
            string symbol2 = symbol;
            symbol = symbol.substr(0, symbol.find('-'));
            init_webSocket("ascendex.com", "443", "/api/pro/v2/stream");
            string s = "{ \"op\": \"sub\",\"ch\":\"depth:" + symbol + "-PERP\" }";
            write_Socket(s);
            s = "{ \"op\": \"sub\",\"ch\":\"bbo:" + symbol + "-PERP\" }";
            write_Socket(s);
            Json::Reader reader;
            Json::Value result;
		    for(int i = 0; i < 3; i++){
		        read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
		    }

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
                Json::Value result;
                read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
                

                if(ct2 - ct > TIME_REFRESH + 5 && (result["data"]["asks"].size() > 0 || result["data"]["bids"].size() > 0)){ 
                    ct = ct2;
                    depth.clear();
                }
        
                mtxDepth.lock();

                if(result["m"].asString() == "bbo" && result["data"]["ts"].asInt64()){
                    ts = result["data"]["ts"].asInt64();
        	        double price = atof( result["data"]["ask"][0].asString().c_str() );
                    double qty   = atof( result["data"]["ask"][1].asString().c_str() );
                    
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                    price = atof( result["data"]["bid"][0].asString().c_str() );
                    qty   = atof( result["data"]["bid"][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }                
                else if(result["m"].asString() == "depth"){	
                    
                    for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
                        double price = atof( result["data"]["asks"][i][0].asString().c_str() );
                        double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
                    }
                    for ( int i = 0 ; i < result["data"]["bids"].size(); i++ ) {
                        double price = atof( result["data"]["bids"][i][0].asString().c_str() );
                        double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
                    }
                    
                    if(result["data"]["ts"].asInt64() <= ts){
                        depth["asks"][a.first] = a.second;
                        depth["bids"][b.first] = b.second;
                    }
                    ts = result["data"]["ts"].asInt64();
                }
                else if(result["m"].asString() == "ping")
                    write_Socket(R"({ "op": "pong" })");   
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		        //cout << result << '\n'; 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
