


class fKucoin: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "622788ead6e69d00019242dc";
    string secret_key = "1d592ee9-7f85-452a-ac45-e61e3985f11e";
    
    public:
    fKucoin(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    void wesbsocketInit_depth(string symbol){
        time_t current_time;
        int pingInterval;
        string token, endpoints;
        string idC = "154591120590802";
        string s = "https://api-futures.kucoin.com/api/v1/bullet-public";
        Json::Value result;
        post_curl(s, result, "");
        endpoints = result["data"]["instanceServers"][0]["endpoint"].asString();
        string endpoint = endpoints.substr(6,17);
        token = result["data"]["token"].asString();
        pingInterval = result["data"]["instanceServers"][0]["pingInterval"].asUInt64();
        pingInterval /= 1000;
        init_http(endpoint);
        string symbol2 = symbol;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        symbol.erase(symbol.size() - 1);

        try {
            s = "/endpoint?token=" + token + "&[connectId=" + idC + "]";
            init_webSocket(endpoint, "443", s.c_str());
            Json::Reader reader;
		    Json::Value json_result;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();
            write_Socket(R"({"id":"154591120590802","type":"ping"})");
            s = "{\"id\": 154591120590802,\"type\": \"subscribe\",\"topic\": \"/contractMarket/level2Depth50:" + symbol + "M\",\"response\": true}";
            write_Socket(s);
            s = "{\"id\": 154591120590802,\"type\": \"subscribe\",\"topic\": \"/contractMarket/tickerV2:" + symbol + "M\",\"response\": true}";
            write_Socket(s);
            
            time(&current_time);
            int ct = current_time;
            int ct3 = ct;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                int ct4 = ct2;
                if(ct2 - ct >= pingInterval - 2){
                    ct = ct2;
                    write_Socket(R"({"id":"154591120590802","type":"ping"})");
                }
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
			    reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                mtxDepth.lock();
                
                if(ct4 - ct3 > TIME_REFRESH + 5){
                    ct3 = ct4;
                    depth.clear();
                }
                
                if(json_result.isMember("data")){
                    if(json_result["subject"].asString() == "level2"){                  
                        
                        for ( int i = 0 ; i < json_result["data"]["bids"].size() ; i++ ) {
                            double price = atof( json_result["data"]["bids"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["data"]["bids"][i][1].asString().c_str());
                            if ( qty == 0.0 ) 
                                depth["bids"].erase(price);
                            else 
                                depth["bids"][price] = qty;
                        }
                        for ( int i = 0 ; i < json_result["data"]["asks"].size() ; i++ ) {
                            double price = atof( json_result["data"]["asks"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["data"]["asks"][i][1].asString().c_str());
                            if ( qty == 0.0 ) 
                                depth["asks"].erase(price);
                            else 
                                depth["asks"][price] = qty;
                        }
                    }
                    else if(json_result["subject"].asString() == "tickerV2"){
                            double price = atof( json_result["data"]["bestBidPrice"].asString().c_str());
                            double qty 	 = atof( json_result["data"]["bestBidSize"].asString().c_str());
                            if ( qty == 0.0 ) 
                                depth["bids"].erase(price);
                            else 
                                depth["bids"][price] = qty;
                            
                            price = atof( json_result["data"]["bestAskPrice"].asString().c_str());
                            qty 	 = atof( json_result["data"]["bestAskSize"].asString().c_str());
                            if ( qty == 0.0 ) 
                                depth["asks"].erase(price);
                            else 
                                depth["asks"][price] = qty;
                    }
                 }
                 else if(!(json_result["type"].asString() == "pong" || json_result["type"].asString() == "ack"))
                    throw exception(); 
	             
	             mtxDepth.unlock();	
                    
            }
            webSocket_close();

        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		     	//cout << json_result << endl;
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
