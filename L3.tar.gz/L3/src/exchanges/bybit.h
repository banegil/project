

class Bybit: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "yAMi0Oz7Os5Wtiv0or";
    string secret_key = "t9nU58iFZz4l1Vo5SSe2PSGHia8TkOJl4gyA";
    
    public:
    Bybit(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.bybit.com/spot/quote/v1/depth?symbol=" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();

            mtxDepth.lock(); 
         	
         	depth.clear(); 
     		for  ( int i = 0 ; i < result["result"]["bids"].size() ; i++ ) {
	            double price = atof( result["result"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["result"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
            for ( int i = 0 ; i < result["result"]["asks"].size() ; i++ ) {
	            double price = atof( result["result"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["result"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }

            mtxDepth.unlock();
        
        } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){  
        curl_depth(symbol);
        time_t current_time;
        init_http("stream.bybit.com");
        string symbol2 = symbol;
        
        try {
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            init_webSocket("stream.bybit.com", "443", "/spot/quote/ws/v2");
            string s = "{\"topic\": \"depth\",\"event\": \"sub\",\"params\": {\"symbol\": \"" + symbol + "\",\"binary\": false}}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
            read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();

            time(&current_time);
            int ct = current_time;
            int ct3 = ct;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                int ct4 = ct2;
                Json::Reader reader;
		        Json::Value json_result;
                if(ct2 - ct >= 25){
                    ct = ct2;
                    write_Socket(R"({"op":"ping"})");
                }
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                if(ct4 - ct3 > TIME_REFRESH){ 
                    ct3 = ct4;
                    std::async (launch::async, &Bybit::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();
                
             	if(json_result.isMember("data") && (json_result["data"].isMember("b") || json_result["data"].isMember("a"))){	
             	        
             		for  ( int i = 0 ; i < json_result["data"]["b"].size() ; i++ ) {
                        double price = atof( json_result["data"]["b"][i][0].asString().c_str() );
                        double qty   = atof( json_result["data"]["b"][i][1].asString().c_str() );
                        depth["bids"][price] = qty;
                    }
                    for ( int i = 0 ; i < json_result["data"]["a"].size() ; i++ ) {
                        double price = atof( json_result["data"]["a"][i][0].asString().c_str() );
                        double qty   = atof( json_result["data"]["a"][i][1].asString().c_str() );
                        depth["asks"][price] = qty;
                    }
                }               
                else if (!json_result.isMember("pong"))
                    throw exception();
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		     	//cout << json_result << '\n';
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        Json::Value json_result;
        string err;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string ep = to_string (get_current_ms_epoch());

        string url("https://api.bybit.com/spot/v1/order?");
        string action = "POST";
        
        string_toupper(side);
        string msg = "api_key=" + api_key + "&qty=" + to_string(quantity) + "&side=" + side + "&symbol=" + symbol + "&timestamp=" + ep + "&type=MARKET";
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        string post_data = msg + "&sign=" + signature;
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/x-www-form-urlencoded";
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Bybit: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Bybit: order.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
