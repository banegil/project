

class Exmo: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "K-ab80ba7836b5e2bce25df5f3391abfa60749f077";
    string secret_key = "S-f26af48636a96b658e696c097db8c39203ab9341";
    
    public:
    Exmo(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol[symbol.find('-')] = '_';
        string s = "pair=" + symbol + "&limit=100";
        string s2 = "https://api.exmo.com/v1.1/order_book";
        mtxCurl.lock();
        post_curl(s2, result, s);
        mtxCurl.unlock();
     	
     	mtxDepth.lock();
     	
     	depth.clear(); 
     	if(result.isMember(symbol) && result[symbol].isMember("ask")){	
	        for ( int i = 0 ; i < result[symbol]["ask"].size(); i++ ) {
		        double price = atof( result[symbol]["ask"][i][0].asString().c_str() );
		        double qty   = atof( result[symbol]["ask"][i][1].asString().c_str() );
		        depth["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result[symbol]["bid"].size() ; i++ ) {
		        double price = atof( result[symbol]["bid"][i][0].asString().c_str() );
		        double qty   = atof( result[symbol]["bid"][i][1].asString().c_str() );
		        depth["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Exmo: " + symbol );
	    
        mtxDepth.unlock();
    }
    
    void wesbsocketInit_depth(string symbol){ 
        time_t current_time;  
        init_http("ws-api.exmo.com");
        int timestamp = 0;
                
        try {
            string symbol2 = symbol;
            init_webSocket("ws-api.exmo.com", "443", "/v1/public");
            symbol[symbol.find('-')] = '_';
            string s = "{\"id\": 1, \"method\": \"subscribe\",\"topics\": [\"spot/order_book_updates:" + symbol + "\"]}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;
		    for(int i = 0; i < 2; i++){
		        read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
		    }

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&Exmo::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();

             	if(result.isMember("ts")){	
             	    int ts = json_result["ts"].asUInt64();
             	    if(ts > timestamp){
             	        timestamp = ts;
             	        
                 	    if(result["data"].isMember("ask")){
                            for ( int i = 0 ; i < result["data"]["ask"].size(); i++ ) {
	                            double price = atof( result["data"]["ask"][i][0].asString().c_str() );
	                            double qty   = atof( result["data"]["ask"][i][1].asString().c_str() );
                                if ( qty == 0.0 ) 
                                    depth["asks"].erase(price);
                                else 
                                    depth["asks"][price] = qty;
                            }
                        }
                        if(result["data"].isMember("bid")){
                            for  ( int i = 0 ; i < result["data"]["bid"].size() ; i++ ) {
	                            double price = atof( result["data"]["bid"][i][0].asString().c_str() );
	                            double qty   = atof( result["data"]["bid"][i][1].asString().c_str() );
                                if ( qty == 0.0 ) 
                                    depth["bids"].erase(price);
                                else 
                                    depth["bids"][price] = qty;
                            }
                        }
                    }
                }
                else 
                    writte_log( "ERROR: <wss_depth> Exmo: " + symbol );
	            
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        time_t current_time;
        Json::Value json_result;
        string err;

        int t = time(&current_time);
        string ep = to_string (t);
        symbol[symbol.find('-')] = '_';

        string url("https://api.exmo.com/v1.1/order_create?");
        string action = "POST";
        
        string_toupper(side);
        string post_data = "nonce=" + ep + "&pair=" + symbol + "&quantity=" + to_string(quantity) + "&price=0&type=market_" + side;
        string msg = post_data;
        
        string signature =  hmac_sha512( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/x-www-form-urlencoded";
        extra_http_header.push_back(header_chunk);
        header_chunk="Key:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Sign:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Exmo: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Exmo: order.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
