
class Bitfinex: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, double >  idPrice;
    map < string, map <double,double> >  depth;
    string api_key = "p3tVsBKJbz66VUOdhcZQxZhUs1lcRvkosj64MyM8Yet";
    string secret_key = "eDeR6XLtOQaPE9yjIejXKh2GRcH11MJmzJYEb8ftnBC";
    
    public:
    Bitfinex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value json_result; 
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        symbol.erase(symbol.size() - 1);
        string s = "https://api-pub.bitfinex.com/v2/book/t" + symbol + "/R0";
        
        try{
            mtxCurl.lock();
            get_curl(s, json_result);
            mtxCurl.unlock();
         	
         	mtxDepth.lock();
         	
         	depth.clear();
         	idPrice.clear();
         	for(int i = 0; i < json_result.size(); i++){
            	if(atoi( json_result[i][2].asString().c_str()) < 0){
                    double price = atof( json_result[i][1].asString().c_str());
                    double qty 	 = atof( json_result[i][2].asString().c_str());
                    if ( price == 0.0 ) 
                        depth["asks"].erase(idPrice[json_result[i][0].asString()]);
                    else {
                        depth["asks"][price] = qty;
                        idPrice[json_result[i][0].asString()] = price;
                    }
                }
                else{
                    double price = atof( json_result[i][1].asString().c_str());
                    double qty 	 = atof( json_result[i][2].asString().c_str());
                    if ( price == 0.0 ) 
                        depth["bids"].erase(idPrice[json_result[i][0].asString()]);
                    else {
                        depth["bids"][price] = qty;
                        idPrice[json_result[i][0].asString()] = price;
                    }
                }
            }
            
            mtxDepth.unlock();
        
	    } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << json_result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time; 
        init_http("api-pub.bitfinex.com");
        string symbol2 = symbol;
        
        try {
            Json::Reader reader;
            Json::Value json_result;
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            symbol.erase(symbol.size() - 1);
            init_webSocket("api-pub.bitfinex.com", "443", "/ws/2");
            string s = "{ \"event\": \"subscribe\", \"channel\": \"book\", \"prec\": \"R0\", \"symbol\": \"t" + symbol + "\" }";
            write_Socket(s);
		    for(int i = 0; i < 3; i++){
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
            }
            
            time(&current_time);
            int ct = current_time;
            while (true) {
                Json::Reader reader;
                Json::Value json_result;
                time(&current_time);
                int ct2 = current_time;
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&Bitfinex::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();
                
                if (json_result.isArray() && json_result[1].isArray()) {
                    if(atof( json_result[1][2].asString().c_str()) < 0){
                        double price = atof( json_result[1][1].asString().c_str());
                        double qty 	 = atof( json_result[1][2].asString().c_str());
                        if ( price == 0.0 ) {
                            depth["asks"].erase(idPrice[json_result[1][0].asString()]);
                        } else {
                            depth["asks"][price] = qty;
                            idPrice[json_result[1][0].asString()] = price;
                        }
                    }
                    else{
                        double price = atof( json_result[1][1].asString().c_str());
                        double qty 	 = atof( json_result[1][2].asString().c_str());
                        if ( price == 0.0 ) {
                            depth["bids"].erase(idPrice[json_result[1][0].asString()]);
                        } else {
                            depth["bids"][price] = qty;
                            idPrice[json_result[1][0].asString()] = price;
                        }
                    }
                }
                else if(json_result[1].asString() != "hb")
                    throw exception();
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		     	//cout << json_result << '\n';
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        Json::Value json_result;
        string err;

        string ep = to_string (get_current_ms_epoch());

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url("https://api.bitfinex.com/v2/auth/w/order/submit");
        string action = "POST";
        
        // BUY?? SELL??
        string post_data = "{\"type\":\"MARKET\",\"symbol\":\"t" + symbol + "\",\"amount\":\"" + to_string (quantity) + "\"}";
        string msg = "/api/v2/auth/w/order/submit" + ep + "{\"type\":\"MARKET\",\"symbol\":\"t" + symbol + "\",\"amount\":\"" + to_string (quantity) + "\"}";
        
        string signature = hmac_sha384( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="bfx-nonce:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "bfx-apikey:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "bfx-signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Bitfinex: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Bitfinex: order.size() is 0";
            writte_log(err);
        }
   }
   
    map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }

    map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }
};
