


class fMexc: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "mx0fyo03A2kyS4wViR";
    string secret_key = "64cb0ad1e3cb4db489a5e158efec9107";
    
    public:
    fMexc(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol[symbol.find('-')] = '_';
        string s = "https://contract.mexc.com/api/v1/contract/depth/" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	
         	mtxDepth.lock();

         	depth.clear(); 
            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	            double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	            double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }

            mtxDepth.unlock();
        
      } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time;
        curl_depth(symbol);
        init_http("contract.mexc.com");
        string symbol2 = symbol;
        
        try {
            symbol[symbol.find('-')] = '_';
            init_webSocket("contract.mexc.com", "443", "/ws");
            string s = "{\"method\":\"sub.depth.full\",\"param\":{\"symbol\":\"" + symbol + "\",\"limit\":20}}";
            write_Socket(s);
            write_Socket(R"({"method":"ping"})");
            Json::Reader reader;
		    Json::Value json_result;
		    for(int i = 0; i < 4; i++){
		        read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
		    }

            time(&current_time);
            int ct = current_time;
            int ct3 = ct;
            while (true) {
                Json::Reader reader;
		        Json::Value json_result;
                time(&current_time);
                int ct2 = current_time;
                int ct4 = ct2;
                if(ct2 - ct >= 3){
                    ct = ct2;
                    write_Socket(R"({"method":"ping"})");
                }
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                if(ct4 - ct3 > TIME_REFRESH){ 
                    ct3 = ct4;
                    std::async (&fMexc::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();
                
                if(json_result["channel"].asString() == "push.depth.full") {
             	        
                    for ( int i = 0 ; i < json_result["data"]["bids"].size() ; i++ ) {
                        double price = atof( json_result["data"]["bids"][i][0].asString().c_str());
                        double hangingOrder = atof( json_result["data"]["bids"][i][1].asString().c_str());
                        double qty 	 = atof( json_result["data"]["bids"][i][2].asString().c_str());
                        if ( hangingOrder == 0.0 ) {
                            depth["bids"].erase(price);
                        } else {
                            depth["bids"][price] = qty;
                        }
                    }
                    for ( int i = 0 ; i < json_result["data"]["asks"].size() ; i++ ) {
                        double price = atof( json_result["data"]["asks"][i][0].asString().c_str());
                        double hangingOrder = atof( json_result["data"]["asks"][i][1].asString().c_str());
                        double qty 	 = atof( json_result["data"]["asks"][i][2].asString().c_str());
                        if ( hangingOrder == 0.0 ) {
                            depth["asks"].erase(price);
                        } else {
                            depth["asks"][price] = qty;
                        }
                    }
                }
                else if(json_result["channel"].asString() != "pong")
                    throw exception();

                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		     	//cout << json_result << endl;
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        Json::Value json_result;
        string err;
        
        string ep = to_string (get_current_ms_epoch());
        symbol[symbol.find('-')] = '_';

        string url("https://www.mexc.com/open/api/v2/order/place");
        string action = "POST";
        
        string position = side == "buy" ? "BID": "ASK";
        string post_data  = "{\"symbol\":\"" + symbol + "\",\"price\":\"" + to_string(price) + "\",\"quantity\":\"" + to_string(quantity) + "\",\"trade_type\":\"" + position + "\",\"order_type\":\"LIMIT_ORDER\"}";
        string msg = api_key + ep + post_data;
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="ApiKey:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Request-Time:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Mexc: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Mexc: order.size() is 0";
            writte_log(err);
        }
   }
   
    void withdraw( string coin, string address, double amount, string network ) {	
        Json::Value json_result;
        string err;
        
        string ep = to_string (get_current_ms_epoch());

        string url("https://www.mexc.com/open/api/v2/asset/withdraw");
        string action = "POST";
        
        string post_data  = "{\"currency\":\"" + coin + "\",\"amount\":" + to_string(amount) + ",\"address\":\"" + address + "\"}";
        string msg = api_key + ep + post_data;
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="ApiKey:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Request-Time:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Mexc: error reading withdraw response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Mexc: withdraw.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
