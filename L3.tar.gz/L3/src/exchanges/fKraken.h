

class fKraken: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    fKraken(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        symbol.erase(symbol.size() - 1);  
        string symbol2 = symbol;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end()); 
        symbol2[symbol2.find('-')] = 'Z';   
        symbol2 = "X" + symbol2;
        string s = "https://api.kraken.com/0/public/Depth?pair=" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();    	
   	
         	mtxDepth.lock();
         	
         	depth.clear();                  
	        for ( int i = 0 ; i < result["result"][symbol2]["asks"].size(); i++ ) {
		        double price = atof( result["result"][symbol2]["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["result"][symbol2]["asks"][i][1].asString().c_str() );
		        depth["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["result"][symbol2]["bids"].size() ; i++ ) {
		        double price = atof( result["result"][symbol2]["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["result"][symbol2]["bids"][i][1].asString().c_str() );
		        depth["bids"][price] = qty;
	        }
	            
	        mtxDepth.unlock();
	    
	        } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        init_http("ws.kraken.com");
        
        try {
            string symbol2 = symbol;
            symbol.erase(symbol.size() - 1);   
            symbol[symbol.find('-')] = '/';
            init_webSocket("ws.kraken.com", "443", "/");
            string s = "{\"event\": \"subscribe\",\"pair\": [\"" + symbol + "\"],\"subscription\": {\"depth\": 100 ,\"name\": \"book\"}}";
            write_Socket(s);
            Json::Reader reader;
            Json::Value json_result;
		    for(int i = 0; i < 4; i++){
		        read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
		    }

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
                Json::Value json_result;
                read_Socket();
                string er = get_socket_data();	
		        reader.parse( er , json_result );
                buffer_clear();
                

                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&fKraken::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();

                if(er[0] != '{' && (json_result[1].isMember("a") || json_result[1].isMember("b"))) {
                        for ( int i = 0 ; i < json_result[1]["a"].size() ; i++ ) {
                            double price = atof( json_result[1]["a"][i][0].asString().c_str());
                            double qty 	 = atof( json_result[1]["a"][i][1].asString().c_str());
                            if ( qty == 0.0 ) {
                                depth["asks"].erase(price);
                            } else {
                                depth["asks"][price] = qty;
                            }
                        }
                        for ( int i = 0 ; i < json_result[1]["b"].size() ; i++ ) {
                            double price = atof( json_result[1]["b"][i][0].asString().c_str());
                            double qty 	 = atof( json_result[1]["b"][i][1].asString().c_str());
                            if ( qty == 0.0 ) {
                                depth["bids"].erase(price);
                            } else {
                                depth["bids"][price] = qty;
                            }
                        }
                } 
                else if(json_result["event"].asString() != "heartbeat"){
                    cout << json_result << endl;
                    throw exception();
                }
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		        //cout << result << '\n'; 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
