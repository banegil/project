

class fHuobi: public Exchange {
    mutex mtxDepth,mtxCurl;
    map < string, map <double,double> >  depth;
    
    public:
    fHuobi(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    void curl_depth(string symbol){
        Json::Value result; 
        
        string s = "https://api.hbdm.com/linear-swap-ex/market/depth?contract_code=" + symbol + "&type=step0";
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
  	
         	mtxDepth.lock();
         	
         	depth.clear(); 
            for ( int i = 0 ; i < result["tick"]["asks"].size(); i++ ) {
	            double price = atof( result["tick"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["tick"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["tick"]["bids"].size() ; i++ ) {
	            double price = atof( result["tick"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["tick"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	        
            mtxDepth.unlock();
        
      } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time; 
        init_http("api.hbdm.com");
        string symbol2 = symbol;
        
        try {
            transform(symbol.begin(), symbol.end(), symbol.begin(),
            [](unsigned char c){ return tolower(c); });
            init_webSocket("api.hbdm.com", "443", "/linear-swap-ws");
            string s = "{\"sub\": \"market." + symbol + ".depth.size_150.high_freq\",\"data_type\":\"incremental\"}";
            write_Socket(s);
            s = "{\"sub\": \"market." + symbol2 + ".bbo\",\"id\": \"id8\"}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
		    for(int i = 0; i < 8; i++){
                read_Socket();	
                buffer_clear();
            }
            
            time(&current_time);
            int ct = current_time;
            while (true) {
                Json::Reader reader;
		        Json::Value json_result;
                time(&current_time);
                int ct2 = current_time;
                read_Socket();	
                s = decompress_gzip(get_socket_data());
		        reader.parse( s , json_result );
                buffer_clear();
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (launch::async, &fHuobi::curl_depth, this, symbol2);
                }
              
                mtxDepth.lock();
                
                if(json_result.isMember("tick")){
                    if(json_result["tick"].isMember("bids") || json_result["tick"].isMember("asks")){
                        for ( int i = 0 ; i < json_result["tick"]["bids"].size() ; i++ ) {
                            double price = atof( json_result["tick"]["bids"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["tick"]["bids"][i][1].asString().c_str());
                            if ( qty == 0.0 ) {
                                depth["bids"].erase(price);
                            } else {
                                depth["bids"][price] = qty;
                            }
                        }
                        for ( int i = 0 ; i < json_result["tick"]["asks"].size() ; i++ ) {
                            double price = atof( json_result["tick"]["asks"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["tick"]["asks"][i][1].asString().c_str());
                            if ( qty == 0.0 ) {
                                depth["asks"].erase(price);
                            } else {
                                depth["asks"][price] = qty;
                            }
                        }
                    }
                    else if (json_result["tick"].isMember("bid") || json_result["tick"].isMember("ask")){
                        double price = atof( json_result["tick"]["bid"][0].asString().c_str());
                        double qty 	 = atof( json_result["tick"]["bid"][1].asString().c_str());
                        if ( qty == 0.0 ) {
                            depth["bids"].erase(price);
                        } else {
                            depth["bids"][price] = qty;
                        }
                        
                        price = atof( json_result["tick"]["ask"][0].asString().c_str());
                        qty 	 = atof( json_result["tick"]["ask"][1].asString().c_str());
                        if ( qty == 0.0 ) {
                            depth["asks"].erase(price);
                        } else {
                            depth["asks"][price] = qty;
                        }
                    }
                }
                else if(json_result.isMember("ping")){
                    int j = json_result["ping"].asUInt64();
                    s = "{\"pong\": " + to_string(j) + "}";
                    write_Socket(s);
                }
                else
                    throw exception();

                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		     	//cout << json_result << endl;
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};

