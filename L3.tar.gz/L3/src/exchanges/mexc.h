


class Mexc: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    string api_key = "mx0fyo03A2kyS4wViR";
    string secret_key = "64cb0ad1e3cb4db489a5e158efec9107";
    
    public:
    Mexc(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '_';
        string s = "https://www.mexc.com/open/api/v2/market/depth?symbol=" + symbol + "&depth=100";
        get_curl(s, result);
     	
     	if(result.isMember("data") && result["data"].isMember("bids")){	
	        for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
		        double price = atof( result["data"]["asks"][i]["price"].asString().c_str() );
		        double qty   = atof( result["data"]["asks"][i]["quantity"].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
		        double price = atof( result["data"]["bids"][i]["price"].asString().c_str() );
		        double qty   = atof( result["data"]["bids"][i]["quantity"].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Mexc: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time;
        int i;
        string j;
        depth = curl_depth(symbol);
        init_http("contract.mexc.com");
        string symbol2 = symbol;
        int timestamp = 0;
        
        try {
            symbol[symbol.find('-')] = '_';
            init_webSocket("contract.mexc.com", "443", "/ws");
            string s = "{\"method\":\"sub.depth.full\",\"param\":{\"symbol\":\"" + symbol + "\",\"limit\":20}}";
            write_Socket(s);
            write_Socket(R"({"method":"ping"})");
            Json::Reader reader;
		    Json::Value json_result;
		    for(int i = 0; i < 4; i++){
		        read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
		    }

            time(&current_time);
            int ct = current_time;
            int ct3 = ct;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                int ct4 = ct2;
                if(ct2 - ct > 12){
                    ct = ct2;
                    write_Socket(R"({"method":"ping"})");
                }
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                mtxDepth.lock();
                
                if(ct4 - ct3 > TIME_REFRESH){
                    ct3 = ct4;
                    depth.clear();
                    depth = curl_depth(symbol2);
                }
                else{
                    if(json_result["channel"].asString() != "pong") {
                        int ts = json_result["data"]["version"].asUInt64();
                 	    if(ts > timestamp){
                 	        timestamp = ts;
                 	        
                            if(json_result["data"].isMember("bids")){
                                for ( i = 0 ; i < json_result["data"]["bids"].size() ; i++ ) {
                                    double price = atof( json_result["data"]["bids"][i][0].asString().c_str());
                                    double hangingOrder = atof( json_result["data"]["bids"][i][1].asString().c_str());
                                    double qty 	 = atof( json_result["data"]["bids"][i][2].asString().c_str());
                                    if ( hangingOrder == 0.0 ) {
                                        depth["bids"].erase(price);
                                    } else {
                                        depth["bids"][price] = qty;
                                    }
                                }
                            }
                            if(json_result["data"].isMember("asks")){
                                for ( i = 0 ; i < json_result["data"]["asks"].size() ; i++ ) {
                                    double price = atof( json_result["data"]["asks"][i][0].asString().c_str());
                                    double hangingOrder = atof( json_result["data"]["asks"][i][1].asString().c_str());
                                    double qty 	 = atof( json_result["data"]["asks"][i][2].asString().c_str());
                                    if ( hangingOrder == 0.0 ) {
                                        depth["asks"].erase(price);
                                    } else {
                                        depth["asks"][price] = qty;
                                    }
                                }
                            }
                        }
                    }
                }

                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        Json::Value json_result;
        string err;
        
        string ep = to_string (get_current_ms_epoch());
        symbol[symbol.find('-')] = '_';

        string url("https://www.mexc.com/open/api/v2/order/place");
        string action = "POST";
        
        string position = side == "buy" ? "BID": "ASK";
        string post_data  = "{\"symbol\":\"" + symbol + "\",\"price\":\"" + to_string(price) + "\",\"quantity\":\"" + to_string(quantity) + "\",\"trade_type\":\"" + position + "\",\"order_type\":\"LIMIT_ORDER\"}";
        string msg = api_key + ep + post_data;
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="ApiKey:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Request-Time:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Mexc: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Mexc: order.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
   
       map < string, map <double,double> > getget(string symbol){
       map < string, map <double,double> > d;
        mtxDepth.lock();
        d = curl_depth(symbol);
        mtxDepth.unlock();
        return d;
    }
};
