

class Bibox: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    Bibox(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol[symbol.find('-')] = '_';
        string s = "https://api.bibox.com/v3/mdata/depth?pair=" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();    	

         	mtxDepth.lock();
         	
         	depth.clear();                  
            for ( int i = 0 ; i < result["result"]["asks"].size(); i++ ) {
	            double price = atof( result["result"]["asks"][i]["price"].asString().c_str() );
	            double qty   = atof( result["result"]["asks"][i]["volume"].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["result"]["bids"].size() ; i++ ) {
	            double price = atof( result["result"]["bids"][i]["price"].asString().c_str() );
	            double qty   = atof( result["result"]["bids"][i]["volume"].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	            
	        mtxDepth.unlock();
	    
	        } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        init_http("npush.bibox360.com");
        
        try {
            string symbol2 = symbol;
            symbol[symbol.find('-')] = '_';
            init_webSocket("npush.bibox360.com", "443", "/");
            string s = "{\"sub\": \"BTC_USDT_depth\"}";
            write_Socket(s);

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
                Json::Value result;
                read_Socket();	
                s = decompress_deflate(get_socket_data());
		        reader.parse( s , result );
                buffer_clear();
                
cout << result << endl;
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    //std::async (launch::async, &Bibox::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();
 
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		        //cout << result << '\n'; 
            return;
          }
   }
   
    void fWesbsocketInit_depth(string symbol){  
        time_t current_time;
        curl_depth(symbol);
        init_http("ascendex.com");
        
        try {
            string symbol2 = symbol;
            symbol = symbol.substr(0, symbol.find('-'));
            init_webSocket("ascendex.com", "443", "/api/pro/v2/stream");
            string s = "{ \"op\": \"sub\",\"ch\":\"depth:" + symbol + "-PERP\" }";
            write_Socket(s);
            s = "{ \"op\": \"sub\",\"ch\":\"bbo:" + symbol + "-PERP\" }";
            write_Socket(s);
            Json::Reader reader;
            Json::Value result;
		    for(int i = 0; i < 4; i++){
		        read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
		    }

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
                Json::Value result;
                read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
                

                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    depth.clear();
                }
                
                mtxDepth.lock();

                if(result["m"].asString() == "bbo"){	
        	        double price = atof( result["data"]["ask"][0].asString().c_str() );
                    double qty   = atof( result["data"]["ask"][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                    price = atof( result["data"]["bid"][0].asString().c_str() );
                    qty   = atof( result["data"]["bid"][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }                
                else if(result["m"].asString() == "depth"){	

             	        if(result["data"].isMember("asks")) {
                            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	                            double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	                            double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
                                if ( qty == 0.0 ) 
	                                depth["asks"].erase(price);
                                else 
	                                depth["asks"][price] = qty;
                            }
                        }
                        if(result["data"].isMember("bids")) {
                            for ( int i = 0 ; i < result["data"]["bids"].size(); i++ ) {
	                            double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	                            double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
                                if ( qty == 0.0 ) 
	                                depth["bids"].erase(price);
                                else 
	                                depth["bids"][price] = qty;
                            }
                        }
                }
                else if(result["m"].asString() == "ping")
                    write_Socket(R"({ "op": "pong" })");
                else
                    throw exception();    
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		        //cout << result << '\n'; 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
