class Bibox: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    Bibox(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol[symbol.find('-')] = '_';
        string s = "https://api.bibox.com/v3/mdata/depth?pair=" + symbol;
        mtxCurl.lock();
        get_curl(s, result);
        mtxCurl.unlock();    	
     	
     	mtxDepth.lock();
     	
     	depth.clear();    
     	
        for ( int i = 0 ; i < result["result"]["asks"][0].size(); i++ ) {
	        double price = atof( result["result"]["asks"][0][i]["price"].asString().c_str() );
	        double qty   = atof( result["result"]["asks"][0][i]["volume"].asString().c_str() );
	        depth["asks"][price] = qty;
        }
        for  ( int i = 0 ; i < result["result"]["bids"][0].size() ; i++ ) {
	        double price = atof( result["result"]["bids"][0][i]["price"].asString().c_str() );
	        double qty   = atof( result["result"]["bids"][0][i]["volume"].asString().c_str() );
	        depth["bids"][price] = qty;
        }
	        
	    mtxDepth.unlock();
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        curl_depth(symbol);
        init_http("npush.bibox360.com");
        int timestamp = 0;
        
        try {
            string symbol2 = symbol;
            symbol[symbol.find('-')] = '_';
            init_webSocket("npush.bibox360.com", "443", "/");
            string s = "{\"sub\":\"BTC_USDT_depth\"}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;
		    /*for(int i = 0; i < 4; i++){
		        read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
		    }*/

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                read_Socket();	
                s = decompress_gzip(get_socket_data());
		        reader.parse( s , result );
                buffer_clear();
                
                cout << result << endl;

                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    //std::async (&Bibox::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();
                
                /*if(result.isMember("data") && result["data"].isMember("ts")){	
             	        
             	        if(result["data"].isMember("asks")) {
                            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	                            double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	                            double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
                                if ( qty == 0.0 ) 
	                                depth["asks"].erase(price);
                                else 
	                                depth["asks"][price] = qty;
                            }
                        }
                        if(result["data"].isMember("bids")) {
                            for ( int i = 0 ; i < result["data"]["bids"].size(); i++ ) {
	                            double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	                            double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
                                if ( qty == 0.0 ) 
	                                depth["bids"].erase(price);
                                else 
	                                depth["bids"][price] = qty;
                            }
                        }
                }
                else {
                    write_Socket(R"({ "op": "pong" })");
                    if(!result.isMember("m"))
                        writte_log( "ERROR: <wss_depth> Aax: " + symbol );
                }*/
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
