
class Bitrue: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    Bitrue(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value json_result; 
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://openapi.bitrue.com/api/v1/depth?symbol=" + symbol;
        mtxCurl.lock();
        get_curl(s, json_result);
        mtxCurl.unlock();    	
     	
     	mtxDepth.lock();
     	
     	depth.clear();                  
        for ( int i = 0 ; i < json_result["asks"].size(); i++ ) {
	        double price = atof( json_result["asks"][i][0].asString().c_str() );
	        double qty   = atof( json_result["asks"][i][1].asString().c_str() );
	        depth["asks"][price] = qty;
        }
        for  ( int i = 0 ; i < json_result["bids"].size() ; i++ ) {
	        double price = atof( json_result["bids"][i][0].asString().c_str() );
	        double qty   = atof( json_result["bids"][i][1].asString().c_str() );
	        depth["bids"][price] = qty;
        }

	    mtxDepth.unlock();
    }
    
   void wesbsocketInit_depth(string symbol){  
       
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
