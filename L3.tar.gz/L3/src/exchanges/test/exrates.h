
#include "exchange.h"

class Exrates: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Exrates(const int& id, string &api_key, string &secret_key) : Exchange(id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.exrates.me/v1/public/book?pair=" + symbol;
        get_curl(s, result);
     	
     	if(result.isMember("data") && result["data"].isMember("buy")){	
	        for ( int i = 0 ; i < result["data"]["buy"].size(); i++ ) {
		        double price = atof( result["data"]["buy"][i]["rate"].asString().c_str() );
		        double qty   = atof( result["data"]["buy"][i]["volume"].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["data"]["sell"].size() ; i++ ) {
		        double price = atof( result["data"]["sell"][i]["rate"].asString().c_str() );
		        double qty   = atof( result["data"]["sell"][i]["volume"].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        cout << "ERROR" << endl;
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
        init_http("socket.exrates.me");
        depth = curl_depth(symbol);
                
        try {
            init_webSocket("socket.exrates.me", "443", "/");
            symbol[symbol.find('-')] = '_';
            string s = "{type: 'book', event: 'book_1'}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;

            while (true) {
                read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
                
                mtxDepth.lock();

             	/*if(result.isMember("data") && result["data"].isMember("ask")){	
	                for ( int i = 0 ; i < result["data"]["ask"].size(); i++ ) {
		                double price = atof( result["data"]["ask"][i][0].asString().c_str() );
		                double qty   = atof( result["data"]["ask"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
	                }
	                for  ( int i = 0 ; i < result["data"]["bid"].size() ; i++ ) {
		                double price = atof( result["data"]["bid"][i][0].asString().c_str() );
		                double qty   = atof( result["data"]["bid"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
	                }
	            }
	            else {
	                cout << "ERROR" << endl;
	            }*/
	            cout << result;
                    
                while(400 < depth["bids"].size())
                    depth["bids"].erase( prev( depth["bids"].end() ) );
                while(400 < depth["asks"].size())
                    depth["asks"].erase( prev( depth["asks"].end() ) );
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
            cout << "ERROR: " << e.what() << endl;
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
