

class Bigone: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    
    public:
    Bigone(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        string s = "https://big.one/api/v3/asset_pairs/" + symbol + "/depth?limit=100";
        mtxCurl.lock();
        get_curl(s, result);
        mtxCurl.unlock();
     	
        mtxDepth.lock();
        
        depth.clear(); 
     	if(result.isMember("data") && result["data"].isMember("asks")){	
	        for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
		        double price = atof( result["data"]["asks"][i]["price"].asString().c_str() );
		        double qty   = atof( result["data"]["asks"][i]["quantity"].asString().c_str() );
		        depth["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
		        double price = atof( result["data"]["bids"][i]["price"].asString().c_str() );
		        double qty   = atof( result["data"]["bids"][i]["quantity"].asString().c_str() );
		        depth["bids"][price] = qty;
	        }
	    }
	    else
	        cout << "ERROR" << endl;
	 
	    mtxDepth.unlock();
    }
    
    void wesbsocketInit_depth(string symbol){  
        init_http("big.one");
        
        try {
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            init_webSocket("big.one", "443", "/ws/contract/v2");
            string s = "{\"requestId\": \"1\", \"subscribeMarketDepthRequest\":{\"market\":\"" + symbol + "\"}}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;
		    /*for(int i = 0; i < 2; i++){
		        read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
            }
            
            if(result.isMember("snapshot") && result["snapshot"].isMember(symbol)){	
                for ( int i = 0 ; i < result["snapshot"][symbol]["a"].size(); i++ ) {
                    double price = atof( result["snapshot"][symbol]["a"][i][0].asString().c_str() );
                    double qty   = atof( result["snapshot"][symbol]["a"][i][1].asString().c_str() );
                    depth["asks"][price] = qty;
                }
                for ( int i = 0 ; i < result["snapshot"][symbol]["b"].size(); i++ ) {
                    double price = atof( result["snapshot"][symbol]["b"][i][0].asString().c_str() );
                    double qty   = atof( result["snapshot"][symbol]["b"][i][1].asString().c_str() );
                    depth["bids"][price] = qty;
                }
            }*/

            while (true) {
                read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
                
                mtxDepth.lock();

                /*if(result.isMember("update") && result["update"].isMember(symbol)){	
	                for ( int i = 0 ; i < result["update"][symbol]["a"].size(); i++ ) {
		                double price = atof( result["update"][symbol]["a"][i][0].asString().c_str() );
		                double qty   = atof( result["update"][symbol]["a"][i][1].asString().c_str() );
	                    if ( qty == 0.0 ) 
		                    depth["asks"].erase(price);
	                    else 
		                    depth["asks"][price] = qty;
	                }
	                for ( int i = 0 ; i < result["update"][symbol]["b"].size(); i++ ) {
		                double price = atof( result["update"][symbol]["b"][i][0].asString().c_str() );
		                double qty   = atof( result["update"][symbol]["b"][i][1].asString().c_str() );
	                    if ( qty == 0.0 ) 
		                    depth["bids"].erase(price);
	                    else 
		                    depth["bids"][price] = qty;
	                }
	            }
	            else {
                    cout << "ERROR" << endl;
                }*/
                cout << result << endl;
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
            cout << "ERROR: " << e.what() << endl;
            return;
          }
   }
   
    map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }

    map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }
};
