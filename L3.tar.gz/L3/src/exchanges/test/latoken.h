class Latoken: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    Latoken(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        string s = "https://aws.okex.com/api/v5/market/books?instId=" + symbol + "&sz=100";
        mtxCurl.lock();
        get_curl(s, result);
        mtxCurl.unlock();
     	
        mtxDepth.lock();
     		 
     	depth.clear(); 	    
     	if(result.isMember("data")){	
	        for ( int i = 0 ; i < result["data"][0]["asks"].size(); i++ ) {
		        double price = atof( result["data"][0]["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["data"][0]["asks"][i][1].asString().c_str() );
		        depth["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["data"][0]["bids"].size() ; i++ ) {
		        double price = atof( result["data"][0]["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["data"][0]["bids"][i][1].asString().c_str() );
		        depth["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Aax: " + symbol );
	 
	    mtxDepth.unlock();
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        int i;
        string j;
        init_http("api.latoken.com");
        
        try {
            init_webSocket("api.latoken.com", "443", "/stomp/v1/book/ETH/USDT");
            Json::Reader reader;
	        Json::Value json_result;

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                read_Socket();	
                string s = get_socket_data();
                cout << decompress_gzip(s) << endl;
	            reader.parse( s , json_result );
                buffer_clear();
                
                cout << json_result << endl;
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                   // std::async (&Latoken::curl_depth, this, symbol);
                }
                
                mtxDepth.lock();
                
             	/*if(json_result.isMember("data")){	
             	        
             		for  ( int i = 0 ; i < json_result["data"][0]["bids"].size() ; i++ ) {
                        double price = atof( json_result["data"][0]["bids"][i][0].asString().c_str() );
                        double qty   = atof( json_result["data"][0]["bids"][i][1].asString().c_str() );
                        depth["bids"][price] = qty;
                    }
                    for ( int i = 0 ; i < json_result["data"][0]["asks"].size() ; i++ ) {
                        double price = atof( json_result["data"][0]["asks"][i][0].asString().c_str() );
                        double qty   = atof( json_result["data"][0]["asks"][i][1].asString().c_str() );
                        depth["asks"][price] = qty;
                    }
                }*/
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
	         	writte_log( err ); 
            return;
          }
    }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
