#include <map>
#include "include.h"

#include <chrono>
#include <thread>
#include <future> 


void init(string symbol, vector<bool> v, const int n){  
    int i = 0, cont = 0;
    vector<bool> vD(n, 1);
    ex.resize(n);
    map < string, double > comission;
    map < string, int > index;
    
    ini(comission, index, v);
        
    vector<thread> ths(n);    
    for(int i = 0; i < n; i++) 
        ths[i] = thread (doSomething, i, symbol);

    std::this_thread::sleep_for(std::chrono::milliseconds(13000));
    
    map <string, int> vecesC, vecesV;
    int contWin = 0, contLose = 0;
    double past = 0, totalpq = 0, volume = 0;
    string arb;
    map < string, map <double,double> > depth;
    multimap < double, pair < string, map <double,double> > > minAsks; 
    multimap < double, pair < string, map <double,double,greater<double> > >, greater<double> > maxBids;
    map <double,double,greater<double > > bidsmap;
    while(1){
        string iC, iV;
        minAsks.clear();
        maxBids.clear();

        for(int i = 0; i < n; i++) {
            if(vD[i]) {
                depth = ex[i]->get_socketDepth();
                if(!depth.empty()) {
                
                    if(depth["asks"].size() > 0)               
                        minAsks.insert( pair< double, pair < string, map <double,double> > >(depth["asks"].begin()->first, pair< string, map <double,double> >(ex[i]->get_id(), depth["asks"])) );
                    
                    if(depth["bids"].size() > 0){
                        bidsmap.clear();
                        bidsmap.insert(depth["bids"].begin(), depth["bids"].end());
                        auto it = depth["bids"].end(); --it;
                        maxBids.insert( pair< double, pair < string, map <double,double,greater<double > > > >(it->first, pair < string, map <double,double,greater<double > > >(ex[i]->get_id(), bidsmap)) );
                    }
                }
                else{
                    string err = "ERROR: depth[] map is empty! in exchange " + ex[i]->get_id();
                    writte_log(err);
                    vD[i] = 0;
                }
            }
        }
 
        double diff = (1 - (  (minAsks.begin()->first + minAsks.begin()->first * comission[minAsks.begin()->second.first]) 
                            / (maxBids.begin()->first - maxBids.begin()->first * comission[maxBids.begin()->second.first]) ) );
        double diffP = 1 - minAsks.begin()->first / maxBids.begin()->first;
        
        /*cout << "ASKS:\n";
        for(auto ita = minAsks.begin(); ita != minAsks.end(); ++ita)
            cout << ita->first << " in exchange " << ita->second.first << '\n';           
        cout << "BIDS:\n";
        for(auto itb = maxBids.begin(); itb != maxBids.end(); ++itb)
            cout << itb->first << " in exchange " << itb->second.first << '\n';
        
        cout << "diff pair(fees): " << diff * 100 << "%" << ",  diff pair: " << diffP * 100 << "%\n\n";*/

                            
        auto itA = minAsks.begin();
        auto itB = maxBids.begin();
        auto ita = itA->second.second.begin();
        auto itb = itB->second.second.begin();
        iC = itA->second.first;
        iV = itB->second.first;
        vector<pair<string, double>> ordersBuy, ordersSell; // exchange, quantity
        if(diff > 0.0002 && iV != iC) {       
            
            while(diff > 0.0002 && iV != iC){
           
                //double profitQuantity = 0,
                double totalQuantity = 0;
                bool which1, which2; 
                while( diff > 0.0002 && ita != itA->second.second.end() && itb != itB->second.second.end() ){
                    double quantity = min(ita->second, itb->second);
                    
                    //profitQuantity += ( (itb->first - itb->first * comission[iV]) - (ita->first + ita->first * comission[iC]) ) * quantity;
                    ita->second -= quantity;
                    itb->second -= quantity;
                    
                    which1 = which2 = 0;
                    if(ita->second  == 0){
                        ita++;
                        which1 = 1;
                    }    
                    if(itb->second == 0){
                        itb++;
                        which2 = 1;
                    }
                        
                    totalQuantity += quantity;
                    
                    diff = (1 - (  (ita->first + ita->first * comission[iC]) 
                                 / (itb->first - itb->first * comission[iV]) ) ); 
                }
                
                double barrier = totalQuantity * ita->first;
                if(barrier > 9) {
                    if(barrier > 1000)
                        totalQuantity *= 0.5;
                    
                    bool check = 0;
                    for(int i = 0; i < ordersBuy.size(); i++) 
                        if(iC == ordersBuy[i].first) {
                            ordersBuy[i].second += totalQuantity;
                            check = 1;
                        }
                    
                    if(!check)                        
                        ordersBuy.push_back(pair<string, double>(iC, totalQuantity));
                    
                    check = 0;    
                    for(int i = 0; i < ordersSell.size(); i++) 
                        if(iV == ordersSell[i].first) {
                            ordersSell[i].second += totalQuantity;
                            check = 1;
                        }
                        
                     
                    if(!check)  
                        ordersSell.push_back(pair<string, double>(iV, totalQuantity)); 
                }
                
                if(which1) {
                    itA++;
                    ita = itA->second.second.begin();
                    iC = itA->second.first;
                }
                if(which2){
                    itB++;
                    itb = itB->second.second.begin();
                    iV = itB->second.first;
                }
                
                diff = (1 - (  (itA->first + itA->first * comission[itA->second.first]) 
                             / (itB->first - itB->first * comission[itB->second.first]) ) );
                             
            }
            
            // BUY / SELL
            if(!ordersBuy.empty()) {
                vector<future<multimap < double, pair < string, map <double,double> > >>> vFutBuy(ordersBuy.size());
                vector<future<multimap < double, pair < string, map <double,double,greater<double> > >, greater<double> >>> vFutSell(ordersSell.size());
                int contBuy = 0, contSell = 0;
                
                for (auto& x: ordersBuy) 
                    vFutBuy[contBuy++] = std::async (makeOrderBuy, symbol, index[x.first]);
                for (auto& x: ordersSell) 
                    vFutSell[contSell++] = std::async (makeOrderSell, symbol, index[x.first]);
                
                int iBuy = 0, iSell = 0;      
                minAsks = vFutBuy[iBuy].get();
                maxBids = vFutSell[iSell].get();  
                ita = minAsks.begin()->second.second.begin();
                itb = maxBids.begin()->second.second.begin(); 
                if(contBuy > 1 || contSell > 1)
                    cout << "----------------------------------------------------MULTIPLE ORDER----------------------------------------------------\n\n";   
                else
                    cout << "-----------------------------------------------------SINGLE ORDER-----------------------------------------------------\n\n";                            
                while(iBuy < contBuy && iSell < contSell){      
                    iC = minAsks.begin()->second.first;  
                    iV = maxBids.begin()->second.first;                               
                    double quantity = min(ordersBuy[iBuy].second, ordersSell[iSell].second);
                        
                    double bPrice = 0, buyQuantity, sellQuantity;
                    buyQuantity = sellQuantity = quantity;
                    while(buyQuantity > 0 && ita != minAsks.begin()->second.second.end()){
                        if(ita->second <= buyQuantity) {
                            buyQuantity -= ita->second;
                            bPrice += ita->first * ita->second;
                            ita++;
                        }
                        else{
                            bPrice += buyQuantity * ita->first;
                            buyQuantity = 0;
                        }
                    }
                    
                    double sPrice = 0;
                    while(sellQuantity > 0 && itb != maxBids.begin()->second.second.end()){
                        if(itb->second <= sellQuantity) {
                            sellQuantity -= itb->second;
                            sPrice += itb->first * itb->second;
                            itb++;
                        }
                        else{
                            sPrice += sellQuantity * itb->first;
                            sellQuantity = 0;
                        }
                    }
                    
                    double profitQuantity = (sPrice - sPrice * comission[iV]) - (bPrice + bPrice * comission[iC]);
                    totalpq += profitQuantity;
                    volume += quantity * 2;
                    int vcsC = ++vecesV[iC];
                    int vcsV = ++vecesC[iV];

                    diff = 100 * (1 - ((minAsks.begin()->first + minAsks.begin()->first * comission[iC]) 
                                    /  (maxBids.begin()->first - maxBids.begin()->first * comission[iV]) ) );
                    arb = "                                | diff pair(fees): " + to_string(diff); 
                    
                    diff = 100 * (1 - minAsks.begin()->first / maxBids.begin()->first);
                    arb += "  diff pair: " + to_string(diff) + " |";
                    
                    cout << arb << '\n';

                    arb = "                        [ Buy in exchange: " + iC + " " + to_string(vcsC) + " times, Sell in exchange: " + iV + " " + to_string(vcsV) + " times ]";
                    cout << arb << '\n';
                    
                    if(profitQuantity > 0){ 
                        arb = "  PROFIT: ";
                        contWin++;
                    }
                    else{
                        arb = "  LOSS: ";
                        contLose++;
                    }
                        
                    arb += to_string(profitQuantity) + "$, Buy/Sell: " + to_string(quantity * minAsks.begin()->first) + "$, totalProfit: " + to_string(totalpq) + "$, totalVolume: " + to_string(volume * minAsks.begin()->first) +  "$ [ win: " + to_string(contWin) + ", lose: " + to_string(contLose) + " ]\n";
                    cout << arb << '\n';
                    
                    
                    if(quantity == ordersBuy[iBuy].second)  
                        if(++iBuy < contBuy)
                            minAsks = vFutBuy[iBuy].get();
                            
                    if(quantity == ordersSell[iSell].second)
                        if(++iSell < contSell)
                            maxBids = vFutSell[iSell].get();   
                                                                      
                } 
                cout << "----------------------------------------------------------------------------------------------------------------------\n\n";
                std::this_thread::sleep_for(std::chrono::milliseconds(2000));
            }
        }
        //std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    
    for(int i = 0; i < n; i++)
        ths[i].join();
}

int main() {
    vector<bool> v(MAX_EXCHANGES);
    string symbol = symba;
    int num = 0;
    
    if(vCandidates(symbol, v, num))
        init(symbol, v, num);
    else
        cout << "Symbol not supported!" << endl;
    return 0;
}
