

class fBybit: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "puZeGX6khwU51p9Snm";
    string secret_key = "Nb9sK6tV5n17xvQfzek6Vy486M0gbbTn8dkT";
    
    public:
    fBybit(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> > depthCache;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.bytick.com/v2/public/orderBook/L2?symbol=" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();

            mtxDepth.lock(); 

         	depth.clear(); 
     		for  ( int i = 0 ; i < result["result"].size() ; i++ ) {
     		    if(result["result"][i]["side"].asString() == "Buy"){
	                double price = atof( result["result"][i]["price"].asString().c_str() );
	                double qty   = atof( result["result"][i]["size"].asString().c_str() );
	                depth["bids"][price] = qty;
	            }
	            else{
	                double price = atof( result["result"][i]["price"].asString().c_str() );
	                double qty   = atof( result["result"][i]["size"].asString().c_str() );
	                depth["asks"][price] = qty;
	            }
            }

            mtxDepth.unlock();
            
            depthCache = depth;
            if(depthCache.empty())
	            throw exception();
        
        } catch (std::exception const& e) {
            depth.clear();
            depthCache.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return depthCache;
      }
      return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
    try{
        time_t current_time;
        init_http("stream.bytick.com");
        string symbol2 = symbol;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        init_webSocket("stream.bytick.com", "443", "/realtime_public");
        string s = "{\"op\": \"subscribe\", \"args\": [\"orderBookL2_25." + symbol + "\"]}";
        write_Socket(s);
        Json::Reader reader;
	    Json::Value json_result;
        read_Socket();	
        buffer_clear();

        time(&current_time);
        int ct = current_time;
        int ct3 = ct;
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            int ct4 = ct2;
            Json::Reader reader;
	        Json::Value json_result;
            if(ct2 - ct >= 25){
                ct = ct2;
                write_Socket(R"({"op":"ping"})");
            }
            read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();

         	if(ct4 - ct3 > 5){ 
                ct3 = ct4;
                std::async (&fBybit::curl_depth, this, symbol2);
            }

            mtxDepth.lock();
       
         	if(json_result.isMember("topic")){	
                        	
                for ( int i = 0 ; i < json_result["data"]["delete"].size(); i++ ) {
                    double price = atof( json_result["data"]["delete"][i]["price"].asString().c_str() );
                    if(json_result["data"]["delete"][i]["side"].asString() == "Buy")
                        depth["bids"].erase(price);
                    else
                        depth["asks"].erase(price);
                }
                
                for ( int i = 0 ; i < json_result["data"]["insert"].size(); i++ ) {
                    double price = atof( json_result["data"]["insert"][i]["price"].asString().c_str() );
                    double qty   = atof( json_result["data"]["insert"][i]["size"].asString().c_str() );
                    if(json_result["data"]["insert"][i]["side"].asString() == "Buy")
                        depth["bids"][price] = qty;
                    else
                        depth["asks"][price] = qty;
                }
                
                for ( int i = 0 ; i < json_result["data"]["update"].size(); i++ ) {
                    double price = atof( json_result["data"]["update"][i]["price"].asString().c_str() );
                    double qty   = atof( json_result["data"]["update"][i]["size"].asString().c_str() );
                    if(json_result["data"]["update"][i]["side"].asString() == "Buy")
                        depth["bids"][price] = qty;
                    else
                        depth["asks"][price] = qty;
                }
            }               
            else if (!json_result.isMember("pong") && !json_result.isMember("request"))
                throw exception();
                
            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
   double send_order( string symbol, string side, double quantity, bool open ) {	
        Json::Value json_result;
        string err, reduceOnly;
        double price = -1;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string ep = to_string (get_current_ms_epoch());

        string url("https://api.bytick.com/private/linear/order/create");
        string action = "POST";
        
        if(open)
            reduceOnly = "false";
        else
            reduceOnly = "true";
        
        side[0] = toupper(side[0]);
        string msg = "api_key=" + api_key + "&close_on_trigger=false&order_type=Market&qty=" + to_string(quantity) + "&reduce_only=" + reduceOnly + "&side=" + side + "&symbol=" + symbol + "&time_in_force=GoodTillCancel&timestamp=" + ep;
       
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        string post_data = "{\"api_key\":\"" + api_key + "\",\"side\":\"" + side + "\",\"symbol\":\"" + symbol + "\",\"order_type\":\"Market\",\"qty\":" + to_string(quantity) + ",\"time_in_force\":\"GoodTillCancel\",\"reduce_only\":" + reduceOnly + ",\"close_on_trigger\":false,\"timestamp\":" + ep + ",\"sign\":\"" + signature + "\"}";
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);

        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            std::this_thread::sleep_for(std::chrono::milliseconds(100));
	            
	            if(json_result["ret_code"].asInt64() == 0 && json_result["ext_code"].asString() == "")
	           	    price = get_order(symbol, json_result["result"]["order_id"].asString());     
	                
	            if(price <= 0)
	                throw exception();
            		
            	} catch ( exception &e ) {
             	    string err = get_id() + ": error reading send_order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Bybit: send_order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
   }
   
   double get_order( string symbol, string order_id ) {	
        Json::Value json_result;
        string err;
        double price = -1;
        
        string ep = to_string (get_current_ms_epoch());

        string url("https://api.bytick.com/private/linear/order/search?");
        string action = "GET";
        
        string msg = "api_key=" + api_key + "&order_id=" + order_id + "&symbol=" + symbol + "&timestamp=" + ep;
       
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        string post_data = "";
        url += msg + "&sign=" + signature + "&symbol=" + symbol;
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/x-www-form-urlencoded";
        extra_http_header.push_back(header_chunk);

        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            
	            if(json_result["ret_code"].asInt64() == 0 && json_result["ext_code"].asString() == "")
	                price = json_result["result"]["last_exec_price"].asDouble();	  
	                
	            if(price <= 0)
                    throw exception();         
            		
            	} catch ( exception &e ) {
             	    string err = get_id() + ": error reading get_order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Bybit: get_order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
   }
   
    double get_minQty(string symbol){
        Json::Value json_result;
        string s = "https://api.bytick.com/v2/public/symbols";  
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        double minQty = 0;
        int i = 0; 

        try{        
            get_curl(s, json_result);

            if(json_result["ret_code"].asInt64() == 0 && json_result["ret_msg"].asString() == "OK")
                while(i < json_result["result"].size())                
                    if(json_result["result"][i++]["name"].asString() == symbol)
                        minQty = json_result["result"][i - 1]["lot_size_filter"]["min_trading_qty"].asDouble();

            if(minQty != 0)
                cout << get_id() << '\n'; 
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in get_minQty ";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }
        return minQty;
    }
    
   bool set_leverage( string symbol ) {	
        Json::Value json_result;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string ep = to_string (get_current_ms_epoch());

        string url("https://api.bytick.com/private/linear/position/set-leverage");
        string action = "POST";
        
        string msg = "api_key=" + api_key + "&buy_leverage=" + to_string(LEVERAGE) + "&sell_leverage=" + to_string(LEVERAGE) + "&symbol=" + symbol + "&timestamp=" + ep;
       
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        string post_data = "{\"api_key\":\"" + api_key + "\",\"buy_leverage\":" + to_string(LEVERAGE) + ",\"sell_leverage\":" + to_string(LEVERAGE) + ",\"symbol\":\"" + symbol + "\",\"timestamp\":" + ep + ",\"sign\":\"" + signature + "\"}";
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);

        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        try {
            Json::Reader reader;
            json_result.clear();	
            reader.parse( str_result , json_result );
            
            bool ok = (json_result["ret_code"].asInt64() == 34036 && json_result["ret_msg"].asString() == "leverage not modified")
                   || (json_result["ret_code"].asInt64() == 0 && json_result["ret_msg"].asString() == "OK"); 
                
            if(!ok)
                throw exception();
        		
        	} catch ( exception &e ) {
         	    string err = get_id() + ": error set_leverage response, ";
         	    err.append( e.what() );
                writte_log(err);
                cout << json_result << endl;
                return 0;
        }   
        return 1;
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
