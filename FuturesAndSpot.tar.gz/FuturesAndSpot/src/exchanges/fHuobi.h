

class fHuobi: public Exchange {
    mutex mtxDepth,mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "b1rkuf4drg-8ccc354d-5a7e1ead-45a4f";
    string api_secret = "b8a1f62b-68e3e659-65084d0a-761ac";
    double minQty = 0;
    
    string createSignatureParamHuobi(string url) {
        std::map<string, const char *> params;
        time_t nowtime = time(0);
        struct tm *utc = gmtime(&nowtime);
        char buf[50];
        strftime(buf, 50, "%Y-%m-%dT%H:%M:%S", utc);
        CURL *curl = curl_easy_init();
        std::string timestamp = encode(buf);

        params["AccessKeyId"] = api_key.c_str();
        params["SignatureMethod"] = "HmacSHA256";
        params["SignatureVersion"] = "2";
        params["Timestamp"] = timestamp.c_str();

        std::string paramsStr;
        paramsStr.append("POST").append("\n")
                .append("api.hbdm.com").append("\n")
                .append(url).append("\n");
        std::string spliceStr;
        for (map<string, const char *>::iterator iter = params.begin(); iter != params.end(); ++iter) {
            spliceStr.append(iter->first).append("=").append(iter->second);
            if (iter != --params.end()) {
                spliceStr.append("&");
            }
        }
        paramsStr.append(spliceStr);;

        unsigned int md_len;
        unsigned char *str = HMAC(EVP_sha256(),
                                  api_secret.c_str(), strlen(api_secret.c_str()),
                                  reinterpret_cast<const unsigned char *>(paramsStr.c_str()),
                                  paramsStr.size(),
                                  nullptr,
                                  &md_len);
        char signature[100];
        EVP_EncodeBlock((unsigned char *) signature, str, md_len);

        spliceStr.append("&Signature=").append(encode(signature)).c_str();
        return spliceStr;
    }
    
    public:
    fHuobi(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> > depthCache;
        string s = "https://api.hbdm.com/linear-swap-ex/market/depth?contract_code=" + symbol + "&type=step0";
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
  	
         	mtxDepth.lock();
         	
         	depth.clear(); 
            for ( int i = 0 ; i < result["tick"]["asks"].size(); i++ ) {
	            double price = atof( result["tick"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["tick"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty * minQty;
            }
            for  ( int i = 0 ; i < result["tick"]["bids"].size() ; i++ ) {
	            double price = atof( result["tick"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["tick"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty * minQty;
            }
	        
            mtxDepth.unlock();
            
            depthCache = depth;
            if(depthCache.empty())
	            throw exception();
        
      } catch (std::exception const& e) {
            depthCache.clear();
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return depthCache;
      }
      return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){
    try{
        time_t current_time; 
        init_http("api.hbdm.vn");
        pair<double,double> a, b;
        long ts = 0;
        
        init_webSocket("api.hbdm.vn", "443", "/linear-swap-ws");
        string s = "{\"sub\": \"market." + symbol + ".depth.step0\",\"id\": \"id5\"}";
        write_Socket(s);
        Json::Reader reader;
	    Json::Value json_result;
        for(int i = 0; i < 2; i++){
            read_Socket();	
            buffer_clear();
        }

        
        time(&current_time);
        int ct = current_time;
        while (true) {
            Json::Reader reader;
	        Json::Value json_result;
            time(&current_time);
            int ct2 = current_time;
            read_Socket();	
            s = decompress_gzip(get_socket_data());
	        reader.parse( s , json_result );
            buffer_clear();

            mtxDepth.lock();
            
             if(json_result["ts"].asInt64() >= ts && json_result.isMember("tick") && (json_result["tick"].isMember("bids") || json_result["tick"].isMember("asks"))){   
                depth.clear();
                ts = json_result["ts"].asInt64();                
                for ( int i = 0 ; i < json_result["tick"]["bids"].size() ; i++ ) {
                    double price = atof( json_result["tick"]["bids"][i][0].asString().c_str());
                    double qty 	 = atof( json_result["tick"]["bids"][i][1].asString().c_str());
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty * minQty;
                }
                for ( int i = 0 ; i < json_result["tick"]["asks"].size() ; i++ ) {
                    double price = atof( json_result["tick"]["asks"][i][0].asString().c_str());
                    double qty 	 = atof( json_result["tick"]["asks"][i][1].asString().c_str());
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty * minQty;
                }
            }
            else {
                long j = json_result["ping"].asInt64();
                s = "{\"pong\":" + to_string(j) + "}";
                write_Socket(s);
            }

            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    double send_order( string symbol, string side, double quantity, bool open ) {	
        string post_data = createSignatureParamHuobi("/linear-swap-api/v1/swap_cross_order");
        Json::Value json_result;
        double price = -1;
        string err, reduceOnly = "1";

        string url("https://api.hbdm.com/linear-swap-api/v1/swap_cross_order?");
        string action = "POST";
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        string str_result;
        url += post_data;
        long qty = quantity;
        qty /= minQty;

        if(open)
            reduceOnly = "0";   

        string body = "{\"account-id\":\"48038614\",\"pair\":\"" + symbol + "\",\"contract_type\":\"swap\",\"reduce_only\":" + reduceOnly + ",\"order_price_type\":\"optimal_5\",\"direction\":\"" + side + "\",\"volume\":" + to_string(qty) + ",\"lever_rate\":" + to_string(LEVERAGE) + "}";
        curl_api_with_header( url, str_result , extra_http_header, body, action) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            std::this_thread::sleep_for(std::chrono::milliseconds(100));
	            
	            if(json_result.isMember("status") && json_result["status"].asString() == "ok" && !json_result.isMember("err_code") && !json_result.isMember("err_msg"))
	                price = get_order(symbol, json_result["data"]["order_id_str"].asString()); 
	            cout << json_result << endl;
	            if(price <= 0)
	                throw exception();    
            		
            	} catch ( exception &e ) {
             	    err = get_id() + ": error reading send_order response ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Huobi: send_order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
    }
    
    double get_order( string symbol, string order_id ) {	
        string post_data = createSignatureParamHuobi("/linear-swap-api/v1/swap_cross_order_info");
        Json::Value json_result;
        double price = -1;
        string err;

        string url("https://api.hbdm.com/linear-swap-api/v1/swap_cross_order_info?");
        string action = "POST";
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        string str_result;
        url += post_data;

        string body = "{\"account-id\":\"48038614\",\"order_id\":\"" + order_id + "\",\"contract_code\":\"" + symbol + "\"}";
        curl_api_with_header( url, str_result , extra_http_header, body, action) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            
	            if(json_result.isMember("status") && json_result["status"].asString() == "ok" && !json_result.isMember("err_code") && !json_result.isMember("err_msg"))
	                price = json_result["data"][0]["trade_avg_price"].asDouble();
cout << json_result << endl;
	            if(price <= 0)
	                throw exception();
            		
            	} catch ( exception &e ) {
             	    err = get_id() + ": error reading get_order response ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Huobi: get_order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
    }
    
    double get_minQty(string symbol){
        Json::Value json_result; 
        string s = "https://api.hbdm.com/linear-swap-api/v1/swap_contract_info";   
        int i = 0;

        try{        
            get_curl(s, json_result);

            while(minQty == 0 && i < json_result["data"].size())
                if(json_result["data"][i++]["contract_code"].asString() == symbol)
                     minQty = json_result["data"][i - 1]["contract_size"].asDouble();
            
            if(minQty != 0)
                cout << get_id() << '\n';
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in set_minQty ";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }
        return minQty;
    }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};

