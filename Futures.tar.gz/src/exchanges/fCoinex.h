

class fCoinex: public Exchange {
    mutex mtxDepth, mtxCurl, mtxW;
    map < string, map <double,double> >  depth;
    string api_key = "A91DDF24854643F9881B02FF476F2891";
    string api_secret = "7BD4DF45A4C871B86BDE2F58FEBDC72342EF3B4FFFC39381";
    bool ok = false;
    
    public:
    fCoinex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time;
        init_http("perpetual.coinex.com");
        long ts = 0;
        
        try {
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            init_webSocket("perpetual.coinex.com", "443", "/");
            string s = "{\"method\":\"depth.subscribe\",\"params\":[\"" + symbol + "\",20,\"0\",true],\"id\": 11}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();
            
            time(&current_time);
            int ct = current_time;
            while (true) {
                Json::Reader reader;
		        Json::Value json_result;
                time(&current_time);
                int ct2 = current_time;
                read_Socket();	
			    reader.parse( get_socket_data() , json_result );
                buffer_clear();

                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    s = "{\"method\":\"depth.query\",\"params\":[\"" + symbol + "\",20,\"0.01\"],\"id\":15}";
                    mtxW.lock();
                    write_Socket(s);  
                    mtxW.unlock();                
                }

                mtxDepth.lock();
    
                if(json_result["method"].asString() == "depth.update"){
                    if(json_result["params"][1]["time"].asInt64() >= ts){
                        ts = json_result["params"][1]["time"].asInt64();
                        for ( int i = 0 ; i < json_result["params"][1]["asks"].size() ; i++ ) {
                            double price = atof( json_result["params"][1]["asks"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["params"][1]["asks"][i][1].asString().c_str());
                            if ( qty == 0.0 )
                                depth["asks"].erase(price);
                            else 
                                depth["asks"][price] = qty;
                        }
                        for ( int i = 0 ; i < json_result["params"][1]["bids"].size() ; i++ ) {
                            double price = atof( json_result["params"][1]["bids"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["params"][1]["bids"][i][1].asString().c_str());
                            if ( qty == 0.0 ) 
                                depth["bids"].erase(price);
                            else 
                                depth["bids"][price] = qty;
                        }
                    }
                }
                else{
                    ts = json_result["result"]["time"].asInt64();
                    depth.clear();
                    for ( int i = 0 ; i < json_result["result"]["asks"].size() ; i++ ) {
                        double price = atof( json_result["result"]["asks"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["result"]["asks"][i][1].asString().c_str());
                        if ( qty == 0.0 )
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
                    }
                    for ( int i = 0 ; i < json_result["result"]["bids"].size() ; i++ ) {
                        double price = atof( json_result["result"]["bids"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["result"]["bids"][i][1].asString().c_str());
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
                    }
                    ok = true;
                }

                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		        //cout << json_result << '\n'; 
            return;
          }
   }
   
    map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }

    map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        ok = false;
        string  s = "{\"method\":\"depth.query\",\"params\":[\"" + symbol + "\",50,\"0\"],\"id\":15}";
        mtxW.lock();
        write_Socket(s);
        mtxW.unlock();
        while(!ok){} 
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }
};
