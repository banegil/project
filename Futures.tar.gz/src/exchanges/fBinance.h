

class fBinance: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    fBinance(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://fapi.binance.com/fapi/v1/depth?symbol=" + symbol + "&limit=100";
        
        try{
            mtxCurl.lock();
            get_curl(s, result);     	
            mtxCurl.unlock();
         	
         	mtxDepth.lock();
         	                
            depth.clear(); 
            for ( int i = 0 ; i < result["asks"].size(); i++ ) {
	            double price = atof( result["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
	            double price = atof( result["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	            
	        mtxDepth.unlock();
	    
	    } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time;
        init_http("fstream.binance.com");
        
        try {
            string symbol2 = symbol;
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            transform(symbol.begin(), symbol.end(), symbol.begin(),
            [](unsigned char c){ return tolower(c); });
            string s = " /stream?streams=" + symbol + "@depth@100ms/" + symbol + "@bookTicker";
            init_webSocket("fstream.binance.com", "443", s.c_str());
            
            time(&current_time);
            int ct = current_time;
            while (true) {
                Json::Reader reader;
                Json::Value json_result;
                time(&current_time);
                int ct2 = current_time;
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&fBinance::curl_depth, this, symbol2);
                }

                mtxDepth.lock();
                
                if(json_result["data"]["e"].asString() == "depthUpdate"){           	        
                    for ( int i = 0 ; i < json_result["data"]["b"].size() ; i++ ) {
                        double price = atof( json_result["data"]["b"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["data"]["b"][i][1].asString().c_str());
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
                    }
                    for ( int i = 0 ; i < json_result["data"]["a"].size() ; i++ ) {
                        double price = atof( json_result["data"]["a"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["data"]["a"][i][1].asString().c_str());
                        if ( qty == 0.0 ) 
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
                    }	
                }
                else if(json_result["data"]["e"].asString() == "bookTicker"){   
                    double price = atof( json_result["data"]["b"].asString().c_str());
                    double qty 	 = atof( json_result["data"]["B"].asString().c_str());
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                    price = atof( json_result["data"]["a"].asString().c_str());
                    qty = atof( json_result["data"]["A"].asString().c_str());
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                }
                else
                   throw exception();
                
                mtxDepth.unlock();	
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
	         	writte_log( err ); 
	            //cout << json_result << '\n'; 
            return;
          }
    }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
