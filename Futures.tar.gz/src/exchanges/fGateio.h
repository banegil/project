

class fGateio: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "d12c6b411de430840c474455e25285fd";
    string secret_key = "d7ae70d34d768d9a140ed6b61ae8f31b281e0f1b006762b4ee9f21c4f52e0460";
    
    
    public:
    fGateio(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol[symbol.find('-')] = '_';
        string s = "https://api.gateio.ws/api/v4/futures/usdt/order_book?contract=" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	
         	mtxDepth.lock();     
         	
         	depth.clear(); 
            for ( int i = 0 ; i < result["asks"].size(); i++ ) {
	            double price = atof( result["asks"][i]["p"].asString().c_str() );
	            double qty   = atof( result["asks"][i]["s"].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
	            double price = atof( result["bids"][i]["p"].asString().c_str() );
	            double qty   = atof( result["bids"][i]["s"].asString().c_str() );
	            depth["bids"][price] = qty;
            }

            mtxDepth.unlock();  
        
      } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }   
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time; 
        init_http("fx-ws.gateio.ws");
        
        try {
            time(&current_time);
            int ct = current_time;
            string symbol2 = symbol;
            symbol[symbol.find('-')] = '_';
            init_webSocket("fx-ws.gateio.ws", "443", "/v4/ws/usdt");
            string s = "{\"time\" : " + to_string(ct) + ", \"channel\" : \"futures.order_book\", \"event\": \"subscribe\", \"payload\" : [\"" + symbol + "\", \"20\", \"0\"]}";
            write_Socket(s);
            //s = "{\"time\" : " + to_string(ct) + ", \"channel\" : \"futures.book_ticker\", \"event\": \"subscribe\", \"payload\" : [\"" + symbol + "\"]}";
            //write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();
          
            while (true) {
                Json::Reader reader;
		        Json::Value json_result;
                time(&current_time);
                int ct2 = current_time;
                read_Socket();	
			    reader.parse( get_socket_data() , json_result );
                buffer_clear();
             
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&fGateio::curl_depth, this, symbol2);
                }
                mtxDepth.lock();               
                
                /*if(json_result["channel"].asString() == "futures.book_ticker"){
                    double price = atof( json_result["result"]["a"].asString().c_str());
                    double qty = atof( json_result["result"]["A"].asString().c_str());
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                    price = atof( json_result["result"]["b"].asString().c_str());
                    qty = atof( json_result["result"]["B"].asString().c_str());
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }
                else*/ if(json_result["channel"].asString() == "futures.order_book"){
                    for ( int i = 0 ; i < json_result["result"]["bids"].size() ; i++ ) {
                        double price = atof( json_result["result"]["bids"][i]["p"].asString().c_str());
                        double qty 	 = atof( json_result["result"]["bids"][i]["s"].asString().c_str());
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
                    }
                    for ( int i = 0 ; i < json_result["result"]["asks"].size() ; i++ ) {
                        double price = atof( json_result["result"]["asks"][i]["p"].asString().c_str());
                        double qty 	 = atof( json_result["result"]["asks"][i]["s"].asString().c_str());
                        if ( qty == 0.0 ) 
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
                    }
                }
                else
                    throw exception();
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		     	//cout << json_result << endl;
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
