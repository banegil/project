#include "include.h"

#define MULTIPLE_ORDER 0
#define DEBUG 0
#define WAIT 1000

bool cerrar = 0;

bool openPos(map < string, int > index){
    vector<pair<string, double>> ordersBuy, ordersSell; // exchange, quantity
    vector<pair<double,pair<string, string>>> op;
    auto itA = minAsks_open.begin();
    auto itB = maxBids_open.begin();
    auto ita = itA->second.second.begin();
    auto itb = itB->second.second.begin();
    string iC = itA->second.first;
    string iV = itB->second.first;
    double diff = -100;

    if(itA != minAsks_open.end() && itB != maxBids_open.end()){  
        diff = 1 - itA->first / itB->first;
        /* DEBUG del chino
        double diff = 1 - minAsks_open.begin()->first / maxBids_open.begin()->first;
        
        cout << "  ASKS:\n";
        for(auto ita = minAsks_open.rbegin(); ita != minAsks_open.rend(); ++ita)
            cout << " " << left << setw(12) << ita->first << left << setw(12) << ita->second.first << left << setw(6) <<  "  fee: " << comission[ita->second.first] * 100 << "%\n";           
        cout << "  BIDS:\n";
        for(auto itb = maxBids_open.begin(); itb != maxBids_open.end(); ++itb)
        cout << " " << left << setw(12) << itb->first << left << setw(12) << itb->second.first << left << setw(6) << "  fee: " << comission[itb->second.first] * 100 << "%\n";*/  
        

    }

    if(!cerrar && diff > 0.0005 && iV != iC) {       
        bool multipleOrder = 1;
        cout << "diffOpen: " << diff * 100 << '\n';
        cout << "Ask: " << itA->first << " Bid: " << itB->first << '\n';
         
        while(multipleOrder && diff > 0.0005 && iV != iC && itA != minAsks_open.end() && itB != maxBids_open.end()){      
            double totalQuantity = 0, price_qty = ita->first;
            bool which1, which2; 
            auto aEnd = itA->second.second.end();
            auto bEnd = itB->second.second.end(); 
            
            while( diff > 0.0005 && ita != aEnd && itb != bEnd ){
                double quantity = min(ita->second, itb->second);
                ita->second -= quantity;
                itb->second -= quantity;
                
                totalQuantity += quantity;
                
                which1 = which2 = 0;
                if(ita->second  == 0){
                    ita++;
                    which1 = 1;
                }    
                if(itb->second == 0){
                    itb++;
                    which2 = 1;
                }
                
                diff = (1 - (  (ita->first + ita->first * comission[iC]) 
                             / (itb->first - itb->first * comission[iV]) ) ); 
            }
            
            double mqty = max(minQtyMap[iC], minQtyMap[iV]);
            totalQuantity -= fmod(totalQuantity, mqty);

            if(totalQuantity != 0 && totalQuantity >= mqty) {
                if(price_qty * totalQuantity > 20) 
                    totalQuantity = 20 / price_qty;
                //else
                    //totalQuantity *= 0.9;
                
                totalQuantity -= fmod(totalQuantity, mqty); 
                
                if(totalQuantity != 0 && totalQuantity >= mqty) { 
                    op.push_back({totalQuantity,{iC,iV}});
                                  
                    bool check = 0;
                    for(int i = 0; i < ordersBuy.size() && !check; i++) 
                        if(iC == ordersBuy[i].first) {
                            ordersBuy[i].second += totalQuantity;
                            check = 1;
                        }
                    
                    if(!check)                        
                        ordersBuy.push_back({iC, totalQuantity});
                    
                    check = 0;    
                    for(int i = 0; i < ordersSell.size() && !check; i++) 
                        if(iV == ordersSell[i].first) {
                            ordersSell[i].second += totalQuantity;
                            check = 1;
                        }
                                         
                    if(!check)  
                        ordersSell.push_back({iV, totalQuantity}); 
                }
            }
            
            if(which1) {
                itA++;
                ita = itA->second.second.begin();
                iC = itA->second.first;
            }
            if(which2){
                itB++;
                itb = itB->second.second.begin();
                iV = itB->second.first;
            }
            
            diff = 1 - itA->first / itB->first ;  
            
            if(!ordersBuy.empty())
                multipleOrder = MULTIPLE_ORDER;                       
        }
        
        // open LONG & SHORT
        if(!ordersBuy.empty()) {
            cerrar = 1;
            vector<future<double>> vFutBuy(ordersBuy.size()), vFutSell(ordersSell.size());
            
            int contBuy = 0, contSell = 0; 
            for (auto& x: ordersBuy) 
                vFutBuy[contBuy++] = std::async (&Exchange::send_order, ex[index[x.first]], symba, "buy", x.second, 1);
            for (auto& x: ordersSell) 
                vFutSell[contSell++] = std::async (&Exchange::send_order, ex[index[x.first]], symba, "sell", x.second, 1);
                  
                
            map<string,double> priceBuy, priceSell; 
            contBuy = 0, contSell = 0; 
            for (auto& x: ordersBuy) 
                priceBuy[x.first] = vFutBuy[contBuy++].get();
            for (auto& x: ordersSell) 
                priceSell[x.first] = vFutSell[contSell++].get();    
                
            // print result
            while(mtxOrder) {std::this_thread::sleep_for(std::chrono::milliseconds(1));} 
            cout << "----------------------------------------OPEN----------------------------------------:" << '\n';
            for(auto& i : op){            
                double diff = 1 - ((priceBuy[i.second.first] + priceBuy[i.second.first] * comission[i.second.first]) / (priceSell[i.second.second] - priceSell[i.second.second] * comission[i.second.second])); 
                double profloss = ((priceSell[i.second.second] - priceSell[i.second.second] * comission[i.second.second]) - (priceBuy[i.second.first] + priceBuy[i.second.first] * comission[i.second.first])) * i.first;
                double qty = openPositions[i.second.first][i.second.second].second;
                double diffAv = (openPositions[i.second.first][i.second.second].first * qty + diff * i.first) / (qty + i.first);
                openPositions[i.second.second][i.second.first] = {diffAv, qty + i.first};
                
                string s = "Long in " + i.second.first + "(" + to_string(priceBuy[i.second.first]) + ") Short in " + i.second.second + "(" + to_string(priceSell[i.second.second]) + ") Qty: " + to_string(i.first);
                cout << s << '\n';
                s = "diffAverage: " + to_string(diffAv * 100) + "%" +  " diffOpen: " + to_string(diff * 100) + "%";
                cout << s << '\n';
                
                if(profloss > 0)
                    s = "ProfitOpen: " + to_string(profloss) + "$";
                else 
                    s = "LossOpen: " + to_string(profloss) + "$"; 
                cout << s << "\n\n";
                 
                bannedShort[i.second.first] = 1; 
                bannedLong[i.second.second] = 1;
            }                  
            cout << "------------------------------------------------------------------------------------:" << "\n\n";
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        }
    }
    mtxOrder = 1; 
    return true;
}

bool closePos(map < string, int > index){    
    vector<pair<string, double>> ordersBuy, ordersSell; // exchange, quantity
    vector<pair<double,pair<string, string>>> op;
    bool cerrarC = 0;
        
    for(auto& itSellers : openPositions){ 
        string iC = itSellers.first;
        auto ita = asks_close[iC].begin();
        auto itaEnd = asks_close[iC].end();
                 
        for(auto& itBuyers : openPositions[iC]){
            string iV = itBuyers.first;
            auto itb = bids_close[iV].begin(); 
            auto itbEnd = bids_close[iV].end();  
            double diff = -100, price; 
            if(ita != itaEnd && itb != itbEnd){  
                diff = (1 - (  (ita->first + ita->first * comission[iC]) 
                                 / (itb->first - itb->first * comission[iV]) ) );
                if(DEBUG)
                    cout << "diffClose: " << diff * 100 << '\n';
                price = ita->first;
            }

            if(!cerrarC && diff > (itBuyers.second.first * -1) + 0.0003){         
                double totalQuantity = 0, averageAsk = 0, averageBid = 0;
                   
                while( diff > (itBuyers.second.first * -1) + 0.0003 && ita != itaEnd && itb != itbEnd ){
                    double quantity = min(ita->second, itb->second);
                    ita->second -= quantity;
                    itb->second -= quantity;
                    
                    totalQuantity += quantity;
                    averageAsk += ita->first * quantity;
                    averageBid += itb->first * quantity;
                    
                    if(ita->second == 0)
                        ita++;
                    if(itb->second == 0){
                        bids_close[iV].erase(itb);
                        itb = bids_close[iV].begin();
                    }
                    
                    diff = (1 - (  (ita->first + ita->first * comission[iC]) 
                                 / (itb->first - itb->first * comission[iV]) ) ); 
                }                
                double mqty = max(minQtyMap[iC], minQtyMap[iV]);
                totalQuantity -= fmod(totalQuantity, mqty);                
                
                double price_qty = averageAsk;
                averageAsk /= totalQuantity;
                averageBid /= totalQuantity;
                if(totalQuantity != 0 && totalQuantity >= mqty && averageAsk / averageBid > (itBuyers.second.first * -1) + 0.0003) {                     
                    bool check = 0;
                                       
                    if(price_qty > 20) 
                        totalQuantity = 20 / price;
                    //else
                        //totalQuantity *= 0.9;
                    
                    totalQuantity -= fmod(totalQuantity, mqty); 
                    
                    if(totalQuantity > openPositions[iC][iV].second)
                        totalQuantity = openPositions[iC][iV].second;
                    
                    if(totalQuantity != 0 && totalQuantity >= mqty) { 
                        op.push_back({totalQuantity,{iC,iV}});
                                      
                        bool check = 0;
                        for(int i = 0; i < ordersBuy.size() && !check; i++) 
                            if(iC == ordersBuy[i].first) {
                                ordersBuy[i].second += totalQuantity;
                                check = 1;
                            }
                        
                        if(!check)                        
                            ordersBuy.push_back({iC, totalQuantity});
                        
                        check = 0;    
                        for(int i = 0; i < ordersSell.size() && !check; i++) 
                            if(iV == ordersSell[i].first) {
                                ordersSell[i].second += totalQuantity;
                                check = 1;
                            }
                                             
                        if(!check)  
                            ordersSell.push_back({iV, totalQuantity}); 
                    }
                }                                          
            }             
        }
    }    
        
    // close LONG & SHORT
    if(!ordersBuy.empty()) {
        vector<future<double>> vFutBuy(ordersBuy.size()), vFutSell(ordersSell.size());
        
        int contBuy = 0, contSell = 0; 
        for (auto& x: ordersBuy) 
            vFutBuy[contBuy++] = std::async (&Exchange::send_order, ex[index[x.first]], symba, "buy", x.second, 0);
        for (auto& x: ordersSell) 
            vFutSell[contSell++] = std::async (&Exchange::send_order, ex[index[x.first]], symba, "sell", x.second, 0);
            
        map<string,double> priceBuy, priceSell; 
        contBuy = 0, contSell = 0; 
        for (auto& x: ordersBuy) 
            priceBuy[x.first] = vFutBuy[contBuy++].get();
        for (auto& x: ordersSell) 
            priceSell[x.first] = vFutSell[contSell++].get();    
            
        // print result
        cout << "----------------------------------------CLOSE----------------------------------------:" << '\n';
        map <string,bool> delBanShort;
        for(auto& i : op){
            double diff = 1 - ((priceBuy[i.second.first] + priceBuy[i.second.first] * comission[i.second.first]) / (priceSell[i.second.second] - priceSell[i.second.second] * comission[i.second.second])); 
            double profloss = ((priceSell[i.second.second] - priceSell[i.second.second] * comission[i.second.second]) - (priceBuy[i.second.first] + priceBuy[i.second.first] * comission[i.second.first])) * i.first;
            double diffOp = openPositions[i.second.first][i.second.second].first - diff;
            double proflossOp;
            
            string s = "Close-Short in " + i.second.first + "(" + to_string(priceBuy[i.second.first]) + ") Close-Long in " + i.second.second + "(" + to_string(priceSell[i.second.second]) + ") Qty: " + to_string(i.first);
            cout << s << '\n';
            s = "diffOp: " + to_string(diffOp * 100) + "%" + " diffAverage: " + to_string(openPositions[i.second.first][i.second.second].first * 100) + "%" + " diffClose: " + to_string(diff * 100) + "%";
            cout << s << '\n';
            
            if(proflossOp > 0)
                s = "ProfitOp: --- $ PLClose: " + to_string(profloss) + "$";
            else 
                s = "LossOp: --- $ PLClose: " + to_string(profloss) + "$"; 
            cout << s << "\n\n";
            
            if(openPositions[i.second.first][i.second.second].second - i.first == 0){
                openPositions[i.second.first].erase(i.second.second);
                delBanShort[i.second.second] = 1;
                if(openPositions[i.second.first].size() == 0) {
                    openPositions.erase(i.second.first);  
                    bannedLong[i.second.first] = 0; 
                }
            }
            else
                openPositions[i.second.first][i.second.second].second -= i.first;
        }
        cout << "-------------------------------------------------------------------------------------:" << "\n\n";
        
        for(auto& i : openPositions)
            for(auto& j : i.second)
                if(delBanShort[j.first]) {
                    delBanShort[j.first] = 0;
                    break;
                }
                    
        for(auto& i : delBanShort)
            if(bannedShort[i.first])
                bannedShort[i.first] = 0;
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        cerrarC = 1;
    }    
    mtxOrder = 0; 
    return true;
}

void init(string symbol, vector<bool> v, const int n){  
    vector<bool> vD(n, 1);
    ex.resize(n);
    map < string, int > index;
    
    ini(comission, index, v);
    for(int i = 0; i < n; i++) 
        minQtyMap[ex[i]->get_id()] = ex[i]->get_minQty(symbol); 
    cout << "get_minQty OK" << '\n';
    for(int i = 0; i < n; i++)
        ex[i]->set_leverage(symbol);
    cout << "set_leverage OK" << '\n';
        
    vector<thread> ths(n);    
    for(int i = 0; i < n; i++) 
        ths[i] = thread (doSomething, i, symbol);
        
    std::this_thread::sleep_for(std::chrono::milliseconds(10000));
    
    map < string, map <double,double> > depth;
    map <double,double,greater<double > > bidsmap;
    while(1){
        minAsks_open.clear(); asks_close.clear();
        maxBids_open.clear(); bids_close.clear();

        for(int i = 0; i < n; i++) {
            if(vD[i]) {
                depth = ex[i]->get_socketDepth();    
                string id = ex[i]->get_id();
                if(id.back() != '-'){                
                    if(depth["asks"].size() > 0){  
                        if(bannedLong[id])
                            asks_close[id] = depth["asks"];                                                
                        else       
                            minAsks_open.insert( pair< double, pair < string, map <double,double> > >(depth["asks"].begin()->first + depth["asks"].begin()->first  * comission[id],
                                                 pair< string, map <double,double> >(id, depth["asks"])) );
                    }
                    
                    if(depth["bids"].size() > 0 ){
                        if(bannedShort[id])
                            bids_close[id].insert(depth["bids"].begin(), depth["bids"].end());                      
                        else {
                            bidsmap.clear();
                            bidsmap.insert(depth["bids"].begin(), depth["bids"].end());
                            auto it = depth["bids"].end(); --it;
                            maxBids_open.insert( pair< double, pair < string, map <double,double,greater<double > > > >(it->first - it->first * comission[id],
                                                 pair < string, map <double,double,greater<double > > >(id, bidsmap)) );
                        }
                    }
                }
                else
                    v[i] = 0;
            }
        } 
                
        future<bool> f1 = std::async (openPos, index);
        future<bool> f2 = std::async (closePos, index);
        
        f1.get(); f2.get();
        
        //if(DEBUG)
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    
    for(int i = 0; i < n; i++)
        ths[i].join();
}

int main() {
    vector<bool> v(MAX_EXCHANGES);
    int num = 0;
    
    if(vCandidates(symba, v, num))
        init(symba, v, num);
    else
        cout << "Symbol not supported!" << endl;
    return 0;
}
