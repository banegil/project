#include <map>
#include "include.h"

#include <iomanip>
#include <chrono>
#include <thread>
#include <future> 

#define DEBUG 1
#define WAIT 10

void init(string symbol, vector<bool> v, const int n){  
    int i = 0, cont = 0;
    vector<bool> vD(n, 1);
    ex.resize(n);
    map < string, double > comission;
    map < string, int > index;
    
    ini(comission, index, v);
        
    vector<thread> ths(n);    
    for(int i = 0; i < n; i++) 
        ths[i] = thread (doSomething, i, symbol);

    std::this_thread::sleep_for(std::chrono::milliseconds(30000));
    
    map <string, int> vecesC, vecesV;
    int contWin = 0, contLose = 0;
    double past = 0, totalpq = 0, volume = 0;
    string arb;
    map < string, map <double,double> > depth;
    multimap < double, pair < string, map <double,double> > > minAsks; 
    multimap < double, pair < string, map <double,double,greater<double> > >, greater<double> > maxBids;
    map <double,double,greater<double > > bidsmap;
    while(1){
        string iC, iV;
        minAsks.clear();
        maxBids.clear();

        for(int i = 0; i < n; i++) {
            if(vD[i]) {
                depth = ex[i]->get_socketDepth();    
                if(ex[i]->get_id().back() != '-'){                
                    if(depth["asks"].size() > 0)               
                        minAsks.insert( pair< double, pair < string, map <double,double> > >(depth["asks"].begin()->first + depth["asks"].begin()->first  * comission[ex[i]->get_id()],
                                        pair< string, map <double,double> >(ex[i]->get_id(), depth["asks"])) );
                    
                    if(depth["bids"].size() > 0){
                        bidsmap.clear();
                        bidsmap.insert(depth["bids"].begin(), depth["bids"].end());
                        auto it = depth["bids"].end(); --it;
                        maxBids.insert( pair< double, pair < string, map <double,double,greater<double > > > >(it->first - it->first * comission[ex[i]->get_id()], pair < string, map <double,double,greater<double > > >(ex[i]->get_id(), bidsmap)) );
                    }
                }
                else{
                    v[i] = 0;
                }
            }
        }
 
        double diff = 1 - minAsks.begin()->first / maxBids.begin()->first;
        
        if(DEBUG == 2){
            cout << "  ASKS:\n";
            for(auto ita = minAsks.rbegin(); ita != minAsks.rend(); ++ita)
                cout << " " << left << setw(12) << ita->first << left << setw(12) << ita->second.first << left << setw(6) <<  "  fee: " << comission[ita->second.first] * 100 << "%\n";           
            cout << "  BIDS:\n";
            for(auto itb = maxBids.begin(); itb != maxBids.end(); ++itb)
                cout << " " << left << setw(12) << itb->first << left << setw(12) << itb->second.first << left << setw(6) << "  fee: " << comission[itb->second.first] * 100 << "%\n";  
            
            cout << "  diff pair(fees): " << diff * 100 << "%\n\n";
        }
                            
        auto itA = minAsks.begin();
        auto itB = maxBids.begin();
        auto ita = itA->second.second.begin();
        auto itb = itB->second.second.begin();
        iC = itA->second.first;
        iV = itB->second.first;
        vector<pair<string, double>> ordersBuy, ordersSell; // exchange, quantity
        if(diff > 0.0001 && iV != iC) {       
            
            while(diff > 0.0001 && iV != iC){
           
                //double profitQuantity = 0,
                double totalQuantity = 0;
                bool which1, which2; 
                while( diff > 0.0001 && ita != itA->second.second.end() && itb != itB->second.second.end() ){
                    double quantity = min(ita->second, itb->second);
                    if(DEBUG == 1){
                        cout << " " << setw(10) << left << iC << ": " << setw(10) << left << ita->first << " " << setw(10) << left << ita->second << "  ";
                        cout << " " << setw(10) << left << iV << ": " << setw(10) << left << itb->first << " " << setw(10) << left << itb->second << "\n";
                    }
                    //profitQuantity += ( (itb->first - itb->first * comission[iV]) - (ita->first + ita->first * comission[iC]) ) * quantity;
                    ita->second -= quantity;
                    itb->second -= quantity;
                    
                    which1 = which2 = 0;
                    if(ita->second  <= 1){
                        ita++;
                        which1 = 1;
                    }    
                    if(itb->second <= 1){
                        itb++;
                        which2 = 1;
                    }
                        
                    totalQuantity += quantity;
                    
                    diff = (1 - (  (ita->first + ita->first * comission[iC]) 
                                 / (itb->first - itb->first * comission[iV]) ) ); 
                }
                
                if(totalQuantity > 5000) totalQuantity = 0;
                double barrier = totalQuantity * ita->first;
                if(barrier > 10 && barrier < 5000) {
                    
                    bool check = 0;
                    for(int i = 0; i < ordersBuy.size(); i++) 
                        if(iC == ordersBuy[i].first) {
                            ordersBuy[i].second += totalQuantity;
                            check = 1;
                        }
                    
                    if(!check)                        
                        ordersBuy.push_back(pair<string, double>(iC, totalQuantity));
                    
                    check = 0;    
                    for(int i = 0; i < ordersSell.size(); i++) 
                        if(iV == ordersSell[i].first) {
                            ordersSell[i].second += totalQuantity;
                            check = 1;
                        }
                        
                     
                    if(!check)  
                        ordersSell.push_back(pair<string, double>(iV, totalQuantity)); 
                }
                
                if(which1) {
                    itA++;
                    ita = itA->second.second.begin();
                    iC = itA->second.first;
                }
                if(which2){
                    itB++;
                    itb = itB->second.second.begin();
                    iV = itB->second.first;
                }
                
                diff = 1 - itA->first / itB->first ;
                             
            }
            cout << '\n';
            
            // BUY / SELL
            if(!ordersBuy.empty()) {
                vector<future<multimap < double, pair < string, map <double,double> > >>> vFutBuy(ordersBuy.size());
                vector<future<multimap < double, pair < string, map <double,double,greater<double> > >, greater<double> >>> vFutSell(ordersSell.size());
                int contBuy = 0, contSell = 0;
                
                for (auto& x: ordersBuy) 
                    vFutBuy[contBuy++] = std::async (makeOrderBuy, symbol, index[x.first]);
                for (auto& x: ordersSell) 
                    vFutSell[contSell++] = std::async (makeOrderSell, symbol, index[x.first]);
                
                if(DEBUG == 1){
                    cout << "  ASKS:\n";
                    for(auto ita = minAsks.rbegin(); ita != minAsks.rend(); ++ita)
                        cout << " " << left << setw(12) << ita->first << left << setw(12) << ita->second.first << left << setw(6) <<  "  fee: " << comission[ita->second.first] * 100 << "%\n";           
                    cout << "  BIDS:\n";
                    for(auto itb = maxBids.begin(); itb != maxBids.end(); ++itb)
                        cout << " " << left << setw(12) << itb->first << left << setw(12) << itb->second.first << left << setw(6) << "  fee: " << comission[itb->second.first] * 100 << "%\n";  
                    
                    cout << "  diff pair(fees): " << diff * 100 << "%\n\n";
                }
                
                int iBuy = 0, iSell = 0;      
                minAsks = vFutBuy[iBuy].get();
                maxBids = vFutSell[iSell].get();  
                ita = minAsks.begin()->second.second.begin();
                itb = maxBids.begin()->second.second.begin(); 
                cout << '\n';
                if(contBuy > 1 || contSell > 1)
                    cout << "----------------------------------------------------MULTIPLE ORDER----------------------------------------------------\n\n";   
                else
                    cout << "-----------------------------------------------------SINGLE ORDER-----------------------------------------------------\n\n";                            
                while(iBuy < contBuy && iSell < contSell){      
                    iC = minAsks.begin()->second.first;  
                    iV = maxBids.begin()->second.first;                               
                    double quantity = min(ordersBuy[iBuy].second, ordersSell[iSell].second);
                        
                    double bPrice = 0, buyQuantity, sellQuantity;
                    buyQuantity = sellQuantity = quantity * 0.9;
                    cout << "  " << minAsks.begin()->second.first << ":" << '\n';
                    while(buyQuantity > 0 && ita != minAsks.begin()->second.second.end()){
                        cout << " " << setw(10) << left << ita->first + ita->first * comission[minAsks.begin()->second.first] << " " << ita->second << '\n';
                        if(ita->second <= buyQuantity) {
                            buyQuantity -= ita->second;
                            bPrice += ita->first * ita->second;
                            ita++;
                        }
                        else{
                            bPrice += buyQuantity * ita->first;
                            buyQuantity = 0;
                        }
                    }
                    
                    double sPrice = 0;
                    cout << "  " << maxBids.begin()->second.first << ":" << '\n';
                    while(sellQuantity > 0 && itb != maxBids.begin()->second.second.end()){
                        cout << " " << setw(10) << left << itb->first - itb->first * comission[maxBids.begin()->second.first] << " " << itb->second << '\n';
                        if(itb->second <= sellQuantity) {
                            sellQuantity -= itb->second;
                            sPrice += itb->first * itb->second;
                            itb++;
                        }
                        else{
                            sPrice += sellQuantity * itb->first;
                            sellQuantity = 0;
                        }
                    }
                    
                    double profitQuantity = (sPrice - sPrice * comission[iV]) - (bPrice + bPrice * comission[iC]);
                    totalpq += profitQuantity;
                    volume += quantity;
                    int vcsC = ++vecesV[iC];
                    int vcsV = ++vecesC[iV];

                    diff = 100 * (1 - ((minAsks.begin()->first + minAsks.begin()->first * comission[iC]) 
                                    /  (maxBids.begin()->first - maxBids.begin()->first * comission[iV]) ) );
                    arb = "                              | diff pair(fees): " + to_string(diff) + "%"; 
                    
                    diff = 100 * (1 - minAsks.begin()->first / maxBids.begin()->first);
                    arb += "  diff pair: " + to_string(diff) + "% |";
                    
                    cout << arb << '\n';

                    arb = "                        [ Buy in exchange: " + iC + " " + to_string(vcsC) + " times, Sell in exchange: " + iV + " " + to_string(vcsV) + " times ]";
                    cout << arb << '\n';
                    
                    if(profitQuantity > 0){ 
                        arb = "  PROFIT: ";
                        contWin++;
                    }
                    else{
                        arb = "  LOSS: ";
                        contLose++;
                    }
                        
                    arb += to_string(profitQuantity) + "$, Buy/Sell: "/*aprox*/ + to_string(quantity * minAsks.begin()->first) + "$, totalProfit: " + to_string(totalpq) + "$, totalVolume: "/*aprox*/  + to_string(volume * minAsks.begin()->first) +  "$ [ win: " + to_string(contWin) + ", lose: " + to_string(contLose) + " ]\n";
                    cout << arb << '\n';
                    
                    
                    if(quantity == ordersBuy[iBuy].second)  
                        if(++iBuy < contBuy)
                            minAsks = vFutBuy[iBuy].get();
                            
                    if(quantity == ordersSell[iSell].second)
                        if(++iSell < contSell)
                            maxBids = vFutSell[iSell].get();   
                                                                      
                } 
                cout << "----------------------------------------------------------------------------------------------------------------------\n\n";
                std::this_thread::sleep_for(std::chrono::milliseconds(2000));
            }
        }
        //std::this_thread::sleep_for(std::chrono::milliseconds(WAIT));
    }
    
    for(int i = 0; i < n; i++)
        ths[i].join();
}

int main() {
    vector<bool> v(MAX_EXCHANGES);
    string symbol = symba;
    int num = 0;
    
    if(vCandidates(symbol, v, num))
        init(symbol, v, num);
    else
        cout << "Symbol not supported!" << endl;
    return 0;
}
