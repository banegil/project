#include "include.h"

#define MULTIPLE_ORDER 0
#define DEBUG 1
#define WAIT 100

bool cerrar = 0;
double minimo = -10;

bool openPos(map < string, int > index){
    auto itA = minAsks_open.begin();
    auto itB = maxBids_open.begin();
    double diff = -100;

    if(itA != minAsks_open.end() && itB != maxBids_open.end()){  
        diff = 1 - itA->first / itB->first;
        string iC = itA->second.first;
        string iV = itB->second.first;
       
        
        if(!cerrar){

        double diff = 1 - minAsks_open.begin()->first / maxBids_open.begin()->first;
        
       /*cout << "  ASKS:\n";
        for(auto ita = minAsks_open.rbegin(); ita != minAsks_open.rend(); ++ita)
            cout << " " << left << setw(12) << ita->first << left << setw(12) << ita->second.first << left << setw(6) <<  "  fee: " << comission[ita->second.first] * 100 << "%\n";           
        cout << "  BIDS:\n";
        for(auto itb = maxBids_open.begin(); itb != maxBids_open.end(); ++itb)
        cout << " " << left << setw(12) << itb->first << left << setw(12) << itb->second.first << left << setw(6) << "  fee: " << comission[itb->second.first] * 100 << "%\n";*/ 
               // cout << "diffOpen: " << diff * 100 << " long: " << iC << " short: " << iV << '\n';
                
            if(diff > 0){
                cerrar = 1;
                openPositions[iV][iC] = {diff,0};
                bannedShort[iC] = 1;
                bannedLong[iV] = 1; 
            } 
        }
    }
    
    return true;
}

bool closePos(map < string, int > index){    
    vector<pair<string, double>> ordersBuy, ordersSell; // exchange, quantity
    vector<pair<double,pair<string, string>>> op;
    bool cerrarC = 0;
        
    for(auto& itSellers : openPositions){ 
        string iC = itSellers.first;
        auto ita = asks_close[iC].begin();
        auto itaEnd = asks_close[iC].end();
                 
        for(auto& itBuyers : openPositions[iC]){
            string iV = itBuyers.first;
            auto itb = bids_close[iV].begin(); 
            auto itbEnd = bids_close[iV].end();  
            double diff = -100, price; 
            if(ita != itaEnd && itb != itbEnd){  
                diff = (1 - (  (ita->first + ita->first * comission[iC]) 
                                 / (itb->first - itb->first * comission[iV]) ) );
                //if(DEBUG) {
                    //cout << "diffClose: " << diff * 100 << " close-short: " << iC << " close-long: " << iV << '\n';
                    //if(diff > (openPositions[iC][iV].first * -1) + 0.0001)
                    if(diff > minimo){
                        minimo = diff;
                        cout << "DiffClose: " << minimo * 100 << endl;
                    }
                    //    cout << "********************************LOGRADO********************************!" << '\n';
                
            }
            
        }
    }
    return true;
}

void init(string symbol, vector<bool> v, const int n){  
    vector<bool> vD(n, 1);
    ex.resize(n);
    map < string, int > index;
    
    ini(comission, index, v);
    for(int i = 0; i < n; i++) 
        minQtyMap[ex[i]->get_id()] = ex[i]->get_minQty(symbol); 
    cout << "get_minQty OK" << '\n';
    for(int i = 0; i < n; i++)
        ex[i]->set_leverage(symbol);
    cout << "set_leverage OK" << '\n';
        
    vector<thread> ths(n);    
    for(int i = 0; i < n; i++) 
        ths[i] = thread (doSomething, i, symbol);
        
    std::this_thread::sleep_for(std::chrono::milliseconds(10000));
    
    map < string, map <double,double> > depth;
    map <double,double,greater<double > > bidsmap;
    while(1){
        minAsks_open.clear(); asks_close.clear();
        maxBids_open.clear(); bids_close.clear();

        for(int i = 0; i < n; i++) {
            if(vD[i]) {
                depth = ex[i]->get_socketDepth();    
                string id = ex[i]->get_id();
                if(id.back() != '-'){                
                    if(depth["asks"].size() > 0){  
                        if(bannedLong[id])
                            asks_close[id] = depth["asks"];                                                
                        else       
                            minAsks_open.insert( pair< double, pair < string, map <double,double> > >(depth["asks"].begin()->first + depth["asks"].begin()->first  * comission[id],
                                                 pair< string, map <double,double> >(id, depth["asks"])) );
                    }
                    
                    if(depth["bids"].size() > 0 ){
                        if(bannedShort[id])
                            bids_close[id].insert(depth["bids"].begin(), depth["bids"].end());                      
                        else {
                            bidsmap.clear();
                            bidsmap.insert(depth["bids"].begin(), depth["bids"].end());
                            auto it = depth["bids"].end(); --it;
                            maxBids_open.insert( pair< double, pair < string, map <double,double,greater<double > > > >(it->first - it->first * comission[id],
                                                 pair < string, map <double,double,greater<double > > >(id, bidsmap)) );
                        }
                    }
                }
                else
                    v[i] = 0;
            }
        } 
                
        future<bool> f1 = std::async (openPos, index);
        future<bool> f2 = std::async (closePos, index);
        
        f1.get(); f2.get();
        
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    
    for(int i = 0; i < n; i++)
        ths[i].join();
}

int main() {
    vector<bool> v(MAX_EXCHANGES);
    int num = 0;
    
    if(vCandidates(symba, v, num))
        init(symba, v, num);
    else
        cout << "Symbol not supported!" << endl;
    return 0;
}
