
#include "../lib/myappcpp_logger.h"
#include "../lib/myappcpp_utils.h"

#include "../src/exchange.h"
#include "../src/exchanges/fAax.h"
#include "../src/exchanges/fAscendex.h"
#include "../src/exchanges/fBinance.h"
#include "../src/exchanges/fBitfinex.h"
#include "../src/exchanges/fBitget.h"
#include "../src/exchanges/fBybit.h"
#include "../src/exchanges/fCoinex.h"
#include "../src/exchanges/fCryptocom.h"
#include "../src/exchanges/fDelta.h"
#include "../src/exchanges/fFtx.h"
#include "../src/exchanges/fGateio.h"
#include "../src/exchanges/fHuobi.h"
#include "../src/exchanges/fKucoin.h"
#include "../src/exchanges/fMexc.h"
#include "../src/exchanges/fOkx.h"
#include "../src/exchanges/fPhemex.h"

#define MAX_EXCHANGES 16

using namespace std;

vector<Exchange*> ex;
bool mtxOrder = 1;
map < string, double > comission, minQtyMap;
unordered_map < string, bool > bannedLong, bannedShort;
unordered_map < string, unordered_map < string, pair< double, double > > > openPositions;
unordered_map < string, map <double,double> > asks_close;
unordered_map < string, map <double,double,greater<double> > >  bids_close;
multimap < double, pair < string, map <double,double> > > minAsks_open; 
multimap < double, pair < string, map <double,double,greater<double> > >, greater<double> > maxBids_open;

string symba = "APE-USDT";

void doSomething(int i, string symbol){
    ex[i]->wesbsocketInit_depth(symbol);
}

bool vCandidates(string s, vector<bool>& v, int &num){
    ifstream file;
    string cent = "-1", word;
    bool ok = false;
    string s1 = s.substr(0, s.find('-'));
    string s2 = s.substr(s.find('-') + 1, s.length() - 1);
    s2 += "f.txt";
    
    file.open (s2);
    if (!file.is_open()) {
        cout << "File couldn't open" << endl;
        return 0;
    }
    
    for(int i = 0; i < MAX_EXCHANGES; i++)
        file >> word;

    while (word != "-1" && !ok) {
        file >> word;
        if(word == s1){
            ok = true;
            for(int i = 0; i < MAX_EXCHANGES; i++){
                file >> word;
                if(i == 3 || i == 4 || i == 8 || i == 9 || i == 14 || i == 15)
                 // BITFINEX(precios raros), BINANCE(futures not allowed), BITGET(no rula send_order), CRYPTOCOM(hay que descargarse la app(invasiva)),
                 // DELTA(no rula send_order), PHEMEX(no da avgPrice ni execPrice)
                    v[i] = 0;
                else
                    v[i] = stoi(word);
                if(v[i])
                    num++;
            }
        }
        else 
            for(int i = 0; i < MAX_EXCHANGES; i++)
                file >> word;
    }
    
    file.close();
    return ok;
}

void ini(map < string, double >& comission, map < string, int >& index, vector<bool> &v){
    int i = 0, cont = 0;
    
    comission["fAax"] = 0.0006;
    if(v[i++]) {
        index["fAaax"] = cont;
        ex[cont++] = new fAax(0.0006, "fAax", "", "");
    }
    comission["fAscendex"] = 0.0006;
    if(v[i++]) {
        index["fAscendex"] = cont;
        ex[cont++] = new fAscendex(0.0006, "fAscendex", "", "");
    }
    comission["fBinance"] = 0.000414;
    if(v[i++]) {
        index["fBinance"] = cont;
        ex[cont++] = new fBinance(0.000414, "fBinance", "", "");
    }
    comission["fBitfinex"] = 0.00130;
    if(v[i++]) {
        index["fBitifnex"] = cont;
        ex[cont++] = new fBitfinex(0.00130, "fBitfinex", "", "");
    }
    comission["fBitget"] = 0.0012;
    if(v[i++]) {
        index["fBitget"] = cont;
        ex[cont++] = new fBitget(0.0012, "fBitget", "", "");
    }
    comission["fBybit"] = 0.0006;
    if(v[i++]) {
        index["fBybit"] = cont;
        ex[cont++] = new fBybit(0.0006, "fBybit", "", "");
    }
    comission["fCoinex"] = 0.0005;
    if(v[i++]) {
        index["fCoinex"] = cont;
        ex[cont++] = new fCoinex(0.0005, "fCoinex", "", "");
    }
    comission["fCryptocom"] = 0.00112;
    if(v[i++]) {
        index["fCryptocom"] = cont;
        ex[cont++] = new fCryptocom(0.00112, "fCryptocom", "", "");
    }
    comission["fDelta"] = 0.00075;
    if(v[i++]) {
        index["fDelta"] = cont;
        ex[cont++] = new fDelta(0.00075, "fDelta", "", "");
    }
    comission["fFtx"] = 0.0007;
    if(v[i++]) {
        index["fFtx"] = cont;
        ex[cont++] = new fFtx(0.0007, "fFtx", "", "");
    }
    comission["fGateio"] = 0.0005;
    if(v[i++]) {
        index["fGateio"] = cont;
        ex[cont++] = new fGateio(0.0005, "fGateio", "", "");
    }
    comission["fHuobi"] = 0.0005;
    if(v[i++]) {
        index["fHuobi"] = cont;
        ex[cont++] = new fHuobi(0.0005, "fHuobi", "", "");
    }
    comission["fKucoin"] = 0.0006;
    if(v[i++]) {
        index["fKucoin"] = cont;
        ex[cont++] = new fKucoin(0.0006, "fKucoin", "", "");
    }
    comission["fMexc"] = 0.0006;
    if(v[i++]) {
        index["fMexc"] = cont;
        ex[cont++] = new fMexc(0.0006, "fMexc", "", "");
    }
    comission["fOkx"] = 0.0005;
    if(v[i++]) {
        index["fOkx"] = cont;
        ex[cont++] = new fOkx(0.0005, "fOkx", "", "");
    }
    comission["fPhemex"] = 0.0015;
    if(v[i++]) {
        index["fPhemex"] = cont;
        ex[cont++] = new fPhemex(0.0015, "fPhemex", "", "");
    }
}
