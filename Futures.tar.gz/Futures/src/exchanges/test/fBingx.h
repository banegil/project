

class fBingx: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    fBingx(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    void curl_depth(string symbol){
        Json::Value result;
        vector <string> extra_http_header;
        string header_chunk="User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        string action = "GET", post_data = "";	

        string url = "https://api-swap-rest.bingbon.pro/api/v1/market/getMarketDepth?symbol=" + symbol + "&level=50";
        
        try{
            mtxCurl.lock();
            string str_result;
            curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;
            mtxCurl.unlock();

            Json::Reader reader;
            result.clear();	
            reader.parse( str_result , result );

            mtxDepth.lock();
            
            depth.clear();    
            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	            double price = atof( result["data"]["asks"][i]["p"].asString().c_str() );
	            double qty   = atof( result["data"]["asks"][i]["v"].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	            double price = atof( result["data"]["bids"][i]["p"].asString().c_str() );
	            double qty   = atof( result["data"]["bids"][i]["v"].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	     
	        mtxDepth.unlock();
	    
            } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }    
   
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        init_http("open-ws-swap.bingbon.pro");
        pair<double,double> a, b;
        long ts = 0;
        
        try {
            init_webSocket("open-ws-swap.bingbon.pro", "443", "/ws");
            string s = "{ \"id\": \"id1\", \"reqType\": \"sub\", \"dataType\": \"market.depth." + symbol + ".step0.level20\" }";
            write_Socket(s);
            Json::Reader reader;
            Json::Value result;

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
                Json::Value result;
                read_Socket();	
                string str_result;
                gzipInflate(get_socket_data(), str_result);
                reader.parse( str_result , result );
                
                buffer_clear();

                mtxDepth.lock();
                
                depth.clear();    
                for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	                double price = atof( result["data"]["asks"][i]["p"].asString().c_str() );
	                double qty   = atof( result["data"]["asks"][i]["v"].asString().c_str() );
	                depth["asks"][price] = qty;
                }
                for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	                double price = atof( result["data"]["bids"][i]["p"].asString().c_str() );
	                double qty   = atof( result["data"]["bids"][i]["v"].asString().c_str() );
	                depth["bids"][price] = qty;
                }
	         
	            mtxDepth.unlock();
	            
	           if(result["data"]["asks"].size() == 0){
	                                s = "{\"Pong\"}";

                    write_Socket(s);
	            }
	            cout << result << endl;
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		        //cout << result << '\n'; 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
