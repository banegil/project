


class fMexc: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "mx0lLCnfcAi1MgfXPh";
    string secret_key = "1a20719060b04300afded2dbbfe85fe7";
    double minQty = 0;
    
    public:
    fMexc(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> > depthCache;
        symbol[symbol.find('-')] = '_';
        string s = "https://contract.mexc.com/api/v1/contract/depth/" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();

         	mtxDepth.lock();

         	depth.clear(); 
            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	            double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty * minQty;
            }
            for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	            double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty * minQty;
            }

            mtxDepth.unlock();
            
            if(depth.empty())
	            throw exception();
            
            depthCache = depth;
        
      } catch (std::exception const& e) {
            depthCache.clear();
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return depthCache;
      }
      return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){
    try{
        time_t current_time;
        curl_depth(symbol);
        init_http("contract.mexc.com");
        long ts = 0;
        
        symbol[symbol.find('-')] = '_';
        init_webSocket("contract.mexc.com", "443", "/ws");
        string s = "{\"method\":\"sub.depth.full\",\"param\":{\"symbol\":\"" + symbol + "\",\"limit\":20}}";
        write_Socket(s);
        write_Socket(R"({"method":"ping"})");
        Json::Reader reader;
	    Json::Value json_result;
	    for(int i = 0; i < 4; i++){
	        read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();
	    }

        time(&current_time);
        int ct = current_time;
        while (true) {
            Json::Reader reader;
	        Json::Value json_result;
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct >= 3){
                ct = ct2;
                write_Socket(R"({"method":"ping"})");
            }
            read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();

            mtxDepth.lock();
            
            if(json_result["channel"].asString() == "push.depth.full" && json_result["ts"].asInt64() >= ts) {
                ts = json_result["ts"].asInt64();
         	    depth.clear();    
                for ( int i = 0 ; i < json_result["data"]["bids"].size() ; i++ ) {
                    double price = atof( json_result["data"]["bids"][i][0].asString().c_str());
                    double hangingOrder = atof( json_result["data"]["bids"][i][1].asString().c_str());
                    double qty 	 = atof( json_result["data"]["bids"][i][2].asString().c_str());
                    if ( hangingOrder == 0.0 ) {
                        depth["bids"].erase(price);
                    } else {
                        depth["bids"][price] = qty * minQty;
                    }
                }
                for ( int i = 0 ; i < json_result["data"]["asks"].size() ; i++ ) {
                    double price = atof( json_result["data"]["asks"][i][0].asString().c_str());
                    double hangingOrder = atof( json_result["data"]["asks"][i][1].asString().c_str());
                    double qty 	 = atof( json_result["data"]["asks"][i][2].asString().c_str());
                    if ( hangingOrder == 0.0 ) {
                        depth["asks"].erase(price);
                    } else {
                        depth["asks"][price] = qty * minQty;
                    }
                }
            }
            else if(json_result["channel"].asString() != "pong")
                throw exception();

            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    double send_order( string symbol, string side, double quantity, bool open ) {	
        Json::Value json_result;
        string err;
        double price = -1;
        
        string ep = to_string (get_current_ms_epoch());
        symbol[symbol.find('-')] = '_';

        string url("https://contract.mexc.com/api/v1/private/order/submit");
        string action = "POST";  
        
        if(open)
            side = side == "buy" ? "1" : "3";
        else
            side = side == "buy" ? "2" : "4";
        
        string post_data  = "{\"symbol\":\"" + symbol + "\",\"price\":0,\"vol\":" + to_string(quantity / minQty) + ",\"leverage\":" + to_string(LEVERAGE) + ",\"side\":" + side + ",\"type\":5,\"openType\":2}";
        string msg = api_key + ep + post_data;
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="ApiKey:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Request-Time:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            std::this_thread::sleep_for(std::chrono::milliseconds(100));

	            if(json_result.isMember("success") && json_result["success"].asString() == "true" && json_result.isMember("code") && json_result["code"].asInt64() == 0)
	                price = get_order(json_result["data"].asString());
	                
	            if(price <= 0)
	                throw exception();
            		
            	} catch ( exception &e ) {
             	    err = "Mexc: error reading send_order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Mexc: send_order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
   }
   
    double get_order(string order_id) {	
        Json::Value json_result;
        string err;
        double price = -1;
        
        string ep = to_string (get_current_ms_epoch());

        string url = "https://contract.mexc.com/api/v1/private/order/get/" + order_id;
        string action = "GET";
        
        string post_data  = "";
        string msg = api_key + ep + post_data;
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="ApiKey:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Request-Time:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );

	            if(json_result.isMember("success") && json_result["success"].asString() == "true" && json_result.isMember("code") && json_result["code"].asInt64() == 0)
	                price = json_result["data"]["dealAvgPrice"].asDouble();
	                
	            if(price <= 0)
	                throw exception();	            
           		
            	} catch ( exception &e ) {
             	    err = "Mexc: error reading get_order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Mexc: get_order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
   }
   
    double get_minQty(string symbol){
        Json::Value json_result; 
        symbol[symbol.find('-')] = '_';
        string s = "https://contract.mexc.com/api/v1/contract/detail?symbol=" + symbol; 

        try{        
            get_curl(s, json_result);

            if(json_result["code"].asInt64() == 0 && json_result["success"].asString() == "true")
                minQty = json_result["data"]["contractSize"].asDouble();

            if(minQty == 0)
                throw exception();  
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in set_minQty ";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }
        return minQty;
    }
   
    void withdraw( string coin, string address, double amount, string network ) {	
        Json::Value json_result;
        string err;
        
        string ep = to_string (get_current_ms_epoch());

        string url("https://www.mexc.com/open/api/v2/asset/withdraw");
        string action = "POST";
        
        string post_data  = "{\"currency\":\"" + coin + "\",\"amount\":" + to_string(amount) + ",\"address\":\"" + address + "\"}";
        string msg = api_key + ep + post_data;
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="ApiKey:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Request-Time:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Mexc: error reading withdraw response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Mexc: withdraw.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
