

class fCoinex: public Exchange {
    mutex mtxDepth, mtxCurl, mtxW;
    map < string, map <double,double> >  depth, depthCache;
    string api_key = "EE1166B29F4A4EDE9EED59EEFD77CA9C";
    string secret_key = "2259A8991C1BC5908182A63AEA305B0F7743B048CB63C97B";
    int num = 0;
    
    public:
    fCoinex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void wesbsocketInit_depth(string symbol){
    try{
        time_t current_time;
        init_http("perpetual.coinex.com");
        long ts = 0;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        init_webSocket("perpetual.coinex.com", "443", "/");
        string s = "{\"method\":\"depth.subscribe\",\"params\":[\"" + symbol + "\",20,\"0\",true],\"id\": 11}";
        write_Socket(s);
        Json::Reader reader;
	    Json::Value json_result;
        read_Socket();	
	    reader.parse( get_socket_data() , json_result );
        buffer_clear();
        
        time(&current_time);
        int ct = current_time;
        while (true) {
            Json::Reader reader;
	        Json::Value json_result;
            time(&current_time);
            int ct2 = current_time;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();

            if(ct2 - ct > 5){ 
                ct = ct2;
                s = "{\"method\":\"depth.query\",\"params\":[\"" + symbol + "\",20,\"0.01\"],\"id\":15}";
                mtxW.lock();
                write_Socket(s);  
                mtxW.unlock();                
            }

            mtxDepth.lock();

            if(json_result["method"].asString() == "depth.update"){
                if(json_result["params"][1]["time"].asInt64() >= ts){
                    ts = json_result["params"][1]["time"].asInt64();
                    for ( int i = 0 ; i < json_result["params"][1]["asks"].size() ; i++ ) {
                        double price = atof( json_result["params"][1]["asks"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["params"][1]["asks"][i][1].asString().c_str());
                        if ( qty == 0.0 )
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
                    }
                    for ( int i = 0 ; i < json_result["params"][1]["bids"].size() ; i++ ) {
                        double price = atof( json_result["params"][1]["bids"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["params"][1]["bids"][i][1].asString().c_str());
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
                    }
                }
            }
            else{
                ts = json_result["result"]["time"].asInt64();
                depth.clear();
                for ( int i = 0 ; i < json_result["result"]["asks"].size() ; i++ ) {
                    double price = atof( json_result["result"]["asks"][i][0].asString().c_str());
                    double qty 	 = atof( json_result["result"]["asks"][i][1].asString().c_str());
                    if ( qty == 0.0 )
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                }
                for ( int i = 0 ; i < json_result["result"]["bids"].size() ; i++ ) {
                    double price = atof( json_result["result"]["bids"][i][0].asString().c_str());
                    double qty 	 = atof( json_result["result"]["bids"][i][1].asString().c_str());
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }
                depthCache = depth;
                num = 1;
            }

            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    double send_order( string symbol, string side, double quantity, bool open ) {
        Json::Value json_result;
        string err;
        double price = -1;

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url = "https://api.coinex.com/perpetual/v1/order/put_market?";
        string action = "POST";	
        string ep = to_string (get_current_ms_epoch());
        side = side == "sell" ? "1" : "2";
            
        string post_data = "access_id=" + api_key + "&amount=" + to_string(quantity) + "&market=" + symbol + "&side=" + side + "&timestamp=" + ep;
        string msg = post_data + "&secret_key=" + secret_key;
        string signature =  sha256(msg.c_str());
        
        vector <string> extra_http_header;
        string header_chunk="User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/x-www-form-urlencoded";
        extra_http_header.push_back(header_chunk);
        header_chunk="Authorization:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk="AccessId:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                
                if(json_result["code"].asInt64() == 0)               
                    price = atof( json_result["data"]["last_deal_price"].asString().c_str());
                    
                if(price <= 0)
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    string err = get_id() + ": error send_order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Coinex: sned_order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
    }
   
    map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }
    
    double get_minQty(string symbol){
        Json::Value json_result;
        string s = "https://api.coinex.com/perpetual/v1/market/list";  
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        double minQty = 0;
        int i = 0; 

        try{        
            get_curl(s, json_result);

            if(json_result["code"].asInt64() == 0 && json_result["message"].asString() == "OK")
                while(json_result["data"][i]["name"].asString() != symbol) {i++;}
                
            if(json_result["data"][i]["name"].asString() == symbol)
                minQty = atof( json_result["data"][i]["amount_min"].asString().c_str());

            if(minQty == 0)
                throw exception();  
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in get_minQty ";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }
        return minQty;
    }
    
    bool set_leverage( string symbol ) {
        Json::Value json_result;
        int leverage = 0;

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url = "https://api.coinex.com/perpetual/v1/market/adjust_leverage?";
        string action = "POST";	
        string ep = to_string (get_current_ms_epoch());
            
        string post_data = "access_id=" + api_key + "&leverage=" + to_string(LEVERAGE) + "&market=" + symbol + "&position_type=2&timestamp=" + ep;
        string msg = post_data + "&secret_key=" + secret_key;
        string signature =  sha256(msg.c_str());
        
        vector <string> extra_http_header;
        string header_chunk="User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/x-www-form-urlencoded";
        extra_http_header.push_back(header_chunk);
        header_chunk="Authorization:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk="AccessId:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        try {
            Json::Reader reader;
            json_result.clear();	
            reader.parse( str_result , json_result );
            
            if(json_result["code"].asInt64() == 0 && json_result["message"].asString() == "OK")
                leverage = atof( json_result["data"]["leverage"].asString().c_str());
                
            if(leverage != LEVERAGE)
                throw exception();
        		
        	} catch ( exception &e ) {
         	    string err = get_id() + ": error set_leverage response, ";
         	    err.append( e.what() );
                writte_log(err);
                cout << json_result << endl;
                return 0;
        }   
        return 1;
    }

    map < string, map <double,double> > curl_depth(string symbol){
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string  s = "{\"method\":\"depth.query\",\"params\":[\"" + symbol + "\",50,\"0\"],\"id\":15}";
        mtxW.lock();
        write_Socket(s);
        mtxW.unlock();
        num = 0;
        while(num == 0){std::this_thread::sleep_for(std::chrono::microseconds(1));}
        return depthCache;
    }
};
