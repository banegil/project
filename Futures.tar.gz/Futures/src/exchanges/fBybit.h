

class fBybit: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "yAMi0Oz7Os5Wtiv0or";
    string secret_key = "t9nU58iFZz4l1Vo5SSe2PSGHia8TkOJl4gyA";
    
    public:
    fBybit(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.bytick.com/v2/public/orderBook/L2?symbol=" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();

            mtxDepth.lock(); 
         	
         	depth.clear(); 
     		for  ( int i = 0 ; i < result["result"].size() ; i++ ) {
     		    if(result["result"][i]["side"].asString() == "Buy"){
	                double price = atof( result["result"][i]["price"].asString().c_str() );
	                double qty   = atof( result["result"][i]["size"].asString().c_str() );
	                depth["bids"][price] = qty;
	            }
	            else{
	                double price = atof( result["result"][i]["price"].asString().c_str() );
	                double qty   = atof( result["result"][i]["size"].asString().c_str() );
	                depth["asks"][price] = qty;
	            }
            }

            mtxDepth.unlock();
        
        } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){  
    try{
        time_t current_time;
        init_http("stream.bytick.com");
        string symbol2 = symbol;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        init_webSocket("stream.bytick.com", "443", "/realtime_public");
        string s = "{\"op\": \"subscribe\", \"args\": [\"orderBookL2_25." + symbol + "\"]}";
        write_Socket(s);
        Json::Reader reader;
	    Json::Value json_result;
        read_Socket();	
        buffer_clear();

        time(&current_time);
        int ct = current_time;
        int ct3 = ct;
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            int ct4 = ct2;
            Json::Reader reader;
	        Json::Value json_result;
            if(ct2 - ct >= 25){
                ct = ct2;
                write_Socket(R"({"op":"ping"})");
            }
            read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();
      
            mtxDepth.lock();
       
         	if(json_result.isMember("topic")){	
             	if(ct4 - ct3 > TIME_REFRESH && (json_result["data"]["insert"].size() > 0 || json_result["data"]["update"].size() > 0)){ 
                    ct3 = ct4;
                    depth.clear();
                }
                        	
                for ( int i = 0 ; i < json_result["data"]["delete"].size(); i++ ) {
                    double price = atof( json_result["data"]["delete"][i]["price"].asString().c_str() );
                    if(json_result["data"]["delete"][i]["side"].asString() == "Buy")
                        depth["bids"].erase(price);
                    else
                        depth["asks"].erase(price);
                }
                
                for ( int i = 0 ; i < json_result["data"]["insert"].size(); i++ ) {
                    double price = atof( json_result["data"]["insert"][i]["price"].asString().c_str() );
                    double qty   = atof( json_result["data"]["insert"][i]["size"].asString().c_str() );
                    if(json_result["data"]["insert"][i]["side"].asString() == "Buy")
                        depth["bids"][price] = qty;
                    else
                        depth["asks"][price] = qty;
                }
                
                for ( int i = 0 ; i < json_result["data"]["update"].size(); i++ ) {
                    double price = atof( json_result["data"]["update"][i]["price"].asString().c_str() );
                    double qty   = atof( json_result["data"]["update"][i]["size"].asString().c_str() );
                    if(json_result["data"]["update"][i]["side"].asString() == "Buy")
                        depth["bids"][price] = qty;
                    else
                        depth["asks"][price] = qty;
                }
            }               
            else if (!json_result.isMember("pong") && !json_result.isMember("request"))
                throw exception();
                
            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
