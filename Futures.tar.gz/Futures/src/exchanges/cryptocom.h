

class Cryptocom: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    Cryptocom(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol[symbol.find('-')] = '_';
        string s = "https://api.crypto.com/v2/public/get-book?instrument_name=" + symbol + "&depth=100";
        
        try{
            get_curl(s, result);
         	
         	mtxDepth.lock();
         	
         	depth.clear(); 
            for ( int i = 0 ; i < result["result"]["data"][0]["asks"].size(); i++ ) {
	            double price = atof( result["result"]["data"][0]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["result"]["data"][0]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["result"]["data"][0]["bids"].size() ; i++ ) {
	            double price = atof( result["result"]["data"][0]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["result"]["data"][0]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	        
            mtxDepth.unlock();
        
        } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time; 
        init_http("stream.crypto.com");
        string symbol2 = symbol;
        
        try {
            symbol[symbol.find('-')] = '_';
            init_webSocket("stream.crypto.com", "443",  "/v2/market");
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            string s = "{\"id\": 11,\"method\": \"subscribe\",\"params\": {\"channels\": [\"book." + symbol + ".150\"]},\"nonce\": 1587523073344}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
	        read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();

            time(&current_time);
            int ct = current_time;
            while (true) {
                Json::Reader reader;
		        Json::Value json_result;
                time(&current_time);
                int ct2 = current_time;
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&Cryptocom::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();

                if(json_result.isMember("result") && (json_result["result"]["data"][0].isMember("asks") || json_result["result"]["data"][0].isMember("bids"))){	
             	        
                 		for  ( int i = 0 ; i < json_result["result"]["data"][0]["asks"].size() ; i++ ) {
                 	        double price = atof( json_result["result"]["data"][0]["asks"][i][0].asString().c_str() );
	                        double qty   = atof( json_result["result"]["data"][0]["asks"][i][1].asString().c_str() );
                 		    if ( qty == 0.0 ) 
		                        depth["asks"].erase(price);
	                        else 
		                        depth["asks"][price] = qty;
                        }
                        for  ( int i = 0 ; i < json_result["result"]["data"][0]["bids"].size() ; i++ ) {
                 	        double price = atof( json_result["result"]["data"][0]["bids"][i][0].asString().c_str() );
	                        double qty   = atof( json_result["result"]["data"][0]["bids"][i][1].asString().c_str() );
                 		    if ( qty == 0.0 ) 
		                        depth["bids"].erase(price);
	                        else 
		                        depth["bids"][price] = qty;
                        }
                }
                else {
                    write_Socket(R"({"id":1648636980587,"method":"public/respond-heartbeat"})"); 
                    if(json_result["method"].asString() != "public/heartbeat")
                        throw exception();
                }
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                set_id();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		     	//cout << json_result << '\n';
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        /*Json::Value json_result;
        string err;

        string ep = to_string (get_current_ms_epoch());

        string url("https://api.crypto.com/v2/");
        string action = "POST";
        
        string post_data = "";
        string msg = "{
             \"id\": 11,
             \"method\": \"private/create-order\",
             \"params\": {
               \"instrument_name\": \"ETH_CRO\",
               \"side\": \"BUY\",
               \"type\": \"MARKET\",
               \"quantity\": 1.2,
               \"client_oid\": \"my_order_0002\",
               \"time_in_force\": \"GOOD_TILL_CANCEL\",
               \"exec_inst\": \"POST_ONLY\"},
             \"nonce\": 1587846358253}";
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="X-ACCESS-NONCE:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "X-ACCESS-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "X-ACCESS-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Aax: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Aax: order.size() is 0";
            writte_log(err);
        }*/
   }
   
    double get_minQty(string symbol){
        Json::Value json_result;
        symbol[symbol.find('-')] = '_';
        string s = "https://api.crypto.com/v2/public/get-instruments";   
        int i = 0;
        double minQty = 0;

        try{        
            get_curl(s, json_result);

            if(json_result["code"].asInt64() == 0)
                while(minQty == 0 && i < json_result["result"]["instruments"].size())
                    if(json_result["result"]["instruments"][i++]["instrument_name"].asString() == symbol)
                        minQty = atof( json_result["result"]["instruments"][i - 1]["min_quantity"].asString().c_str() );
            
            if(minQty != 0)
                cout << get_id() << '\n';
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in exist()";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }      
        return minQty;
    }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};

