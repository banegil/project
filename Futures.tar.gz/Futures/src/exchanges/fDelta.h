

class fDelta: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    fDelta(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.delta.exchange/v2/l2orderbook/" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();    	
         	
         	mtxDepth.lock();
         	
         	depth.clear();                  
            for ( int i = 0 ; i < result["result"]["buy"].size(); i++ ) {
	            double price = atof( result["result"]["buy"][i]["price"].asString().c_str() );
	            double qty   = atof( result["result"]["buy"][i]["size"].asString().c_str() );
	            depth["bids"][price] = qty;
            }
            for  ( int i = 0 ; i < result["result"]["sell"].size() ; i++ ) {
	            double price = atof( result["result"]["sell"][i]["price"].asString().c_str() );
	            double qty   = atof( result["result"]["sell"][i]["size"].asString().c_str() );
	            depth["asks"][price] = qty;
            }
	            
	        mtxDepth.unlock();

	        } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){  
    try{
        init_http("socket.delta.exchange");
        long ts = 0;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        init_webSocket("socket.delta.exchange", "443", "/");
        string s = "{\"type\": \"subscribe\",\"payload\": {\"channels\": [{\"name\": \"l2_orderbook\",\"symbols\": [\"" + symbol + "\"]}]}}";
        write_Socket(s);
        Json::Reader reader;
        Json::Value result;
        read_Socket();	
        buffer_clear();

        while (true) {
            Json::Reader reader;
            Json::Value result;
            read_Socket();	
	        reader.parse( get_socket_data() , result );
            buffer_clear();

            mtxDepth.lock();

            if(result["timestamp"].asInt64() >= ts && (result.isMember("buy") || result.isMember("sell"))){	
                ts = result["timestamp"].asInt64();
                
                depth.clear();
                for ( int i = 0 ; i < result["buy"].size(); i++ ) {
                    double price = atof( result["buy"][i]["limit_price"].asString().c_str() );
                    double qty   = atof( result["buy"][i]["size"].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }
                for ( int i = 0 ; i < result["sell"].size(); i++ ) {
                    double price = atof( result["sell"][i]["limit_price"].asString().c_str() );
                    double qty   = atof( result["sell"][i]["size"].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                }
            }
            
            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
