

class fDelta: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "kk4bFdIRobP9XhEa1xoyI8Iha4fcyu";
    string secret_key = "CJGBzz0VzyhftF0whPoibw749cAyAXt1JTEjnJGo3VoTYdOFgHQR78XnFIz6";
    
    public:
    fDelta(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> > depthCache;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.delta.exchange/v2/l2orderbook/" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();    	
         	
         	mtxDepth.lock();
         	
         	depth.clear();                  
            for ( int i = 0 ; i < result["result"]["buy"].size(); i++ ) {
	            double price = atof( result["result"]["buy"][i]["price"].asString().c_str() );
	            double qty   = atof( result["result"]["buy"][i]["size"].asString().c_str() );
	            depth["bids"][price] = qty;
            }
            for  ( int i = 0 ; i < result["result"]["sell"].size() ; i++ ) {
	            double price = atof( result["result"]["sell"][i]["price"].asString().c_str() );
	            double qty   = atof( result["result"]["sell"][i]["size"].asString().c_str() );
	            depth["asks"][price] = qty;
            }
	            
	        mtxDepth.unlock();
	        
	        if(depth.empty())
	            throw exception();
	        
	        depthCache = depth;

	        } catch (std::exception const& e) {
            depth.clear();
            depthCache.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return depthCache;
      }
      return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
    try{
        init_http("socket.delta.exchange");
        long ts = 0;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        init_webSocket("socket.delta.exchange", "443", "/");
        string s = "{\"type\": \"subscribe\",\"payload\": {\"channels\": [{\"name\": \"l2_orderbook\",\"symbols\": [\"" + symbol + "\"]}]}}";
        write_Socket(s);
        Json::Reader reader;
        Json::Value result;
        read_Socket();	
        buffer_clear();

        while (true) {
            Json::Reader reader;
            Json::Value result;
            read_Socket();	
	        reader.parse( get_socket_data() , result );
            buffer_clear();

            mtxDepth.lock();

            if(result["timestamp"].asInt64() >= ts && (result.isMember("buy") || result.isMember("sell"))){	
                ts = result["timestamp"].asInt64();
                
                depth.clear();
                for ( int i = 0 ; i < result["buy"].size(); i++ ) {
                    double price = atof( result["buy"][i]["limit_price"].asString().c_str() );
                    double qty   = atof( result["buy"][i]["size"].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }
                for ( int i = 0 ; i < result["sell"].size(); i++ ) {
                    double price = atof( result["sell"][i]["limit_price"].asString().c_str() );
                    double qty   = atof( result["sell"][i]["size"].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                }
            }
            
            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    bool send_order( string symbol, string side, double quantity, double price, bool open ) {	
        /*Json::Value json_result;
        string err;
        time_t current_time;
        time(&current_time);
        int ct = current_time;
        string ep = to_string (ct);

        string url("https://api.delta.exchange/v2/orders");
        string action = "POST";
        
        string post_data  = "{\"order_type\":\"limit_order\",\"size\":3,\"side\":\"buy\",\"limit_price\":\"0.0005\",\"product_id\":16}";
        string msg = action + ep + "/orders" + post_data;
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="api-key:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "timestamp:" + ep;
        extra_http_header.push_back(header_chunk);
        header_chunk = "signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk="User-Agent: rest-client";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Ascendex: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    return false;
            }   
        } 
        else {
            err = "Ascendex: order.size() is 0";
            writte_log(err);
            return false;
        }*/
        return true;
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
