

class fGateio: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "d12c6b411de430840c474455e25285fd";
    string secret_key = "d7ae70d34d768d9a140ed6b61ae8f31b281e0f1b006762b4ee9f21c4f52e0460";
    double minQty = 0;
        
    public:
    fGateio(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> > depthCache;
        symbol[symbol.find('-')] = '_';
        string s = "https://api.gateio.ws/api/v4/futures/usdt/order_book?contract=" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	cout << result << endl;
         	mtxDepth.lock();     
         	
         	depth.clear(); 
            for ( int i = 0 ; i < result["asks"].size(); i++ ) {
	            double price = atof( result["asks"][i]["p"].asString().c_str() );
	            double qty   = atof( result["asks"][i]["s"].asString().c_str() ) * minQty;
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
	            double price = atof( result["bids"][i]["p"].asString().c_str() );
	            double qty   = atof( result["bids"][i]["s"].asString().c_str() ) * minQty;
	            depth["bids"][price] = qty;
            }

            mtxDepth.unlock(); 
            
            if(depth.empty())
                throw exception();
            
            depthCache = depth;
        
      } catch (std::exception const& e) {
            depthCache.clear();
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return depthCache;
      }  
      return depthCache; 
    }
    
    void wesbsocketInit_depth(string symbol){
    try{
        time_t current_time; 
        init_http("fx-ws.gateio.ws");
        pair<double,double> a, b;
        long ts = 0;
        
        time(&current_time);
        int ct = current_time;
        symbol[symbol.find('-')] = '_';
        init_webSocket("fx-ws.gateio.ws", "443", "/v4/ws/usdt");
        string s = "{\"time\" : " + to_string(ct) + ", \"channel\" : \"futures.order_book\", \"event\": \"subscribe\", \"payload\" : [\"" + symbol + "\", \"20\", \"0\"]}";
        write_Socket(s);
        s = "{\"time\" : " + to_string(ct) + ", \"channel\" : \"futures.book_ticker\", \"event\": \"subscribe\", \"payload\" : [\"" + symbol + "\"]}";
        write_Socket(s);
        Json::Reader reader;
	    Json::Value json_result;
        read_Socket();	
	    reader.parse( get_socket_data() , json_result );
        buffer_clear();
      
        while (true) {
            Json::Reader reader;
	        Json::Value json_result;
            time(&current_time);
            int ct2 = current_time;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();

            mtxDepth.lock();               
            
            if(json_result["channel"].asString() == "futures.book_ticker" && json_result["result"]["t"].asInt64() >= ts){
                ts = json_result["result"]["t"].asInt64();
                a.first = atof( json_result["result"]["a"].asString().c_str());
                a.second = atof( json_result["result"]["A"].asString().c_str());
                if ( a.second == 0.0 ) 
                    depth["asks"].erase(a.first);
                else 
                    depth["asks"][a.first] = a.second * minQty;
                b.first = atof( json_result["result"]["b"].asString().c_str());
                b.second = atof( json_result["result"]["B"].asString().c_str());
                if ( b.second == 0.0 ) 
                    depth["bids"].erase(b.first);
                else 
                    depth["bids"][b.first] = b.second * minQty;
            }
            else if(json_result["channel"].asString() == "futures.order_book"){
                depth.clear();
                for ( int i = 0 ; i < json_result["result"]["bids"].size() ; i++ ) {
                    double price = atof( json_result["result"]["bids"][i]["p"].asString().c_str());
                    double qty 	 = atof( json_result["result"]["bids"][i]["s"].asString().c_str());
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty * minQty;
                }
                for ( int i = 0 ; i < json_result["result"]["asks"].size() ; i++ ) {
                    double price = atof( json_result["result"]["asks"][i]["p"].asString().c_str());
                    double qty 	 = atof( json_result["result"]["asks"][i]["s"].asString().c_str());
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty * minQty;
                }
                
                if(json_result["result"]["t"].asInt64() < ts){
                    depth["asks"][a.first] = a.second * minQty;
                    depth["bids"][b.first] = b.second * minQty;
                }
                ts = json_result["result"]["t"].asInt64();
            }
                
            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    double send_order( string symbol, string side, double quantity, bool open ) {	
        time_t current_time;
        Json::Value json_result;
        double price = -1;
        string err, reduceOnly = "true";

        int t = time(&current_time);
        string ep = to_string(t);

        symbol[symbol.find('-')] = '_';
        string url("https://api.gateio.ws/api/v4/futures/usdt/orders");
        string action = "POST";
        
        if(side == "sell")
            quantity *= -1;
            
        if(open)
            reduceOnly = "false";   
            
        string_toupper(side);
        string post_data = "{\"contract\":\"" + symbol + "\",\"size\":" + to_string(quantity / minQty) + ",\"iceberg\":0,\"price\":\"0\",\"reduce_only\":" + reduceOnly + ",\"tif\":\"ioc\",\"text\":\"t-my-custom-id\"}";
        string msg = action + "\n" + "/api/v4/futures/usdt/orders" + "\n" + "\n" + sha512( post_data.c_str() ) + "\n" + ep;
        
        string signature =  hmac_sha512( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Timestamp:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;

        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result);
	            
	            if(!json_result.isMember("detail") && !json_result.isMember("label") && json_result.isMember("finish_as") && json_result["finish_as"].asString() == "filled")
	                price = atof( json_result["fill_price"].asString().c_str());
	                
	            if(price <= 0)
	                throw exception();
            		
            	} catch ( exception &e ) {
         	        string err = get_id() + ": error send_order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Gateio: send_order(), order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
   }
   
    double get_minQty(string symbol){
        Json::Value json_result;
        symbol[symbol.find('-')] = '_';  
        string s = "https://api.gateio.ws/api/v4/futures/usdt/contracts/" + symbol;   

        try{        
            get_curl(s, json_result);

            minQty = atof( json_result["quanto_multiplier"].asString().c_str() );

            if(minQty == 0)
                throw exception();  
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in set_minQty ";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }
        return minQty;
    }
    
    bool set_leverage( string symbol ) {	
        time_t current_time;
        Json::Value json_result;
        int leverage = 0;

        int t = time(&current_time);
        string ep = to_string(t);

        symbol[symbol.find('-')] = '_';
        string url= "https://api.gateio.ws/api/v4/futures/usdt/positions/" + symbol + "/leverage?leverage=" + to_string(LEVERAGE);
        string action = "POST"; 
            
        string post_data = "{\"leverage\":\"" + to_string(LEVERAGE) + "\"}";
        string msg = action + "\n" + "/api/v4/futures/usdt/positions/" + symbol + "/leverage" + "\n" + "leverage=" + to_string(LEVERAGE) + "\n" + sha512( post_data.c_str() ) + "\n" + ep;
        
        string signature =  hmac_sha512( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Timestamp:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        try {
            Json::Reader reader;
            json_result.clear();	
            reader.parse( str_result , json_result);
            
            leverage = atoi( json_result["leverage"].asString().c_str());
            
            if(leverage != LEVERAGE)
                throw exception();
        		
        	} catch ( exception &e ) {
     	        string err = get_id() + ": error set_leverage response, ";
         	    err.append( e.what() );
                writte_log(err);
                cout << json_result << endl;
                return 0;
        }   
        return 1;
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
