

class fPhemex: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "4a2216b8-341d-4eda-9396-55cb156ae26d";
    string secret_key = "kJ8MPAmjchp3nTEC-Lwo5i_cl90GVqwzf8a9sXab2Bw5ZTM1ODM0Yi00NGI5LTRkM2MtODcxNy0yMWFkZjU4ZDkzZjY";
    
    public:
    fPhemex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        symbol.erase(symbol.size() - 1);
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.phemex.com/md/orderbook?symbol=" + symbol;
        map < string, map <double,double> > depthCache;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	
            mtxDepth.lock();
            
            depth.clear();    
            for ( int i = 0 ; i < result["result"]["book"]["asks"].size(); i++ ) {
	            double price = atof( result["result"]["book"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["result"]["book"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price / 10000] = qty;
            }
            for  ( int i = 0 ; i < result["result"]["book"]["bids"].size() ; i++ ) {
	            double price = atof( result["result"]["book"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["result"]["book"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price / 10000] = qty;
            }
	     
	        mtxDepth.unlock();
	        
	        depthCache = depth;
	    
            } catch (std::exception const& e) {
            depthCache.clear();
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return depthCache;
      }
      return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
    try{
        string symbol2 = symbol;
        time_t current_time;
        init_http("phemex.com");
        long ts = 0, ts2;
        
        symbol.erase(symbol.size() - 1);
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        init_webSocket("phemex.com", "443", "/ws");
        string s = "{\"id\": 1234,\"method\": \"orderbook.subscribe\",\"params\": [\"" + symbol + "\"]}";
        write_Socket(s);
        Json::Reader reader;
        Json::Value result;
        for(int i = 0; i < 2; i++){
            read_Socket();	
            buffer_clear();
        }

        time(&current_time);
        int ct = current_time;
        int ct3 = ct;
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            int ct4 = ct2;
            Json::Reader reader;
            Json::Value result;
            read_Socket();	
	        reader.parse( get_socket_data() , result );
            buffer_clear();             

            if(ct4- ct3 > 20){
                ct3 = ct4;
                s = "{\"id\": 1234,\"method\": \"server.ping\",\"params\": []}";
                write_Socket(s);                
            }

            if( ct2 - ct > 5){ 
                ct = ct2;
                std::async (&fPhemex::curl_depth, this, symbol2);
            }

            mtxDepth.lock();
            
            ts2 = result["timestamp"].asInt64();
            if(ts2 >= ts){
                ts = ts2;
                
                for ( int i = 0 ; i < result["book"]["asks"].size(); i++ ) {
                    double price = atof( result["book"]["asks"][i][0].asString().c_str() ) / 10000;
                    double qty   = atof( result["book"]["asks"][i][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                }
                for ( int i = 0 ; i < result["book"]["bids"].size(); i++ ) {
                    double price = atof( result["book"]["bids"][i][0].asString().c_str() ) / 10000;
                    double qty   = atof( result["book"]["bids"][i][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }
            }
            
            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    bool send_order( string symbol, string side, double quantity, double price ) {	
        time_t current_time;
        Json::Value json_result;
        string err;

        time(&current_time);
        int ct = current_time;
        string ep = to_string (ct + 60);
        cout << ct << endl;

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url("https://api.phemex.com/orders");
        string action = "POST";
        
        string_toupper(side);
        string post_data = "{\"symbol\":\"BTCUSD\",\"clOrdID\":\"uuid-1573058952611\",\"side\":\"Sell\",\"priceEp\":93185000,\"orderQty\":7,\"ordType\":\"Limit\",\"reduceOnly\":false,\"timeInForce\":\"GoodTillCancel\",\"takeProfitEp\":0,\"stopLossEp\":0}";
        string msg = "/orders" + ep + post_data;
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="x-phemex-access-token:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "x-phemex-request-expiry:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "x-phemex-request-signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = get_id() + ": error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    return false;
            }   
        } 
        else {
            err = get_id() + ": order.size() is 0";
            writte_log(err);
            return false;
        }
        return true;
    }
   
    map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }
};
