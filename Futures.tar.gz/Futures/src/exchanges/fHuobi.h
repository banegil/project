

class fHuobi: public Exchange {
    mutex mtxDepth,mtxCurl;
    map < string, map <double,double> >  depth;
    
    public:
    fHuobi(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    void curl_depth(string symbol){
        Json::Value result; 
        
        string s = "https://api.hbdm.com/linear-swap-ex/market/depth?contract_code=" + symbol + "&type=step0";
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
  	
         	mtxDepth.lock();
         	
         	depth.clear(); 
            for ( int i = 0 ; i < result["tick"]["asks"].size(); i++ ) {
	            double price = atof( result["tick"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["tick"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["tick"]["bids"].size() ; i++ ) {
	            double price = atof( result["tick"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["tick"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	        
            mtxDepth.unlock();
        
      } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){
    try{
        time_t current_time; 
        init_http("api.hbdm.com");
        string symbol2 = symbol;
        pair<double,double> a, b;
        long ts = 0;
        
        transform(symbol.begin(), symbol.end(), symbol.begin(),
        [](unsigned char c){ return tolower(c); });
        init_webSocket("api.hbdm.com", "443", "/linear-swap-ws");
        string s = "{\"sub\": \"market." + symbol + ".depth.size_150.high_freq\",\"data_type\":\"incremental\"}";
        write_Socket(s);
        s = "{\"sub\": \"market." + symbol2 + ".bbo\",\"id\": \"id8\"}";
        write_Socket(s);
        Json::Reader reader;
	    Json::Value json_result;
	    for(int i = 0; i < 2; i++){
            read_Socket();	
            buffer_clear();
        }
        
        time(&current_time);
        int ct = current_time;
        while (true) {
            Json::Reader reader;
	        Json::Value json_result;
            time(&current_time);
            int ct2 = current_time;
            read_Socket();	
            s = decompress_gzip(get_socket_data());
	        reader.parse( s , json_result );
            buffer_clear();
          
            mtxDepth.lock();
            
            if(json_result.isMember("tick")){
                if ((json_result["tick"].isMember("bid") || json_result["tick"].isMember("ask")) && json_result["ts"].asInt64() >= ts){
        	        a.first = atof( json_result["tick"]["ask"][0].asString().c_str() );
                    a.second = atof( json_result["tick"]["ask"][1].asString().c_str() );

                    if ( a.second == 0.0 ) 
                        depth["asks"].erase(a.first);
                    else 
                        depth["asks"][a.first] = a.second;
                    b.first = atof( json_result["tick"]["bid"][0].asString().c_str() );
                    b.second = atof( json_result["tick"]["bid"][1].asString().c_str() );
                    if ( b.second == 0.0 ) 
                        depth["bids"].erase(b.first);
                    else 
                        depth["bids"][b.first] = b.second;
                } 
                else if(json_result["tick"].isMember("bids") || json_result["tick"].isMember("asks")){
                    if(ct2 - ct > TIME_REFRESH){ 
                        ct = ct2;
                        depth.clear();
                    }
                    
                    for ( int i = 0 ; i < json_result["tick"]["bids"].size() ; i++ ) {
                        double price = atof( json_result["tick"]["bids"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["tick"]["bids"][i][1].asString().c_str());
                        if ( qty == 0.0 ) {
                            depth["bids"].erase(price);
                        } else {
                            depth["bids"][price] = qty;
                        }
                    }
                    for ( int i = 0 ; i < json_result["tick"]["asks"].size() ; i++ ) {
                        double price = atof( json_result["tick"]["asks"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["tick"]["asks"][i][1].asString().c_str());
                        if ( qty == 0.0 ) {
                            depth["asks"].erase(price);
                        } else {
                            depth["asks"][price] = qty;
                        }
                    }
                    
                    if(json_result["ts"].asInt64() < ts){
                        depth["asks"][a.first] = a.second;
                        depth["bids"][b.first] = b.second;
                    }
                }                   
                ts = json_result["ts"].asInt64();
            }
            else if(json_result.isMember("ping")){
                int j = json_result["ping"].asUInt64();
                s = "{\"pong\": " + to_string(j) + "}";
                write_Socket(s);
            }

            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};

