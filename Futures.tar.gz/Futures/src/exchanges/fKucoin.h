


class fKucoin: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "627594311d2fe700017c0de5";
    string secret_key = "51cf2538-5f4c-4667-b8df-08aadbbef81c";
    double minQty = 0;
    
    public:
    fKucoin(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> > depthCache;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api-futures.kucoin.com/api/v1/level2/snapshot?symbol=" + symbol + "M";
 
        try{
            mtxCurl.lock();
            get_curl(s, result);     	
            mtxCurl.unlock();

         	mtxDepth.lock();
         	                
            depth.clear(); 
            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	            double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty * minQty;
            }
            for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	            double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty * minQty;
            }
	            
	        mtxDepth.unlock();
	        
	        if(depth.empty())
	            throw exception();
	        
	        depthCache = depth;
	    
	    } catch (std::exception const& e) {
            depth.clear();
            depthCache.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return depthCache;
      }
      return depthCache;
    }
   
    void wesbsocketInit_depth(string symbol){
    try{
        time_t current_time;
        int pingInterval;
        string token, endpoints;
        string idC = "154591120590802";
        string s = "https://api-futures.kucoin.com/api/v1/bullet-public";
        Json::Value result;
        post_curl(s, result, "");
        endpoints = result["data"]["instanceServers"][0]["endpoint"].asString();
        string endpoint = endpoints.substr(6,17);
        token = result["data"]["token"].asString();
        pingInterval = result["data"]["instanceServers"][0]["pingInterval"].asUInt64();
        pingInterval /= 1000;
        init_http(endpoint);
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        long ts = 0;
        pair<double,double> a, b;

        s = "/endpoint?token=" + token + "&[connectId=" + idC + "]";
        init_webSocket(endpoint, "443", s.c_str());
        Json::Reader reader;
        Json::Value json_result;
        read_Socket();	
        reader.parse( get_socket_data() , json_result );
        buffer_clear();
        write_Socket(R"({"id":"154591120590802","type":"ping"})");
        s = "{\"id\": 154591120590802,\"type\": \"subscribe\",\"topic\": \"/contractMarket/level2Depth50:" + symbol + "M\",\"response\": true}";
        write_Socket(s);
        s = "{\"id\": 154591120590802,\"type\": \"subscribe\",\"topic\": \"/contractMarket/tickerV2:" + symbol + "M\",\"response\": true}";
        write_Socket(s);
        
        time(&current_time);
        int ct = current_time;
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            if(ct2 - ct >= pingInterval - 2){
                ct = ct2;
                write_Socket(R"({"id":"154591120590802","type":"ping"})");
            }
            Json::Reader reader;
            Json::Value json_result;
            read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();

            mtxDepth.lock();

            if(json_result.isMember("data")){
                if(json_result["subject"].asString() == "level2"){                  
                    depth.clear();
                    for ( int i = 0 ; i < json_result["data"]["bids"].size() ; i++ ) {
                        double price = atof( json_result["data"]["bids"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["data"]["bids"][i][1].asString().c_str());
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty * minQty;
                    }
                    for ( int i = 0 ; i < json_result["data"]["asks"].size() ; i++ ) {
                        double price = atof( json_result["data"]["asks"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["data"]["asks"][i][1].asString().c_str());
                        if ( qty == 0.0 ) 
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty * minQty;
                    }
                    
                    if(json_result["data"]["timestamp"].asInt64() < ts){
                        depth["asks"][a.first] = a.second * minQty;
                        depth["bids"][b.first] = b.second * minQty;
                    } 
                    ts = json_result["data"]["timestamp"].asInt64() * 1000000;
                }
                else if(json_result["subject"].asString() == "tickerV2" && json_result["data"]["ts"].asInt64() >= ts){
                    ts = json_result["data"]["ts"].asInt64();
                    a.first = atof( json_result["data"]["bestBidPrice"].asString().c_str());
                    a.second  = atof( json_result["data"]["bestBidSize"].asString().c_str());
                    if ( a.second == 0.0 ) 
                        depth["bids"].erase(a.first);
                    else 
                        depth["bids"][a.first] = a.second * minQty;
                    b.first = atof( json_result["data"]["bestAskPrice"].asString().c_str());
                    b.second = atof( json_result["data"]["bestAskSize"].asString().c_str());
                    if ( b.second == 0.0 ) 
                        depth["asks"].erase(b.first);
                    else 
                        depth["asks"][b.first] = b.second * minQty;                            
                }
             }
             else if(!(json_result["type"].asString() == "pong" || json_result["type"].asString() == "ack"))
                throw exception(); 
             
             mtxDepth.unlock();	
                
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    double send_order( string symbol, string side, double quantity, bool open ) {	
        Json::Value json_result;
        string err, reduceOnly = "true";
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string ep = to_string (get_current_ms_epoch());
        double price = -1;
        long qty = quantity;
        qty /= minQty;

        string url("https://api-futures.kucoin.com/api/v1/orders");
        string action = "POST";
        
        if(open)
            reduceOnly = "false";   
        
        string post_data = "{\"clientOid\":\"154591120590801\",\"side\":\"" + side + "\",\"symbol\":\"" + symbol + "M\",\"type\":\"market\",\"leverage\":\"" + to_string(LEVERAGE) + "\",\"reduceOnly\":" + reduceOnly + ",\"size\":" + to_string(qty) + "}";
        string msg = ep + action + "/api/v1/orders" + post_data;
        string ph = "tradingKucoin";
        
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        string phrase = hmac_sha256h( secret_key.c_str(), ph.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk = "KC-API-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-TIMESTAMP:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk="KC-API-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-PASSPHRASE:";
        header_chunk.append( phrase );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-KEY-VERSION:2";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            std::this_thread::sleep_for(std::chrono::milliseconds(7000));

	            if(json_result.isMember("code") && json_result["code"].asString() == "200000")
	                price = get_order(json_result["data"]["orderId"].asString());
	                
	            if(price <= 0)
	                throw exception();
            		
            	} catch ( exception &e ) {
             	    err = "Kucoin: error reading send_order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Kucoin: send_order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
   }
   
    double get_order( string order_id ) {	
        Json::Value json_result;
        string err;
        string ep = to_string (get_current_ms_epoch());
        double price = -1;

        string url = "https://api-futures.kucoin.com/api/v1/orders/" + order_id;
        string action = "GET"; 
        
        string post_data = "";
        string msg = ep + action + "/api/v1/orders/" + order_id;
        string ph = "tradingKucoin";
        
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        string phrase = hmac_sha256h( secret_key.c_str(), ph.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk = "KC-API-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-TIMESTAMP:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk="KC-API-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-PASSPHRASE:";
        header_chunk.append( phrase );
        extra_http_header.push_back(header_chunk);
        header_chunk = "KC-API-KEY-VERSION:2";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );

	            if(json_result.isMember("code") && json_result["code"].asString() == "200000")
	                price = (atof(json_result["data"]["filledValue"].asString().c_str()) / atof(json_result["data"]["filledSize"].asString().c_str())) / 1000 ;
	            if(price <= 0)
	                throw exception();
	                
	            price /= 0.01;
	                           		
            	} catch ( exception &e ) {
             	    err = "Kucoin: error reading get_order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Kucoin: get_order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
   }
   
    double get_minQty(string symbol){
        Json::Value json_result; 
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api-futures.kucoin.com/api/v1/contracts/" + symbol + "M"; 

        try{        
            get_curl(s, json_result);

            if(json_result["code"].asString() == "200000")
                minQty = json_result["data"]["multiplier"].asDouble();

            minQty = 10; 
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in set_minQty ";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }
        return minQty;
    }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
