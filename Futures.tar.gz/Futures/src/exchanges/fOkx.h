class fOkx: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "b5edb994-633d-4a7f-ada8-ca2118e8f291";
    string secret_key = "0D96AFED82374BC7B3BC132473A20D6A";
    double minQty = 0;
    
    void sig(vector<string>& extra_http_header, string& signature, string& ep){
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="OK-ACCESS-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "OK-ACCESS-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "OK-ACCESS-TIMESTAMP:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "OK-ACCESS-PASSPHRASE:.Unbuitretraidor1.";
        extra_http_header.push_back(header_chunk);    
    }
    
    public:
    fOkx(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        string s = "https://aws.okx.com/api/v5/market/books?instId=" + symbol + "-SWAP&sz=100";
        map < string, map <double,double> > depthCache;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	
            mtxDepth.lock();
         		 
         	depth.clear(); 	    
            for ( int i = 0 ; i < result["data"][0]["asks"].size(); i++ ) {
	            double price = atof( result["data"][0]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["data"][0]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty * minQty;
            }
            for  ( int i = 0 ; i < result["data"][0]["bids"].size() ; i++ ) {
	            double price = atof( result["data"][0]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["data"][0]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty * minQty;
            }
	     
	        mtxDepth.unlock();
	    
	        depthCache = depth;
	        if(depthCache.empty())
	            throw exception();
	    
	  } catch (std::exception const& e) {
	        depthCache.clear();
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return depthCache;
      }
      return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
    try{
        string symbol2 = symbol;
        time_t current_time;
        init_http("wsaws.okx.com");
        long ts = 0, ts2;

        init_webSocket("wsaws.okx.com", "443", "/ws/v5/public");
        string s = "{\"op\":\"subscribe\",\"args\":[{\"channel\":\"books-l2-tbt\",\"instId\":\"" + symbol + "-SWAP\"}]}";
        write_Socket(s);
        Json::Reader reader;
	    Json::Value json_result;
	    for(int i = 0; i < 2; i++){
            read_Socket();	
            buffer_clear();
        }

        time(&current_time);
        int ct = current_time;
        while (true) {
            Json::Reader reader;
	        Json::Value json_result;
            time(&current_time);
            int ct2 = current_time;
            read_Socket();	
            reader.parse( get_socket_data() , json_result );
            buffer_clear();
            if(ct2 - ct > 5 ){ 
                ct = ct2;
                std::async (&fOkx::curl_depth, this, symbol2);
            }

            mtxDepth.lock();

            ts2 = atof( json_result["data"][0]["ts"].asString().c_str() );
            if(ts2 >= ts){
                ts = ts2;
             	      
         	    for  ( int i = 0 ; i < json_result["data"][0]["bids"].size() ; i++ ) {
                    double price = atof( json_result["data"][0]["bids"][i][0].asString().c_str() );
                    double qty   = atof( json_result["data"][0]["bids"][i][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty * minQty;
                        
                }
                for ( int i = 0 ; i < json_result["data"][0]["asks"].size() ; i++ ) {
                    double price = atof( json_result["data"][0]["asks"][i][0].asString().c_str() );
                    double qty   = atof( json_result["data"][0]["asks"][i][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty * minQty;
                }
            }
            
            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
    }
    
    double send_order( string symbol, string side, double quantity, bool open ) {	
        Json::Value json_result;
        string err, futSide, reduceOnly = "true";
        time_t now;
        time(&now);
        char buf[sizeof "2011-10-08T07:07:09Z"];
        strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", gmtime(&now));
        string ep = buf;
        string url("https://aws.okex.com/api/v5/trade/order");
        string action = "POST";
        double price = -1;
        int qty = quantity;
        
        if(open){
            futSide = side == "buy" ? "long" : "short";
            reduceOnly = "false";
        }
        else
            futSide = side == "buy" ? "short" : "long";

        string post_data = "{\"instId\":\"" + symbol + "-SWAP\",\"tdMode\":\"cross\",\"side\":\"" + side + "\",\"posSide\":\"" + futSide + "\",\"ordType\":\"market\",\"sz\":\"" + to_string(qty / minQty) + "\",\"reduceOnly\":" + reduceOnly + "}";        
        string msg = ep + action + "/api/v5/trade/order" + post_data;
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        sig(extra_http_header, signature, ep);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                
                if(json_result.isMember("code") && atoi( json_result["code"].asString().c_str() ) == 0)
                    price = get_price(symbol, json_result["data"][0]["ordId"].asString());            		
            		
                if(price <= 0)
                    throw exception();     
                
            	} catch ( exception &e ) {
             	    err = "Okx: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Okx: order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
    }
    
    double get_price( string symbol, string order_id ) {	
        Json::Value json_result;
        string err;
        time_t now;
        time(&now);
        char buf[sizeof "2011-10-08T07:07:09Z"];
        strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", gmtime(&now));
        string ep = buf;
        string url = "https://aws.okex.com/api/v5/trade/order?ordId=" + order_id + "&instId=" + symbol + "-SWAP";
        string action = "GET";
        double price = -1;

        string post_data = "";        
        string msg = ep + action + "/api/v5/trade/order?ordId=" + order_id + "&instId=" + symbol + "-SWAP";
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        sig(extra_http_header, signature, ep);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );

                if(json_result.isMember("code") && atoi( json_result["code"].asString().c_str() ) == 0 && json_result["data"][0]["state"].asString() == "filled")
                    price = atof( json_result["data"][0]["avgPx"].asString().c_str() );            		
            		
                if(price <= 0)
                    throw exception();                                
            		
            	} catch ( exception &e ) {
             	    err = "Okx: error reading get_price response";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Okx: get_price.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
    }
    
    void set_longShortMode() {	
        Json::Value json_result;
        time_t now;
        time(&now);
        char buf[sizeof "2011-10-08T07:07:09Z"];
        strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", gmtime(&now));
        string err, ep = buf;
        string url = "https://aws.okex.com/api/v5/account/set-position-mode";
        string action = "POST";

        string post_data = "{\"posMode\":\"long_short_mode\"}";        
        string msg = ep + action + "/api/v5/account/set-position-mode" + post_data;
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        sig(extra_http_header, signature, ep);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Okx: error reading set_longShortMode response";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return;
            }   
        } 
        else {
            err = "Okx: set_longShortMode.size() is 0";
            writte_log(err);
            return;
        }
    }
    
    bool set_leverage(string symbol) {	
        Json::Value json_result;
        time_t now;
        time(&now);
        int leverage = 0;
        char buf[sizeof "2011-10-08T07:07:09Z"];
        strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", gmtime(&now));
        string err, ep = buf;
        string url = "https://aws.okex.com/api/v5/account/set-leverage";
        string action = "POST";

        string post_data = "{\"instId\":\"" + symbol + "\",\"lever\":\"" + to_string(LEVERAGE) + "\",\"mgnMode\":\"cross\"}";        
        string msg = ep + action + "/api/v5/account/set-leverage" + post_data;
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        sig(extra_http_header, signature, ep);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        try {
            Json::Reader reader;
            json_result.clear();	
            reader.parse( str_result , json_result );
            
            if(atoi( json_result["code"].asString().c_str() ) == 0)
                leverage = atoi( json_result["data"][0]["lever"].asString().c_str() );
        	
        	if(leverage != LEVERAGE)
        	    throw exception();
        		
        	} catch ( exception &e ) {
         	    err = "Okx: error set_leverage response";
         	    err.append( e.what() );
                writte_log(err);
                cout << json_result << endl;
                return 0;
        }   
        return 1;
    }
    
    double get_minSize( string symbol ) {
        symbol = symbol.substr(0, symbol.find('-'));	
        Json::Value json_result;
        string err;
        time_t now;
        time(&now);
        char buf[sizeof "2011-10-08T07:07:09Z"];
        strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", gmtime(&now));
        string ep = buf;
        string url = "https://aws.okex.com/api/v5/asset/convert/currency-pair?fromCcy=USDT&toCcy=" + symbol;
        string action = "GET";
        double minSize = -1;

        string post_data = "";        
        string msg = ep + action + "/api/v5/asset/convert/currency-pair?fromCcy=USDT&toCcy=" + symbol;
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        sig(extra_http_header, signature, ep);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Okx: error reading get_minSize response ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            err = "Okx: get_minSize.size() is 0";
            writte_log(err);
            return -1;
        }
        return minSize;
    }
    
    double get_minQty(string symbol){
        Json::Value json_result; 
        string s = "https://aws.okx.com/api/v5/public/instruments?instType=SWAP&instId=" + symbol + "-SWAP"; 

        try{        
            get_curl(s, json_result);

            if(json_result["code"].asString() == "0")
                minQty = atof( json_result["data"][0]["ctVal"].asString().c_str() );

            if(minQty == 0)
                throw exception();  
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in set_minQty ";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }
        return minQty;
    }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
