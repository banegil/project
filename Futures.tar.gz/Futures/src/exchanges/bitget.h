

class Bitget: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    Bitget(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.bitget.com/api/spot/v1/market/depth?symbol=" + symbol + "_SPBL&limit=50";
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();    	
         	
         	mtxDepth.lock();
         	
         	depth.clear();                  
            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	            double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	            double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            } 
	        mtxDepth.unlock();

	        } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        init_http("ws.bitget.com");
        long ts = 0, ts2;
        
        try {
            string symbol2 = symbol;
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            init_webSocket("ws.bitget.com", "443", "/spot/v1/stream");
            string s = "{\"op\":\"subscribe\",\"args\":[{\"instType\":\"sp\",\"channel\":\"books\",\"instId\":\"" + symbol + "\"}]}";
            write_Socket(s);
            Json::Reader reader;
            Json::Value result;
            read_Socket();	
            buffer_clear();

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
                Json::Value result;
                read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();             
    
                mtxDepth.lock();
                
                if(ct2 - ct > TIME_REFRESH + 5 && (result["data"][0]["asks"].size() > 0 || result["data"][0]["bids"].size() > 0)){ 
                    s = "{\"op\":\"ping\"}";
                    write_Socket(s);
                    ct = ct2;
                    depth.clear();
                    //std::async (&Bitget::curl_depth, this, symbol2);
                }
                
                ts2 = atof( result["data"][0]["ts"].asString().c_str() );
                if(ts2 >= ts){
                    ts = ts2;
                    for ( int i = 0 ; i < result["data"][0]["asks"].size(); i++ ) {
                        double price = atof( result["data"][0]["asks"][i][0].asString().c_str() );
                        double qty   = atof( result["data"][0]["asks"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
                    }
                    for ( int i = 0 ; i < result["data"][0]["bids"].size(); i++ ) {
                        double price = atof( result["data"][0]["bids"][i][0].asString().c_str() );
                        double qty   = atof( result["data"][0]["bids"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
                    }
                }
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                set_id();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
		        //cout << result << '\n'; 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
