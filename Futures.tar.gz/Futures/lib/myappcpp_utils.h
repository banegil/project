

#ifndef MYAPPCPP_UTILS
#define MYAPPCPP_UTILS

#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <string.h>
#include <sys/time.h>
#include <openssl/hmac.h>
#include <openssl/sha.h>
#include <openssl/md5.h>
#include <iostream>
#include <zlib.h>
#include <future>
#include <curl/curl.h>
#include <cstdio>  
#include <cstring>  
#include <cstdlib> 
#include <map>
#include <unordered_map>
#include <iomanip>
#include <chrono>
#include <thread>
#include <future> 
using namespace std;

std::vector<unsigned char> digest_;

bool gzipInflate( const std::string& compressedBytes, std::string& uncompressedBytes ) {  
  if ( compressedBytes.size() == 0 ) {  
    uncompressedBytes = compressedBytes ;  
    return true ;  
  }  
  
  uncompressedBytes.clear() ;  
  
  unsigned full_length = compressedBytes.size() ;  
  unsigned half_length = compressedBytes.size() / 2;  
  
  unsigned uncompLength = full_length ;  
  char* uncomp = (char*) calloc( sizeof(char), uncompLength );  
  
  z_stream strm;  
  strm.next_in = (Bytef *) compressedBytes.c_str();  
  strm.avail_in = compressedBytes.size() ;  
  strm.total_out = 0;  
  strm.zalloc = Z_NULL;  
  strm.zfree = Z_NULL;  
  
  bool done = false ;  
  
  if (inflateInit2(&strm, (16+MAX_WBITS)) != Z_OK) {  
    free( uncomp );  
    return false;  
  }  
  
  while (!done) {  
    // If our output buffer is too small  
    if (strm.total_out >= uncompLength ) {  
      // Increase size of output buffer  
      char* uncomp2 = (char*) calloc( sizeof(char), uncompLength + half_length );  
      memcpy( uncomp2, uncomp, uncompLength );  
      uncompLength += half_length ;  
      free( uncomp );  
      uncomp = uncomp2 ;  
    }  
  
    strm.next_out = (Bytef *) (uncomp + strm.total_out);  
    strm.avail_out = uncompLength - strm.total_out;  
  
    // Inflate another chunk.  
    int err = inflate (&strm, Z_SYNC_FLUSH);  
    if (err == Z_STREAM_END) done = true;  
    else if (err != Z_OK)  {  
      break;  
    }  
  }  
  
  if (inflateEnd (&strm) != Z_OK) {  
    free( uncomp );  
    return false;  
  }  
  
  for ( size_t i=0; i<strm.total_out; ++i ) {  
    uncompressedBytes += uncomp[ i ];  
  }  
  free( uncomp );  
  return true ;  
}  

//--------------------------------
void split_string( string &s, char delim, vector <string> &result) {

    std::stringstream ss;
    ss.str(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        result.push_back(item);
    }
    
}

//--------------------------------
int replace_string_once( string& str, const char *from, const char *to, int offset) {

    size_t start_pos = str.find(from, offset);
    if( start_pos == std::string::npos ) {
        return 0;
    }
    str.replace(start_pos, strlen(from), to);
    return start_pos + strlen(to);
}


//--------------------------------
bool replace_string( string& str, const char *from, const char *to) {

    bool found = false;
    size_t start_pos = 0;
    while((start_pos = str.find(from, start_pos)) != std::string::npos) {
        str.replace(start_pos, strlen( from ), to);
        found = true;
        start_pos += strlen(to);
    }
    return found;
}


//-----------------------
void string_toupper( string& src) {
    for ( int i = 0 ; i < src.size() ; i++ ) {
        src[i] = toupper(src[i]);
    }
}


//--------------------------------------
string b2a_hex( char *byte_arr, int n ) {

    const static std::string HexCodes = "0123456789abcdef";
    string HexString;
    for ( int i = 0; i < n ; ++i ) {
        unsigned char BinValue = byte_arr[i];
        HexString += HexCodes[( BinValue >> 4 ) & 0x0F];
        HexString += HexCodes[BinValue & 0x0F];
    }
    return HexString;
}



//---------------------------------
time_t get_current_epoch( ) {

    struct timeval tv;
    gettimeofday(&tv, NULL); 

    return tv.tv_sec ;
}

//---------------------------------
unsigned long get_current_ms_epoch( ) {

    struct timeval tv;
    gettimeofday(&tv, NULL); 

    return tv.tv_sec * 1000 + tv.tv_usec / 1000 ;

}


//--------------------
inline bool file_exists (const std::string& name) {
 	 return ( access( name.c_str(), F_OK ) != -1 );
}

//---------------------------
string hmac_sha256( const char *key, const char *data) {

    unsigned char* digest;
    digest = HMAC(EVP_sha256(), key, strlen(key), (unsigned char*)data, strlen(data), NULL, NULL);    
    return b2a_hex( (char *)digest, 32 );
}   

//---------------------------
string hmac_sha384( const char *key, const char *data) {

    unsigned char* digest;
    digest = HMAC(EVP_sha384(), key, strlen(key), (unsigned char*)data, strlen(data), NULL, NULL);    
    return b2a_hex( (char *)digest, 48 );
}  

//---------------------------
string hmac_sha512( const char *key, const char *data) {
    unsigned char* digest;
    digest = HMAC(EVP_sha512(), key, strlen(key), (unsigned char*)data, strlen(data), NULL, NULL);    
    return b2a_hex( (char *)digest, 64 );
}  

string hmac_sha256h( const char *secret_key, const char *data) {
        unsigned int md_len;
        unsigned char *str = HMAC(EVP_sha256(),
                                  secret_key, strlen(secret_key),
                                  reinterpret_cast<const unsigned char *>(data),
                                  strlen(data),
                                  nullptr,
                                  &md_len);
        //signature buf afer hmac and base64
        char signature[100];
        EVP_EncodeBlock((unsigned char *) signature, str, md_len);
    string hh = signature;
    return hh;
} 

//------------------------------
string sha256( const char *data ) {

    unsigned char digest[32];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, data, strlen(data) );
    SHA256_Final(digest, &sha256);
    return b2a_hex( (char *)digest, 32 );
    
}

//------------------------------
string sha512( const char *data ) {

    unsigned char digest[64];
    SHA512_CTX sha512;
    SHA512_Init(&sha512);
    SHA512_Update(&sha512, data, strlen(data) );
    SHA512_Final(digest, &sha512);
    return b2a_hex( (char *)digest, 64 );
    
}

std::string base64_encode(const std::string &in) {
    std::string out;
    std::string b = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    int val=0, valb=-6;
    for (unsigned char c : in) {
        val = (val<<8) + c;
        valb += 8;
        while (valb>=0) {
            out.push_back(b[(val>>valb)&0x3F]);
            valb-=6;
        }
    }
    if (valb>-6) out.push_back(b[((val<<8)>>(valb+8))&0x3F]);
    while (out.size()%4) out.push_back('=');
    return out;
}

std::string base64_decode(const std::string &in) {

    std::string out;
    std::string b = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    std::vector<int> T(256,-1);
    for (int i=0; i<64; i++) T[b[i]] = i;

    int val=0, valb=-8;
    for (unsigned char c : in) {
        if (T[c] == -1) break;
        val = (val<<6) + T[c];
        valb += 6;
        if (valb>=0) {
            out.push_back(char((val>>valb)&0xFF));
            valb-=8;
        }
    }
    return out;
}

std::string urlencode(const std::string &s)
{
    static const char lookup[]= "0123456789abcdef";
    std::stringstream e;
    for(int i=0, ix=s.length(); i<ix; i++)
    {
        const char& c = s[i];
        if ( (48 <= c && c <= 57) ||//0-9
             (65 <= c && c <= 90) ||//abc...xyz
             (97 <= c && c <= 122) || //ABC...XYZ
             (c=='-' || c=='_' || c=='.' || c=='~') 
        )
        {
            e << c;
        }
        else
        {
            e << '%';
            e << lookup[ (c&0xF0)>>4 ];
            e << lookup[ (c&0x0F) ];
        }
    }
    return e.str();
}

string decompress_gzip(const string& str)
{
    z_stream zs;                     
    memset(&zs, 0, sizeof(zs));

    if (inflateInit2(&zs, 15 + 16) != Z_OK)
        cout << "ERROR decompressing" << endl;

    zs.next_in = (Bytef*)str.data();
    zs.avail_in = str.size();

    int ret;
    char outbuffer[32768];
    string outstring;

    do {
        zs.next_out = reinterpret_cast<Bytef*>(outbuffer);
        zs.avail_out = sizeof(outbuffer);

        ret = inflate(&zs, 0);

        if (outstring.size() < zs.total_out) {
            outstring.append(outbuffer,
                             zs.total_out - outstring.size());
        }

    } while (ret == Z_OK);

    inflateEnd(&zs);

    if (ret != Z_STREAM_END) {     
        cout << "ERROR decompressing" << endl;
    }

    return outstring;
}

string decompress_deflate(const string& str)
{
    z_stream zs;                      
    memset(&zs, 0, sizeof(zs));

    if (inflateInit(&zs) != Z_OK)
        throw(runtime_error("ERROR: decompressing"));

    zs.next_in = (Bytef*)str.data();
    zs.avail_in = str.size();

    int ret;
    char outbuffer[32768];
    std::string outstring;

    do {
        zs.next_out = reinterpret_cast<Bytef*>(outbuffer);
        zs.avail_out = sizeof(outbuffer);

        ret = inflate(&zs, 0);

        if (outstring.size() < zs.total_out) {
            outstring.append(outbuffer,
                             zs.total_out - outstring.size());
        }

    } while (ret == Z_OK);

    inflateEnd(&zs);

    if (ret != Z_STREAM_END) {    
        ostringstream oss;
        oss << "ERROR: decompressing (" << ret << ") "
            << zs.msg;
        throw(runtime_error(oss.str()));
    }

    return outstring;
}

std::string encode(const char *buf) {
    char *output = curl_easy_escape(curl_easy_init(), buf, 0);
    std::string str = output;
    if (output) {
        curl_free(output);
    }
    return str;
}

std::string createSignatureParamHuobi(string url) {
    std::map<string, const char *> params;
    string api_key = "dbuqg6hkte-a31b9fed-d6cfe996-18922";
    string api_secret = "507eeb5a-a381cce5-3b9a3f4d-8aafb";
    time_t nowtime = time(0);
    struct tm *utc = gmtime(&nowtime);
    char buf[50];
    strftime(buf, 50, "%Y-%m-%dT%H:%M:%S", utc);
    CURL *curl = curl_easy_init();
    std::string timestamp = encode(buf);

    params["AccessKeyId"] = api_key.c_str();
    params["SignatureMethod"] = "HmacSHA256";
    params["SignatureVersion"] = "2";
    params["Timestamp"] = timestamp.c_str();

    std::string paramsStr;
    paramsStr.append("POST").append("\n")
            .append("api.huobi.pro").append("\n")
            .append(url).append("\n");
    std::string spliceStr;
    for (map<string, const char *>::iterator iter = params.begin(); iter != params.end(); ++iter) {
        spliceStr.append(iter->first).append("=").append(iter->second);
        if (iter != --params.end()) {
            spliceStr.append("&");
        }
    }
    paramsStr.append(spliceStr);;

    unsigned int md_len;
    unsigned char *str = HMAC(EVP_sha256(),
                              api_secret.c_str(), strlen(api_secret.c_str()),
                              reinterpret_cast<const unsigned char *>(paramsStr.c_str()),
                              paramsStr.size(),
                              nullptr,
                              &md_len);
    char signature[100];
    EVP_EncodeBlock((unsigned char *) signature, str, md_len);

    spliceStr.append("&Signature=").append(encode(signature)).c_str();
    return spliceStr;
}

#endif
