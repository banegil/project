
#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"

#include <openssl/hmac.h>
#include <openssl/sha.h>

using namespace std;
using namespace rapidjson;

mutex mtxErr;
  
string b2a_hex( char *byte_arr, int n ) {

    const static std::string HexCodes = "0123456789abcdef";
    string HexString;
    for ( int i = 0; i < n ; ++i ) {
        unsigned char BinValue = byte_arr[i];
        HexString += HexCodes[( BinValue >> 4 ) & 0x0F];
        HexString += HexCodes[BinValue & 0x0F];
    }
    return HexString;
}  
    
inline unsigned long get_current_ms_epoch( ) noexcept {
    struct timeval tv;
    gettimeofday(&tv, NULL); 

    return tv.tv_sec * 1000 + tv.tv_usec / 1000 ;

}   

string hmac_sha256( const char *key, const char *data) {

    unsigned char* digest;
    digest = HMAC(EVP_sha256(), key, strlen(key), (unsigned char*)data, strlen(data), NULL, NULL);    
    return b2a_hex( (char *)digest, 32 );
} 
    
void writte_err(const string& file, const string& s){
    time_t now = time(0);
    char* dt = ctime(&now);
    mtxErr.lock();
    cout << dt << " " << s << '\n';
    ofstream output(file, std::ios::app);
    output << dt << " " << s << '\n';
    mtxErr.unlock();
}

void printJson(const Document& d){
    StringBuffer sb;
    PrettyWriter<StringBuffer> writer(sb);
    d.Accept(writer);
    puts(sb.GetString());
}

static size_t curl_cb( void *content, size_t size, size_t nmemb, std::string *buffer ) {	
    buffer->append((char*)content, size*nmemb);
    return size*nmemb;
}

void curl_api_with_header( const string& url, string& str_result ){
	CURL* curl;
    CURLcode res;
    curl = curl_easy_init();

    if( curl ) {		    
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
	    curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");
	    curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
	    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
	    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );

	    res = curl_easy_perform(curl);
	    curl_easy_cleanup(curl);

	    /* Check for errors */ 
	    if ( res != CURLE_OK ) {
		    writte_err( "err.txt", "ERROR: <curl_api_with_header> failed: " + string(curl_easy_strerror(res)) ) ;
	    } 	
    }
 }
 
inline void curl_api_with_headerPost( string &url, string &str_result, vector <string> &extra_http_header , string &post_data , string &action ) noexcept {
    	CURL* curl;
	    CURLcode res;
	    curl = curl_easy_init();

	    if( curl ) {

		    curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
		    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
		    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );
		    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
		    curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");

		    if ( extra_http_header.size() > 0 ) {
			    
			    struct curl_slist *chunk = NULL;
			    for ( int i = 0 ; i < extra_http_header.size() ;i++ ) {
				    chunk = curl_slist_append(chunk, extra_http_header[i].c_str() );
			    }
			    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, chunk);
		    }

		    if ( post_data.size() > 0 || action == "POST" ) {
			    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data.c_str() );
     		}

		    res = curl_easy_perform(curl);
		    curl_easy_cleanup(curl);

		    /* Check for errors */ 
		    if ( res != CURLE_OK ) {
		        string err = curl_easy_strerror(res) ;
			    writte_err( "err.txt", "ERROR: <curl_api_with_headerPost> curl_easy_perform() failed: " + err ) ;
		    } 	
	    }
	 }

