

class Binance {
    const unsigned short id = 0;
    string api_key = "oBNIYfFRy75TFChwWyqAA2bIHONGT4fOZP8VLEGSbi6FcQWrHQKPxbB31JkeG87F";
    string secret_key = "beck39rQ606hqkhELAdPtTlT2J6XGdsvZ0S5XBJ6asxtmlLmOaffuEeCPsvEwrqU";

    public:
    void websocketInit_depth(){
        Document d;
        Exchange ex;
        
        try {
            ex.init_http("stream.binance.com");
            ex.init_webSocket("stream.binance.com", "443", "/stream?streams=btcbusd@bookTicker/btcusdc@bookTicker/usdcbusd@bookTicker");
                          
            while (true) {
                ex.read_Socket();	
                d.Parse(ex.get_socket_data().c_str());
              
                auto&& c = coins[d["data"]["s"].GetString()];

                c.mtx->lock(); 
                
                c.ask = stod(d["data"]["a"].GetString());
                c.bid = stod(d["data"]["b"].GetString());
                
                c.mtx->unlock(); 

                ex.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  Binance-Spot " + string(e.what());
         	writte_err( "err.txt", err ); 
         	ex.webSocket_close();
            return;
          }
    }  
    
    void websocketInit_trades(string listenKey){
        Document d;
        Exchange ex;
        string s = "/ws/" + listenKey;
        double quantity = 0.0008;
        
        try {
            ex.init_http("stream.binance.com");
            ex.init_webSocket("stream.binance.com", "443", s.c_str());
                          
            while (true) {
                ex.read_Socket();	
                d.Parse(ex.get_socket_data().c_str());

                if(d.IsObject()){
                    if(d.HasMember("X") && d["X"] == "FILLED" && d["s"] == "BTCUSDC"){
                        double qumQty = send_order("BTCBUSD", "sell", quantity, 0, "MARKET");
            
                        qumQty = round( qumQty * 100.0 ) / 100.0;
                        send_order("USDCBUSD", "buy", qumQty, 0, "MARKET"); 

                        ok = 1;
                    }
                }
                else
                    throw exception();

                ex.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  Binance-Spot " + string(e.what());
         	writte_err( "err.txt", err ); 
         	ex.webSocket_close();
            return;
          }
    } 
    
    double send_order( string symbol, string side, double quantity, double price1, string type ) {	
        string err;
        Document d;
        double price = 0;

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url("https://api.binance.com/api/v3/order?");
        string action = "POST";
        
        string post_data("symbol=");
        post_data.append( symbol );
        
        if(type == "LIMIT"){
            post_data.append("&price=");
            post_data.append( to_string(price1) );
            post_data.append("&timeInForce=GTC");
        }

        post_data.append("&side=");        
        post_data.append( side );
        post_data.append("&type=");
        post_data.append( type );
        post_data.append("&quantity=");
        post_data.append( to_string(quantity) );	        
        post_data.append("&timestamp=");
        post_data.append( to_string( get_current_ms_epoch() ) );
        string signature =  hmac_sha256( secret_key.c_str(), post_data.c_str() );
        post_data.append( "&signature=");
        post_data.append( signature );

        vector <string> extra_http_header;
        string header_chunk("X-MBX-APIKEY: ");
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_headerPost( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {	
                d.Parse(str_result.c_str());
                printJson(d);
                
                if(d.HasMember("type") && d["type"] != "LIMIT")  
                    price = stod(d["cummulativeQuoteQty"].GetString());
	                
            	} catch ( exception &e ) {
             	    err = ": error reading send_order response ";
             	    err.append( e.what() );
                    writte_err("err.txt", err);
                    printJson(d);
                    return -1;
            }   
        } 
        else {
            err = ": send_order.size() is 0";
            writte_err("err.txt", err);
            return -1;
        }
        return price;
    }
    
    string get_listenKey() {	
        string err;
        Document d;
        string s = "";

        string url("https://api.binance.com/api/v3/userDataStream?");
        string action = "POST";
        
        string post_data = "";

        vector <string> extra_http_header;
        string header_chunk("X-MBX-APIKEY: ");
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_headerPost( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {	
                d.Parse(str_result.c_str());
                
                if(d.IsObject() && d.HasMember("listenKey"))
	                s = d["listenKey"].GetString();
	                
            	} catch ( exception &e ) {
             	    err = ": error reading send_order response ";
             	    err.append( e.what() );
                    writte_err("err.txt", err);
                    printJson(d);
                    return s;
            }   
        } 
        else {
            err = ": send_order.size() is 0";
            writte_err("err.txt", err);
            return s;
        }
        return s;
    }
};

