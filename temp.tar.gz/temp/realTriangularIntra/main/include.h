
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <iostream>
#include <future>
#include <curl/curl.h>
#include <cstdio>  
#include <cstring>  
#include <cstdlib> 
#include <unordered_map>
#include <map>
#include <fstream>
#include <mutex>
#include <iomanip>
#include <chrono>
#include <thread>
#include <cmath>
#include <ctime>
#include <atomic>
#include <set>
#include <curl/curl.h>

#include "../lib/myappcpp_utils.h"

#include "../src/exchange.h"

struct tPairs {
    double bid; 
    double ask; 
    mutex *mtx;
    
    public:
    tPairs(){
        mtx = new mutex();
    }
};

unordered_map<string, tPairs> coins;
bool ok = 0;

#include "../src/exchanges/binance.h"










