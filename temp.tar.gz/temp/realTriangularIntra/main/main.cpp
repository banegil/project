#include "include.h"


void ini(){      
    Binance bin;

    cout << "Starting ... " << endl;    
    auto e = async(&Binance::websocketInit_depth, &bin);       
    auto ee = async(&Binance::websocketInit_trades, &bin, bin.get_listenKey());              

    std::this_thread::sleep_for(std::chrono::milliseconds(10000));    
    cout << "OK!" << endl;

    double quantity = 0.0008; 
     
    ok = 1;      
    while(1){      
        
        if(ok && coins["BTCBUSD"].bid - coins["BTCUSDC"].bid > 0){  
            coins["BTCUSDC"].mtx->lock();
            double price = coins["BTCUSDC"].bid;
            //price = round( price * 100.0 ) / 100.0; 
            coins["BTCUSDC"].mtx->unlock();
            bin.send_order("BTCUSDC", "buy", quantity, price, "LIMIT"); 
            
            ok = 0;   
        }     
      
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
}


int main() {
    curl_global_init(CURL_GLOBAL_ALL);    
    ini();
    return 0;
}
