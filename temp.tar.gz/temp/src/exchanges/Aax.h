

class Aax : public Exchange {
    const string id = "Aax";
    const unsigned short idNum = 0;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETHUSDT";
    string orderId;
    bool limitOrder = 0;
    double remaining_qty = 0;
    
    const string user_ID = "3472618";
    const string api_key = "a0P7BLvMmBlxtxkBA8rRFOZt9t";
    const char* secret_key = "7ce846cbd482aec3458341a9421c6125";
    

    void sig(vector <string>& extra_http_header, const string& ep, const string& signature){
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="X-ACCESS-NONCE:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "X-ACCESS-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "X-ACCESS-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
    }

    public:          
    bool get_pairs(){      
        Document d;
        unordered_map<string, bool> innovation;
        innovation["AVAX"] = innovation["SAND"] = innovation["AXS"] = innovation["WAVES"] = innovation["OP"] = innovation["ICP"] = innovation["PIT"] = innovation["BICO"] = innovation["JST"] = innovation["NFT"] = innovation["SWRV"]
         = innovation["HBAR"] = innovation["EGLD"] = innovation["ZBC"] = innovation["RSR"] = innovation["API3"] = innovation["XTZ"] = innovation["GALA"] = innovation["LOOKS"] = innovation["DOT"] = innovation["UNI"]
         = innovation["ETC"] = innovation["EOS"] = innovation["DYDX"] = innovation["GRT"] = innovation["KNC"] = innovation["SNT"] = 1;
         symbol = chosenSymbol;
         symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
                 
        try{
            string result;          
            curl_api("https://api.aax.com/v2/instruments", result);
            d.Parse(result.c_str());
            
            if(d.HasMember("data") && d["code"] == 1 && d["message"] == "success"){
                for(auto& i : d["data"].GetArray()){
                    if(i["status"] == "enable" && i["type"] == "spot"){ // USDT & BTC                   
                        string base = i["base"].GetString();
                        string quote = i["quote"].GetString();

                        if(innovation[base])
                            fee = {0.001, 0.0015}; // cannot change
                        else
                            fee = {0.0008, 0.0012}; // with 5000$ can be 0.00096 and 0.00072     
                            
                        if( base + "-" + quote == chosenSymbol ){
                            exchangeInfo[idNum].multiplier = stod( i["lotSize"].GetString() );
                            return 1;
                        }
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        } 
        return 0;      
    }


    void websocketInit_depth(){   
        Wss ws;     
        Document d;
        string s = "{\"e\": \"subscribe\", \"stream\": [\"" + symbol + "@book_20\"]}";

        try {   
            ws.init_http("realtime.aax.com");
            ws.init_webSocket("realtime.aax.com", "443", "/marketdata/v2/"); // ms: 300  
            ws.write_Socket(s);
            
            for(int i = 0; i < 2; i++){
                ws.read_Socket();	
                ws.buffer_clear();
            }
            
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("asks")){
                                
                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["asks"].GetArray())
                        asks[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxAsk.unlock();
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["bids"].GetArray())
                        bids[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxBid.unlock();
                    
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){
        Wss ws;
        Document d;
        const string& ep = to_string( get_current_ms_epoch() );
        const string& msg = ep + ":" + api_key;
        const string& signature = hmac_sha256( secret_key, msg.c_str() );

        try {   
            ws.init_http("stream.aax.com");
            ws.init_webSocket("stream.aax.com", "443", "/notification/v2/"); // ms: 300  

            string s = "{\"event\":\"#handshake\",\"cid\":1}";
            ws.write_Socket(s);           
            ws.read_Socket();	
            d.Parse(ws.get_socket_data().c_str());
            if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("id") && d.HasMember("rid") && d["rid"] == 1) {}
            else throw exception();
            ws.buffer_clear();  
                     
            s = "{\"event\":\"login\",\"data\":{\"apiKey\":\"" + api_key + "\",\"nonce\":" + ep + ",\"signature\":\"" + signature + "\"}}";
            ws.write_Socket(s);           
            ws.read_Socket();	
            d.Parse(ws.get_socket_data().c_str());
            if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("isAuthenticated") && d["data"]["isAuthenticated"] == true) {}
            else throw exception();
            ws.buffer_clear();
            
            s = "{\"event\":\"#subscribe\",\"data\":{\"channel\":\"user/" + user_ID + "\"},\"cid\":2}";
            ws.write_Socket(s);            
        
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());
        
                if(d.IsObject()){
                    if(d.HasMember("rid") && d["rid"] == 2)
                        ws.write_Socket("#2");                
                    else if(d.HasMember("data")){                   
                        if(d["data"].HasMember("data") && d["data"]["data"].HasMember("event")){
                        
                            exchangeInfo[idNum].mtx->lock();
                            
                            if(d["data"]["data"]["event"] == "USER_BALANCE")
                                exchangeInfo[idNum].balance[ d["data"]["data"]["data"]["currency"].GetString() ] = stod( d["data"]["data"]["data"]["available"].GetString() );
                            else if(d["data"]["data"]["event"] == "SPOT"){                             
                                if(d["data"]["data"]["data"]["orderStatus"] == 2 || d["data"]["data"]["data"]["orderStatus"] == 3){ 
                                   
                                    if(limitOrder){
                                        orderExecuted = true;                                    
                                        const double& quantity = stod( d["data"]["data"]["data"]["cumQty"].GetString() ) + remaining_qty;
                                        const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", quantity, 0.0, 0);
                                        
                                        if(res == 0)
                                            stopExecution = true;
                                        else if(res == 1)
                                            remaining_qty += quantity;
                                        else
                                            remaining_qty = 0;
                                        
                                            
                                        limitOrder = 0;
                                    }     
                                    
                                    exchangeInfo[idNum].orderPrice = stod( d["data"]["data"]["data"]["avgPrice"].GetString() );        
                                }
                            }
                                                                                   
                            exchangeInfo[idNum].mtx->unlock();
                            
                        }
                        
                    }
                    else {
                        const string& err = "<websocket_User> This is just to show some unknow info about " + id;
         	            writte_err( "err.txt", err );
                        printJson(d);
                    }
                    
                }
                else
                    throw exception();
                  

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }        
    }
    
    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {	
        Document d;
        string type = "MARKET";
        string price_string = "";
        
        if(limit){
            type = "LIMIT";
            price_string = "\"price\": "+ to_string(price) +", ";
        }
            
        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.aax.com/v2/spot/orders";
        
        string_toupper(side);
        const string& post_data = "{\"orderType\": \"" + type + "\", \"symbol\": \"" + symbol + "\", " + price_string + "\"orderQty\": " + to_string(quantity) + ", \"side\": \"" + side + "\"}";
        const string& msg = ep + ":POST/v2/spot/orders" + post_data;
        
        const string& signature = hmac_sha256( secret_key, msg.c_str() );
        
        vector <string> extra_http_header;
        sig(extra_http_header, ep, signature);
        
        string str_result;
        curl_api_with_header(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());  printJson(d);               

                if(d.IsObject() && d.HasMember("data") && d.HasMember("message") && d["message"] == "success" && d.HasMember("code") && d["code"] == 1)
                    orderId = d["data"]["orderID"].GetString();
                else if(d.IsObject() && d.HasMember("code") && d["code"] == 30004)
                    return 1;
                else
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 2;
    }
    
    bool cancel_order() {	
        Document d;
            
        const string& ep = to_string(get_current_ms_epoch());
        const string& url = "https://api.aax.com/v2/spot/orders/cancel/" + orderId;
        
        const string& post_data = "{\"orderID\":\"" + orderId + "\"}";
        const string& msg = ep + ":DELETE/v2/spot/orders/cancel/" + orderId + post_data;
        
        const string& signature = hmac_sha256( secret_key, msg.c_str() );
        
        vector <string> extra_http_header;
        sig(extra_http_header, ep, signature);
        
        string str_result;
        curl_api_with_header(url.c_str(), str_result, extra_http_header , post_data , "DELETE");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());                 

                if(!(d.IsObject() && d.HasMember("data") && d.HasMember("message") && d["message"] == "success" && d.HasMember("code") && d["code"] == 1))
            		throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;
    }
    
    bool withdrawal(){
        const string& err = " Exchange " + id + " doesn't support withdrawal API";
        writte_err( "err.txt", err );         
        return 0;
    }
           
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }   
    
    void set_limitOrder(){
        limitOrder = 1;
    }   
};

