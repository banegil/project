

class Bybit {
    const unsigned short id = 3;
    const string api_key = "8q49uoJFqIU9eVuZZ4";
    const char* secret_key = "eruecjq5Cr3GyYiOSa3Jf3WLagjTR9HrQJjC";
    string order_id;

    void pingInterval(Wss& ws){
        time_t current_time;
        time(&current_time);
        int ct = current_time;  
                                    
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct >= 20){
                ct = ct2;
                ws.write_Socket(R"({"op":"ping"})");
            }
        }
    }

    public:    
    void websocketInit_depth(){   
        Wss ws;     
        Document d;
        string s, quoteAsset, baseAsset;
        unordered_map<string, string> qA;
        qA["DT"] = "USDT"; qA["TH"] = "ETH"; qA["TC"] = "BTC"; qA["AI"] = "DAI"; qA["DC"] = "USDC";
        
        try {
            ws.init_http("stream.bybit.com");
            ws.init_webSocket("stream.bybit.com", "443", "/spot/public/v3"); // 100ms

            s = "{\"op\": \"subscribe\", \"args\": [\"orderbook.40." + cc + "\", \"orderbook.40." + cc1 + "\", \"orderbook.40." + cc2 + "\" ]}";
            ws.write_Socket(s); 

            time_t current_time;
            time(&current_time);
            int ct = current_time;                              
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                if(ct2 - ct >= 20){
                    ct = ct2;
                    ws.write_Socket(R"({"op":"ping"})");
                }
                                           
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(!d.HasMember("op"))
                    pairs[ d["data"]["s"].GetString() ].pushOrderbook(d);

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + to_string(id) + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){    
        Wss ws;    
        Document d;
        time_t current_time;
        time(&current_time);
        long long ct2 = current_time;
        ct2 += 10; ct2 *= 1000;
        
        const string& ep = to_string(ct2);
        const string& msg = "GET/realtime" + ep;
        const string& signature =  hmac_sha256( secret_key, msg.c_str() ); 
        double priceCc1;
        
        try {
            ws.init_http("stream.bybit.com");
            ws.init_webSocket("stream.bybit.com", "443", "/spot/private/v3"); 
            
            string s = "{\"op\": \"auth\",\"args\": [\"" + api_key + "\", \"" + ep + "\", \"" + signature + "\"]}";
            ws.write_Socket(s);  
            
            s = "{\"op\": \"subscribe\",\"args\": [\"order\"]}";
            ws.write_Socket(s);
            
            auto&& f = async(&Bybit::pingInterval, this, ref(ws));                         
             
                            
            while (true) {                                           
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());
             
       
                if(d.IsObject()){
                    printJson(d);
                               
                    if(d.HasMember("topic") && d["topic"] == "order"){
                    
                        if(d["data"][0]["Z"] != "0"){
                            //pairs[ d[0]["s"].GetString() ] = stod( d[0]["Z"].GetString() ) / stod( d[0]["z"].GetString() );
                           
                            orderNotExecuted = false;    
                            
                            if(d["data"][0]["s"].GetString() == cc && !YAOSTIAPUTA){
                                
                                send_order(cc1,"sell", 0.03, 1500);
                                YAOSTIAPUTA = 1;
                            }
                            else if(d["data"][0]["s"].GetString() == cc1 && !YAOSTIAPUTA2){
                                send_order(cc2,"buy", round( stod( d["data"][0]["Z"].GetString() ) * 100.0 ) / 100.0, 1.001);
                                YAOSTIAPUTA2 = 1;
                            }
                        }
                    }
                                                                                                   
                }
                else
                    throw exception();
                
                printJson(d);                

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    }

    double send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) {	
        Document d;
        double price = -1;

        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bytick.com/spot/v3/private/order?";
        const string& orderID = hmac_sha256( url, ep.c_str() );
        
        side[0] = toupper(side[0]);
        
        const string& post_data = "{\"symbol\": \"" + symbol + "\",\"orderQty\":\"" + to_string(quantity) + "\",\"side\": \"" + side + "\",\"orderType\": \"LIMIT\",\"timeInForce\": \"GTC\",\"orderPrice\": \"" +
                                     to_string(orderPrice) + "\",\"orderLinkId\": \"" + orderID.substr(0, 5) + "\"}";
        const string& msg = ep + api_key + "5000" + post_data;

        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("X-BAPI-SIGN-TYPE: 2");
        extra_http_header.push_back("X-BAPI-SIGN:" + signature);
        extra_http_header.push_back("X-BAPI-API-KEY:" + api_key);
        extra_http_header.push_back("X-BAPI-TIMESTAMP:" + ep);
        extra_http_header.push_back("X-BAPI-RECV-WINDOW: 5000");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());
printJson(d);
                if(d.IsObject() && d.HasMember("retCode") && d.HasMember("retMsg") && d["retCode"] == 0 && d["retMsg"] == "OK") {}
                else throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return -1;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return -1;
        }
        
        if(symbol == cc)
            order_id = orderID.substr(0, 5);
        
        return price;  
    } 
    
    bool send_CancelOrder(){
        Document d;

        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bytick.com/spot/v3/private/cancel-order?";
        
        const string& post_data = "{\"orderId\": null,\"orderLinkId\": \"" + order_id + "\"}";
        const string& msg = ep + api_key + "5000" + post_data;

        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("X-BAPI-SIGN:" + signature);
        extra_http_header.push_back("X-BAPI-API-KEY:" + api_key);
        extra_http_header.push_back("X-BAPI-TIMESTAMP:" + ep);
        extra_http_header.push_back("X-BAPI-RECV-WINDOW: 5000");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());
printJson(d);
                
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;        
    } 

};

