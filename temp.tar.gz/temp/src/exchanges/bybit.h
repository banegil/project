

class Bybit : public Exchange {
    const unsigned short id = 3;
    int depth;
    vector<string> v;

    public: 
    void get_exchanges(){        
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api.bytick.com/spot/v1/symbols", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("result") && d["ret_code"] == 0 && d["ret_msg"] == "OK"){
                for(auto& i : d["result"].GetArray()){
                    if(i["showStatus"] == true){ 
                        string quote = i["quoteCurrency"].GetString();
                        string base = i["baseCurrency"].GetString(); 

                        v.push_back(base + quote);

                        orderbook o = orderbook();                        
                        o.fee = {0, 0};                        
                        coins[base][quote] = o;

                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + to_string(id) + string(e.what()) ); 
         	printJson(d);
         	return;
        }
    }
   
    void websocketInit_depth(){        
        Document d;
        string s, quoteAsset, baseAsset;
        unordered_map<string, string> qA;
        qA["DT"] = "USDT"; qA["TH"] = "ETH"; qA["TC"] = "BTC"; qA["AI"] = "DAI"; qA["DC"] = "USDC";
        
        try {
            init_http("stream.bybit.com");
            init_webSocket("stream.bybit.com", "443", "/spot/quote/ws/v2"); // 100ms

            for(auto& i : v)  {   
                string ss = "{\"topic\": \"bookTicker\",\"event\": \"sub\",\"params\": {\"symbol\": \"" + i + "\",\"binary\": false}}";
                write_Socket(ss); 
                read_Socket();	          
                buffer_clear();
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            } 

            time_t current_time;
            time(&current_time);
            int ct = current_time;                              
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                if(ct2 - ct >= 25){
                    ct = ct2;
                    write_Socket(R"({"op":"ping"})");
                }
                                           
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("askPrice")){                   
                    s = d["data"]["symbol"].GetString();
                    quoteAsset = qA[s.substr(s.length() - 2)];
                    baseAsset = s.substr(0, s.length() - quoteAsset.length());
                    
                    auto&& c = coins[baseAsset][quoteAsset];

                    c.mtx->lock(); 
                    
                    c.asks.clear();
                    c.bids.clear();
                    
                    c.asks[stod(d["data"]["askPrice"].GetString())] = 0;
                    c.bids[stod(d["data"]["bidPrice"].GetString())] = 0;
                    
                    c.mtx->unlock(); 
                }
                else if(!d.HasMember("pong") && !(d.HasMember("event") && d["event"] == "sub"))
                    throw exception();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + to_string(id) + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
};

