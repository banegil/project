

class Gateio : public Exchange {
    const string id = "Gateio";
    const unsigned short idNum = 7;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETH_USDT";
    atomic<double> bestAsk, bestBid;
    double quotePrecision;
    bool limitOrder = 0;
    double remaining_qty = 0;
    
    const string api_key = "a6eaba764247a2a42cb4f7e739414613";
    const char* secret_key = "1b059a492d0e13abc36f37f8f180db4dc02808432e2634ebff20af4326eb03f1";

    void pingInterval(Wss& ws){
        time_t current_time;
        time(&current_time);
        int ct = current_time;  
                                    
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct >= 10){
                ct = ct2;
                const string& s = "{\"time\": " + to_string(ct2) + ", \"channel\" : \"spot.ping\"}";
                ws.write_Socket(s);
            }
        }
    }

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.0012, 0.0012}; // with 15000$ 0.0006
        symbol = chosenSymbol;
        symbol[symbol.find('-')] = '_';

        try{
            string result;          
            curl_api("https://api.gateio.ws/api/v4/spot/currency_pairs", result);
            d.Parse(result.c_str()); 

            if(d.IsArray()){
                for(auto& i : d.GetArray()){
                    if(i["trade_status"] == "tradable"){
                        string base = i["base"].GetString();  
                        string quote = i["quote"].GetString();   
                        
                        if( base + "-" + quote == chosenSymbol ){
                            exchangeInfo[idNum].multiplier = 1.0 / pow(10.0, i["amount_precision"].GetDouble()) ;
                            quotePrecision = 1.0 / pow(10.0, i["precision"].GetDouble()) ;
                            return 1;
                        }
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }

    void websocketInit_depth(){ 
        Wss ws;       
        Document d;       
        time_t current_time;  
        time(&current_time);
        int ct = current_time;
        string s = "{\"time\": " + to_string(ct) + ",\"channel\": \"spot.order_book\",\"event\": \"subscribe\", \"payload\": [\"" + symbol + "\", \"20\", \"100ms\"]}";
                
        try {
            ws.init_http("api.gateio.ws");
            ws.init_webSocket("api.gateio.ws", "443", "/ws/v4/");            
            ws.write_Socket(s);
                    
            ws.read_Socket();	
            ws.buffer_clear();
                       
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("result") && d["result"].HasMember("bids")){
  
                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["result"]["asks"].GetArray())
                        asks[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxAsk.unlock();
                    bestAsk = asks.begin()->first;
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["result"]["bids"].GetArray())
                        bids[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxBid.unlock();
                    bestBid = bids.begin()->first;
 
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    }  
    
    void websocketInit_User(){ 
        Wss ws;       
        Document d;       
        time_t current_time;  
        time(&current_time);
        int ct = current_time;
                
        try {
            ws.init_http("api.gateio.ws");
            ws.init_webSocket("api.gateio.ws", "443", "/ws/v4/"); 
            
            string msg = "channel=spot.usertrades&event=subscribe&time=" + to_string(ct);
            string signature = hmac_sha512( secret_key, msg.c_str() );
            string auth = "{\"method\": \"api_key\", \"KEY\": \"" + api_key + "\", \"SIGN\": \"" + signature + "\"}";     
            string s = "{\"auth\": " + auth + ",\"time\": " + to_string(ct) + ",\"channel\": \"spot.usertrades\",\"event\": \"subscribe\",\"payload\": [\"" + symbol + "\"]}";      
            ws.write_Socket(s);
            
            msg = "channel=spot.balances&event=subscribe&time=" + to_string(ct);
            signature = hmac_sha512( secret_key, msg.c_str() );
            auth = "{\"method\": \"api_key\", \"KEY\": \"" + api_key + "\", \"SIGN\": \"" + signature + "\"}";              
            s = "{\"auth\": " + auth + ",\"time\": " + to_string(ct) + ",\"channel\": \"spot.balances\",\"event\": \"subscribe\"}";      
            ws.write_Socket(s);
            
            for(int i = 0; i < 2; i++){        
                ws.read_Socket();
                d.Parse(ws.get_socket_data().c_str());	
                if(!(d.IsObject() && d.HasMember("event") && d.HasMember("result") && d["event"] == "subscribe" && !d["result"].IsNull() && d["result"]["status"] == "success"))
                    throw exception();
                ws.buffer_clear();
            }
            
            auto&& f = async(&Gateio::pingInterval, this, ref(ws));
            
            msg.clear(); signature.clear(); auth.clear(); s.clear(); 
            msg.shrink_to_fit(); signature.shrink_to_fit(); auth.shrink_to_fit(); s.shrink_to_fit();
                       
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject()){
                    if(d.HasMember("channel")){
                    
                        exchangeInfo[idNum].mtx->lock();

                        if(d["channel"] == "spot.balances")
                            exchangeInfo[idNum].balance[ d["result"][0]["currency"].GetString() ] = stod( d["result"][0]["total"].GetString() );
                        else if(d["channel"] == "spot.usertrades"){ // exchangeInfo[idNum].orderPrice == -1
                            if(limitOrder){
                                orderExecuted = true;                                    
                                const double& quantity = stod( d["result"][0]["filled_total"].GetString() );                                    
                                const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", quantity, 0.0, 0);
                                
                                if(res == 0)
                                    stopExecution = true;
                                else if(res == 1)
                                    remaining_qty += quantity;
                                else
                                    remaining_qty = 0;
                                
                                limitOrder = 0;
                            }                             
                            
                            exchangeInfo[idNum].orderPrice = stod( d["result"][0]["price"].GetString() ); 
                        }   
                            
                        exchangeInfo[idNum].mtx->unlock();                       
                                                        
                    }
                    else
                        throw exception();
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    }  
    
    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {	
        Document d;
        double orderPrice;
        
        if(limit)
            orderPrice = price;
        else{
            orderPrice = side == "buy" ? bestAsk * 1.1 : bestBid * 0.9;  
            my_round(orderPrice, quotePrecision);    
        } 

        time_t current_time;
        const int& t = time(&current_time);
        const string& ep = to_string(t);

        const char* url = "https://api.gateio.ws/api/v4/spot/orders";
        const string& action = "POST";
            
        const string& post_data = "{\"currency_pair\":\"" + symbol + "\",\"type\":\"limit\",\"account\":\"spot\",\"side\":\"" + side + "\",\"amount\":\"" + to_string(quantity) +
                                    "\",\"price\":\"" + to_string(orderPrice) + "\"}"; 
        const string& msg = action + "\n" + "/api/v4/spot/orders" + "\n" + "\n" + sha512( post_data.c_str() ) + "\n" + ep;
        
        const string& signature = hmac_sha512( secret_key, msg.c_str() );
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Accept: application/json");
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("KEY:" + api_key);
        extra_http_header.push_back("Timestamp:" + ep);
        extra_http_header.push_back("SIGN:" + signature);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str()); 

                if(d.IsObject() && d.HasMember("status") && d.HasMember("fill_price")){
                    if(d["status"] == "closed" && stod( d["fill_price"].GetString() ) != 0.0)
                        exchangeInfo[idNum].orderPrice = stod( d["fill_price"].GetString() );
                }
                else if(d.IsObject() && d.HasMember("label") && d["label"] == "INVALID_PARAM_VALUE")
                    return 1;
                else
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 2;
    }
    
    bool cancel_order() {	
        Document d;

        time_t current_time;
        const int& t = time(&current_time);
        const string& ep = to_string(t);

        const string& url = "https://api.gateio.ws/api/v4/spot/orders?currency_pair=" + symbol;
        const string& action = "DELETE";
            
        const string& msg = action + "\n" + "/api/v4/spot/orders" + "\n" + "currency_pair=" + symbol + "\n" + sha512( "" ) + "\n" + ep;        
        const string& signature = hmac_sha512( secret_key, msg.c_str() );
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Accept: application/json");
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("KEY:" + api_key);
        extra_http_header.push_back("Timestamp:" + ep);
        extra_http_header.push_back("SIGN:" + signature);
        
        string str_result;
        curl_api_with_header( url.c_str(), str_result , extra_http_header, "", action ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str()); 
                
                if(!(d.IsArray() && d[0].HasMember("status") && d[0]["status"] == "cancelled"))
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;
    }
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

