

class Okx : public Exchange {
    const string id = "Okx";
    const unsigned short idNum = 11;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string base = "ETH";
    string quote = "USDT";
    atomic<double> bestAsk, bestBid;
    double quotePrecision;
    string orderId;
    bool limitOrder = 0;
    double remaining_qty = 0;
    
    const string api_key = "88d2368c-b1e2-46c3-b48b-ba171c51c058";
    const char* secret_key = "7C0666CFEAED16090916E88467AA733C";

    /* CRC32 okx algorithm doesn't work, return negative values'
    long long checkSum(){
        string s = "";
        
        auto&& i = asks.begin();
        auto&& j = bids.begin();
        int cont = 0;
        while (cont++ < 25){
            if(j != bids.end()){
                s += "bid[" + removeZeros(my_toString(j->first)) + ":" + removeZeros(my_toString(j->second)) + "]:";
                ++j;
            }
            
            if(i != asks.end()){
                s += "ask[" + removeZeros(my_toString(i->first)) + ":" + removeZeros(my_toString(i->second)) + "]:";
                ++i;
            }
        }
        
        s.pop_back();
        return CRC32(s);
    }*/

    void pingInterval(Wss& ws){
        time_t current_time;
        time(&current_time);
        int ct = current_time;  
                                    
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct >= 25){
                ct = ct2;
                const string& ss = "ping";
                ws.write_Socket(ss);
            }
        }
    }

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.0008, 0.001}; 
        string symbol = chosenSymbol;
        base = symbol.substr(0, symbol.find('-'));
        quote = symbol.substr(symbol.find('-') + 1, symbol.length() - 1); 
        
        try{
            string result;          
            curl_api("https://aws.okx.com/api/v5/public/instruments?instType=SPOT", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("data") && d["code"] == "0"){
                for(auto& i : d["data"].GetArray()){
                    if(i["state"] == "live"){       
                        string quote = i["quoteCcy"].GetString();
                        string base = i["baseCcy"].GetString();

                        if( base + "-" + quote == chosenSymbol ){
                            exchangeInfo[idNum].multiplier = stod( i["minSz"].GetString() );
                            quotePrecision = stod( i["tickSz"].GetString() );
                            return 1;
                        }
                    }
                }
            }
            else
                throw exception();
                
        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }       
        return 0;
    }    

    void websocketInit_depth(){ 
        Wss ws;    
        Document d;
        string s = "{\"op\":\"subscribe\",\"args\":[{\"channel\":\"books5\",\"instId\":\"" + chosenSymbol + "\"}]}";

        try {   
            ws.init_http("wsaws.okx.com");
            ws.init_webSocket("wsaws.okx.com", "443", "/ws/v5/public");  
            ws.write_Socket(s);         

            ws.read_Socket();	
            ws.buffer_clear();
                      
            time_t current_time;
            time(&current_time);
            int ct = current_time;                              
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                if(ct2 - ct >= 25){
                    ct = ct2;
                    const string& ss = "ping";
                    ws.write_Socket(ss);
                }
                         
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"][0].HasMember("asks")){
                
                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["data"][0]["asks"].GetArray())
                        asks[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxAsk.unlock();
                    bestAsk = asks.begin()->first;
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["data"][0]["bids"].GetArray())
                        bids[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxBid.unlock();
                    bestBid = bids.begin()->first;

                    /*By the moment, we use 5books, problem with CRC32 Okx algorithm, it returns negative values, and it shouldn't
                    if(checkSum() != d["data"]["checksum"].GetInt64()){
                        const string& err = "<wss_depth> " + id + " Packet loss, reconnecting...";
                        writte_err( "err.txt", err );
                        write_Socket(s);
                    }*/
                }
                else if(!d.HasMember("event"))
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){ 
        Wss ws;    
        Document d;

        try {   
            ws.init_http("wsaws.okx.com");
            ws.init_webSocket("wsaws.okx.com", "443", "/ws/v5/private"); 
            
            time_t current_time;
            time(&current_time);
            int ct = current_time;
            const string& ep = to_string(ct);
            
            const string& msg = ep + "GET/users/self/verify";
            const string& signature =  hmac_sha256_2( secret_key, msg.c_str() );

            string s = "{\"op\": \"login\",\"args\": [{\"apiKey\": \"" + api_key + "\",\"passphrase\": \"160196mM.\",\"timestamp\": \"" + ep + "\",\"sign\": \"" + signature + "\"}]}";
            ws.write_Socket(s);   
            
            ws.read_Socket(); 
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("event") && d["event"] == "login" && d.HasMember("code") && d["code"] == "0"))
                throw exception();
            ws.buffer_clear();
            
            s = "{\"op\": \"subscribe\",\"args\": [{\"channel\": \"orders\", \"instType\": \"ANY\"}]}"; 
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("arg") && d["arg"].HasMember("channel") && d["arg"]["channel"] == "orders"))
                throw exception();
            ws.buffer_clear(); 
            
            s = "{\"op\": \"subscribe\",\"args\": [{\"channel\": \"balance_and_position\"}]}"; 
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("arg") && d["arg"].HasMember("channel") && d["arg"]["channel"] == "balance_and_position"))
                throw exception();
            ws.buffer_clear();

            auto&& f = async(&Okx::pingInterval, this, ref(ws)); 
            s.clear(); s.shrink_to_fit();
            
            string uTime = "";                                      
            while (true) {
                         
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("arg") && d["arg"].HasMember("channel")){
                
                    exchangeInfo[idNum].mtx->lock();
                
                    if(d["arg"]["channel"] == "orders" && d["data"][0]["uTime"].GetString() != uTime && d["data"][0][""]["avgPx"] != "0"){
                        if(limitOrder){
                            orderExecuted = true;                                    
                            const double& quantity = stod( d["data"][0]["accFillSz"].GetString() );                                     
                            const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", quantity, 0.0, 0);
                            
                            if(res == 0)
                                stopExecution = true;
                            else if(res == 1)
                                remaining_qty += quantity;
                            else
                                remaining_qty = 0;
                            
                            limitOrder = 0;
                        }
                    
                        exchangeInfo[idNum].orderPrice = stod( d["data"][0]["avgPx"].GetString() ); 
                        uTime = d["data"][0]["uTime"].GetString();
                    }
                    else if(d["arg"]["channel"] == "balance_and_position"){
                        for(auto&& i : d["data"][0]["balData"].GetArray())
                            if(base.c_str() == i["ccy"] || quote.c_str() == i["ccy"])
                                exchangeInfo[idNum].balance[ i["ccy"].GetString() ] = stod( i["cashBal"].GetString() );
                    }
                    else 
                        throw exception();
                        
                    exchangeInfo[idNum].mtx->unlock();
                    
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {	
        Document d;
        double orderPrice;
        
        if(limit)
            orderPrice = price;
        else{
            orderPrice = side == "buy" ? bestAsk * 1.1 : bestBid * 0.9;  
            my_round(orderPrice, quotePrecision);      
        } 
        
        time_t now;
        time(&now);
        char buf[sizeof "2011-10-08T07:07:09Z"];
        strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", gmtime(&now));
        const string& ep = buf;
        const char* url = "https://aws.okex.com/api/v5/trade/order";

        const string& post_data = "{\"instId\":\"" + chosenSymbol + "\",\"tdMode\":\"cash\",\"side\":\"" + side + "\",\"ordType\":\"limit\",\"px\":\"" + to_string(orderPrice) + "\",\"sz\":\"" + to_string(quantity) + "\"}";        
        const string& msg = ep + "POST/api/v5/trade/order" + post_data;
        const string& signature =  hmac_sha256_2( secret_key, msg.c_str() );
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Accept: application/json");
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("OK-ACCESS-KEY:" + api_key);
        extra_http_header.push_back("OK-ACCESS-SIGN:" + signature);
        extra_http_header.push_back("OK-ACCESS-TIMESTAMP:" + ep);
        extra_http_header.push_back("OK-ACCESS-PASSPHRASE: 160196mM.");
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "POST" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str()); 
      
                if(d.IsObject() && d.HasMember("code") && d["code"] == "0")
                    orderId = d["data"][0]["ordId"].GetString();
                else if(d.IsObject() && d.HasMember("code") && d["code"] == "1" && d.HasMember("data") &&  d["data"].Size() > 0 && d["data"][0].HasMember("sCode") && d["data"][0]["sCode"] == "51020")
                    return 1;
                else
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 2;
    }
    
    bool cancel_order() {	
        Document d;
        
        time_t now;
        time(&now);
        char buf[sizeof "2011-10-08T07:07:09Z"];
        strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", gmtime(&now));
        const string& ep = buf;
        const char* url = "https://aws.okex.com/api/v5/trade/cancel-order";

        const string& post_data = "{\"instId\":\"" + chosenSymbol + "\",\"ordId\":\"" + orderId + "\"}";        
        const string& msg = ep + "POST/api/v5/trade/cancel-order" + post_data;
        const string& signature =  hmac_sha256_2( secret_key, msg.c_str() );
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Accept: application/json");
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("OK-ACCESS-KEY:" + api_key);
        extra_http_header.push_back("OK-ACCESS-SIGN:" + signature);
        extra_http_header.push_back("OK-ACCESS-TIMESTAMP:" + ep);
        extra_http_header.push_back("OK-ACCESS-PASSPHRASE: 160196mM.");
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "POST" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str()); 
      
                if(!(d.IsObject() && d.HasMember("code") && d["code"] == "0"))
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;
    }
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

