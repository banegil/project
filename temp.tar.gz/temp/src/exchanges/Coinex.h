

class Coinex : public Exchange {
    const string id = "Coinex";
    const unsigned short idNum = 4;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETHUSDT";
    string base = "ETH";
    string quote = "USDT";
    atomic<double> bestAsk, bestBid;
    double quotePrecision;
    string orderId;
    bool limitOrder = 0;
    double remaining_qty = 0;
    
    string api_key = "29C38AADE8444EBE9CD6840A882BE643";
    const char* secret_key = "E49DFF792A780D55CB452D4D2F5467BBDB41F090166DDEA7";

    bool get_pairInfo(){        
        Document d;
        
        try{
            string result;          
            curl_api("https://api.coinex.com/v1/market/detail?market=" + symbol, result);
            d.Parse(result.c_str());         

            if(d.HasMember("code") && d["code"] == 0 && d.HasMember("message") && d["message"] == "OK"){
                exchangeInfo[idNum].multiplier = stod( d["data"]["min_amount"].GetString() );
                quotePrecision = 1.0 / pow(10.0, d["data"]["pricing_decimal"].GetDouble() );
            }    
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairInfo> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 1;
    }

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.00128, 0.00128}; // with 3600$ 0.00112 
        symbol = chosenSymbol;
        base = symbol.substr(0, symbol.find('-'));
        quote = symbol.substr(symbol.find('-') + 1, symbol.length() - 1); 
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end()); 
        
        try{
            string result;          
            curl_api("https://api.coinex.com/v1/market/list", result);
            d.Parse(result.c_str());        

            if(d.HasMember("data") && d["code"] == 0 && d["message"] == "OK"){
                for(auto& i : d["data"].GetArray()){
                    string s = i.GetString();

                    if(symbol ==  s){
                        if(get_pairInfo())
                            return 1;    
                    }                   
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }

    void websocketInit_depth(){
        Wss ws;
        Document d;
        string s = "{\"method\":\"depth.subscribe\",\"params\":[\"" + symbol + "\",20,\"0\",false],\"id\": 11}";
        
        try {
            ws.init_http("socket.coinex.com");
            ws.init_webSocket("socket.coinex.com", "443", "/");
            ws.write_Socket(s);
            
            ws.read_Socket(); 	
            ws.buffer_clear();
                              
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str()); 

                if(d.IsObject() && d.HasMember("method") && d["method"] == "depth.update"){

                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["params"][1]["asks"].GetArray())
                        asks[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxAsk.unlock();
                    bestAsk = asks.begin()->first;
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["params"][1]["bids"].GetArray())
                        bids[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxBid.unlock();
                    bestBid = bids.begin()->first;
                
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){
        Wss ws;
        Document d;
        const string& ep = to_string (get_current_ms_epoch());
        const string& msg = "access_id=" + api_key + "&tonce=" + ep + "&secret_key=" + secret_key;
        
        unsigned char digest[MD5_DIGEST_LENGTH];
        char msgString[msg.length() + 1];
        strcpy(msgString, msg.c_str());
        MD5((unsigned char*)&msgString, strlen(msgString), (unsigned char*)&digest); 
        char mdString[33]; 
        for(int i = 0; i < 16; i++)
             sprintf(&mdString[i*2], "%02x", (unsigned int)digest[i]);
        
        string signature = mdString;   
        string_toupper(signature);
        
        string s = "{\"method\": \"server.sign\",\"params\": [\"" + api_key + "\",\"" + signature + "\"," + ep + "],\"id\":15}";
        
        try {
            ws.init_http("socket.coinex.com");
            ws.init_webSocket("socket.coinex.com", "443", "/");
            ws.write_Socket(s);
            
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("error") && d["error"].IsNull() && d.HasMember("result") && d["result"].HasMember("status") && d["result"]["status"] == "success"))
                throw exception();
            ws.buffer_clear();
            
            s = "{\"method\": \"asset.subscribe\",\"params\": [\"" + base + "\",\"" + quote + "\"],\"id\": 15}";
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("error") && d["error"].IsNull() && d.HasMember("result") && d["result"].HasMember("status") && d["result"]["status"] == "success"))
                throw exception();
            ws.buffer_clear();
            
            s = "{\"method\": \"order.subscribe\",\"params\": [\"" + symbol + "\"],\"id\": 15}";
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("error") && d["error"].IsNull() && d.HasMember("result") && d["result"].HasMember("status") && d["result"]["status"] == "success"))
                throw exception();
            ws.buffer_clear();
                              
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("method")){                    
                    exchangeInfo[idNum].mtx->lock();
    
                    if(d["method"] == "asset.update"){
                        if(d["params"][0].HasMember(base.c_str()))
                            exchangeInfo[idNum].balance[base] = stod( d["params"][0][base.c_str()]["available"].GetString() );
                        else
                            exchangeInfo[idNum].balance[quote] = stod( d["params"][0][quote.c_str()]["available"].GetString() );                            
                    }
                    else if(d["method"] == "order.update"){                        
                        if(limitOrder){
                            orderExecuted = true;                                    
                            const double& quantity = stod( d["params"][1]["deal_stock"].GetString() );                                    
                            const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", quantity, 0.0, 0);
                            
                            if(res == 0)
                                stopExecution = true;
                            else if(res == 1)
                                remaining_qty += quantity;
                            else
                                remaining_qty = 0;
                            
                            limitOrder = 0;
                        } 
                    
                        exchangeInfo[idNum].orderPrice = stod( d["params"][1]["last_deal_price"].GetString() ); // last_deal_price != Avg_price
                    }
                        
                    exchangeInfo[idNum].mtx->unlock();
                    
                }
                else 
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    }
    
    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {
        Document d;
        double orderPrice;
        
        if(limit)
            orderPrice = price;
        else{
            orderPrice = side == "buy" ? bestAsk * 1.1 : bestBid * 0.9;  
            my_round(orderPrice, quotePrecision);      
        }
        
        const char* url = "https://api.coinex.com/v1/order/limit";
        const string& ep = to_string (get_current_ms_epoch());
        const string& post_data = "{\"access_id\":\"" + api_key + "\",\"amount\":\"" + to_string(quantity) + "\",\"market\":\"" + symbol + "\",\"price\":\"" +
                                     to_string(orderPrice) + "\",\"tonce\":" + ep + ",\"type\":\"" + side + "\"}";
        const string& msg = "access_id=" + api_key + "&amount=" + to_string(quantity) + "&market=" + symbol + "&price=" + to_string(orderPrice) + "&tonce=" +
                             ep + "&type=" + side + "&secret_key=" + secret_key;
        
        // **** MD5 ****
        unsigned char digest[MD5_DIGEST_LENGTH];
        char msgString[msg.length() + 1];
        strcpy(msgString, msg.c_str());
        MD5((unsigned char*)&msgString, strlen(msgString), (unsigned char*)&digest); 
        char mdString[33]; 
        for(int i = 0; i < 16; i++)
             sprintf(&mdString[i*2], "%02x", (unsigned int)digest[i]);
        
        string signature = mdString;   
        string_toupper(signature);
        // *************

        vector <string> extra_http_header;
        extra_http_header.push_back("User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36");
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("authorization:" + signature);

        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "POST" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());  

                if(d.IsObject() && d.HasMember("code")) {
                    if(d.HasMember("message") && d["code"] == 0 && d["message"] == "Success"){}
                    else if(d["code"] == 602)
                        return 1;
                    else
                        throw exception();    
                }
                else throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 2;
    }
    
    bool cancel_order() {
        Document d;
        
        string url = "https://api.coinex.com/v1/order/pending?";
        const string& ep = to_string (get_current_ms_epoch());
        const string& post_data = "access_id=" + api_key + "&market=" + symbol + "&tonce=" + ep;
        const string& msg = "access_id=" + api_key + "&market=" + symbol + "&tonce=" + ep + "&secret_key=" + secret_key;
        url += post_data;
        
        // **** MD5 ****
        unsigned char digest[MD5_DIGEST_LENGTH];
        char msgString[msg.length() + 1];
        strcpy(msgString, msg.c_str());
        MD5((unsigned char*)&msgString, strlen(msgString), (unsigned char*)&digest); 
        char mdString[33]; 
        for(int i = 0; i < 16; i++)
             sprintf(&mdString[i*2], "%02x", (unsigned int)digest[i]);
        
        string signature = mdString;   
        string_toupper(signature);
        // *************

        vector <string> extra_http_header;
        extra_http_header.push_back("User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36");
        extra_http_header.push_back("authorization:" + signature);

        string str_result;
        curl_api_with_header( url.c_str(), str_result , extra_http_header, post_data, "DELETE" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());  
               
                if(!(d.IsObject() && d.HasMember("code") && d["code"] == 0 && d.HasMember("message") && d["message"] == "Success"))
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading cancel_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": cancel_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;
    }
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

