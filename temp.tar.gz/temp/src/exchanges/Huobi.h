

class Huobi : public Exchange {
    const string id = "Huobi";
    const unsigned short idNum = 8;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ethusdt";
    string timestamp;
    atomic<double> bestAsk, bestBid;
    double quotePrecision;
    string orderId;
    bool limitOrder = 0;
    double remaining_qty = 0;
    
    const string api_key = "d4629f1d-851f7da5-dab4c45e6f-f1b32";
    const char* api_secret = "586bac90-c8f6249d-769ef6f9-2d2f7";

    string createSignatureParamHuobi(const string& url, const string& action) {
        map<string, const char *> params;
        time_t nowtime = time(0);
        struct tm *utc = gmtime(&nowtime);
        char buf[50];
        strftime(buf, 50, "%Y-%m-%dT%H:%M:%S", utc);
        CURL *curl = curl_easy_init();
        timestamp = encode(buf);

        params["AccessKeyId"] = api_key.c_str();
        params["SignatureMethod"] = "HmacSHA256";
        params["SignatureVersion"] = "2";
        params["Timestamp"] = timestamp.c_str();

        string paramsStr;
        paramsStr.append(action).append("\n").append("api.huobi.pro").append("\n").append(url).append("\n");
        string spliceStr;
        
        for (map<string, const char *>::iterator iter = params.begin(); iter != params.end(); ++iter) {
            spliceStr.append(iter->first).append("=").append(iter->second);
            if (iter != --params.end()) 
                spliceStr.append("&");
        }
        
        paramsStr.append(spliceStr);

        unsigned int md_len;
        unsigned char *str = HMAC(EVP_sha256(), api_secret, strlen(api_secret), reinterpret_cast<const unsigned char *>(paramsStr.c_str()), paramsStr.size(), nullptr, &md_len);
        char signature[100];
        EVP_EncodeBlock((unsigned char *) signature, str, md_len);
        spliceStr.append("&Signature=").append(encode(signature)).c_str();
        
        return spliceStr;
    }
    
    string createSignatureParamHuobiWs() {
        std::map<string, const char *> params;
        time_t nowtime = time(0);
        struct tm *utc = gmtime(&nowtime);
        char buf[50];
        strftime(buf, 50, "%Y-%m-%dT%H:%M:%S", utc);
        CURL *curl = curl_easy_init();
        this->timestamp = buf;
        string ts = encode(this->timestamp.c_str());

        params["accessKey"] = api_key.c_str();
        params["signatureMethod"] = "HmacSHA256";
        params["signatureVersion"] = "2.1";
        params["timestamp"] = ts.c_str();

        std::string paramsStr;
        paramsStr.append("GET").append("\n").append("api.huobi.pro").append("\n").append("/ws/v2").append("\n");
        std::string spliceStr;
        for (map<string, const char *>::iterator iter = params.begin(); iter != params.end(); ++iter) {
            spliceStr.append(iter->first).append("=").append(iter->second);
            if (iter != --params.end()) {
                spliceStr.append("&");
            }
        }
        paramsStr.append(spliceStr);

        unsigned int md_len;
        unsigned char *str = HMAC(EVP_sha256(),api_secret, strlen(api_secret), reinterpret_cast<const unsigned char *>(paramsStr.c_str()), paramsStr.size(), nullptr,&md_len);
        char signature[100];
        EVP_EncodeBlock((unsigned char *) signature, str, md_len);

        return signature;
    }

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.0018, 0.0018}; // with 2500$ 0.0012
        symbol = chosenSymbol;  
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());  
        transform(symbol.begin(), symbol.end(), symbol.begin(),[](unsigned char c){ return tolower(c); }); 

        try{
            string result;          
            curl_api("https://api-aws.huobi.pro/v2/settings/common/symbols", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("data") && d["status"] == "ok"){
                for(auto& i : d["data"].GetArray()){
                    if(i["state"] == "online" && i["te"] == true){
                        string base = i["bc"].GetString();  
                        string quote = i["qc"].GetString(); 
                        transform(base.begin(), base.end(), base.begin(),[](unsigned char c){ return toupper(c); }); 
                        transform(quote.begin(), quote.end(), quote.begin(),[](unsigned char c){ return toupper(c); }); 
                        
                        if( base + "-" + quote == chosenSymbol ){
                            exchangeInfo[idNum].multiplier = 1.0 / pow(10.0, i["tap"].GetDouble()) ;
                            quotePrecision = 1.0 / pow(10.0, i["tpp"].GetDouble()) ;
                            return 1;
                        }
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }
    
    void websocketInit_depth(){ 
        Wss ws;       
        Document d;  
        string s = "{\"sub\": \"market." + symbol + ".mbp.refresh.20\",\"id\": \"id1\"}";
                
        try {
            ws.init_http("api-aws.huobi.pro");
            ws.init_webSocket("api-aws.huobi.pro", "443", "/ws");   
            ws.write_Socket(s); 
            
            ws.read_Socket();
            ws.buffer_clear();
                         
            while (true) {
                ws.read_Socket();	
                d.Parse(decompress_gzip(ws.get_socket_data()).c_str());

                if(d.IsObject() && d.HasMember("tick") && d["tick"].HasMember("bids")){
                
                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["tick"]["asks"].GetArray())
                        asks[ i[0].GetDouble() ] = i[1].GetDouble();
                    mtxAsk.unlock();
                    bestAsk = asks.begin()->first;
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["tick"]["bids"].GetArray())
                        bids[ i[0].GetDouble() ] = i[1].GetDouble();
                    mtxBid.unlock();
                    bestBid = bids.begin()->first;
                
                }
                else if(d.HasMember("ping")){
                    const long& l = d["ping"].GetUint64();
                    s = "{\"pong\":" + to_string(l) + "}";
                    ws.write_Socket(s); 
                }
                else if(!d.HasMember("subbed"))
                    throw exception();              

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){ 
        Wss ws;       
        Document d; 
                
        try {
            ws.init_http("api.huobi.pro");
            ws.init_webSocket("api.huobi.pro", "443", "/ws/v2");   
            
            const string& signature = createSignatureParamHuobiWs(); 
            string s = "{\"action\": \"req\", \"ch\": \"auth\",\"params\": { \"authType\":\"api\",\"accessKey\": \"" +
                         api_key + "\",\"signatureMethod\": \"HmacSHA256\",\"signatureVersion\": \"2.1\",\"timestamp\": \"" +
                         timestamp + "\",\"signature\": \"" + signature + "\"}}";
            ws.write_Socket(s); 
 
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("code") && d.HasMember("ch") && d["code"] == 200 && d["ch"] == "auth"))
                throw exception();
            ws.buffer_clear();
                
            s = "{\"action\": \"sub\",\"ch\": \"trade.clearing#" + symbol + "#0\"}";
            ws.write_Socket(s); 
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("code") && d["code"] == 200))
                throw exception();
            ws.buffer_clear();
            
            s = "{\"action\": \"sub\",\"ch\": \"accounts.update#2\"}";
            ws.write_Socket(s); 
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("code") && d["code"] == 200))
                throw exception();
            ws.buffer_clear();
                         
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("action")){
                
                    if(d["action"] == "push"){  
                    
                        if(d.HasMember("ch")){     
                        
                            exchangeInfo[idNum].mtx->lock();      
                        
                            if(d["ch"] == "accounts.update#2")
                                exchangeInfo[idNum].balance[ d["data"]["currency"].GetString() ] = stod( d["data"]["available"].GetString() );
                            if(d["ch"].GetString() == "trade.clearing#" + symbol + "#0" && d["data"]["orderStatus"] == "filled"){ 
                                if(limitOrder){
                                    orderExecuted = true;                                    
                                    const double& quantity = stod( d["data"]["tradeVolume"].GetString() );                                    
                                    const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", quantity, 0.0, 0);
                                    
                                    if(res == 0)
                                        stopExecution = true;
                                    else if(res == 1)
                                        remaining_qty += quantity;
                                    else
                                        remaining_qty = 0;
                                    
                                    limitOrder = 0;
                                } 
                                                   
                                exchangeInfo[idNum].orderPrice = stod( d["data"]["tradePrice"].GetString() ); 
                            }
                                
                            exchangeInfo[idNum].mtx->unlock(); 
                        } 
                        else 
                            throw exception();            
                                                 
                    }
                    else if(d["action"] == "ping"){
                        const long& l = d["data"]["ts"].GetUint64();
                        s = "{\"action\": \"pong\",\"data\": {\"ts\": " + to_string(l) + "}}";
                        ws.write_Socket(s);
                    }
                    else
                        throw exception();
                     
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
        
    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {	 
        Document d;
        double orderPrice;
        
        if(limit)
            orderPrice = price;
        else{
            orderPrice = side == "buy" ? bestAsk * 1.05 : bestBid * 0.95;  
            my_round(orderPrice, quotePrecision);      
        } 

        const string& post_data = createSignatureParamHuobi("/v1/order/orders/place", "POST");
        const string& url = "https://api.huobi.pro/v1/order/orders/place?" + post_data;

        vector <string> extra_http_header;
        extra_http_header.push_back("Accept: application/json");
        extra_http_header.push_back("Content-Type: application/json");

        const string& body = "{\"account-id\":\"48038614\",\"price\":\"" + my_toString(orderPrice) + "\",\"symbol\":\"" + symbol + "\",\"type\":\"" + side + "-limit\",\"amount\":\"" + my_toString(quantity) + "\"}";
        
        string str_result;
        curl_api_with_header( url.c_str(), str_result , extra_http_header, body, "POST");

        if ( str_result.size() > 0 ) {
            try {
                d.Parse(str_result.c_str());

	            if(d.IsObject() && d.HasMember("status")){
	                if(d["status"] == "ok")
	                    orderId = d["data"].GetString();
	                else if(d["status"] == "error" && d.HasMember("err-code") && d["err-code"] == "order-limitorder-amount-min-error")
	                    return 1;
	                else
	                    throw exception();
	            }
	            else
	                throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 2;
    } 
    
    bool cancel_order() {	 
        Document d;

        const string& post_data = createSignatureParamHuobi("/v1/order/orders/" + orderId + "/submitcancel", "POST");
        const string& url = "https://api.huobi.pro/v1/order/orders/" + orderId + "/submitcancel?" + post_data;

        vector <string> extra_http_header;
        extra_http_header.push_back("Accept: application/json");
        extra_http_header.push_back("Content-Type: application/json");

        const string& body = "{\"order-id\":\""+orderId+"\"}";
        
        string str_result;
        curl_api_with_header( url.c_str(), str_result , extra_http_header, body, "POST");

        if ( str_result.size() > 0 ) {
            try {
                d.Parse(str_result.c_str());
	            
	            if(!(d.IsObject() && d.HasMember("status") && d["status"] == "ok"))
	                throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading cancel_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": cancel_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;
    } 
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

