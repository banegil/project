

class Ascendex : public Exchange {
    const string id = "Ascendex";
    const unsigned short idNum = 1;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETH/USDT";
    string base = "ETH";
    string quote = "USDT";
    string orderId;
    bool limitOrder = 0;
    double remaining_qty = 0;
    
    const string api_key = "qdB0DS6HQfSHvD5pa46MVR85hD1RhYDj";
    const char* secret_key = "WXfHJkkNMovwJkftXnijTuF8FuwB8ecfQ9cCiJVCIQCa4uzjYwMkIH4hAdVEbgSL";

    public:
    bool get_pairs(){      
        Document d;
        unordered_map<string, bool> largeCap;
        largeCap["BTC"] = largeCap["ETH"] = largeCap["XRP"] = largeCap["USDT"] = largeCap["BCH"] = largeCap["LTC"] = largeCap["EOS"] = largeCap["BNB"] = largeCap["BSV"] = largeCap["XLM"] = largeCap["ADA"] = largeCap["TRX"] = largeCap["LINK"] = largeCap["HT"]
         = largeCap["OKB"] = largeCap["ATOM"] = largeCap["DASH"] = largeCap["ETC"] = largeCap["NEO"] = largeCap["XEM"] = largeCap["DOGE"] = largeCap["ZEC"] = largeCap["ALGO"] = largeCap["DOT"] = largeCap["FIL"] = largeCap["UNI"]
         = largeCap["FTT"] = 1;
        symbol = chosenSymbol;
        base = symbol.substr(0, symbol.find('-'));
        quote = symbol.substr(symbol.find('-') + 1, symbol.length() - 1); 
        symbol[symbol.find('-')] = '/';     
        
        try{
            string result;          
            curl_api("https://ascendex.com/api/pro/v1/cash/products", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("data") && d["code"] == 0){
                for(auto& i : d["data"].GetArray()){
                    if(i["statusCode"] == "Normal"){          
                        string s = i["symbol"].GetString();
                        string base = s.substr(0, s.find('/'));
                        string quote = s.substr(s.find('/') + 1, s.length() - 1);
                
                        if(largeCap[base])
                            fee = {0.001, 0.001}; // with 2000$ can be 0.00075 and 0.00085
                        else
                            fee = {0.002, 0.002}; // with 2000$ can be 0.0016 and 0.0018

                        if(base + "-" + quote == chosenSymbol){
                            exchangeInfo[idNum].multiplier = stod( i["lotSize"].GetString() );
                            return 1;
                        }
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }

    void websocketInit_depth(){ 
        Wss ws;       
        Document d;
        string s = "{ \"op\": \"sub\", \"id\": \"abc123\", \"ch\":\"depth:" + symbol + "\" }";
        
        try {
            unsigned long long seqNum = 0;
            ws.init_http("ascendex.com");
            ws.init_webSocket("ascendex.com", "443", "/api/pro/v2/stream");
            ws.write_Socket(s); 

            ws.read_Socket();
            ws.buffer_clear();	

            while (true) {                     
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("asks")){
                    if(seqNum == 0 || seqNum + 1 == d["data"]["seqnum"].GetUint64()){
                        seqNum = d["data"]["seqnum"].GetUint64();
                    
                        mtxAsk.lock();
                        for(auto&& i : d["data"]["asks"].GetArray()){
                            double price = stod( i[0].GetString() );
                            double qty = stod( i[1].GetString() );
                            
                            if(qty == 0)
                                asks.erase(price);
                            else
                                asks[price] = qty;
                        }
                        mtxAsk.unlock();
                            
                        mtxBid.lock();
                        for(auto&& i : d["data"]["bids"].GetArray()){
                            double price = stod( i[0].GetString() );
                            double qty = stod( i[1].GetString() );
                            
                            if(qty == 0)
                                bids.erase(price);
                            else
                                bids[price] = qty;
                        }
                        mtxBid.unlock();
                    }
                    else{
                        const string& err = "<wss_depth> " + id + " Packet loss, reconnecting...";
                        writte_err( "err.txt", err ); 
                        seqNum = 0;
                        ws.write_Socket(s);
                    }                    
                }
                else if(d.HasMember("m") && d["m"] == "ping")
                    ws.write_Socket(R"({ "op": "pong" })");  
                else if(!(d.HasMember("m") && d["m"] == "sub"))
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){  
        Wss ws;      
        Document d;
        const string& ep = to_string(get_current_ms_epoch());
        
        try {
            ws.init_http("ascendex.com");
            ws.init_webSocket("ascendex.com", "443", "/2/api/pro/v2/stream");

            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(d.IsObject() && d.HasMember("m") && d["m"] == "connected") {}
            else throw exception();
            ws.buffer_clear();
            
            const string& msg = ep + "+v2/stream";
            const string& signature =  hmac_sha256( secret_key, msg.c_str() );
            string s = "{\"op\":\"auth\", \"id\": \"abc123\", \"t\": " + ep + ", \"key\": \"" + api_key + "\", \"sig\": \"" + signature + "\"}";
            ws.write_Socket(s); 
            
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(d.IsObject() && d.HasMember("m") && d["m"] == "auth" && d.HasMember("code") && d["code"] == 0) {}
            else throw exception();
            ws.buffer_clear();
            
            s = "{ \"op\": \"sub\", \"id\": \"abc123\", \"ch\":\"order:cash\" }";
            ws.write_Socket(s);
            
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(d.IsObject() && d.HasMember("m") && d["m"] == "sub" && d.HasMember("code") && d["code"] == 0) {}
            else throw exception();
            ws.buffer_clear();

            while (true) {                     
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject()){
                    if(d.HasMember("m") && d["m"] == "order" && d.HasMember("ac") && d["ac"] == "CASH"){                  
                        if(d.HasMember("data") && d["data"].HasMember("cfq")){
                            if(d["data"]["cfq"] != "0"){
                            
                                if(limitOrder){
                                    orderExecuted = true;                                    
                                    const double& quantity = stod( d["data"]["cfq"].GetString() );                                    
                                    const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", quantity, 0.0, 0);
                                    
                                    if(res == 0)
                                        stopExecution = true;
                                    else if(res == 1)
                                        remaining_qty += quantity;
                                    else
                                        remaining_qty = 0;
                                    
                                    limitOrder = 0;
                                } 
                            
                                exchangeInfo[idNum].mtx->lock();
                                
                                exchangeInfo[idNum].balance[base] = stod( d["data"]["bab"].GetString() );
                                exchangeInfo[idNum].balance[quote] = stod( d["data"]["qab"].GetString() );
                                exchangeInfo[idNum].orderPrice = stod( d["data"]["ap"].GetString() );
                                
                                exchangeInfo[idNum].mtx->unlock();
                            }
                        }
                    }
                    else if(d.HasMember("m") && d["m"] == "ping")
                        ws.write_Socket(R"({ "op": "pong" })");
                    else
                        throw exception();
                        
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {	
        Document d;
        string type = "market";
        string price_string = "";
        
        if(limit){
            type = "limit";
            price_string = "\"orderPrice\":\""+ to_string(price) +"\",";
        }
        
        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://ascendex.com/2/api/pro/v1/cash/order";
        
        const string& msg = ep + "+order";
        const string& post_data  = "{\"time\":" + ep + ",\"symbol\":\"" + symbol + "\"," + price_string + "\"orderQty\":\"" + to_string(quantity) + "\",\"orderType\":\"" + type + "\",\"side\":\"" + side + "\"}";        
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="x-auth-key:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "x-auth-signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "x-auth-timestamp:" + ep;
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "POST" ) ;

        if ( str_result.size() > 0 ) {
            try {
                d.Parse(str_result.c_str()); 

                if(d.HasMember("data") && d["code"] == 0)
                    orderId = d["data"]["info"]["orderId"].GetString();
                else if(d.HasMember("code") && d["code"] == 300014 && d.HasMember("reason") && d["reason"] == "LOT_SIZE_VIOLATION")
                    return 1;
                else
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response, " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 2;
    }
    
    bool cancel_order() {	
        Document d;
        
        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://ascendex.com/2/api/pro/v1/cash/order";
        
        const string& msg = ep + "+order";
        const string& post_data  = "{\"orderId\": \"" + orderId + "\", \"symbol\": \"" + symbol + "\", \"time\": " + ep + "}";        
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="x-auth-key:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "x-auth-signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "x-auth-timestamp:" + ep;
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "DELETE" ) ;

        if ( str_result.size() > 0 ) {
            try {
                d.Parse(str_result.c_str()); 

                if(!(d.IsObject() && d.HasMember("code") && d["code"] == 0))
            		throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading cancel_order response, " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": cancel_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;
    }
   
    bool withdrawal(){
        const string& err = " Exchange " + id + " doesn't support withdrawal API";
        writte_err( "err.txt", err );         
        return 0;
    }  
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

