// websocket chapa en menos de 5 min, he tintentado ping pero nada

class fBitget : public Exchange {
    const double fee = 0.0012;
    const string id = "fBitget";
    unordered_map<string, double> priceAskAnt, priceBidAnt;

    vector<string> get_pairsP(){
         vector<string> v;  
         
         for(auto& i : coins)
            for(auto& j : i.second)
                for(auto& k : j.second.asks)
                    if(k.second == id){
                        string symbol = j.first + i.first;
                        v.push_back(symbol);
                        break;
                    } 
                    
         return v;
    }

    // umcbl:USDT Contract, dmcbl:USD Contract(Altcoins as collateral)+
    public:
    void get_pairs(){        
        Document d;
        vector<string> s;
        
        try{
            string result;          
            curl_api_with_header("https://api.bitget.com/api/mix/v1/market/contracts?productType=umcbl", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("data") && d["code"] == "00000" && d["msg"] == "success"){
                for(auto& i : d["data"].GetArray()){
                    string quote = i["quoteCoin"].GetString();
                    string base = i["baseCoin"].GetString();

                    if( coins.find(quote) == coins.end() || (coins.find(quote) != coins.end() && coins[quote].find(base) == coins[quote].end()) ){
                        tExchange e = tExchange();
                        e.asks.insert( {0, id} );
                        coins[quote][base] = e;
                    }
                    else
                        coins[quote][base].asks.insert( {0, id} );
                }
            }
            else
                throw exception();
                
            result = "";    
                
            curl_api_with_header("https://api.bitget.com/api/mix/v1/market/contracts?productType=dmcbl", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("data") && d["code"] == "00000" && d["msg"] == "success"){
                for(auto& i : d["data"].GetArray()){            
                    string quote = i["quoteCoin"].GetString();
                    string base = i["baseCoin"].GetString();

                    if( coins.find(quote) == coins.end() || (coins.find(quote) != coins.end() && coins[quote].find(base) == coins[quote].end()) ){
                        tExchange e = tExchange();
                        e.asks.insert( {0, id} );
                        coins[quote][base] = e;
                    }
                    else
                        coins[quote][base].asks.insert( {0, id} );
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }
    }
    
    public:
    void websocketInit_depth(){        
        Document d;
        string s = "{\"op\":\"subscribe\",\"args\":[", quoteAsset, baseAsset;

        try {   
            init_http("ws.bitget.com");
            init_webSocket("ws.bitget.com", "443", "/mix/v1/stream");
            
            // all this is because the string is too large to fit in one write_socket
            vector<string> v = get_pairsP();
            for(int i = 0; i < v.size() / 2; i++)
                s += "{\"instType\":\"mc\",\"channel\":\"ticker\",\"instId\":\"" + v[i] + "\"},";
            s.pop_back();
            s += "]}";
            write_Socket(s); // first half of s
            
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            
            s = "{\"op\":\"subscribe\",\"args\":[";            
            for(int i = v.size() / 2; i < v.size(); i++)
                s += "{\"instType\":\"mc\",\"channel\":\"ticker\",\"instId\":\"" + v[i] + "\"},";
            s.pop_back();
            s += "]}";
            write_Socket(s); // first half of s
            
            v.clear();
            s.clear();
            v.shrink_to_fit();
            s.shrink_to_fit();
            
            for(int i = 0; i < 100; i++){
                read_Socket();
                buffer_clear();
            }
                      
            time_t current_time;
            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                
                if(ct2 - ct >= 10){
                    ct = ct2;
                    write_Socket(R"({\"op\":\"ping\"})");
                }
                
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.HasMember("data")){
                    s = d["data"][0]["instId"].GetString();
                    
                    if(s.back() == 'T'){
                        quoteAsset = "USDT";
                        baseAsset = s.substr(0, s.length() - 4);
                    }
                    else{
                        quoteAsset = "USD";
                        baseAsset = s.substr(0, s.length() - 3);                    
                    }
                    
                    auto&& c = coins[quoteAsset][baseAsset];
                    auto&& pAa = priceAskAnt[s];
                    auto&& pBa = priceBidAnt[s];
                    
                    double priceA = stod(d["data"][0]["bestAsk"].GetString());
                    priceA += priceA * fee;

                    c.mtx->lock();
                    
                    if(pAa != priceA){
                        c.asks.erase( {pAa, id} );
                        c.asks.insert( {priceA, id} );
                        pAa = priceA;
                    }
                    
                    double priceB = stod(d["data"][0]["bestBid"].GetString());
                    priceB -= priceB * fee;
                    
                    if(pBa != priceB){
                        c.bids.erase( {pBa, id} );
                        c.bids.insert( {priceB, id} );
                        pBa = priceB;
                    }
                    
                    c.mtx->unlock(); 
                }

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
};

