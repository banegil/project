

class Bitfinex {
    const double fee = 0.00075;
    const string id = "bitfinex";

    public:
    int get_pairs(){        
        Document d;
        try{
            string result;          
            curl_api_with_header("https://api-pub.bitfinex.com/v2/conf/pub:list:pair:futures", result);
            d.Parse(result.c_str()); 
            

            int cont = 0;
            for(auto& i : d[0].GetArray()){
                if(cont < 20){  
                    cont++;              
                    string s = i.GetString();
                    string base = s.substr(0, s.find(':'));
                    base.pop_back(); base.pop_back();
                    string quote = s.substr(s.find(':') + 1, s.length() - 1);
                    quote.pop_back(); quote.pop_back(); 
                    
                    if(quote == "UST")
                        quote = "USDT";
                    if(base == "ALG")
                        base == "ALGO";
                     
                    coins[ quote ][ base ] = tExchange();
                }
            }

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 20;
        //return d["symbols"].GetArray().Size();
    }
    
    void websocketInit_depth(const string baseAsset, const string quoteAsset){
        // orderbook muy chustero, dificilmente fiable
        Exchange ex;
        ex.init_http("api-pub.bitfinex.com");
        double priceBidAnt = 0, priceAskAnt = 0;
                
        string quote = quoteAsset, base = baseAsset;
        if(quote == "USDT")
            quote = "UST";
        if(baseAsset == "ALGO")
            base = "ALG";
            
        string symbol = base + "F0:" + quote + "F0";
        
        Document d;
        try {
            ex.init_webSocket("api-pub.bitfinex.com", "443", "/ws/2");
            string s = "{\"event\":\"subscribe\",\"channel\":\"book\",\"symbol\":\"" + symbol + "\",\"prec\":\"R0\",\"freq\":\"F0\",\"len\":\"25\"}";
            ex.write_Socket(s);
            
            for(int i = 0; i < 3; i++){
                ex.read_Socket();
                ex.buffer_clear();
            }
                              
            while (true) {
                ex.read_Socket();	
                d.Parse(ex.get_socket_data().c_str());
                
                coins[baseAsset][quoteAsset].mtx->lock();
                
                printJson(d);
                
                coins[baseAsset][quoteAsset].mtx->unlock();  

                ex.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + baseAsset + quoteAsset + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	//ex.webSocket_close();
            return;
          }
    } 
};

