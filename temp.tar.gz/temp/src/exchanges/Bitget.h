// websocket chapa en menos de 5 min, he tintentado ping pero nada

class Bitget : public Exchange {
    const unsigned short id = 4;
    vector<string> v;

    void get_24Volume(){         
        Document d;
        unordered_map<string, string> qA;
        qA["DT"] = "USDT"; qA["TC"] = "BTC"; qA["DC"] = "USDC"; qA["TH"] = "ETH";
        
        try{
            string result;          
            curl_api_with_header("https://api.bitget.com/api/spot/v1/market/tickers", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("data") && d["code"] == "00000" && d["msg"] == "success"){
                for(auto& i : d["data"].GetArray()){
                    string s = i["symbol"].GetString();
                    string quote = qA[s.substr(s.length() - 2)];
                    string base = s.substr(0, s.length() - quote.length());
                    
                    coins[base][quote].volume = stod( i["usdtVol"].GetString() );
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + string(e.what()) ); 
         	printJson(d);
         	return;
        }       
    }

    public:
    void get_pairs(){        
        Document d;
        vector<string> s;
        
        try{
            string result;          
            curl_api_with_header("https://api.bitget.com/api/spot/v1/public/products", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("data") && d["code"] == "00000" && d["msg"] == "success"){
                for(auto& i : d["data"].GetArray()){
                    if(i["status"] == "online"){
                        string quote = i["quoteCoin"].GetString();
                        string base = i["baseCoin"].GetString();

                        v.push_back(base + quote);

                        orderbook o = orderbook();                       
                        o.fee = {0.0, 0.0};                        
                        coins[base][quote] = o;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + string(e.what()) ); 
         	printJson(d);
         	return;
        }
        
        get_24Volume();
    }
    
    public:
    void websocketInit_depth(){        
        Document d;
        Wss ws;
        unordered_map<string, string> qA;
        qA["DT"] = "USDT"; qA["TC"] = "BTC"; qA["DC"] = "USDC"; qA["TH"] = "ETH";

        try {   
            ws.init_http("ws.bitget.com");
            ws.init_webSocket("ws.bitget.com", "443", "/spot/v1/stream");
            
            // all this is because the string is too large to fit in one write_socket
            // if the websocket fails, increase number 8 to 9 for example, if is > 10 make 2 fors, just 10mesagges/second
            for(int j = 0; j < 8; j++){
                string s = "{\"op\": \"subscribe\",\"args\": [";
                for(int i = (v.size() / 8) * j; i < (v.size() / 8) * (j + 1); i++)
                    s += "{\"instType\":\"SP\",\"channel\":\"books5\",\"instId\":\"" + v[i] + "\"},";
                s.pop_back();
                s += "]}";
                ws.write_Socket(s); 
                
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
                      
            time_t current_time;
            time(&current_time);
            int ct = current_time;
            string s, baseAsset, quoteAsset;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                
                if(ct2 - ct >= 10){
                    ct = ct2;
                    ws.write_Socket("ping");
                }
                
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("action") && d["action"] == "snapshot"){
                    s = d["arg"]["instId"].GetString();
                    quoteAsset = qA[s.substr(s.length() - 2)];
                    baseAsset = s.substr(0, s.length() - quoteAsset.length());

                    auto&& c = coins[baseAsset][quoteAsset];
                    auto&& data = d["data"][0];

                    c.mtx->lock();
                    
                    if(data.HasMember("asks") && data["asks"].Size() > 0){
                        c.asks.clear();
                        c.asks[ stod(data["asks"][0][0].GetString()) ] = 0;
                    }
                    
                    if(data.HasMember("bids") && data["bids"].Size() > 0){
                        c.bids.clear();
                        c.bids[ stod(data["bids"][0][0].GetString()) ] = 0;
                    }
                    
                    c.mtx->unlock(); 
                }

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
};

