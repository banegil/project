

class Bitget {
    const unsigned short id = 4;
    const string phrase = "";
    
    const string api_key = "";
    const char* secret_key = "";
    
    public:
    void websocketInit_depth(){    
        Wss ws;    
        Document d;

        try {   
            ws.init_http("ws.bitget.com");
            ws.init_webSocket("ws.bitget.com", "443", "/spot/v1/stream");

            string s = "{\"op\": \"subscribe\",\"args\": [";
            s += "{\"instType\":\"SP\",\"channel\":\"ticker\",\"instId\":\"" + cc + "\"},";
            s += "{\"instType\":\"SP\",\"channel\":\"ticker\",\"instId\":\"" + cc1 + "\"},";
            s += "{\"instType\":\"SP\",\"channel\":\"ticker\",\"instId\":\"" + cc2 + "\"}]}";
            ws.write_Socket(s); // first half of s
                      
            time_t current_time;
            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                
                if(ct2 - ct >= 10){
                    ct = ct2;
                    ws.write_Socket("ping");
                }
                
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.HasMember("data")){
                    s = d["data"][0]["instId"].GetString();
                    
                }

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    double send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) {	
        Document d;

        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bitget.com/api/spot/v1/trade/orders";
        
        side[0] = toupper(side[0]);
        
        const string& post_data = "{\"symbol\":\"" + symbol + "_SPBL\",\"side\":\"" + side + "\",\"orderType\":\"limit\",\"force\":\"normal\",\"price\":\"" + to_string(orderPrice) + "\",\"quantity\":\"" + to_string(quantity) + "\"}";
        const string& msg = ep + "POST/api/spot/v1/trade/orders" + post_data;

        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("ACCESS-KEY:" + api_key);
        extra_http_header.push_back("ACCESS-SIGN:" + signature);
        extra_http_header.push_back("ACCESS-PASSPHRASE:" + phrase);
        extra_http_header.push_back("ACCESS-TIMESTAMP:" + ep);
        extra_http_header.push_back("ACCESS-KEY:" + api_key);
        extra_http_header.push_back("locale:en-US");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                printJson(d);
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return -1;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return -1;
        }
        
        return 0;  
    } 
};

