

class Bitget : public Exchange{
    const unsigned short id = 4;
    string order_id;
    const string phrase = "tradingbitget";
    
    const string api_key = "bg_d8eca45e2096c42061c645105f004ded";
    const char* secret_key = "2dfcc214300bfbefd8ca4c20071eff768f7dcd34584f321d9452531e0d6f1a9f";

    void pingInterval(Wss& ws){
        time_t current_time;
        time(&current_time);
        int ct = current_time;  
                                    
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct > 18){
                ct = ct2;
                ws.write_Socket("ping");
            }
        }
        
        this_thread::sleep_for(chrono::milliseconds(2000));
    }
    
    public:
    void websocketInit_depth(){    
        Wss ws;    
        Document d;

        try {   
            ws.init_http("ws.bitget.com");
            ws.init_webSocket("ws.bitget.com", "443", "/spot/v1/stream");

            string s = "{\"op\": \"subscribe\",\"args\": [";
            s += "{\"instType\":\"SP\",\"channel\":\"books5\",\"instId\":\"" + cc + "\"},";
            s += "{\"instType\":\"SP\",\"channel\":\"books5\",\"instId\":\"" + cc1 + "\"},";
            s += "{\"instType\":\"SP\",\"channel\":\"books5\",\"instId\":\"" + cc2 + "\"}]}";
            ws.write_Socket(s); // first half of s
                      
            time_t current_time;
            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                
                if(ct2 - ct >= 10){
                    ct = ct2;
                    ws.write_Socket("ping");
                }
                
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].IsArray() && d.HasMember("action") && d["action"] == "snapshot"){
                    auto&& o = pairs[ d["arg"]["instId"].GetString() ];

                    o.mtx->lock();

                    if(d["data"][0]["asks"].Size() > 0)
                        o.asks[0].first = stod( d["data"][0]["asks"][0][0].GetString() );
                    if(d["data"][0]["bids"].Size() > 0)
                        o.bids[0].first = stod( d["data"][0]["bids"][0][0].GetString() );
                    
                    o.mtx->unlock();
                }

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){    
        Wss ws;    
        Document d;
        
        try {
            ws.init_http("ws.bitget.com");
            ws.init_webSocket("ws.bitget.com", "443", "/spot/v1/stream");                         
            
            time_t current_time;
            time(&current_time);
            int ct = current_time;
            
            const string& msg = to_string(ct) + "GET/user/verify";
            const string& signature =  hmac_sha256_2( secret_key, msg.c_str() ); 
                    
            string s = "{\"op\": \"login\",\"args\": [{\"apiKey\": \"" + api_key + "\",\"passphrase\": \"" + phrase + "\",\"timestamp\": \"" + to_string(ct) + "\",\"sign\": \"" + signature + "\"}]}";                            
            ws.write_Socket(s);                   
            ws.read_Socket();	
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("code") && d["code"] == 0 && d.HasMember("event") && d["event"] == "login"))
                throw exception();
            ws.buffer_clear();
            
            s = "{\"op\": \"subscribe\",\"args\": [{\"channel\": \"orders\",\"instType\": \"spbl\",\"instId\": \"" + cc + "_SPBL\"}]}";
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("event") && d["event"] == "subscribe") && d.HasMember("agr") && d["arg"].HasMember("instId") && d["arg"]["instId"].GetString() == cc + "_SPBL")
                throw exception();
            ws.buffer_clear();
            
            s = "{\"op\": \"subscribe\",\"args\": [{\"channel\": \"orders\",\"instType\": \"spbl\",\"instId\": \"" + cc1 + "_SPBL\"}]}";
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("event") && d["event"] == "subscribe") && d.HasMember("agr") && d["arg"].HasMember("instId") && d["arg"]["instId"].GetString() == cc1 + "_SPBL")
                throw exception();
            ws.buffer_clear();
            
            s = "{\"op\": \"subscribe\",\"args\": [{\"channel\": \"orders\",\"instType\": \"spbl\",\"instId\": \"" + cc2 + "_SPBL\"}]}";
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("event") && d["event"] == "subscribe") && d.HasMember("agr") && d["arg"].HasMember("instId") && d["arg"]["instId"].GetString() == cc2 + "_SPBL")
                throw exception();
            ws.buffer_clear();
            
            auto&& f = async(&Bitget::pingInterval, this, ref(ws));  
            
            double last_rejected_qty = 0, last_rejected_qty2 = 0;             
            while (true) {                                           
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());
                   
                if(d.IsObject() && d.HasMember("data") && d["data"].IsArray()){
                    if(d["data"][0].HasMember("status") && (d["data"][0]["status"] == "partial-fill" || d["data"][0]["status"] == "full-fill")){

                        if(d["arg"]["instId"].GetString() == cc + "_SPBL"){
                        
                            if(d["data"][0]["status"] == "full-fill"){
                                ok = 1;
                            }
                            else{
                                const double& rem_qty = stod( d["data"][0]["fillSz"].GetString() );
                                const double& price = ORDER3 ? pairs[cc1].get_ask() : pairs[cc1].get_bid();
                                quantity_global = quantity_global - rem_qty;
                                
                                const double& check = send_order(cc1, type_order2, rem_qty + last_rejected_qty, round( price * POW_CC1 ) / POW_CC1);

                                if(check > 0)                                    
                                    last_rejected_qty += rem_qty; 
                                else 
                                    last_rejected_qty = 0;
                            }
                            
                        }
                        else if(d["arg"]["instId"].GetString() == cc1 + "_SPBL" && d["data"][0]["status"] == "partial-fill"){
                            const double& rem_qty = round( stod( d["data"][0]["fillSz"].GetString() ) * POW_CC2_QTY ) / POW_CC2_QTY;
                            const double& price = ORDER3 ? pairs[cc2].get_ask() : pairs[cc2].get_bid();
                            
                            const int& check = send_order(cc2, type_order3, rem_qty + last_rejected_qty2, round( price * POW_CC2 ) / POW_CC2);
                            
                            if(check > 0)
                                last_rejected_qty2 += rem_qty;
                            else
                                last_rejected_qty2 = 0;        
                        }
                        
                    }
                }
                else if(!(d.IsObject() && d.HasMember("event") && d["event"] == "subscribe")){
                    cout << "Just to check wss_User Bitget\n";
                    printJson(d);
                }              

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    }
    
    int send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) {	
        Document d;
        int ret_code = 0;

        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bitget.com/api/spot/v1/trade/orders";       
        
        const string& post_data = "{\"symbol\":\"" + symbol + "_SPBL\",\"side\":\"" + side + "\",\"orderType\":\"limit\",\"force\":\"normal\",\"price\":\"" +
                                    my_toString_extended(orderPrice) + "\",\"quantity\":\"" + my_toString_extended(quantity) + "\"}";
        const string& msg = ep + "POST/api/spot/v1/trade/orders" + post_data;
        const string& signature =  hmac_sha256_2( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("ACCESS-KEY:" + api_key);
        extra_http_header.push_back("ACCESS-SIGN:" + signature);
        extra_http_header.push_back("ACCESS-PASSPHRASE:" + phrase);
        extra_http_header.push_back("ACCESS-TIMESTAMP:" + ep);
        extra_http_header.push_back("ACCESS-KEY:" + api_key);
        extra_http_header.push_back("locale:en-US");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(d.IsObject() && d.HasMember("code") && d["code"] == "00000" && d.HasMember("msg") && d["msg"] == "success" && d.HasMember("data") && d["data"].HasMember("orderId"))
                    order_id = d["data"]["orderId"].GetString();
                else{
                    printJson(d);
                    cout << symbol << endl;
                }
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 1;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 1;
        }
        
        return ret_code;  
    } 
    
    int send_CancelOrder(const string& symbol){
        Document d;
        int ret_code = 0;

        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bitget.com/api/spot/v1/trade/cancel-order";       
        
        const string& post_data = "{\"symbol\": \"" + cc + "_SPBL\",\"orderId\": \"" + order_id + "\"}";
        const string& msg = ep + "POST/api/spot/v1/trade/cancel-order" + post_data;
        const string& signature =  hmac_sha256_2( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("ACCESS-KEY:" + api_key);
        extra_http_header.push_back("ACCESS-SIGN:" + signature);
        extra_http_header.push_back("ACCESS-PASSPHRASE:" + phrase);
        extra_http_header.push_back("ACCESS-TIMESTAMP:" + ep);
        extra_http_header.push_back("ACCESS-KEY:" + api_key);
        extra_http_header.push_back("locale:en-US");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 1;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 1;
        }
        
        return ret_code;          
    }
};

