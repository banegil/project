

class Binance : public Exchange {
    const string id = "Binance";
    const unsigned short idNum = 2;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETHUSDT";
    string base = "ETH";
    string quote = "USDT";
    string orderId;
    bool limitOrder = 0;
    double remaining_qty = 0;
    
    const string api_key = "oBNIYfFRy75TFChwWyqAA2bIHONGT4fOZP8VLEGSbi6FcQWrHQKPxbB31JkeG87F";
    const char* secret_key = "beck39rQ606hqkhELAdPtTlT2J6XGdsvZ0S5XBJ6asxtmlLmOaffuEeCPsvEwrqU";

    string get_listenKey() {	
        Document d;
        string s = "";

        const char* url = "https://api.binance.com/api/v3/userDataStream?";        
        string post_data = "";

        vector <string> extra_http_header;
        string header_chunk("X-MBX-APIKEY: ");
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header(url, str_result, extra_http_header , post_data , "POST");

        if ( str_result.size() > 0 ) {
            try {	
                d.Parse(str_result.c_str());
                
                if(d.IsObject() && d.HasMember("listenKey"))
	                s = d["listenKey"].GetString();
	                
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err("err.txt", err);
                    printJson(d);
                    return s;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err("err.txt", err);
            return s;
        }
        return s;
    }

    public:
    bool get_pairs(){        
        Document d;
        unordered_map<string, bool> q, promotionUSDT, promotionBTC;
        q["USDT"] = q["ETH"] = q["BTC"] = q["USDC"] = q["USD"] = q["EUR"] = q["DAI"] = 1;
        promotionUSDT["BUSDUSDT"] = promotionUSDT["TUSDUSDT"] = promotionUSDT["USDCUSDT"] = promotionUSDT["USDPUSDT"] = 1; 
        promotionBTC["BTCBUSD"] = promotionBTC["BTCTUSD"] = promotionBTC["BTCUSDC"] = promotionBTC["BTCUSDP"] = promotionBTC["BTCUSDT"] = 1;
        symbol = chosenSymbol;
        base = symbol.substr(0, symbol.find('-'));
        quote = symbol.substr(symbol.find('-') + 1, symbol.length() - 1); 
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
                
        try{
            string result;          
            curl_api("https://api1.binance.com/api/v3/exchangeInfo", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("symbols")){
                for(auto& i : d["symbols"].GetArray()){
                    if(i["status"] == "TRADING" && i["isSpotTradingAllowed"] == true){     
                        string base = i["baseAsset"].GetString();
                        string quote = i["quoteAsset"].GetString();
                        pair<double, double> p;
                
                        if(promotionUSDT[base + quote] || promotionBTC[base + quote])
                            fee = {0, 0}; 
                        else if(quote == "BUSD")
                            fee = {0, 0.00075};
                        else
                            fee = {0.00075, 0.00075}; 

                        if(base + "-" + quote == chosenSymbol){
                            for(auto&& j : i["filters"].GetArray()){
                                if(j["filterType"] == "LOT_SIZE"){// minQty?
                                    exchangeInfo[idNum].multiplier = stod( j["stepSize"].GetString() );
                                    break;
                                }
                            }
                            return 1;
                        }
                    }
                }
            }
            else
                throw exception();
                

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }

    void websocketInit_depth(){      
        Wss ws;  
        Document d;         
        string symbol = chosenSymbol;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        transform(symbol.begin(), symbol.end(), symbol.begin(),
        [](unsigned char c){ return tolower(c); });
        string s = "/ws/" + symbol + "@depth20@100ms";

        try {
            ws.init_http("stream.binance.com");
            ws.init_webSocket("stream.binance.com", "443", s.c_str());
                          
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("asks")){
                                
                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["asks"].GetArray())
                        asks[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxAsk.unlock();
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["bids"].GetArray())
                        bids[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxBid.unlock();
                    
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    }
    
    void websocketInit_User(){
        Document d;
        Wss ws;
        const string& s = "/ws/" + get_listenKey();
        
        try {
            ws.init_http("stream.binance.com");
            ws.init_webSocket("stream.binance.com", "443", s.c_str());
                          
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("e")){
                    exchangeInfo[idNum].mtx->lock();
                
                    if(d["e"] == "executionReport"){  
                                               
                        if(d.HasMember("Z") && d["Z"] != "0.00000000"){
                        
                            if(limitOrder){
                                orderExecuted = true;                                    
                                const double& quantity = stod( d["z"].GetString() );                                    
                                const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", quantity, 0.0, 0);
                                
                                if(res == 0)
                                    stopExecution = true;
                                else if(res == 1)
                                    remaining_qty += quantity;
                                else
                                    remaining_qty = 0;
                                
                                limitOrder = 0;
                            }
                        
                            exchangeInfo[idNum].orderPrice = stod( d["Z"].GetString() ) / stod( d["z"].GetString() ); 
                        }
                        
                    }                                                      
                    else if(d["e"] == "outboundAccountPosition")
                        for(auto&& i : d["B"].GetArray())
                            if(i["a"].GetString() == base || i["a"].GetString() == quote)
                                exchangeInfo[idNum].balance[ i["a"].GetString() ] = stod( i["f"].GetString() );
                    
                    exchangeInfo[idNum].mtx->unlock();
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = id + "ERROR: <wss_User>  " + e.what();
         	writte_err( "err.txt", err ); 
         	ws.webSocket_close();
            return;
          }
    } 
        
    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {	
        Document d; 
        string type = "MARKET";
        string price_string = "";
        
        if(limit){
            type = "LIMIT";
            price_string = "&price=" + to_string(price) + "&timeInForce=FOK";
        }       
        
        string post_data = "symbol=" + symbol + "&side=" + side + "&type=" + type + "&quantity=" + to_string(quantity) + "&timestamp=" + to_string( get_current_ms_epoch() ) + price_string;
                
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );       
        post_data += "&signature=" + signature;      
        const char* url = "https://api.binance.com/api/v3/order?";

        vector <string> extra_http_header;
        extra_http_header.push_back("X-MBX-APIKEY: " + api_key);
        
        string str_result;
        curl_api_with_header(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {	
                d.Parse(str_result.c_str());
                
                if(d.IsObject() && d.HasMember("code")){
                    if(d["code"] == -1013 && d.HasMember("msg") && d["msg"] == "Filter failure: LOT_SIZE")
                        return 1;
                    else
                        throw exception();
                }  
                else
                    throw exception();             
	                
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err("err.txt", err);
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err("err.txt", err);
            return 0;
        }
        return 2;
    }
    
    bool cancel_order() {	
        Document d;
        
        string post_data = "symbol=" + symbol + "&timestamp=" + to_string( get_current_ms_epoch() );        
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );       
        post_data += "&signature=" + signature;      
        const char* url = "https://api.binance.com/api/v3/openOrders?";

        vector <string> extra_http_header;
        extra_http_header.push_back("X-MBX-APIKEY: " + api_key);
        
        string str_result;
        curl_api_with_header(url, str_result, extra_http_header , post_data , "DELETE");

        if (str_result.size() > 0) {
            try {	
                d.Parse(str_result.c_str());
                
                if(d.IsObject() && d.HasMember("code"))  
                    throw exception();              
	                
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading cancel_order response " + e.what();
                    writte_err("err.txt", err);
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": cancel_order.size() is 0";
            writte_err("err.txt", err);
            return 0;
        }
        return 1;
    }
    
    bool withdrawal(const string& coin, const string& address, const double& quantity, const string& network) {	
        Document d;

        const char* url = "https://api.binance.com/sapi/v1/capital/withdraw/apply?";
        
	    string post_data = "coin=" + coin + "&network=" + network + "&address=" + address + "&amount=" + to_string(quantity) + "&timestamp=" + to_string( get_current_ms_epoch() );
        
        string signature =  hmac_sha256( secret_key, post_data.c_str() );
        post_data.append( "&signature=");
        post_data.append( signature );

	    vector <string> extra_http_header;
	    string header_chunk("X-MBX-APIKEY: ");
	    header_chunk.append( api_key );
	    extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "POST" ) ;

        if ( str_result.size() > 0 ) {
	        try {
                d.Parse(str_result.c_str());
                
                printJson(d);
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading withdrawal response " + e.what();
                    writte_err("err.txt", err);
                    printJson(d);
                    return 0;
	        }   
        } 
        else {
            const string& err = id + ": withdrawal.size() is 0";
            writte_err("err.txt", err);
            return 0;
        }
        return 1;
    }     
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

