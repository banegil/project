

class Binance : public Exchange {
    const string api_key = "oBNIYfFRy75TFChwWyqAA2bIHONGT4fOZP8VLEGSbi6FcQWrHQKPxbB31JkeG87F";
    const char* secret_key = "beck39rQ606hqkhELAdPtTlT2J6XGdsvZ0S5XBJ6asxtmlLmOaffuEeCPsvEwrqU";
    unordered_map<string, orderInfo> order; // <order_id, orderInfo>
    mutex mtx_orderInfo;

    inline string generate_order_id(const string& symbol){
        srand (time(NULL));
    
        const string& mix = to_string(nanos()) + symbol;
        const string& order_id = hmac_sha256( api_key.substr(0, rand() % 10 + 1).c_str(), mix.c_str() );
        return order_id.substr(0, 20);
    }

    string get_listenKey() {	
        Document d;
        string s = "";

        const char* url = "https://api.binance.com/api/v3/userDataStream?";        
        string post_data = "";

        vector <string> extra_http_header;
        string header_chunk("X-MBX-APIKEY: ");
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if ( str_result.size() > 0 ) {
            try {	
                d.Parse(str_result.c_str());
                
                if(d.IsObject() && d.HasMember("listenKey"))
	                s = d["listenKey"].GetString();
	                
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response " + string(e.what());
                    writte_err("err.txt", err);
                    printJson(d);
                    return s;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err("err.txt", err);
            return s;
        }
        return s;
    }

    void get_24Volume(){        
        Document d, d2, d3;
        unordered_map<string, string> m, inversed_m;
        m["DT"] = "USDT"; m["NB"] = "BNB"; m["TC"] = "BTC"; m["TH"] = "ETH"; m["RP"] = "XRP"; m["RX"] = "TRX"; m["GE"] = "DOGE"; m["OT"] = "DOT";
        m["UD"] = "AUD"; m["UR"] = "EUR"; m["BP"] = "GBP"; m["DC"] = "USDC"; m["DP"] = "USDP";
               
        inversed_m["DR"] = "BIDR"; inversed_m["RL"] = "BRL"; inversed_m["UB"] = "RUB"; inversed_m["RY"] = "TRY";
        inversed_m["AH"] = "UAH"; inversed_m["RT"] = "IDRT"; inversed_m["GN"] = "NGN"; inversed_m["AI"] = "DAI";
        
        unordered_map<string, double> priceQuote;
        priceQuote["USDT"] = priceQuote["BUSD"] = priceQuote["TUSD"] = 1;
        
        try{
            string result;  
            string s = "";
            for(auto&& i : m)
                if(i.second != "USDT")
                    s += "\"" + i.second + "USDT\",";
            s.pop_back();    

            curl_api_with_header("https://api1.binance.com/api/v3/ticker/24hr?symbols=[" + s + "]", result);
            d.Parse(result.c_str());
            if(d.IsArray() && d[0].HasMember("symbol")){
                for(auto&& i : d.GetArray()){
                    const string& symbol = i["symbol"].GetString();
                    string substr = symbol.substr(symbol.length() - 6);
                    substr = substr.substr(0, 2);
                    priceQuote[ m[ substr ] ] = stod( i["weightedAvgPrice"].GetString() );
                }
            }
            else
                throw exception();
            
            result.clear();

            s = "";
            for(auto&& i : inversed_m)
                s += "\"USDT" + i.second + "\",";
            s.pop_back();    

            curl_api_with_header("https://api1.binance.com/api/v3/ticker/24hr?symbols=[" + s + "]", result);
            d3.Parse(result.c_str()); 

            if(d3.IsArray() && d3[0].HasMember("symbol")){
                for(auto&& i : d3.GetArray()){
                    const string& symbol = i["symbol"].GetString();
                    const string& substr = symbol.substr(symbol.length() - 2);
                    priceQuote[ inversed_m[ substr ] ] = 1 / stod( i["weightedAvgPrice"].GetString() );
                }
            }
            else
                throw exception();

            result.clear();
                  
            curl_api_with_header("https://api1.binance.com/api/v3/ticker/24hr", result);
            d2.Parse(result.c_str()); 

            if(d2.IsArray()){
                for(auto& i : d2.GetArray()){
                    string s = i["symbol"].GetString();
                    const string& substr = s.substr(s.length() - 2);
                   
                    if(m.find(substr) != m.end() || inversed_m.find(substr) != inversed_m.end() || substr == "SD"){
                        string quote;
                        
                        if(substr == "SD")
                            quote = s.substr(s.length() - 4);                   
                        else if(m.find(substr) != m.end())
                            quote = m[substr]; 
                        else
                            quote = inversed_m[substr];
                            
                        string base = s.substr(0, s.length() - quote.length());
                        double v = stod( i["quoteVolume"].GetString() );
                        
                        if(v != 0)
                            coins[base][quote].volume = v * priceQuote[quote];    
                    }
                    /*else
                        cout << "ERROR: <get_24Volume> please include the following coin " << s << endl; */
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_24Volume> " + string(e.what()) ); 
         	printJson(d);
         	printJson(d2);
         	return;
        }       
    }

    public:
    void get_pairs(){        
        Document d;
        unordered_map<string, bool> promotionUSDT, promotionBTC;
        promotionUSDT["BUSDUSDT"] = promotionUSDT["TUSDBUSD"] = promotionUSDT["TUSDUSDT"] = promotionUSDT["USDCBUSD"] = promotionUSDT["USDCUSDT"] = promotionUSDT["USDPBUSD"] = promotionUSDT["USDPUSDT"] = 1; 
        promotionBTC["BTCAUD"] = promotionBTC["BTCBIDR"] = promotionBTC["BTCBRL"] = promotionBTC["BTCEUR"] = promotionBTC["BTCGBP"] = promotionBTC["BTCGBP"] = promotionBTC["BTCGBP"] =
        promotionBTC["BTCRUB"] = promotionBTC["BTCTRY"] = promotionBTC["BTCTUSD"] = promotionBTC["BTCUAH"] = promotionBTC["BTCUSDC"] = promotionBTC["BTCUSDP"] = promotionBTC["BTCUSDT"] = 1;
        
        try{
            string result;          
            curl_api_with_header("https://api.binance.com/api/v3/exchangeInfo", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("symbols")){
                for(auto& i : d["symbols"].GetArray()){
                    if(i["status"] == "TRADING" && i["permissions"][0] == "SPOT"){  
                        string base = i["baseAsset"].GetString(); 
                        string quote = i["quoteAsset"].GetString();       
                        orderbook o = orderbook();
                        
                        if(promotionUSDT[base + quote] || promotionBTC[base + quote])
                            o.fee = {0.0, 0.0}; 
                        else if(quote == "BUSD")
                            o.fee = {0.0, 0.00075};
                        else
                            o.fee = {0.00075, 0.00075}; 
                        
                        coins[base][quote] = o;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_exchanges> " + string(e.what()) ); 
         	printJson(d);
        }
        
        get_24Volume();
    }
    
    void websocketInit_depth(){
        Document d;
        Wss ws;
        string s, baseAsset, quoteAsset;
        
        try {
            ws.init_http("stream.binance.com");
            ws.init_webSocket("stream.binance.com", "443", "/ws/!bookTicker");
            unordered_map<string, string> m;
            m["DT"] = "USDT"; m["NB"] = "BNB"; m["TC"] = "BTC"; m["TH"] = "ETH"; m["RP"] = "XRP"; m["RX"] = "TRX"; m["GE"] = "DOGE"; m["OT"] = "DOT"; m["DS"] = "USDS";
            m["UD"] = "AUD"; m["UR"] = "EUR"; m["BP"] = "GBP"; m["DC"] = "USDC"; m["AI"] = "DAI"; m["DP"] = "USDP"; m["AX"] = "PAX"; m["ST"] = "UST"; m["DR"] = "BIDR";
            m["RL"] = "BRL"; m["UB"] = "RUB"; m["RY"] = "TRY"; m["RW"] = "BKRW"; m["AH"] = "UAH"; m["RT"] = "IDRT"; m["GN"] = "NGN"; m["AR"] = "ZAR"; m["ND"] = "BVND";
                          
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());
                
                if(d.IsObject() && d.HasMember("a") && d.HasMember("b")){ 
                    s = d["s"].GetString();
                    const string& apanio = s.substr(s.length() - 2);
                        
                    if(apanio == "SD")
                        quoteAsset = s.substr(s.length() - 4);                    
                    else
                        quoteAsset = m[s.substr(s.length() - 2)];                         
                    baseAsset = s.substr(0, s.length() - quoteAsset.length());

                    auto&& c = coins[baseAsset][quoteAsset];

                    c.mtx->lock(); 
                    
                    c.asks.clear();
                    c.bids.clear();
                    
                    c.asks[ stod(d["a"].GetString()) ] = stod(d["A"].GetString());
                    c.bids[ stod(d["b"].GetString()) ] = stod(d["B"].GetString());
                    
                    c.mtx->unlock(); 
                }
                else 
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  Binance-Spot " + string(e.what());
         	writte_err( "err.txt", err ); 
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){
        Document d;
        Wss ws;
        string s = "/ws/" + get_listenKey();
        
        try {
            ws.init_http("stream.binance.com");
            ws.init_webSocket("stream.binance.com", "443", s.c_str());
            
            string side, pair;
            double quantity;            
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("e") && d["e"] == "executionReport"){ 
                    const string& order_id = d["c"].GetString();
                    
                    mtx_orderInfo.lock();
                    
                    auto&& o_info = order[ order_id ]; 
                    
                    if(!o_info.second_order_executed){
                        o_info.second_order_executed = 1;
                        side = o_info.side2;
                        pair = o_info.pair2;
                        quantity = stod( d["l"].GetString() );
                    }
                    else{
                        side = o_info.side3;
                        pair = o_info.pair3;
                        
                        if(side == "buy"){
                            const string& base = pair.substr(0, pair.find('-'));
                            const string& quote = pair.substr(pair.find('-') + 1, pair.length() -1);
                            quantity = stod( d["Z"].GetString() ) / (coins[base][quote].get_ask().first);   
                        }
                        else
                            quantity = stod( d["Z"].GetString() );
                            
                        order.erase(order_id);
                    } // coger precios etc, compararlos a ver si la orden ha salido bien
                    
                    mtx_orderInfo.unlock();
                    
                    send_order(pair, side, quantity, order_id);    
                }

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	ws.webSocket_close();
            return;
          }
    }  
    
    int send_order(string symbol, const string& side, const double& quantity, const string& order_id) {
        Document d;  
        int ret_code = 0;   
        const string& base = symbol.substr(0, symbol.find('-'));
        const string& quote = symbol.substr(symbol.find('-') + 1, symbol.length() -1);
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        const double& orderPrice = side == "buy" ? coins[base][quote].get_ask().first * 1.005 : coins[base][quote].get_bid().first * 0.995; // MARKET
        
        const string& ep = to_string(get_current_ms_epoch());
        string post_data = "symbol=" + symbol + "&side=" + side + "&type=LIMIT&quantity=" + my_toString_extended(quantity) + "&timestamp=" + to_string( get_current_ms_epoch() ) + "&price=" +
                            my_toString_extended(orderPrice) + "&newClientOrderId=" + order_id + "&timeInForce=GTC";                
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );       
        post_data += "&signature=" + signature;      
        const char* url = "https://api.binance.com/api/v3/order?";

        vector <string> extra_http_header;
        extra_http_header.push_back("X-MBX-APIKEY: " + api_key);
        
        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {	
                d.Parse(str_result.c_str());
                
                if(d.HasMember("code")){
                    mtx_orderInfo.lock();
                    order.erase(order_id);
                    mtx_orderInfo.unlock();
                    
                    cout << symbol << "\n";
                    ret_code = d["code"].GetInt64(); 
                    printJson(d);  
                }      
	                
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response " + string(e.what());
                    writte_err("err.txt", err);
                    printJson(d);
                    return ret_code;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err("err.txt", err);
            return ret_code;
        }
        
        return ret_code;
    }
    
    void send_triangular_order(string side1, string side2, string side3, string pair1, string pair2, string pair3, double quantity){
        const string& order_id = generate_order_id(pair1 + pair2);        
        mtx_orderInfo.lock();
        order[ order_id ] = { 0, side2, pair2, side3, pair3 }; 
        mtx_orderInfo.unlock();
        send_order(side1, pair1, quantity, order_id);
    }
};




