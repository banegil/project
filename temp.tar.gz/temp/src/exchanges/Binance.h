

class Binance : public Exchange {
    const string api_key = "oBNIYfFRy75TFChwWyqAA2bIHONGT4fOZP8VLEGSbi6FcQWrHQKPxbB31JkeG87F";
    const char* secret_key = "beck39rQ606hqkhELAdPtTlT2J6XGdsvZ0S5XBJ6asxtmlLmOaffuEeCPsvEwrqU";

    string get_listenKey() {	
        Document d;
        string s = "";

        const char* url = "https://api.binance.com/api/v3/userDataStream?";        
        string post_data = "";

        vector <string> extra_http_header;
        string header_chunk("X-MBX-APIKEY: ");
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if ( str_result.size() > 0 ) {
            try {	
                d.Parse(str_result.c_str());
                
                if(d.IsObject() && d.HasMember("listenKey"))
	                s = d["listenKey"].GetString();
	                
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response " + string(e.what());
                    writte_err("err.txt", err);
                    printJson(d);
                    return s;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err("err.txt", err);
            return s;
        }
        return s;
    }

    public:
    void getInfo(){        
        Document d, d3;
        unordered_map<string, bool> promotionUSDT, promotionBTC;
        promotionUSDT["BUSDUSDT"] = promotionUSDT["TUSDBUSD"] = promotionUSDT["TUSDUSDT"] = promotionUSDT["USDCBUSD"] = promotionUSDT["USDCUSDT"] = promotionUSDT["USDPBUSD"] = promotionUSDT["USDPUSDT"] = 1; 
        promotionBTC["BTCAUD"] = promotionBTC["BTCBIDR"] = promotionBTC["BTCBRL"] = promotionBTC["BTCEUR"] = promotionBTC["BTCGBP"] = promotionBTC["BTCGBP"] = promotionBTC["BTCGBP"] =
        promotionBTC["BTCRUB"] = promotionBTC["BTCTRY"] = promotionBTC["BTCTUSD"] = promotionBTC["BTCUAH"] = promotionBTC["BTCUSDC"] = promotionBTC["BTCUSDP"] = promotionBTC["BTCUSDT"] = 1;
        string symbol2 = cc;
        symbol2 = symbol2.substr(0, symbol2.find('-'));
                
        try{
            string result;  
            curl_api_with_header("https://api1.binance.com/api/v3/avgPrice?symbol=" + symbol2 + "BUSD", result);
            d3.Parse(result.c_str()); 

            if(d3.IsObject() && d3.HasMember("price"))
                QUANTITY = 15 / stod( d3["price"].GetString() );
            else
                throw exception();
             
            result.clear(); 
            
            cc.erase(remove(cc.begin(), cc.end(), '-'), cc.end());
            cc1.erase(remove(cc1.begin(), cc1.end(), '-'), cc1.end());
            cc2.erase(remove(cc2.begin(), cc2.end(), '-'), cc2.end()); 
                
            result.clear();  
                       
            curl_api_with_header("https://api1.binance.com/api/v3/exchangeInfo", result);
            d.Parse(result.c_str());

            if(d.HasMember("symbols")){
                for(auto& i : d["symbols"].GetArray()){
                    if(i["status"] == "TRADING" && i["isSpotTradingAllowed"] == true){     
                        string symbol = i["symbol"].GetString();
                        string quote = i["quoteAsset"].GetString();
                
                        if(symbol == cc || symbol == cc1 || symbol == cc2){
                            string symbol2 = symbol;
                            string_tolower(symbol2);
                        
                            if(promotionUSDT[symbol] || promotionBTC[symbol])
                                pairs[symbol2].fees = {0, 0}; 
                            else if(quote == "BUSD")
                                pairs[symbol2].fees = {0, 0.00075};
                            else
                                pairs[symbol2].fees = {0.00075, 0.00075};
                                
                                
                            if(symbol == cc){
                                POW_CC = 1 / stod( i["filters"][0]["tickSize"].GetString() );
                                POW_CC_QTY = 1 / stod( i["filters"][2]["stepSize"].GetString() );
                            }
                            else if(symbol == cc1){
                                POW_CC1 = 1 / stod( i["filters"][0]["tickSize"].GetString() );
                                POW_CC1_QTY = 1 / stod( i["filters"][2]["stepSize"].GetString() );;
                            }
                            else if(symbol == cc2){
                                POW_CC2 = 1 / stod( i["filters"][0]["tickSize"].GetString() );
                                POW_CC2_QTY = 1 / stod( i["filters"][2]["stepSize"].GetString() );
                            }
                            else{
                                cout << "Impossible case! getInfo() Binance" << endl;
                            } 
                        }
                    }
                }
            }
            else
                throw exception();
                
            QUANTITY = round( QUANTITY * POW_CC_QTY ) / POW_CC_QTY;  

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_info> " + string(e.what()) ); 
         	printJson(d3);
        }
    }

    void websocketInit_depth(){
        string ccw = cc; string_tolower(ccw);
        string cc1w = cc1; string_tolower(cc1w);
        string cc2w = cc2; string_tolower(cc2w);
    
        Document d;
        Wss ex;
        
        const string& stream = "/stream?streams=" + ccw + "@depth5@100ms/" + cc1w + "@depth5@100ms/" + cc2w + "@depth5@100ms";

        try {
            ex.init_http("stream.binance.com");
            ex.init_webSocket("stream.binance.com", "443", stream.c_str());
                          
            while (true) {
                ex.read_Socket();	
                d.Parse(ex.get_socket_data().c_str());
               
                const string& s = d["stream"].GetString();
                auto&& o = pairs[ s.substr(0, s.length() - 13) ];

                o.mtx->lock();               

                o.asks[0].first = stod( d["data"]["asks"][0][0].GetString() );
                o.bids[0].first = stod( d["data"]["bids"][0][0].GetString() );
                
                o.mtx->unlock();

                ex.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  Binance-Spot " + string(e.what());
         	writte_err( "err.txt", err ); 
         	ex.webSocket_close();
            return;
          }
    }  
    
    void websocketInit_User(){
        Document d;
        Wss ex;
        string s = "/ws/" + get_listenKey();
        
        try {
            ex.init_http("stream.binance.com");
            ex.init_webSocket("stream.binance.com", "443", s.c_str());

            string ccw = cc; string_tolower(ccw);
            string cc1w = cc1; string_tolower(cc1w);
            string cc2w = cc2; string_tolower(cc2w);
            
            double last_rejected_qty = 0, last_rejected_qty2 = 0;  
            double price1 = 0, price2 = 0;
          
            while (true) {
                ex.read_Socket();	
                d.Parse(ex.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("e") && d["e"] == "executionReport"){  
                    if(d["s"].GetString() == cc && stod( d["l"].GetString() ) != 0.0){  
                        // para ORDER1 == 1 hay que cambiar cc1 por cc2                     
                        const double& rem_qty = stod( d["l"].GetString() );
                        const double& price = ORDER1 ? pairs[cc1w].get_ask() : pairs[cc1w].get_bid();
                        quantity_global = quantity_global - rem_qty;
                        
                        if(d["X"] == "FILLED") 
                            ok = 1; 
                        
                        const int& check = send_order(cc1, type_order2, rem_qty + last_rejected_qty, round( price * POW_CC1 ) / POW_CC1);

                        if(check > 0){                                
                            last_rejected_qty += rem_qty; 
                        }     
                        else{
                            last_rejected_qty = 0;
                        }
                         
                        price1 = stod( d["L"].GetString() );                       
                    }
                    else if(d["s"].GetString() == cc1 && stod( d["Z"].GetString() ) != 0.0){
                        double rem_qty = ORDER3 ? stod( d["Z"].GetString() ) / pairs[cc2w].get_ask() : stod( d["Z"].GetString() );
                        const double& price = ORDER3 ? pairs[cc2w].get_ask() : pairs[cc2w].get_bid();

                        const int& check = send_order(cc2, type_order3, round( (rem_qty + last_rejected_qty2) * POW_CC2_QTY ) / POW_CC2_QTY, round( price * POW_CC2 ) / POW_CC2);

                        if(check > 0){                                 
                            last_rejected_qty2 += rem_qty; 
                        }     
                        else{
                            last_rejected_qty2 = 0;
                        }  
                        
                        price2 = stod( d["L"].GetString() );                        
                    }
                    else if(d["s"].GetString() == cc2){
                        cout << "diff: " << ((price2 / price1) / stod( d["L"].GetString() ) - 1) * 100 << "%\n";
                    }
                }

                ex.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	ex.webSocket_close();
            return;
          }
    } 
    
    int send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) {
        Document d;  
        int ret_code = 0;     
        
        string post_data = "symbol=" + symbol + "&side=" + side + "&type=LIMIT&quantity=" + my_toString_extended(quantity) + "&timestamp=" + to_string( get_current_ms_epoch() ) + "&price=" +
                            my_toString_extended(orderPrice) + "&timeInForce=GTC";                
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );       
        post_data += "&signature=" + signature;      
        const char* url = "https://api.binance.com/api/v3/order?";

        vector <string> extra_http_header;
        extra_http_header.push_back("X-MBX-APIKEY: " + api_key);
        
        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {	
                d.Parse(str_result.c_str());
                
                if(d.HasMember("code")){
                    cout << symbol << "\n";
                    ret_code = d["code"].GetInt64(); 
                    printJson(d);  
                }          
	                
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response " + string(e.what());
                    writte_err("err.txt", err);
                    printJson(d);
                    return ret_code;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err("err.txt", err);
            return ret_code;
        }
        
        return ret_code;
    }
    
    int send_CancelOrder(const string& symbol){
        Document d;
        
        string post_data = "symbol=" + symbol + "&timestamp=" + to_string( get_current_ms_epoch() );        
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );       
        post_data += "&signature=" + signature;      
        const char* url = "https://api.binance.com/api/v3/openOrders?";

        vector <string> extra_http_header;
        extra_http_header.push_back("X-MBX-APIKEY: " + api_key);
        
        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "DELETE");

        if (str_result.size() > 0) {
            try {	
                d.Parse(str_result.c_str());
                              
	                
            	} catch ( exception &e ) {
             	    const string& err = ": error reading cancel_order response " + string(e.what());
                    writte_err("err.txt", err);
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = ": cancel_order.size() is 0";
            writte_err("err.txt", err);
            return 0;
        }
        return 1;
    }
  
};

