

class Bybit : public Exchange {
    const unsigned short id = 3;
    const string api_key = "YFaEVASsKpkIEkBT56";
    const char* secret_key = "ey3dAUWyRXy7Zwi9Sgl0reykCisRu6b2n3HZ";
    string order_id;
    int cont = 0;

    void pingInterval(Wss& ws){
        time_t current_time;
        time(&current_time);
        int ct = current_time;  
                                    
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct >= 20){
                ct = ct2;
                ws.write_Socket(R"({"op":"ping"})");
            }
        }
    }

    public:    
    void websocketInit_depth(){   
        Wss ws;     
        Document d;
        
        type_order2 = ORDER1 ? "buy" : "sell";
        type_order3 = ORDER1 ? "sell" : "buy"; 
        
        try {
            ws.init_http("stream.bybit.com");
            ws.init_webSocket("stream.bybit.com", "443", "/spot/public/v3"); // 100ms

            string s = "{\"op\": \"subscribe\", \"args\": [\"orderbook.40." + cc + "\", \"orderbook.40." + cc1 + "\", \"orderbook.40." + cc2 + "\" ]}";
            ws.write_Socket(s); 

            time_t current_time;
            time(&current_time);
            int ct = current_time;                              
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                if(ct2 - ct >= 20){
                    ct = ct2;
                    ws.write_Socket(R"({"op":"ping"})");
                }
                                           
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(!d.HasMember("op")){
                    auto&& o = pairs[ d["data"]["s"].GetString() ];

                    o.mtx->lock();
                    
                    for(int i = 0; i < 1; i++){
                        o.asks[i].first = stod( d["data"]["a"][i][0].GetString() );
                        //o.asks[i].second = stod( d["data"]["a"][i][1].GetString() );
                    }
                    
                    for(int i = 0; i < 1; i++){
                        o.bids[i].first = stod( d["data"]["b"][i][0].GetString() );
                        //o.bids[i].second = stod( d["data"]["b"][i][1].GetString() );
                    }
                    
                    o.mtx->unlock();
                }

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + to_string(id) + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
         	FAIL = 1;
            return;
          }
    } 
    
    void websocketInit_User(){    
        Wss ws;    
        Document d;
        time_t current_time;
        time(&current_time);
        long long ct2 = current_time;
        ct2 += 10; ct2 *= 1000;
        
        const string& ep = to_string(ct2);
        const string& msg = "GET/realtime" + ep;
        const string& signature =  hmac_sha256( secret_key, msg.c_str() ); 
        double priceCc1;
        
        try {
            ws.init_http("stream.bybit.com");
            ws.init_webSocket("stream.bybit.com", "443", "/spot/private/v3"); 
            
            string s = "{\"op\": \"auth\",\"args\": [\"" + api_key + "\", \"" + ep + "\", \"" + signature + "\"]}";
            ws.write_Socket(s);  
            
            s = "{\"op\": \"subscribe\",\"args\": [\"order\"]}";
            ws.write_Socket(s);
            
            auto&& f = async(&Bybit::pingInterval, this, ref(ws));                         
             
            double last_rejected_qty = 0, last_rejected_qty2 = 0;              
            while (true) {                                           
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());
                   
                if(d.IsObject()){                              
                    if(d.HasMember("topic") && d["topic"] == "order"){                   
                        if(d["data"][0]["l"] != "0"){  
                                                    
                            if(d["data"][0]["s"].GetString() == cc){                        
                                const double& rem_qty = stod( d["data"][0]["l"].GetString() );
                                const double& price = ORDER3 ? pairs[cc1].get_ask() : pairs[cc1].get_bid();
                                quantity_global = quantity_global - rem_qty;
                                
                                const double& check = send_order(cc1, type_order2, rem_qty + last_rejected_qty, round( price * POW_CC1 ) / POW_CC1);

                                if(check > 0)                                  
                                    last_rejected_qty += rem_qty;      
                                else{
                                    if(stod( d["data"][0]["z"].GetString() ) == stod( d["data"][0]["q"].GetString() )) // z == totalQtyFilled & q == totalQty
                                        ok = 1; 
                                    last_rejected_qty = 0;
                                }
                                                          
                            }
                            else if(d["data"][0]["s"].GetString() == cc1){
                                const double& rem_qty = round( stod( d["data"][0]["Z"].GetString() ) * POW_CC2_QTY ) / POW_CC2_QTY;
                                int check = 0;
                                
                                if(cc2 != "USDCUSDT" || last_rejected_qty2 * pairs[cc2].get_ask() > 11){
                                    const double& price = ORDER3 ? pairs[cc2].get_ask() : pairs[cc2].get_bid();
                                    check = send_order(cc2, type_order3, rem_qty + last_rejected_qty2, round( price * POW_CC2 ) / POW_CC2);
                                }

                                if(check > 0)
                                    last_rejected_qty2 += rem_qty;
                                else
                                    last_rejected_qty2 = 0;                               
                            }
                        }
                    }
                                                                                                   
                }
                else
                    throw exception();               

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
         	FAIL = 1;
            return;
          }
    }

    int send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) {	
        Document d;
        int ret_code = 0;

        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bytick.com/spot/v3/private/order?";
        const string& orderID = hmac_sha256( url, ep.c_str() );        
        side[0] = toupper(side[0]);
        
        const string& post_data = "{\"symbol\": \"" + symbol + "\",\"orderQty\":\"" + my_toString_extended(quantity) + "\",\"side\": \"" + side + "\",\"orderType\": \"LIMIT\",\"timeInForce\": \"GTC\",\"orderPrice\": \"" +
                                     my_toString_extended(orderPrice) + "\",\"orderLinkId\": \"" + orderID.substr(0, 5) + "\"}";
        const string& msg = ep + api_key + "5000" + post_data;
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("X-BAPI-SIGN-TYPE: 2");
        extra_http_header.push_back("X-BAPI-SIGN:" + signature);
        extra_http_header.push_back("X-BAPI-API-KEY:" + api_key);
        extra_http_header.push_back("X-BAPI-TIMESTAMP:" + ep);
        extra_http_header.push_back("X-BAPI-RECV-WINDOW: 5000");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(d.IsObject() && d.HasMember("retCode") && d.HasMember("retMsg") && d["retCode"] == 0 && d["retMsg"] == "OK") {}
                else{
                    ret_code = d["retCode"].GetInt64();
                    
                    if(ret_code > 0){
                        if(ret_code == 12136 || ret_code == 10002){
                            quantity_global = QUANTITY / 2;
                            send_order(cc, type_order1, quantity_global, round(priceOrder * POW_CC) / POW_CC ); // LIMIT 
                            
                            if(symbol == cc)
                                ok = 1;
                        }  
                        else if(ret_code == 12131){
                            if(cont++ > 4)
                                send_order(cc2, type_order3, 11.0, round( pairs[cc2].get_ask() * POW_CC2 ) / POW_CC2);
                            else
                                send_order(cc1, type_order2, 11.0, round( pairs[cc1].get_bid() * POW_CC1 ) / POW_CC1);
                        }   
                        else
                            cont = 0;
                                                  
                        printJson(d);
                        cout << symbol << endl;
                    }
                   
                }
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 1;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 1;
        }
        
        if(symbol == cc)
            order_id = orderID.substr(0, 5);
        
        return ret_code;  
    } 
    
    int send_CancelOrder(const string& symbol){
        Document d;

        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bytick.com/spot/v3/private/cancel-order?";
        
        const string& post_data = "{\"orderId\": null,\"orderLinkId\": \"" + order_id + "\"}";
        const string& msg = ep + api_key + "5000" + post_data;

        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("X-BAPI-SIGN:" + signature);
        extra_http_header.push_back("X-BAPI-API-KEY:" + api_key);
        extra_http_header.push_back("X-BAPI-TIMESTAMP:" + ep);
        extra_http_header.push_back("X-BAPI-RECV-WINDOW: 5000");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());                
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;        
    } 

};

