

class Bybit : public Exchange {
    const string api_key = "YFaEVASsKpkIEkBT56";
    const char* secret_key = "ey3dAUWyRXy7Zwi9Sgl0reykCisRu6b2n3HZ";
    string order_id;

    void pingInterval(Wss& ws){
        time_t current_time;
        time(&current_time);
        int ct = current_time;  
                                    
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct > 18){
                ct = ct2;
                ws.write_Socket(R"({"op":"ping"})");
            }
        }
        
        this_thread::sleep_for(chrono::milliseconds(2000));
    }
    
    inline string generate_order_id(const string& symbol){
        srand (time(NULL));
    
        const string& mix = to_string(nanos()) + symbol;
        const string& order_id = hmac_sha256( api_key.substr(0, rand() % 10 + 1).c_str(), mix.c_str() );
        return order_id.substr(0, 5);
    }
    
    public:
    void getInfo(){        
        Document d, d2;
        string result; 
        
        string symbol2 = cc;
        symbol2 = symbol2.substr(0, symbol2.find('-'));
         
        curl_api_with_header("https://api.bytick.com/spot/v3/public/quote/ticker/bookTicker?symbol=" + symbol2 + "USDT", result);
        d.Parse(result.c_str()); 

        if(d.IsObject() && d.HasMember("retCode") && d["retCode"] == 0 && d.HasMember("retMsg") && d["retMsg"] == "OK")
            QUANTITY = 15 / stod( d["result"]["askPrice"].GetString() );
        else
            throw exception();
         
        result.clear(); 
        
        cc.erase(remove(cc.begin(), cc.end(), '-'), cc.end());
        cc1.erase(remove(cc1.begin(), cc1.end(), '-'), cc1.end());
        cc2.erase(remove(cc2.begin(), cc2.end(), '-'), cc2.end());
        
        try{
            string r2;  
            curl_api_with_header("https://api.bytick.com/spot/v3/public/symbols", r2);
            d2.Parse(r2.c_str());

            if(d2.IsObject() && d2.HasMember("retCode") && d2["retCode"] == 0 && d2["retMsg"] == "OK"){
                for(auto& i : d2["result"]["list"].GetArray()){
                    const string& symbol = i["name"].GetString();
                    pairs[symbol].fees = { 0.0, 0.0 };
                   
                    if(symbol == cc || symbol == cc1 || symbol == cc2){                                
                  
                        if(symbol == cc){
                            POW_CC = 1 / stod( i["minPricePrecision"].GetString() );
                            POW_CC_QTY = 1 / stod( i["basePrecision"].GetString() );
                        }
                        else if(symbol == cc1){
                            POW_CC1 = 1 / stod( i["minPricePrecision"].GetString() );
                            POW_CC1_QTY = 1 / stod( i["basePrecision"].GetString() );
                        }
                        else if(symbol == cc2){
                            POW_CC2 = 1 / stod( i["minPricePrecision"].GetString() );
                            POW_CC2_QTY = 1 / stod( i["basePrecision"].GetString() );
                        }
                        else{
                            cout << "Impossible case! getInfo() Bybit" << endl;
                        }   
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <getInfo> " + string(e.what()) ); 
         	printJson(d2);
         	return;
        }       
    }

    
    void websocketInit_depth(){   
        Wss ws;     
        Document d;
        
        type_order2 = ORDER1 ? "buy" : "sell";
        type_order3 = ORDER1 ? "sell" : "buy"; 
        
        try {
            ws.init_http("stream.bybit.com");
            ws.init_webSocket("stream.bybit.com", "443", "/spot/public/v3"); // 100ms

            string s = "{\"op\": \"subscribe\", \"args\": [\"orderbook.40." + cc + "\", \"orderbook.40." + cc1 + "\", \"orderbook.40." + cc2 + "\" ]}";
            ws.write_Socket(s); 

            time_t current_time;
            time(&current_time);
            int ct = current_time;                              
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                if(ct2 - ct >= 20){
                    ct = ct2;
                    ws.write_Socket(R"({"op":"ping"})");
                }
                                           
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(!d.HasMember("op")){
                    auto&& o = pairs[ d["data"]["s"].GetString() ];

                    o.mtx->lock();
                    
                    //for(int i = 0; i < 1; i++){
                        o.asks[0].first = stod( d["data"]["a"][0][0].GetString() );
                        //o.asks[i].second = stod( d["data"]["a"][i][1].GetString() );
                    //}
                    
                    //for(int i = 0; i < 1; i++){
                        o.bids[0].first = stod( d["data"]["b"][0][0].GetString() );
                        //o.bids[i].second = stod( d["data"]["b"][i][1].GetString() );
                    //}
                    
                    o.mtx->unlock();
                }

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
         	FAIL = 1;
            return;
          }
    } 
    
    void websocketInit_User(){    
        Wss ws;    
        Document d;
        time_t current_time;
        time(&current_time);
        long long ct2 = current_time;
        ct2 += 10; ct2 *= 1000;
        
        const string& ep = to_string(ct2);
        const string& msg = "GET/realtime" + ep;
        const string& signature =  hmac_sha256( secret_key, msg.c_str() ); 
        
        try {
            ws.init_http("stream.bybit.com");
            ws.init_webSocket("stream.bybit.com", "443", "/spot/private/v3"); 
            
            string s = "{\"op\": \"auth\",\"args\": [\"" + api_key + "\", \"" + ep + "\", \"" + signature + "\"]}";
            ws.write_Socket(s);  
            
            s = "{\"op\": \"subscribe\",\"args\": [\"order\"]}";
            ws.write_Socket(s);
            
            auto&& f = async(&Bybit::pingInterval, this, ref(ws));                         
             
            double last_rejected_qty = 0, last_rejected_qty2 = 0;   
            double price1 = 0, price2 = 0;           
            while (true) {                                           
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());
                   
                if(d.IsObject()){                              
                    if(d.HasMember("topic") && d["topic"] == "order"){                   
                        if(d["data"][0]["l"] != "0"){  
                                                    
                            if(d["data"][0]["s"].GetString() == cc){                        
                                const double& rem_qty = stod( d["data"][0]["l"].GetString() ); // para ORDER1 = 1 esto tiene que modificarse
                                const double& price = ORDER1 ? pairs[cc1].get_ask() : pairs[cc1].get_bid();
                                quantity_global = quantity_global - rem_qty;
                                
                                if(stod( d["data"][0]["z"].GetString() ) == stod( d["data"][0]["q"].GetString() )) // z == totalQtyFilled & q == totalQty
                                    ok = 1; 
                                
                                const int& check = send_order(cc1, type_order2, round( (rem_qty + last_rejected_qty) * POW_CC1_QTY ) / POW_CC1_QTY, round( price * POW_CC1 ) / POW_CC1);

                                if(check > 0){                              
                                    last_rejected_qty += rem_qty; 
                                    
                                    if(check == 12131){
                                        send_order(cc1, type_order2, round( rem_qty * 0.95 * POW_CC1_QTY ) / POW_CC1_QTY, round( price * POW_CC1 ) / POW_CC1);
                                        last_rejected_qty = 0;
                                    }
                                    else if(check == 10002){
                                        send_order(cc1, type_order2, round( (rem_qty + last_rejected_qty) * POW_CC1_QTY ) / POW_CC1_QTY, round( price * POW_CC1 ) / POW_CC1);
                                        last_rejected_qty = 0;                                        
                                    }
                                }     
                                else{
                                    last_rejected_qty = 0;
                                }
                                
                                price1 = stod( d["data"][0]["L"].GetString() );                                                            
                            }
                            else if(d["data"][0]["s"].GetString() == cc1){
                                const double& rem_qty = round( (stod( d["data"][0]["Z"].GetString() ) / pairs[cc2].get_ask() ) * POW_CC2_QTY ) / POW_CC2_QTY;
                                const double& price = ORDER3 ? pairs[cc2].get_ask() : pairs[cc2].get_bid();
                                const int& check = send_order(cc2, type_order3, round( (rem_qty + last_rejected_qty2) * POW_CC2_QTY ) / POW_CC2_QTY, round( price * POW_CC2 ) / POW_CC2);

                                if(check > 0){                               
                                    last_rejected_qty2 += rem_qty; 
                                    
                                    if(check == 12131){
                                        send_order(cc2, type_order3, round( rem_qty * 0.95 * POW_CC2_QTY ) / POW_CC2_QTY, round( price * POW_CC1 ) / POW_CC1);
                                        last_rejected_qty2 = 0;
                                    }
                                    else if(check == 10002){
                                        send_order(cc2, type_order3, round( (rem_qty + last_rejected_qty2) * POW_CC2_QTY ) / POW_CC2_QTY, round( price * POW_CC2 ) / POW_CC2);
                                        last_rejected_qty = 0;                                        
                                    }
                                }     
                                else{
                                    last_rejected_qty2 = 0;
                                } 
                                
                                price2 = stod( d["data"][0]["L"].GetString() );                           
                            }
                            else if(d["data"][0]["s"].GetString() == cc2){
                                cout << "diff: " << ((price2 / price1) / stod( d["data"][0]["L"].GetString() ) - 1) * 100 << "%\n";
                            }
                        }
                    }
                                                                                                   
                }
                else
                    throw exception();               

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
         	FAIL = 1;
            return;
          }
    }

    int send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) {	
        Document d;
        int ret_code = 0;

        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bytick.com/spot/v3/private/order?";      
        side[0] = toupper(side[0]);
       // const string& orderID = generate_order_id(symbol);
        
        const string& post_data = "{\"symbol\": \"" + symbol + "\",\"orderQty\":\"" + my_toString_extended(quantity) + "\",\"side\": \"" + side + "\",\"orderType\": \"LIMIT\",\"timeInForce\": \"GTC\",\"orderPrice\": \"" +
                                     my_toString_extended(orderPrice) + "\"}";
        const string& msg = ep + api_key + "5000" + post_data;
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("X-BAPI-SIGN-TYPE: 2");
        extra_http_header.push_back("X-BAPI-SIGN:" + signature);
        extra_http_header.push_back("X-BAPI-API-KEY:" + api_key);
        extra_http_header.push_back("X-BAPI-TIMESTAMP:" + ep);
        extra_http_header.push_back("X-BAPI-RECV-WINDOW: 5000");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(d.IsObject() && d.HasMember("retCode") && d.HasMember("retMsg") && d["retCode"] == 0 && d["retMsg"] == "OK") {}
                else{
                    ret_code = d["retCode"].GetInt64();
                    
                    if(ret_code > 0){
                        cout << symbol << endl;
                    
                        if(cc == symbol){
                            if(ret_code == 12136){
                                quantity_global = QUANTITY / 2;
                                send_order(cc, type_order1, round(quantity_global * POW_CC_QTY) / POW_CC_QTY, round(priceOrder * POW_CC) / POW_CC ); // LIMIT 
                            }  
                            else if(ret_code == 12131)
                                send_order(cc1, type_order2, 15.0, round(pairs[cc1].get_bid() * POW_CC) / POW_CC ); // LIMIT  
                        }
                                                  
                        printJson(d);
                    }
                   
                }
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 1;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 1;
        }
        
        /*if(symbol == cc)
            order_id = orderID;*/
        
        return ret_code;  
    } 
    
    int send_CancelOrder(const string& symbol){
        Document d;

        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bytick.com/spot/v3/private/cancel-orders?";
        
        
        const string& post_data = "{\"symbol\": \"" + symbol + "\"}";
        const string& msg = ep + api_key + "5000" + post_data;

        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("X-BAPI-SIGN-TYPE: 2");
        extra_http_header.push_back("X-BAPI-SIGN:" + signature);
        extra_http_header.push_back("X-BAPI-API-KEY:" + api_key);
        extra_http_header.push_back("X-BAPI-TIMESTAMP:" + ep);
        extra_http_header.push_back("X-BAPI-RECV-WINDOW: 5000");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());                

            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;        
    } 

};

