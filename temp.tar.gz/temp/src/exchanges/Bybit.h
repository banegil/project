

class Bybit : public Exchange {
    const string id = "Bybit";
    const unsigned short idNum = 3;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETHUSDT";
    atomic<double> bestAsk, bestBid;
    double quotePrecision;
    string orderId;
    bool limitOrder = 0;
    double remaining_qty = 0;
    
    const string api_key = "8q49uoJFqIU9eVuZZ4";
    const char* secret_key = "eruecjq5Cr3GyYiOSa3Jf3WLagjTR9HrQJjC";

    void pingInterval(Wss& ws){
        time_t current_time;
        time(&current_time);
        int ct = current_time;  
                                    
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct >= 20){
                ct = ct2;
                ws.write_Socket(R"({"op":"ping"})");
            }
        }
    }   
    
    public: 
    bool get_pairs(){        
        Document d;
        fee = {0.0, 0.0};
        symbol = chosenSymbol;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        
        try{
            string result;          
            curl_api("https://api.bytick.com/spot/v3/public/symbols", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("result") && d["retCode"] == 0 && d["retMsg"] == "OK"){
                for(auto& i : d["result"]["list"].GetArray()){
                    if(i["showStatus"] == "1"){ 
                        string quote = i["quoteCoin"].GetString();
                        string base = i["baseCoin"].GetString(); 

                        if( base + "-" + quote == chosenSymbol ){
                            exchangeInfo[idNum].multiplier = stod( i["minTradeQty"].GetString() ); 
                            quotePrecision = stod( i["minPricePrecision"].GetString() );
                            return 1;
                        }
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }
   
    void websocketInit_depth(){   
        Wss ws;     
        Document d;
        string s, quoteAsset, baseAsset;
        unordered_map<string, string> qA;
        qA["DT"] = "USDT"; qA["TH"] = "ETH"; qA["TC"] = "BTC"; qA["AI"] = "DAI"; qA["DC"] = "USDC";
        
        try {
            ws.init_http("stream.bybit.com");
            ws.init_webSocket("stream.bybit.com", "443", "/spot/public/v3"); // 100ms

            s = "{\"op\": \"subscribe\", \"args\": [\"orderbook.40." + symbol + "\"]}";
            ws.write_Socket(s); 

            time_t current_time;
            time(&current_time);
            int ct = current_time;                              
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                if(ct2 - ct >= 20){
                    ct = ct2;
                    ws.write_Socket(R"({"op":"ping"})");
                }
                                           
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("b")){
                                
                    mtxAsk.lock();
                    asks.clear();
                    for(int i = 0; i < 20; i++)
                        asks[ stod(d["data"]["a"][i][0].GetString()) ] = stod(d["data"]["a"][i][1].GetString());
                    mtxAsk.unlock();
                    bestAsk = asks.begin()->first;
                        
                    mtxBid.lock();
                    bids.clear();
                    for(int i = 0; i < 20; i++)
                        bids[ stod(d["data"]["b"][i][0].GetString()) ] = stod(d["data"]["b"][i][1].GetString());
                    mtxBid.unlock();
                    bestBid = bids.begin()->first;
                    
                }
                else if (!d.HasMember("op"))
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){    
        Wss ws;    
        Document d;
        time_t current_time;
        time(&current_time);
        long long ct2 = current_time;
        ct2 += 10; ct2 *= 1000;
        
        const string& ep = to_string(ct2);
        const string& msg = "GET/realtime" + ep;
        const string& signature =  hmac_sha256( secret_key, msg.c_str() ); 
        double priceCc1;
        
        try {
            ws.init_http("stream.bybit.com");
            ws.init_webSocket("stream.bybit.com", "443", "/spot/private/v3"); 
            
            string s = "{\"op\": \"auth\",\"args\": [\"" + api_key + "\", \"" + ep + "\", \"" + signature + "\"]}";
            ws.write_Socket(s);  

            ws.read_Socket();	
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("success") && d["success"] == true && d.HasMember("op") && d["op"] == "auth"))
                throw exception();
            
            s = "{\"op\": \"subscribe\",\"args\": [\"order\",\"outboundAccountInfo\"]}";
            ws.write_Socket(s);
            
            auto&& f = async(&Bybit::pingInterval, this, ref(ws));                         
                                         
            while (true) {                                           
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject()){                               
                    if(d.HasMember("topic")){
                        exchangeInfo[idNum].mtx->lock();
                    
                        if(d["topic"] == "order"){                   
                            if(d["data"][0]["Z"] != "0"){                            
                                if(limitOrder){
                                    orderExecuted = true;                                    
                                    const double& quantity = stod( d["z"].GetString() );                                    
                                    const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", quantity, 0.0, 0);
                                    
                                    if(res == 0)
                                        stopExecution = true;
                                    else if(res == 1)
                                        remaining_qty += quantity;
                                    else
                                        remaining_qty = 0;
                                    
                                    limitOrder = 0;
                                }
                            
                                exchangeInfo[idNum].orderPrice = stod( d[0]["Z"].GetString() ) / stod( d[0]["z"].GetString() ); 
                            }                            
                        } 
                        else if(d["topic"] == "outboundAccountInfo")
                            exchangeInfo[idNum].balance[ d["data"][0]["B"][0]["a"].GetString() ] = stod( d["data"][0]["B"][0]["f"].GetString() );
                        
                        exchangeInfo[idNum].mtx->lock();
                        
                    }                                                                                                                                                    
                }
                else
                    throw exception();              

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    }

    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {	
        Document d;
        double orderPrice;
        
        if(limit)
            orderPrice = price;
        else{
            orderPrice = side == "buy" ? bestAsk * 1.01 : bestBid * 0.99;  
            my_round(orderPrice, quotePrecision);      
        }                   
      
        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bytick.com/spot/v3/private/order?";
        const string& orderID = hmac_sha256( url, ep.c_str() );
        
        side[0] = toupper(side[0]);      
        const string& post_data = "{\"symbol\": \"" + symbol + "\",\"orderQty\":\"" + to_string(quantity) + "\",\"side\": \"" + side + "\",\"orderType\": \"LIMIT\",\"timeInForce\": \"GTC\",\"orderPrice\": \"" +
                                     to_string(orderPrice) + "\",\"orderLinkId\": \"" + orderID.substr(0, 5) + "\"}"; 
        const string& msg = ep + api_key + "5000" + post_data;
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("X-BAPI-SIGN-TYPE: 2");
        extra_http_header.push_back("X-BAPI-SIGN:" + signature);
        extra_http_header.push_back("X-BAPI-API-KEY:" + api_key);
        extra_http_header.push_back("X-BAPI-TIMESTAMP:" + ep);
        extra_http_header.push_back("X-BAPI-RECV-WINDOW: 5000");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_header(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(d.IsObject() && d.HasMember("retCode")){
                    if(d["retCode"] == 0 && d.HasMember("retMsg") && d["retMsg"] == "OK")
                        orderId = d["result"]["orderLinkId"].GetString();
                    else if(d["retCode"] == 12136)
                        return 1; 
                    else throw exception();       
                } 
                else
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        
        return 2;  
    } 
    
    bool cancel_order() {	
        Document d;                 
      
        const string& ep = to_string(get_current_ms_epoch());
        const char* url = "https://api.bytick.com/spot/v3/private/cancel-order?";
        const string& orderID = hmac_sha256( url, ep.c_str() );
            
        const string& post_data = "{\"orderLinkId\": \"" + orderId + "\"}"; 
        const string& msg = ep + api_key + "5000" + post_data;
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("X-BAPI-SIGN-TYPE: 2");
        extra_http_header.push_back("X-BAPI-SIGN:" + signature);
        extra_http_header.push_back("X-BAPI-API-KEY:" + api_key);
        extra_http_header.push_back("X-BAPI-TIMESTAMP:" + ep);
        extra_http_header.push_back("X-BAPI-RECV-WINDOW: 5000");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_header(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(!(d.IsObject() && d.HasMember("retCode") && d["retCode"] == 0 && d.HasMember("retMsg") && d["retMsg"] == "OK"))
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading cancel_order response, " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": cancel_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        
        return 1;  
    }
    
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

