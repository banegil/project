

class Kucoin : public Exchange {
    const string id = "Kucoin";
    const unsigned short idNum = 9;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    bool limitOrder = 0;
    double remaining_qty = 0;
    
    const string api_key = "631b0c26ad6404000165229c";
    const char* secret_key = "ad2ccd86-9d35-4067-9693-87dccb5f409a";

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.0008, 0.0008};
        unordered_map<string, bool> b;
        b["1EARTH"] = b["2CRZ"] = b["ABBC"] = b["ACA"] = b["ACE"] = b["ADS"] = b["AFK"] = b["AI"] = b["AIOZ"] = b["AKT"] = b["ALBT"] = b["ALPACA"] = b["APL"] = b["ARKER"] = b["ARNM"] = b["ARRR"] = b["AURY"] = b["AUSD"] = b["AXC"] = 
        b["BASIC"] = b["BFC"] = b["BIFI"] = b["BLOK"] = b["BMON"] = b["BNC"] = b["BOA"] = b["BONDLY"] = b["BOSON"] = b["BRISE"] = b["BULL"] = b["CARD"] = b["CARR"] = b["CAS"] = b["CCD"] = b["CEEK"] = b["CERE"] = b["CEUR"] = b["CFG"] = b["CGG"] =
        b["CIRUS"] = b["CPOOL"] = b["CQT"] = b["CREDI"] = b["CSPR"] = b["CTI"] = b["CUDOS"] = b["CULT"] = b["CUSD"] = b["CWEB"] = b["CWS"] = b["DAO"] = b["DAPPX"] = b["DFI"] = b["DFYN"] = b["DG"] = b["DINO"] = b["DIVI"] = b["DMTR"] = b["DORA"] = 
        b["DPET"] = b["DPI"] = b["DPR"] = b["DREAMS"] = b["DSLA"] = b["DVPN"] = b["DYP"] = b["EDG"] = b["EFX"] = b["EGAME"] = b["ELON"] = b["EPK"] = b["EQX"] = b["EQZ"] = b["ERG"] = b["ERSDL"] = b["ETHO"] = b["EVER"] = b["FALCONS"] = b["FCD"] =
        b["FCL"] = b["FCON"] = b["FEAR"] = b["FLAME"] = b["FLY"] = b["FORM"] = b["FORWARD"] = b["FRA"] = b["FRM"] = b["FRR"] = b["FTG"] = b["GAFI"] = b["GALAX"] = b["GEEQ"] = b["GENS"] = b["GGG"] = b["GHX"] = b["GLCH"] = b["GLMR"] = 
        b["GLQ"] = b["GMEE"] = b["GMM"] =  b["GOM2"] =  b["GOVI"] =  b["H3RO3S"] =  b["HAI"] =  b["HAKA"] =  b["HAPI"] = b["HAWK"] = b["HBB"] = b["HEART"] = b["HERO"] = b["HORD"] = b["HT"] = b["HTR"] = b["HYDRA"] = b["HYVE"] =
        b["IDEA"] = b["IHC"] = b["ILA"] = b["IOI"] = b["ISP"] = b["ITAMCUBE"] = b["JAM"] = b["JUP"] = b["KARA"] = b["KCS"] = b["KDA"] = b["KDOIN"] = b["KIN"] = b["KLV"] = b["KOK"] = b["KRL"] = b["KYL"] = b["LABS"] = b["LACE"] = 
        b["LAVAX"] = b["LAYER"] = b["LIKE"] = b["LOCG"] = b["LON"] = b["LOVE"] = b["LPOOL"] = b["LSS"] = b["LTX"] = b["MAHA"] = b["MAKI"] = b["MARS4"] = b["MARSH"] = b["MASK"] = b["MATTER"] = b["MIR"] = b["MITX"] = b["MJT"] = b["MLK"] = 
        b["MNET"] = b["MNST"] = b["MODEFI"] = b["MONI"] = b["MOOV"] = b["MOVR"] = b["MSWAP"] = b["MTRG"] = b["MTS"] = b["MV"] = b["NAKA"] = b["NDAU"] = b["NEER"] = b["NGC"] = b["NGM"] = b["NHCT"] = b["NIF"] = b["NORD"] = b["NTVRK"] = b["NUM"] = 
        b["ODDZ"] = b["OLE"] = b["ONSTON"] = b["OOE"] = b["OPUL"] = b["ORAI"] = b["ORC"] = b["OUSD"] = b["OVR"] = b["PBR"] = b["PBX"] = b["PCX"] = b["PEL"] = b["PHNX"] = b["PKF"] = b["PLATO"] = b["PLD"] = b["PLGR"] = b["PLU"] = 
        b["PMON"] = b["POL"] = b["POLC"] = b["POLK"] = b["POLX"] = b["PRQ"] = b["PSL"] = b["PUNDIX"] = b["PYR"] = b["QI"] = b["QRDO"] = b["RACEFI"] = b["RANKER"] = b["RBP"] = b["REAP"] = b["REV3L"] = b["REVU"] = b["REVV"] = b["RFOX"] = 
        b["RLY"] = b["RMRK"] = b["RNDR"] = b["ROAR"] = b["ROSE"] = b["ROSN"] = b["ROUTE"] = b["RPC"] = b["SCLP"] = b["SDAO"] = b["SDN"] = b["SFUND"] = b["SHFT"] = b["SHILL"] = b["SHX"] = b["SIENNA"] = b["SIN"] = b["SKEY"] = b["SLCL"] = b["SLIM"] = 
        b["SOLR"] = b["SON"] = b["SOS"] = b["SOV"] = b["SPI"] = b["SRBP"] = b["SRK"] = b["STARLY"] = b["STC"] = b["STEPWATCH"] = b["STG"] = b["STND"] = b["STRONG"] = b["SURV"] = b["SWASH"] = b["SWINGBY"] = b["SWP"] = b["SYNR"] = b["TARA"] = 
        b["TAUM"] = b["TCP"] = b["TIDAL"] = b["TLOS"] = b["TOWER"] = b["TRADE"] = b["TRVL"] = b["TXA"] = b["UFO"] = b["UMB"] = b["UNB"] = b["UNIC"] = b["UNO"] = b["UOS"] = b["UPO"] = b["URUS"] = b["VAI"] = b["VEED"] = b["VEGA"] = 
        b["VEMP"] = b["VISION"] = b["VLX"] = b["VXV"] = b["WAL"] = b["WELL"] = b["WEMIX"] = b["WILD"] = b["WMT"] = b["WOMBAT"] = b["WOOP"] = b["WSIENNA"] = b["XAVA"] = b["XCAD"] = b["XCN"] = b["XCUR"] = b["XDC"] = b["XDEFI"] = b["XED"] = b["XHV"] = 
        b["XNL"] = b["XPRT"] = b["XSR"] = b["XTAG"] = b["XTM"] = b["XWG"] = b["YFDAI"] = b["YLD"] = b["YOP"] = b["ZCX"] = b["ZEE"] = b["ZKT"] = 1;
        unordered_map<string, bool> c;
        c["BURP"] = c["CHMB"] = c["CLH"] = c["COMB"] = c["CWAR"] = c["FT"] = c["GARI"] = c["HIBAYC"] = c["HIENS3"] = c["HIENS4"] = c["HIPUNKS"] = c["HISAND33"] = c["HOTCROSS"] = c["IXS"] = c["LITH"] = c["MELOS"] = c["MEM"] = c["MLS"] = 
        c["NWC"] = c["PDEX"] = c["PLY"] = c["VELO"] = c["VR"] = 1;

        try{
            string result;          
            curl_api("https://api.kucoin.com/api/v1/symbols", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("data") && d["code"] == "200000"){
                for(auto& i : d["data"].GetArray()){
                    if(i["enableTrading"] == true){
                        string base = i["baseCurrency"].GetString();  
                        string quote = i["quoteCurrency"].GetString(); 
                        
                        if(b.find(base) != b.end())
                            fee = {0.0016, 0.0016}; 
                        else if(c.find(base) != c.end())
                            fee = {0.0024, 0.0024};
                        
                        if( base + "-" + quote == chosenSymbol ){
                            exchangeInfo[idNum].multiplier = stod( i["baseIncrement"].GetString() );
                            return 1;
                        }
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }

    void websocketInit_depth(){    
        Wss ws;    
        Document d;         
        int pingInterval;
        vector <string> v;
        string s;
        
        string idC = "154591120590803";
        const char* url = "https://api.kucoin.com/api/v1/bullet-public";
        
        string str_result;
        curl_api_with_header(url, str_result, v, "", "POST");
        d.Parse(str_result.c_str());        

        const string& endpoints = d["data"]["instanceServers"][0]["endpoint"].GetString();
        const string& endpoint = endpoints.substr(6,17);
        const string& token = d["data"]["token"].GetString();
        pingInterval = d["data"]["instanceServers"][0]["pingInterval"].GetUint64();
        pingInterval /= 1000; 
                
        try {
            ws.init_http(endpoint);
            s = "/endpoint?token=" + token + "&[connectId=" + idC + "]";
            ws.init_webSocket(endpoint, "443", s.c_str());
            
            ws.read_Socket();	
            ws.buffer_clear();
            ws.write_Socket(R"({"id":"154591120590803","type":"ping"})");
            s = "{\"id\": 154591120590802,\"type\": \"subscribe\",\"topic\": \"/spotMarket/level2Depth50:" + chosenSymbol + "\",\"response\": false}";
            ws.write_Socket(s);

            time_t current_time;
            time(&current_time);
            int ct = current_time;                         
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                
                if(ct2 - ct >= pingInterval - 2){
                    ct = ct2;
                    ws.write_Socket(R"({"id":"154591120590803","type":"ping"})");
                }
            
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());
                
                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("asks")){
                
                    mtxAsk.lock();
                    asks.clear();
                    for(int i = 0; i < 20; i++)
                        asks[ stod(d["data"]["asks"][i][0].GetString()) ] = stod(d["data"]["asks"][i][1].GetString());
                    mtxAsk.unlock();
                        
                    mtxBid.lock();
                    bids.clear();
                    for(int i = 0; i < 20; i++)
                        bids[ stod(d["data"]["bids"][i][0].GetString()) ] = stod(d["data"]["bids"][i][1].GetString());
                    mtxBid.unlock();
                
                }
                else if(!(d.HasMember("type") && d["type"] == "pong"))
                    throw exception(); 

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){    
        Wss ws;    
        Document d;         
        int pingInterval;
        vector <string> v;
        string s;
        
        string idC = "154591120590802";
        const char* url = "https://api.kucoin.com/api/v1/bullet-private";

        const string& ep = to_string (get_current_ms_epoch());
        
        const string& msg = ep + "POST/api/v1/bullet-private";
        const char* ph = "tradingKucoin";
        
        const string& signature =  hmac_sha256_2( secret_key, msg.c_str() );
        const string& phrase = hmac_sha256_2( secret_key, ph );
        
        vector <string> extra_http_header;
        extra_http_header.push_back("KC-API-SIGN:"+ signature);
        extra_http_header.push_back("KC-API-TIMESTAMP:" + ep);
        extra_http_header.push_back("KC-API-KEY:" + api_key);
        extra_http_header.push_back("KC-API-PASSPHRASE:" + phrase);
        extra_http_header.push_back("KC-API-KEY-VERSION:2");
        extra_http_header.push_back("Content-Type: application/json");

        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, "", "POST" ) ;
        d.Parse(str_result.c_str()); 
        
        if(!(d.IsObject() && d.HasMember("code") && d["code"] == "200000"))
            throw exception();      

        const string& endpoints = d["data"]["instanceServers"][0]["endpoint"].GetString();
        const string& endpoint = endpoints.substr(6,17);
        const string& token = d["data"]["token"].GetString();
        pingInterval = d["data"]["instanceServers"][0]["pingInterval"].GetUint64();
        pingInterval /= 1000; 
                
        try {
            ws.init_http(endpoint);
            s = "/endpoint?token=" + token + "&[connectId=" + idC + "]";
            ws.init_webSocket(endpoint, "443", s.c_str());
            
            ws.read_Socket();	
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("type") && d["type"] == "welcome"))
                throw exception();
            ws.buffer_clear();
            ws.write_Socket(R"({"id":"154591120590802","type":"ping"})");

            ws.read_Socket();
            ws.buffer_clear();
            
            s = "{\"id\": 154591120590802, \"type\": \"subscribe\", \"topic\": \"/spotMarket/tradeOrders\", \"privateChannel\": true, \"response\": true}";
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("type") && d["type"] == "ack"))
                throw exception();
            ws.buffer_clear();
            
            s = "{\"id\": 154591120590802, \"type\": \"subscribe\", \"topic\": \"/account/balance\", \"privateChannel\": true, \"response\": true}";
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("type") && d["type"] == "ack"))
                throw exception();
            ws.buffer_clear();

            time_t current_time;
            time(&current_time);
            int ct = current_time;                         
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                
                if(ct2 - ct >= pingInterval - 2){
                    ct = ct2;
                    ws.write_Socket(R"({"id":"154591120590802","type":"ping"})");
                }
            
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());
                
                if(d.IsObject() && d.HasMember("topic")){
                
                    exchangeInfo[idNum].mtx->lock();
                
                    if(d["topic"] == "/spotMarket/tradeOrders" && d["data"].HasMember("status") && d["data"]["status"] == "match"){
                        if(limitOrder){
                            orderExecuted = true;                                    
                            const double& quantity = stod( d["data"]["filledSize"].GetString() );                                    
                            const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", quantity, 0.0, 0);
                            
                            if(res == 0)
                                stopExecution = true;
                            else if(res == 1)
                                remaining_qty += quantity;
                            else
                                remaining_qty = 0;
                            
                            limitOrder = 0;
                        } 
                    
                        exchangeInfo[idNum].orderPrice = stod( d["data"]["matchPrice"].GetString() );  
                    }
                    else if(d["topic"] == "/account/balance" && d["data"].HasMember("available"))
                        exchangeInfo[idNum].balance[ d["data"]["currency"].GetString() ] = stod( d["data"]["available"].GetString() );  
                        
                    exchangeInfo[idNum].mtx->unlock();  
                          
                }
                else if(!(d.HasMember("type") && d["type"] == "pong"))
                    throw exception();  

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    }
    
    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {	
        Document d;
        string type = "market";
        string price_string = "";
        
        if(limit){
            type = "limit";
            price_string = "\"price\": \""+ to_string(price) +"\", ";
        }

        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://api.kucoin.com/api/v1/orders";
        
        const string& post_data = "{\"clientOid\":\"154591120590801\"," + price_string + "\"side\":\"" + side + "\",\"symbol\":\"" + chosenSymbol + "\",\"type\":\"" + type +
                                     "\",\"size\":\"" + to_string(quantity) + "\"}";
        const string& msg = ep + "POST/api/v1/orders" + post_data;
        const char* ph = "tradingKucoin";
        
        const string& signature =  hmac_sha256_2( secret_key, msg.c_str() );
        const string& phrase = hmac_sha256_2( secret_key, ph );
        
        vector <string> extra_http_header;
        extra_http_header.push_back("KC-API-SIGN:"+ signature);
        extra_http_header.push_back("KC-API-TIMESTAMP:" + ep);
        extra_http_header.push_back("KC-API-KEY:" + api_key);
        extra_http_header.push_back("KC-API-PASSPHRASE:" + phrase);
        extra_http_header.push_back("KC-API-KEY-VERSION:2");
        extra_http_header.push_back("Content-Type: application/json");
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "POST" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(d.IsObject() && d.HasMember("code")){
                    if(d.HasMember("data") && d["code"] == "200000" && d["data"].HasMember("orderId")){}
                    else if(d["code"] == "400760")
                        return 1;
                    else
                        throw exception();
            	}
            	else
            	    throw exception();	
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 2;
    }
    
    bool cancel_order() {	
        Document d;

        const string& ep = to_string (get_current_ms_epoch());

        const string& url = "https://api.kucoin.com/api/v1/orders?symbol=" + chosenSymbol + "&tradeType=TRADE";
        
        const string& post_data = "{\"symbol\":\"" + chosenSymbol + "\",\"tradeType\":\"TRADE\"}";
        const string& msg = ep + "DELETE/api/v1/orders?symbol=" + chosenSymbol + "&tradeType=TRADE" + post_data;
        const char* ph = "tradingKucoin";
        
        const string& signature =  hmac_sha256_2( secret_key, msg.c_str() );
        const string& phrase = hmac_sha256_2( secret_key, ph );
        
        vector <string> extra_http_header;
        extra_http_header.push_back("KC-API-SIGN:"+ signature);
        extra_http_header.push_back("KC-API-TIMESTAMP:" + ep);
        extra_http_header.push_back("KC-API-KEY:" + api_key);
        extra_http_header.push_back("KC-API-PASSPHRASE:" + phrase);
        extra_http_header.push_back("KC-API-KEY-VERSION:2");
        extra_http_header.push_back("Content-Type: application/json");
        
        string str_result;
        curl_api_with_header( url.c_str(), str_result , extra_http_header, post_data, "DELETE" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(!(d.IsObject() && d.HasMember("code") && d.HasMember("data") && d["code"] == "200000"))
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading cancel_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": cancel_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;
   }
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

