

class Binance : Exchange {
    const unsigned short id = 0;

    public:
    void get_exchanges(){        
        Document d;
        unordered_map<string, bool> promotionUSDT, promotionBTC;
        promotionUSDT["BUSDUSDT"] = promotionUSDT["TUSDUSDT"] = promotionUSDT["USDCUSDT"] = promotionUSDT["USDPUSDT"] = 1; 
        promotionBTC["BTCBUSD"] = promotionBTC["BTCTUSD"] = promotionBTC["BTCUSDC"] = promotionBTC["BTCUSDP"] = promotionBTC["BTCUSDT"] = 1;
        
        try{
            string result;          
            curl_api_with_header("https://api.binance.com/api/v3/exchangeInfo", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("symbols")){
                int cont = 0;
                for(auto& i : d["symbols"].GetArray()){
                    if(i["status"] == "TRADING" && i["permissions"][0] == "SPOT"){  
                        string base = i["baseAsset"].GetString(); 
                        string quote = i["quoteAsset"].GetString();       
                        orderbook o = orderbook();
                        
                        if(promotionUSDT[base + quote] || promotionBTC[base + quote])
                            o.fee = {0, 0}; 
                        else if(quote == "BUSD")
                            o.fee = {0, 0.00075};
                        else
                            o.fee = {0.00075, 0.00075}; 
                        
                        coins[base][quote] = o;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_exchanges> " + string(e.what()) ); 
         	printJson(d);
        }
    }
    
    void curl_depth(const string& symbol){
        Document d;
        try{
            string result;      
            const string& url = "https://api.binance.com/api/v3/depth?symbol=" + symbol + "&limit=20";    
            curl_api_with_header(url, result);
            d.Parse(result.c_str()); 

            printJson(d);

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <curl_depth> " + string(e.what()) ); 
         	printJson(d);
         	return;
        }            
    }
    
    void websocketInit_depth(){
        Document d;
        string s, baseAsset, quoteAsset;
        
        try {
            init_http("stream.binance.com");
            init_webSocket("stream.binance.com", "443", "/ws/!bookTicker");
            unordered_map<string, string> m;
            m["DT"] = "USDT"; m["TC"] = "BTC"; m["DC"] = "USDC"; m["TH"] = "ETH"; m["SD"] = "BUSD"; m["DP"] = "USDP";
                          
            while (true) {
                read_Socket();	
                d.Parse(get_socket_data().c_str());
                
                if(d.IsObject() && d.HasMember("a") && d.HasMember("b")){ 
                    s = d["s"].GetString();
                    quoteAsset = m[s.substr(s.length() - 2)];
                    baseAsset = s.substr(0, s.length() - quoteAsset.length());
                    
                    auto&& c = coins[baseAsset][quoteAsset];

                    c.mtx->lock(); 
                    
                    c.asks.clear();
                    c.bids.clear();
                    
                    c.asks[stod(d["a"].GetString())] = 0;
                    c.bids[stod(d["b"].GetString())] = 0;
                    
                    c.mtx->unlock(); 
                }
                else 
                    throw exception();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  Binance-Spot " + string(e.what());
         	writte_err( "err.txt", err ); 
         	/*coins[baseAsset].erase(quoteAsset);
         	if(coins[baseAsset].size() == 1)
         	    coins.erase(baseAsset);*/
         	webSocket_close();
            return;
          }
    }  
};

