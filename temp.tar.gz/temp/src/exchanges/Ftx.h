

class Ftx : public Exchange {
    const string id = "Ftx";
    const unsigned short idNum = 6;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETH/USDT";
    string base = "ETH";
    string quote = "USDT";
    bool limitOrder = 0;
    double remaining_qty = 0;
   
    const string api_key = "AdIMZbPwsjtn1q2gZemf59_rLSyGBJyoPu-q7u_M";
    const char* secret_key = "oXLsT0qNrh7KHlSNGtUOayPpNa23222rMINvk15E";


    bool get_balance() {	
        Document d;
        
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://ftx.com/api/wallet/balances";        
        const string& msg = ep + "GET/api/wallet/balances";
        
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("FTX-KEY:" + api_key);
        extra_http_header.push_back("FTX-SIGN:" + signature);
        extra_http_header.push_back("FTX-TS:" + ep);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, "", "GET" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());  
                
                if(d.IsObject() && d.HasMember("success") && d["success"] == true){
                    for(auto&& i : d["result"].GetArray())
                        if(i["coin"].GetString() == base || i["coin"].GetString() == quote)
                            exchangeInfo[idNum].balance[ i["coin"].GetString() ] = i["free"].GetDouble();
                }
                else
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading get_balance response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": get_balance.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        
        return 1;
    }

    string scientificNotation(const double& d){
        ostringstream s;
        double checkInt = d - int(d);
        
        if(checkInt == 0)
            s << fixed << setprecision(1) << d;
        else
            s << d;
            
        return s.str();        
    }

    unsigned long checkSum(){
        string s = "";
        
        auto&& i = asks.begin();
        auto&& j = bids.begin();        
        for (; i != asks.end(); ++i, ++j)
            s += scientificNotation(j->first) + ":" + scientificNotation(j->second) + ":" + scientificNotation(i->first) + ":" + scientificNotation(i->second) + ":";
        
        s.pop_back();
        return CRC32(s);
    }

    public:
    bool get_pairs(){       
        Document d;
        fee = {0.000194, 0.000679}; // with 675$ 0 maker, with 4000$ -0.0005 maker
        symbol = chosenSymbol;
        base = symbol.substr(0, symbol.find('-'));
        quote = symbol.substr(symbol.find('-') + 1, symbol.length() - 1); 
        symbol[symbol.find('-')] = '/';
        
        try{
            string result;          
            curl_api("https://ftx.com/api/markets", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("result") && d["success"] == true){
                for(auto& i : d["result"].GetArray()){
                    if(i["enabled"] == true && i["futureType"].IsNull()){
                        string base = i["baseCurrency"].GetString();
                        string quote = i["quoteCurrency"].GetString();

                        if( base + "-" + quote == chosenSymbol ){
                            if(get_balance()){
                                exchangeInfo[idNum].multiplier = i["sizeIncrement"].GetDouble();                             
                                return 1;
                            }
                        }
                    }               
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;       
    }

    void websocketInit_depth(){  
        Wss ws;      
        Document d;
        string s = "{\"op\": \"subscribe\", \"channel\": \"orderbook\", \"market\": \"" + symbol + "\"}";

        try {   
            ws.init_http("ftx.com");
            ws.init_webSocket("ftx.com", "443", "/ws");
            ws.write_Socket(s);
            
            ws.read_Socket();	
            ws.buffer_clear();            
                  
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("bids")){
                        mtxAsk.lock();
                        for(auto&& i : d["data"]["asks"].GetArray()){
                            double price = i[0].GetDouble();
                            double qty = i[1].GetDouble();
                            
                            if(qty == 0)
                                asks.erase(price);
                            else
                                asks[price] = qty;
                        }
                        mtxAsk.unlock();
                            
                        mtxBid.lock();
                        for(auto&& i : d["data"]["bids"].GetArray()){
                            double price = i[0].GetDouble();
                            double qty = i[1].GetDouble();
                            
                            if(qty == 0)
                                bids.erase(price);
                            else
                                bids[price] = qty;
                        }
                        mtxBid.unlock();
                }
                else if(!d.HasMember("market"))
                    throw exception();
                    
                if(checkSum() != d["data"]["checksum"].GetUint64()){
                    const string& err = "<wss_depth> " + id + " Packet loss, reconnecting...";
                    writte_err( "err.txt", err );
                    
                    s = "{\"op\": \"unsubscribe\", \"channel\": \"orderbook\", \"market\": \"" + symbol + "\"}";
                    ws.write_Socket(s);
                    s = "{\"op\": \"subscribe\", \"channel\": \"orderbook\", \"market\": \"" + symbol + "\"}";
                    ws.write_Socket(s);
                }
                
                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){      
        Wss ws;      
        Document d;
        const string& ep = to_string (get_current_ms_epoch());
        const string& msg = ep + "websocket_login";
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );
        string s = "{\"args\": {\"key\": \"" + api_key + "\",\"sign\": \"" + signature + "\",\"time\": " + ep + "},\"op\": \"login\"}";

        try {   
            ws.init_http("ftx.com");
            ws.init_webSocket("ftx.com", "443", "/ws");
            ws.write_Socket(s);
            s = "{\"op\": \"subscribe\", \"channel\": \"fills\"}";
            ws.write_Socket(s);
            s = "{\"op\": \"subscribe\", \"channel\": \"orders\"}";
            ws.write_Socket(s);
            
            ws.read_Socket();	
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("type") && d["type"] == "subscribed"))
                throw exception();    
            ws.buffer_clear();      
            
            ws.read_Socket();	
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("type") && d["type"] == "subscribed"))
                throw exception();    
            ws.buffer_clear();      
                  
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("channel") && (d["channel"] == "orders" || d["channel"] == "fills")){               
                    exchangeInfo[idNum].mtx->lock();                    
                    if(d["channel"] == "orders" && d["data"].HasMember("avgFillPrice")){
                        const double& quantity = d["data"]["filledSize"].GetDouble(); 
                        
                        if(quantity != 0){
                            if(limitOrder){
                                orderExecuted = true;                                                                       
                                const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", 0.3, 0.0, 0);
                                
                                if(res == 0)
                                    stopExecution = true;
                                else if(res == 1)
                                    remaining_qty += quantity;
                                else
                                    remaining_qty = 0;
                                
                                limitOrder = 0;
                            }                                              
                        
                            exchangeInfo[idNum].orderPrice = d["data"]["avgFillPrice"].GetDouble();
                            
                            if(d["data"]["side"] == "sell")
                                exchangeInfo[idNum].balance[base] -= d["data"]["size"].GetDouble() + d["data"]["size"].GetDouble() * fee.second;
                            else
                                exchangeInfo[idNum].balance[quote] -= d["data"]["size"].GetDouble() * (exchangeInfo[idNum].orderPrice + exchangeInfo[idNum].orderPrice * fee.second);
                        }
                    }
                    /*else if(d["channel"] == "fills" && exchangeInfo[idNum].orderPrice == -1)
                        exchangeInfo[idNum].orderPrice = d["data"]["price"].GetDouble();*/
                        
                    exchangeInfo[idNum].mtx->unlock();
                    
                }
                else
                    throw exception();
                
                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {	
        Document d;
        string type = "market";
        string price_string = "null";
        
        if(limit){
            type = "limit";
            price_string = to_string(price); 
        }
        
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://ftx.com/api/orders";
        
        const string& post_data = "{\"market\": \"" + symbol + "\", \"side\": \"" + side + "\", \"price\": " + price_string + ",\"size\": " + to_string(quantity) + ", \"type\": \"" + type + "\"}";  
        const string& msg = ep + "POST/api/orders" + post_data;
        
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("Accept: application/json");
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("FTX-KEY:" + api_key);
        extra_http_header.push_back("FTX-SIGN:" + signature);
        extra_http_header.push_back("FTX-TS:" + ep);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "POST" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());  

                if(d.IsObject() && d.HasMember("success")){
                    if(d["success"] == true){}
                    else if(d["success"] == false && d.HasMember("error") && d["error"] == "Size too small")
                        return 1;
                    else
                        throw exception();
                }
                else
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        
        return 2;
    }
    
    bool cancel_order() {	
        Document d;
        
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://ftx.com/api/orders";
        
        const string& post_data = "{\"market\":\"" + symbol + "\"}";  
        const string& msg = ep + "DELETE/api/orders" + post_data;
        
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("Accept: application/json");
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("FTX-KEY:" + api_key);
        extra_http_header.push_back("FTX-SIGN:" + signature);
        extra_http_header.push_back("FTX-TS:" + ep);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "DELETE" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());  
                
                if(!(d.IsObject() && d.HasMember("success") && d["success"] == true))
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading cancel_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": cancel_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        
        return 1;
    }
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

