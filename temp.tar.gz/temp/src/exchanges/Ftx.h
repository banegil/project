

class Ftx : public Exchange {
    const unsigned short id = 6;
    vector<string> v;

    public:
    void get_pairs(){        
        Document d;
        unordered_map<string, double> qA;
        qA["BRZ"] = qA["BRZ"] = qA["BTC"] = qA["DOGE"] = qA["EUR"] = qA["JPY"] = qA["TRYB"] = 0.0;
        qA["USD"] = qA["USDT"] = 1;
        qA["AUD"] = 0.65;
        
        try{
            string result;          
            curl_api_with_header("https://ftx.com/api/markets", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("result") && d["success"] == true){
                for(auto& i : d["result"].GetArray()){
                    if(i["enabled"] == true && i["futureType"].IsNull()){
                        string base = i["baseCurrency"].GetString();
                        string quote = i["quoteCurrency"].GetString();
                        
                        if(qA.find(base) != qA.end() && quote == "USD")
                            qA[base] = i["price"].GetDouble();
                        else if(qA.find(quote) != qA.end() && base == "USD")
                            qA[quote] = i["price"].GetDouble();
                    }               
                }
                
                for(auto& i : d["result"].GetArray()){
                    if(i["enabled"] == true && i["futureType"].IsNull()){
                        string base = i["baseCurrency"].GetString();
                        string quote = i["quoteCurrency"].GetString();
                        
                        v.push_back(base + "/" + quote);
                        
                        orderbook o = orderbook();    
                        o.volume = i["quoteVolume24h"].GetDouble() * qA[quote];                    
                        o.fee = {0.000194, 0.000679}; // with 675$ 0 maker, with 4000$ -0.0005 maker                       
                        coins[base][quote] = o;
                    }               
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + to_string(id) + string(e.what()) ); 
         	printJson(d);
         	return;
        }       
    }

    void websocketInit_depth(){        
        Document d;
        string s;
        set<string> oo;
        Wss ws;

        try {   
            ws.init_http("ftx.com");
            ws.init_webSocket("ftx.com", "443", "/ws");
            
            for(auto& i : v)  {   
                string ss = "{\"op\": \"subscribe\", \"channel\": \"ticker\", \"market\": \"" + i + "\"}";
                ws.write_Socket(ss); 
                ws.read_Socket();	       
                ws.buffer_clear();
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
                      
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("bid")){ 
                    s = d["market"].GetString();
                    auto&& f = s.find('/');
                    auto&& baseAsset = s.substr(0, f);
                    auto&& quoteAsset = s.substr(f + 1, s.length() - 1);
                    
                    // check quote asstes
                    /*if(oo.find(quoteAsset) == oo.end()){
                        oo.insert(quoteAsset);
                        for(auto&& i : oo)
                            cout << i << endl;
                            cout << endl;
                    }*/
                    
                    auto&& c = coins[baseAsset][quoteAsset];

                    c.mtx->lock();

                    if(d["data"]["ask"].IsNumber()){
                        c.asks.clear();
                        c.asks[ d["data"]["ask"].GetDouble() ] = 0;
                    }
                    
                    if(d["data"]["bid"].IsNumber()){
                        c.bids.clear();
                        c.bids[ d["data"]["bid"].GetDouble() ] = 0;;                        
                    }
                    
                    c.mtx->unlock();  
                }
                else if(!d.HasMember("market"))
                    throw exception();
                
                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + to_string(id) + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
};

