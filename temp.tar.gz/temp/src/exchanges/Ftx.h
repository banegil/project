

class Ftx : public Exchange {
    const string api_key = "AdIMZbPwsjtn1q2gZemf59_rLSyGBJyoPu-q7u_M";
    const char* secret_key = "oXLsT0qNrh7KHlSNGtUOayPpNa23222rMINvk15E";

    public:
    void getInfo(){        
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://ftx.com/api/markets", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("result") && d["success"] == true){                
                for(auto& i : d["result"].GetArray()){
                    if(i["enabled"] == true && i["futureType"].IsNull()){
                        const string& base = i["baseCurrency"].GetString();
                        const string& quote = i["quoteCurrency"].GetString();
                        const string& symbol = base + quote;
                        pairs[symbol].fees = {0.000194, 0.000679}; // with 675$ 0 maker, with 4000$ -0.0005 maker 
                    
                        if(symbol == cc || symbol == cc1 || symbol == cc2){                                
                      
                            if(symbol == cc){
                                POW_CC = 1 / i["priceIncrement"].GetDouble();
                                POW_CC_QTY = 1 / i["sizeIncrement"].GetDouble();
                            }
                            else if(symbol == cc1){
                                POW_CC1 = 1 / i["priceIncrement"].GetDouble();
                                POW_CC1_QTY = 1 / i["sizeIncrement"].GetDouble();
                            }
                            else if(symbol == cc2){
                                POW_CC2 = 1 / i["priceIncrement"].GetDouble();
                                POW_CC2_QTY = 1 / i["sizeIncrement"].GetDouble();
                            }
                            else{
                                cout << "Impossible case! getInfo() Ftx" << endl;
                            }   
                        }
                    }               
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <getInfo> " + string(e.what()) ); 
         	printJson(d);
         	return;
        }       
    }

    void websocketInit_depth(){        
        Document d;
        string s;
        Wss ws;

        try {   
            ws.init_http("ftx.com");
            ws.init_webSocket("ftx.com", "443", "/ws");
            
            s = "{\"op\": \"subscribe\", \"channel\": \"ticker\", \"market\": \"" + cc + "\"}";
            ws.write_Socket(s);
            s = "{\"op\": \"subscribe\", \"channel\": \"ticker\", \"market\": \"" + cc1 + "\"}";
            ws.write_Socket(s);
            s = "{\"op\": \"subscribe\", \"channel\": \"ticker\", \"market\": \"" + cc2 + "\"}";
            ws.write_Socket(s);
                      
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("bid")){                     
                    auto&& c = pairs[ d["market"].GetString() ];

                    c.mtx->lock();

                    if(d["data"]["ask"].IsNumber())
                        c.asks[0].first = d["data"]["ask"].GetDouble();
                    
                    if(d["data"]["bid"].IsNumber())
                        c.bids[0].first = d["data"]["bid"].GetDouble();                       
                    
                    c.mtx->unlock();  
                }
                else if(!d.HasMember("market"))
                    throw exception();
                
                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){      
        Wss ws;      
        Document d;
        const string& ep = to_string (get_current_ms_epoch());
        const string& msg = ep + "websocket_login";
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );
        string s = "{\"args\": {\"key\": \"" + api_key + "\",\"sign\": \"" + signature + "\",\"time\": " + ep + "},\"op\": \"login\"}";

        try {   
            ws.init_http("ftx.com");
            ws.init_webSocket("ftx.com", "443", "/ws");
            ws.write_Socket(s);
            //s = "{\"op\": \"subscribe\", \"channel\": \"fills\"}";
            //ws.write_Socket(s);
            s = "{\"op\": \"subscribe\", \"channel\": \"orders\"}";
            ws.write_Socket(s);
            
            for(int i = 0; i < 1; i++){
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());
                if(!(d.IsObject() && d.HasMember("type") && d["type"] == "subscribed"))
                    throw exception();    
                ws.buffer_clear();   
            }      
                  
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                printJson(d);
                
                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    int send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) {		
        Document d;
        int ret_code = 0;
        
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://ftx.com/api/orders";
        
        const string& post_data = "{\"market\": \"" + symbol + "\", \"side\": \"" + side + "\", \"price\": " + my_toString_extended(orderPrice) + ",\"size\": " + my_toString_extended(quantity) + ", \"type\": \"limit\"}";  
        const string& msg = ep + "POST/api/orders" + post_data;
        
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("Accept: application/json");
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("FTX-KEY:" + api_key);
        extra_http_header.push_back("FTX-SIGN:" + signature);
        extra_http_header.push_back("FTX-TS:" + ep);
        
        string str_result;
        curl_api_with_headerPD( url, str_result , extra_http_header, post_data, "POST" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());  
                
                printJson(d);
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        
        return 2;
    }
    
    int send_CancelOrder(const string& symbol){
        Document d;
        
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://ftx.com/api/orders";
        
        const string& post_data = "{\"market\":\"" + symbol + "\"}";  
        const string& msg = ep + "DELETE/api/orders" + post_data;
        
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );

        vector <string> extra_http_header;
        extra_http_header.push_back("Accept: application/json");
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("FTX-KEY:" + api_key);
        extra_http_header.push_back("FTX-SIGN:" + signature);
        extra_http_header.push_back("FTX-TS:" + ep);
        
        string str_result;
        curl_api_with_headerPD( url, str_result , extra_http_header, post_data, "DELETE" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());  
                
                printJson(d);
            		
            	} catch ( exception &e ) {
             	    const string& err = "error reading cancel_order response " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = "cancel_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        
        return 1;
    }
};

