

class Mexc : public Exchange {
    const string id = "Mexc";
    const unsigned short idNum = 10;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETHUSDT";
    string base = "ETH";
    string quote = "USDT";
    atomic<double> bestAsk, bestBid;
    double quotePrecision;
    bool limitOrder = 0;
    double remaining_qty = 0;
    
    const string api_key = "mx0te2DKmL7n7HHSev";
    const char* secret_key = "e5ddca821593497490580969f19e605c";


    bool get_balance() {	
        Document d;
                
        const string& ep = to_string (get_current_ms_epoch());
        string url = "https://api.mexc.com/api/v3/account?"; 
        
        string post_data  = "recvWindow=5000&timestamp=" + ep;
        
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );
        post_data += "&signature=" + signature;
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("X-MEXC-APIKEY:" + api_key);
        url += post_data;
        
        string str_result;
        curl_api_with_header( url.c_str(), str_result , extra_http_header, "", "GET" ) ;
        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(d.IsObject() && d.HasMember("balances")){
                    for(auto&& i : d["balances"].GetArray())
                        if(i["asset"].GetString() == base || i["asset"].GetString() == quote)
                            exchangeInfo[idNum].balance[ i["asset"].GetString() ] = stod( i["free"].GetString() );
                }
                else
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading get_balance response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": get_balance.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;
    }

    void pingInterval(Wss& ws){
        time_t current_time;
        time(&current_time);
        int ct = current_time;  
                                    
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct >= 10){
                ct = ct2;
                ws.write_Socket(R"({"method":"ping"})");
            }
        }
    }

    public:
    bool get_pairs(){               
        Document d;
        fee = {0.0, 0.0016};
        symbol = chosenSymbol;
        base = symbol.substr(0, symbol.find('-'));
        quote = symbol.substr(symbol.find('-') + 1, symbol.length() - 1); 
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        
        try{
            string result;          
            curl_api("https://api.mexc.com/api/v3/exchangeInfo", result);
            d.Parse(result.c_str());
            
            if(d.HasMember("symbols")){
                for(auto& i : d["symbols"].GetArray()){
                    if(i["status"] == "ENABLED" && i["isSpotTradingAllowed"] == true){                
                        string base = i["baseAsset"].GetString();
                        string quote = i["quoteAsset"].GetString();

                        if( base + "-" + quote == chosenSymbol ){
                            if(get_balance()){
                                exchangeInfo[idNum].multiplier = stod( i["baseSizePrecision"].GetString() );
                                quotePrecision = 1.0 / pow(10.0, i["quotePrecision"].GetDouble()) ;
                                return 1;
                            }
                        }
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }      
        return 0;
    }  

    void websocketInit_depth(){ 
        Wss ws;       
        Document d;
        string s = chosenSymbol;
        s[s.find('-')] = '_';
        s = "{\"op\":\"sub.depth\",\"symbol\":\"" + s + "\"}";

        try {   
            long long seqNum = 0;
            ws.init_http("wbs.mexc.com");
            ws.init_webSocket("wbs.mexc.com", "443", "/raw/ws"); 
            ws.write_Socket(R"({"method":"ping"})");
            ws.write_Socket(s); 
              
            time_t current_time;
            time(&current_time);
            int ct = current_time;          
            while (true) {
                time(&current_time);
                int ct2 = current_time;
            
                if(ct2 - ct >= 10){
                    ct = ct2;
                    ws.write_Socket(R"({"method":"ping"})");
                }
            
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("version")){
                    if(seqNum == 0 || seqNum + 1 == stoll( d["data"]["version"].GetString() )){
                        seqNum = stoll( d["data"]["version"].GetString() );
                
                        if(d["data"].HasMember("asks")){
                            mtxAsk.lock();
                            for(auto&& i : d["data"]["asks"].GetArray()){
                                double price = stod( i["p"].GetString() );
                                double qty = stod( i["q"].GetString() );
                                
                                if(qty == 0)
                                    asks.erase(price);
                                else
                                    asks[price] = qty;
                            }
                            
                            if(asks.size() > 30)
                                asks.erase(prev(asks.end()));
                            
                            mtxAsk.unlock();
                            bestAsk = asks.begin()->first;
                        }
                        
                        if(d["data"].HasMember("bids")){
                            mtxBid.lock();
                            for(auto&& i : d["data"]["bids"].GetArray()){
                                double price = stod( i["p"].GetString() );
                                double qty = stod( i["q"].GetString() );
                                
                                if(qty == 0)
                                    bids.erase(price);
                                else
                                    bids[price] = qty;
                            }
                            
                            if(bids.size() > 30)
                                bids.erase(prev(bids.end()));
                            
                            mtxBid.unlock();
                            bestBid = bids.begin()->first;
                        }
                    }
                    else{
                        const string& err = "<wss_depth> " + id + " Packet loss, reconnecting...";
                        writte_err( "err.txt", err ); 
                        seqNum = 0;
                        ws.write_Socket(s);
                    }
                        
                }
                else if(d["channel"] != "pong")
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){ 
        Wss ws;       
        Document d;

        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://api.mexc.com/api/v3/userDataStream"; 
        
        string post_data  = "timestamp=" + ep;
        
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );
        post_data += "&signature=" + signature;
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("X-MEXC-APIKEY:" + api_key);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "POST" ) ;        
        d.Parse(str_result.c_str());
        
        if(!(d.IsObject() && d.HasMember("listenKey")))
            throw exception();
            
        string s = "/ws?listenKey=" + string(d["listenKey"].GetString());

        try {   
            ws.init_http("wbs.mexc.me");
            ws.init_webSocket("wbs.mexc.me", "443", s.c_str()); 
            
            s = "{\"method\": \"SUBSCRIPTION\",\"params\": [\"spot@private.deals.v3.api\"]}";
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("code") && d["code"] == 0 && d.HasMember("msg") && d["msg"] == "spot@private.deals.v3.api"))
                throw exception();
            ws.buffer_clear();           

            auto&& f = async(&Mexc::pingInterval, this, ref(ws));
            s.clear(); s.shrink_to_fit(); 
                        
            while (true) {            
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());
               
                if(d.IsObject() && d.HasMember("c")){                
                    if(d["c"] == "spot@private.deals.v3.api"){
                        if(limitOrder){
                            orderExecuted = true;                                    
                            const double& quantity = stod( d["d"]["v"].GetString() );                                    
                            const unsigned short& res = ex[ Index[bestExchange] ]->send_order("sell", quantity, 0.0, 0);
                            
                            if(res == 0)
                                stopExecution = true;
                            else if(res == 1)
                                remaining_qty += quantity;
                            else
                                remaining_qty = 0;
                            
                            limitOrder = 0;
                        } 
                        
                        exchangeInfo[idNum].mtx->lock();
                    
                        exchangeInfo[idNum].orderPrice = stod( d["d"]["p"].GetString() );

                        if(d["d"]["S"] == 2)
                            exchangeInfo[idNum].balance[base] -= stod( d["d"]["v"].GetString() ) + stod( d["d"]["v"].GetString() ) * fee.second;
                        else
                            exchangeInfo[idNum].balance[quote] -= stod( d["d"]["v"].GetString() ) * (exchangeInfo[idNum].orderPrice + exchangeInfo[idNum].orderPrice * fee.second);
                            
                        exchangeInfo[idNum].mtx->unlock();
                    }
                    else
                        throw exception();
                        
                }                       
                else if(!(d.HasMember("msg") && d["msg"] == "PONG"))
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) {		
        Document d;
        double orderPrice;
        
        if(limit)
            orderPrice = price;
        else{
            orderPrice = side == "buy" ? bestAsk * 1.1 : bestBid * 0.9;  
            my_round(orderPrice, quotePrecision);      
        } 
                
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://api.mexc.com/api/v3/order"; 
        
        string_toupper(side);
        string post_data = "price=" + to_string(orderPrice) + "&symbol=" + symbol + "&side=" + side + "&type=LIMIT&quantity=" + to_string(quantity) + "&recvWindow=5000&timestamp=" + ep;
        
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );
        post_data += "&signature=" + signature;
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("X-MEXC-APIKEY:" + api_key);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "POST" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(!(d.IsObject() && d.HasMember("price") && !d["price"].IsNull() && stod( d["price"].GetString() ) != 0)){}
                else if(d.IsObject() && d.HasMember("code") && d["code"] == 30002)
                    return 1;
                else
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 2;
    }
    
    bool cancel_order() {		
        Document d;
                
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://api.mexc.com/api/v3/openOrders"; 
        
        string post_data = "symbol=" + symbol + "&recvWindow=5000&timestamp=" + ep;
        
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );
        post_data += "&signature=" + signature;
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("X-MEXC-APIKEY:" + api_key);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, "DELETE" ) ;

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(!d.IsArray())
                    throw exception();
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading cancel_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": cancel_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;
    }
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    } 
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

