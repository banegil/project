

class Mexc : public Exchange {
    vector<string> v;
    unordered_map<string, orderInfo> order; // <order_id, orderInfo>
    mutex mtx_orderInfo;

    void pingInterval(Wss& ws){
        time_t current_time;
        time(&current_time);
        int ct = current_time;  
                                    
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct >= 10){
                ct = ct2;
                ws.write_Socket(R"({"method":"ping"})");
            }
        }
    }

    void get_24Volume(){        
        Document d, d2, d3;
        unordered_map<string, string> m;
        m["DT"] = "USDT"; m["TC"] = "BTC"; m["DC"] = "USDC"; m["TH"] = "ETH"; m["DP"] = "USDP";
        double priceBTC, priceETH;
        
        try{
            string result, r2, r3;  
            curl_api_with_header("https://api.mexc.com/api/v3/avgPrice?symbol=BTCUSDT", result);
            d.Parse(result.c_str()); 

            if(d.IsObject() && d.HasMember("price"))
                priceBTC = stod( d["price"].GetString() );
            else
                throw exception();
                
            curl_api_with_header("https://api.mexc.com/api/v3/avgPrice?symbol=ETHUSDT", r3);
            d3.Parse(r3.c_str()); 

            if(d3.IsObject() && d3.HasMember("price"))
                priceETH = stod( d3["price"].GetString() );
            else
                throw exception();
                  
            curl_api_with_header("https://api.mexc.com/api/v3/ticker/24hr", r2);
            d2.Parse(r2.c_str()); 

            if(d2.IsArray()){
                for(auto& i : d2.GetArray()){
                    string s = i["symbol"].GetString();
                   
                    if(m.find(s.substr(s.length() - 2)) != m.end()){
                        string quote = m[s.substr(s.length() - 2)]; 
                        string base = s.substr(0, s.length() - quote.length());
                        double v = stod( i["quoteVolume"].GetString() );
                        
                        if(quote == "BTC") 
                            v *= priceBTC;
                        else if(quote == "ETH")
                            v *= priceETH;
                            
                        coins[base][quote].volume = v;    
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_24Volume> " + string(e.what()) ); 
         	printJson(d);
         	printJson(d2);
            printJson(d3);
         	return;
        }       
    } 

    public:
    void get_pairs(){        
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api.mexc.com/api/v3/exchangeInfo", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("symbols")){
                for(auto& i : d["symbols"].GetArray()){
                    if(i["status"] == "ENABLED" && i["isSpotTradingAllowed"] == true){                
                        string base = i["baseAsset"].GetString();
                        string quote = i["quoteAsset"].GetString();

                        v.push_back(base + "_" + quote);

                        orderbook o = orderbook();                        
                        o.fee = {0.0, 0.0016};                        
                        coins[base][quote] = o;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
        
        get_24Volume();   
    }   

    void websocketInit_depth(){        
        Document d;
        string s, quoteAsset, baseAsset;
        unordered_map<string, string> qA;
        qA["DT"] = "USDT"; qA["TC"] = "BTC"; qA["DC"] = "USDC"; qA["TH"] = "ETH"; qA["DP"] = "USDP";
        Wss ws;

        try {   
            ws.init_http("wbs.mexc.com");
            ws.init_webSocket("wbs.mexc.com", "443", "/raw/ws"); 
            ws.write_Socket("ping");
            
            for(auto& i : v)  {   
                string ss = "{\"op\":\"sub.limit.depth\",\"symbol\":\"" + i + "\", \"depth\": 5}";
                ws.write_Socket(ss); 
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            } 
              
            time_t current_time;
            time(&current_time);
            int ct = current_time;          
            while (true) {
                time(&current_time);
                int ct2 = current_time;
            
                if(ct2 - ct >= 10){
                    ct = ct2;
                    ws.write_Socket("ping");
                }
            
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("channel")){
                    if(d["channel"] == "push.limit.depth"){
                        s = d["symbol"].GetString();
                        quoteAsset = qA[s.substr(s.length() - 2)];
                        baseAsset = s.substr(0, s.length() - quoteAsset.length() - 1);   
                        auto&& c = coins[baseAsset][quoteAsset];

                        c.mtx->lock();

                        if(d["data"]["asks"].Size() > 0){
                            c.asks.clear();
                            c.asks[ stod( d["data"]["asks"][0][0].GetString() ) ] = 0;
                        }
                        
                        if(d["data"]["bids"].Size() > 0){
                            c.bids.clear();
                            c.bids[ stod( d["data"]["bids"][0][0].GetString() ) ] = 0;
                        }
                        
                        c.mtx->unlock();
                    }
                }

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
        void websocketInit_User(){ 
        Wss ws;       
        Document d;

        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://api.mexc.com/api/v3/userDataStream"; 
        
        string post_data  = "timestamp=" + ep;
        
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );
        post_data += "&signature=" + signature;
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("X-MEXC-APIKEY:" + api_key);
        
        string str_result;
        curl_api_with_headerPD( url, str_result , extra_http_header, post_data, "POST" ) ;        
        d.Parse(str_result.c_str());
        
        if(!(d.IsObject() && d.HasMember("listenKey")))
            throw exception();
            
        string s = "/ws?listenKey=" + string(d["listenKey"].GetString());

        try {   
            ws.init_http("wbs.mexc.me");
            ws.init_webSocket("wbs.mexc.me", "443", s.c_str()); 
            
            s = "{\"method\": \"SUBSCRIPTION\",\"params\": [\"spot@private.deals.v3.api\"]}";
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("code") && d["code"] == 0 && d.HasMember("msg") && d["msg"] == "spot@private.deals.v3.api"))
                throw exception();
            ws.buffer_clear();           

            auto&& f = async(&Mexc::pingInterval, this, ref(ws));
            s.clear(); s.shrink_to_fit(); 
            
            string ccSymbol = cc;
            ccSymbol.erase(remove(ccSymbol.begin(), ccSymbol.end(), '_'), ccSymbol.end());
            string cc1Symbol = cc1;
            cc1Symbol.erase(remove(cc1Symbol.begin(), cc1Symbol.end(), '_'), cc1Symbol.end());
            
            double last_rejected_qty = 0, last_rejected_qty2 = 0;            
            while (true) {            
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("c") && d["c"] == "spot@private.deals.v3.api"){                
                    const string& order_id =  d["d"]["i"].GetString();
                    
                    mtx_orderInfo.lock();
                    
                    auto&& o_info = order[ order_id ]; 
                    
                    if(!o_info.second_order_executed){
                        o_info.second_order_executed = 1;
                        side = o_info.side2;
                        pair = o_info.pair2;
                        quantity = stod( d["d"]["v"].GetString() );
                    }
                    else{
                        side = o_info.side3;
                        pair = o_info.pair3;
                        
                        if(side == "buy"){
                            const string& base = pair.substr(0, pair.find('-'));
                            const string& quote = pair.substr(pair.find('-') + 1, pair.length() -1);
                            quantity = (stod( d["d"]["v"].GetString() ) * stod( d["d"]["p"].GetString() )) / (coins[base][quote].get_ask().first);   
                        }
                        else
                            quantity = stod( d["d"]["v"].GetString() ) * stod( d["d"]["p"].GetString() );
                            
                        order.erase(order_id);
                    }
                    
                    mtx_orderInfo.unlock();
                    
                    send_order(pair, side, quantity, order_id);  
                   
                   
                    if(d["s"].GetString() == ccSymbol){                        
                        const double& rem_qty = stod( d["d"]["v"].GetString() );
                        const double& price = ORDER3 ? pairs[cc1].get_ask() * 1.1 : pairs[cc1].get_bid() * 0.9;
                        quantity_global = quantity_global - rem_qty;
                        
                        const double& check = send_order(cc1, type_order2, rem_qty + last_rejected_qty, round( price * POW_CC1 ) / POW_CC1);

                        if(check > 0)                                  
                            last_rejected_qty += rem_qty;      
                        else{ 
                            if(quantity_global == 0) 
                                ok = 1;
                            last_rejected_qty = 0;
                        }
                                                  
                    }
                    else if(d["s"].GetString() == cc1Symbol){
                        const double& rem_qty = round( ( stod( d["d"]["v"].GetString() ) * stod( d["d"]["p"].GetString() ) ) * POW_CC2_QTY ) / POW_CC2_QTY;                        
                        const double& price = ORDER3 ? pairs[cc2].get_ask() * 1.1 : pairs[cc2].get_bid() * 0.9;
                        
                        const int& check = send_order(cc2, type_order3, rem_qty + last_rejected_qty2, round( price * POW_CC2 ) / POW_CC2);

                        if(check > 0)
                            last_rejected_qty2 += rem_qty;
                        else
                            last_rejected_qty2 = 0;                              
                    }                                                   
                }                       
                else if(!(d.HasMember("msg") && d["msg"] == "PONG"))
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    int send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) {			
        Document d;
        int ret_code = 0;
                
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://api.mexc.com/api/v3/order"; 
        
        string symbol2 = symbol;
        symbol2.erase(remove(symbol2.begin(), symbol2.end(), '_'), symbol2.end());
        string_toupper(side);
        
        //cout << "p:" << my_toString_extended(orderPrice) << endl;
        //cout << "q:" << my_toString_extended(quantity) << endl;
        
        string post_data = "price=" + my_toString_extended(orderPrice) + "&symbol=" + symbol2 + "&side=" + side + "&type=LIMIT&quantity=" + my_toString_extended(quantity) + "&recvWindow=5000&timestamp=" + ep;       
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );
        post_data += "&signature=" + signature;
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("X-MEXC-APIKEY:" + api_key);
        
        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                printJson(d);
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return ret_code;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return ret_code;
        }
        return ret_code;
    }
    
    void send_triangular_order(string side1, string side2, string side3, string pair1, string pair2, string pair3, double quantity){
        const string& order_id = generate_order_id(pair1 + pair2);        
        mtx_orderInfo.lock();
        order[ order_id ] = { 0, side2, pair2, side3, pair3 }; 
        mtx_orderInfo.unlock();
        send_order(side1, pair1, quantity, order_id);
    }
};

