

class Mexc : public Exchange {
    const unsigned short id = 10;
    string order_id;
    
    const string api_key = "mx0te2DKmL7n7HHSev";
    const char* secret_key = "e5ddca821593497490580969f19e605c";

    void pingInterval(Wss& ws){
        time_t current_time;
        time(&current_time);
        int ct = current_time;  
                                    
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            
            if(ct2 - ct >= 10){
                ct = ct2;
                ws.write_Socket(R"({"method":"ping"})");
            }
        }
    }

    void getInfo(){
        Document d, d2, d3;
        string symbol2 = cc;
        string symbol3 = cc;
        symbol2 = symbol2.substr(0, symbol2.find('_'));;
        symbol3.erase(remove(symbol3.begin(), symbol3.end(), '_'), symbol3.end());

        try{
            string result;  
            curl_api_with_header("https://api.mexc.com/api/v3/avgPrice?symbol=" + symbol2 + "USDT", result);
            d.Parse(result.c_str()); 

            if(d.IsObject() && d.HasMember("price"))
                QUANTITY = 15 / stod( d["price"].GetString() );
            else
                throw exception();
                
            curl_api_with_header("https://api.mexc.com/api/v3/avgPrice?symbol=" +  symbol3, result);
            d.Parse(result.c_str()); 

            if(d.IsObject() && d.HasMember("price"))
                PRICE = 10 * stod( d["price"].GetString() );
            else
                throw exception();
             
            result.clear();
                  
            curl_api_with_header("https://api.mexc.com/api/v3/exchangeInfo", result);
            d2.Parse(result.c_str()); 
            
            if(d2.HasMember("symbols")){
                for(auto& i : d2["symbols"].GetArray()){
                    const string& base = i["baseAsset"].GetString();
                    const string& quote = i["quoteAsset"].GetString();
                    
                    const string& symbol = base + "_" + quote;
                    
                    if((symbol == cc || symbol == cc1 || symbol == cc2) && i["status"] == "ENABLED" && i["isSpotTradingAllowed"] == true){                
                        if(symbol == cc)
                            POW_CC = pow( 10.0, i["quoteAssetPrecision"].GetInt64() );
                        else if(symbol == cc1)
                            POW_CC1 = pow( 10.0, i["quoteAssetPrecision"].GetInt64() );
                        else if(symbol == cc2){
                            POW_CC2 = pow( 10.0, i["quoteAssetPrecision"].GetInt64() );
                            POW_CC2_QTY = pow( 10.0, i["baseAssetPrecision"].GetInt64() );
                        }
                        else{
                            cout << "Impossible case! getInfo() Mexc" << endl;
                        }
                    } 
                }
            }
            else
                throw exception();
            
            check_varIni();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <getInfo> " + id + string(e.what()) ); 
         	printJson(d);
         	printJson(d2);
         	return;
        } 
    }

    public:   
    void websocketInit_depth(){  
        getInfo();
     
        Wss ws;     
        Document d;
        string s, quoteAsset, baseAsset;
        unordered_map<string, string> qA;
        qA["DT"] = "USDT"; qA["TC"] = "BTC"; qA["DC"] = "USDC"; qA["TH"] = "ETH"; qA["DP"] = "USDP";

        try {   
            ws.init_http("wbs.mexc.com");
            ws.init_webSocket("wbs.mexc.com", "443", "/raw/ws"); 
            ws.write_Socket(R"({"method":"ping"})");
              
            string ss = "{\"op\":\"sub.limit.depth\",\"symbol\":\"" + cc + "\", \"depth\": 5}";
            ws.write_Socket(ss); 
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            
            ss = "{\"op\":\"sub.limit.depth\",\"symbol\":\"" + cc1 + "\", \"depth\": 5}";
            ws.write_Socket(ss); 
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            
            ss = "{\"op\":\"sub.limit.depth\",\"symbol\":\"" + cc2 + "\", \"depth\": 5}";
            ws.write_Socket(ss); 
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
              
            time_t current_time;
            time(&current_time);
            int ct = current_time;          
            while (true) {
                time(&current_time);
                int ct2 = current_time;
            
                if(ct2 - ct >= 10){
                    ct = ct2;
                    ws.write_Socket(R"({"method":"ping"})");
                }
            
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("channel")){
                    if(d["channel"] == "push.limit.depth"){   
                        auto&& o = pairs[ d["symbol"].GetString() ];

                        o.mtx->lock();

                        if(d["data"]["asks"].Size() > 0)
                            o.asks[0].first = stod( d["data"]["asks"][0][0].GetString() );
                        
                        if(d["data"]["bids"].Size() > 0)
                            o.bids[0].first = stod( d["data"]["bids"][0][0].GetString() );
                        
                        o.mtx->unlock();
                    }
                    else if(d["channel"] != "pong")
                        throw exception();
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){ 
        Wss ws;       
        Document d;

        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://api.mexc.com/api/v3/userDataStream"; 
        
        string post_data  = "timestamp=" + ep;
        
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );
        post_data += "&signature=" + signature;
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("X-MEXC-APIKEY:" + api_key);
        
        string str_result;
        curl_api_with_headerPD( url, str_result , extra_http_header, post_data, "POST" ) ;        
        d.Parse(str_result.c_str());
        
        if(!(d.IsObject() && d.HasMember("listenKey")))
            throw exception();
            
        string s = "/ws?listenKey=" + string(d["listenKey"].GetString());

        try {   
            ws.init_http("wbs.mexc.me");
            ws.init_webSocket("wbs.mexc.me", "443", s.c_str()); 
            
            s = "{\"method\": \"SUBSCRIPTION\",\"params\": [\"spot@private.deals.v3.api\"]}";
            ws.write_Socket(s);
            ws.read_Socket();
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("code") && d["code"] == 0 && d.HasMember("msg") && d["msg"] == "spot@private.deals.v3.api"))
                throw exception();
            ws.buffer_clear();           

            auto&& f = async(&Mexc::pingInterval, this, ref(ws));
            s.clear(); s.shrink_to_fit(); 
            
            string ccSymbol = cc;
            ccSymbol.erase(remove(ccSymbol.begin(), ccSymbol.end(), '_'), ccSymbol.end());
            string cc1Symbol = cc1;
            cc1Symbol.erase(remove(cc1Symbol.begin(), cc1Symbol.end(), '_'), cc1Symbol.end());
            
            double last_rejected_qty = 0, last_rejected_qty2 = 0;            
            while (true) {            
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("c") && d["c"] == "spot@private.deals.v3.api"){                
                   
                    if(d["s"].GetString() == ccSymbol){                        
                        const double& rem_qty = stod( d["d"]["v"].GetString() );
                        const double& price = ORDER3 ? pairs[cc1].get_ask() * 1.1 : pairs[cc1].get_bid() * 0.9;
                        quantity_global = quantity_global - rem_qty;
                        
                        const double& check = send_order(cc1, type_order2, rem_qty + last_rejected_qty, round( price * POW_CC1 ) / POW_CC1);

                        if(check > 0)                                  
                            last_rejected_qty += rem_qty;      
                        else{ 
                            if(quantity_global == 0) 
                                ok = 1;
                            last_rejected_qty = 0;
                        }
                                                  
                    }
                    else if(d["s"].GetString() == cc1Symbol){
                        const double& rem_qty = round( ( stod( d["d"]["v"].GetString() ) * stod( d["d"]["p"].GetString() ) ) * POW_CC2_QTY ) / POW_CC2_QTY;                        
                        const double& price = ORDER3 ? pairs[cc2].get_ask() * 1.1 : pairs[cc2].get_bid() * 0.9;
                        
                        const int& check = send_order(cc2, type_order3, rem_qty + last_rejected_qty2, round( price * POW_CC2 ) / POW_CC2);

                        if(check > 0)
                            last_rejected_qty2 += rem_qty;
                        else
                            last_rejected_qty2 = 0;                              
                    }
                                                   
                }                       
                else if(!(d.HasMember("msg") && d["msg"] == "PONG"))
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    int send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) {			
        Document d;
        int ret_code = 0;
                
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://api.mexc.com/api/v3/order"; 
        
        string symbol2 = symbol;
        symbol2.erase(remove(symbol2.begin(), symbol2.end(), '_'), symbol2.end());

        string_toupper(side);
        //cout << "p:" << my_toString_extended(orderPrice) << endl;
        //cout << "q:" << my_toString_extended(quantity) << endl;
        string post_data = "price=" + my_toString_extended(orderPrice) + "&symbol=" + symbol2 + "&side=" + side + "&type=LIMIT&quantity=" + my_toString_extended(quantity) + "&recvWindow=5000&timestamp=" + ep;
        
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );
        post_data += "&signature=" + signature;
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("X-MEXC-APIKEY:" + api_key);
        
        string str_result;
        curl_api_with_headerPD(url, str_result, extra_http_header , post_data , "POST");

        if (str_result.size() > 0) {
            try {
                d.Parse(str_result.c_str());

                if(d.IsObject() && d.HasMember("orderId"))
                    order_id = d["orderId"].GetString();
                else{
                    printJson(d);
                    ret_code = d["code"].GetInt64();
                    
                    if(ret_code == 30002 && symbol == cc){
                        priceOrder = PRICE;
                        ok = 1;
                    }    
                    
                    cout << symbol << " send_order\n";
                }
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return ret_code;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return ret_code;
        }
        return ret_code;
    }
    
    int send_CancelOrder(const string& symbol){	
        Document d;
                
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://api.mexc.com/api/v3/openOrders"; 
        
        string symbol2 = symbol;
        symbol2.erase(remove(symbol2.begin(), symbol2.end(), '_'), symbol2.end());
        
        string post_data = "symbol=" + symbol2 + "&orderId=" + order_id + "&recvWindow=5000&timestamp=" + ep;
        
        const string& signature =  hmac_sha256( secret_key, post_data.c_str() );
        post_data += "&signature=" + signature;
        
        vector <string> extra_http_header;
        extra_http_header.push_back("Content-Type: application/json");
        extra_http_header.push_back("X-MEXC-APIKEY:" + api_key);
        
        string str_result;
        curl_api_with_headerPD( url, str_result , extra_http_header, post_data, "DELETE" ) ;

        if (str_result.size() > 0) {
            try {


            	} catch ( exception &e ) {
             	    const string& err = ": error reading cancel_order response " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": cancel_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 0;
    }
    
    pair<double, double> get_fees() {
        return {0.0, 0.0016};
    }
};

