

class Cryptocom : public Exchange {
    const string api_key = "g9WyBA3iGzymsiWWS72nGj";
    const char* secret_key = "QuRRBL1hSdZLngSZyFNGeE";
    string order_id;

    public:
    void getInfo(){        
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api.crypto.com/v2/public/get-instruments", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("result") && d["code"] == 0){ 
                for(auto& i : d["result"]["instruments"].GetArray()){     
                    const string& symbol = i["instrument_name"].GetString();                    
                    pairs[symbol].fees = {0.000713, 0.000713};   
                                         
                    if(symbol == cc || symbol == cc1 || symbol == cc2){                                
                        if(symbol == cc){
                            POW_CC = 1 / stod( i["min_price"].GetString() );
                            POW_CC_QTY = 1 / stod( i["min_quantity"].GetString() );
                        }
                        else if(symbol == cc1){
                            POW_CC1 = 1 / stod( i["min_price"].GetString() );
                            POW_CC1_QTY = 1 / stod( i["min_quantity"].GetString() );
                        }
                        else if(symbol == cc2){
                            POW_CC2 = 1 / stod( i["min_price"].GetString() );
                            POW_CC2_QTY = 1 / stod( i["min_quantity"].GetString() );
                        }
                        else{
                            cout << "Impossible case! getInfo() Cryptocom" << endl;
                        }   
                   }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + string(e.what()) ); 
         	printJson(d);
         	return;
        }      
        
    }

    void websocketInit_depth(){        
        Document d;
        Wss ws;
        string s;
        
        try {   
            ws.init_http("stream.crypto.com");
            ws.init_webSocket("stream.crypto.com", "443", "/v2/market");
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            
            time_t current_time; 
            time(&current_time);
            int ct = current_time;
            s = "{\"id\": 11,\"method\": \"subscribe\",\"params\": {\"channels\": [\"ticker." + cc + "\",\"ticker." + cc1 + "\",\"ticker." + cc2 + "\"]},\"nonce\": " + to_string(ct) + "}";
            ws.write_Socket(s);
                     
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str()); 

                if(d.IsObject() && d.HasMember("method")){
                    if(d.HasMember("result")){ 
                        auto&& o = pairs[ d["result"]["instrument_name"].GetString() ];

                        o.mtx->lock();
                        
                        if(d["result"]["data"][0]["k"].IsNumber())
                            o.asks[0].first = d["result"]["data"][0]["k"].GetDouble();
                        
                        if(d["result"]["data"][0]["b"].IsNumber())
                            o.bids[0].first = d["result"]["data"][0]["b"].GetDouble();
                        
                        o.mtx->unlock();
                    }
                    else if(d["method"] == "public/heartbeat"){
                        s = "{\"id\":" + to_string(d["id"].GetUint64()) + ",\"method\":\"public/respond-heartbeat\"}";
                        ws.write_Socket(s); 
                    }
                    else if(d["method"] != "subscribe")
                        throw exception();
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    void websocketInit_User(){        
        Document d;
        Wss ws;
        string s;
        
        try {   
            ws.init_http("stream.crypto.com");
            ws.init_webSocket("stream.crypto.com", "443", "/v2/user");
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            
            string ep = to_string (get_current_ms_epoch()); 
            const string& msg = "public/auth11" + api_key + ep;
            const string& signature = hmac_sha256( secret_key, msg.c_str() );
            s = "{\"id\":11,\"method\":\"public/auth\",\"api_key\":\"" + api_key + "\",\"sig\":\"" + signature + "\",\"nonce\":" + ep + "}";
            ws.write_Socket(s);

            ws.read_Socket();	
            d.Parse(ws.get_socket_data().c_str());
            if(!(d.IsObject() && d.HasMember("code") && d["code"] == 0))
                throw exception();
            ws.buffer_clear();
            
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            ep = to_string (get_current_ms_epoch()); 
            s = "{\"id\": 11,\"method\": \"subscribe\",\"params\": {\"channels\": [\"user.trade." + cc + "\",\"user.trade." + cc1 + "\",\"user.trade." + cc2 + "\"]},\"nonce\": " + ep + "}";
            ws.write_Socket(s);
                     
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str()); printJson(d);

                if(d.IsObject() && d.HasMember("method")){
                    if(d["method"] == "public/heartbeat"){
                        const long& n = d["id"].GetUint64();
                        s = "{\"id\":" + to_string(n) + ",\"method\":\"public/respond-heartbeat\"}";
                        ws.write_Socket(s); 
                    }
                }
                else 
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_User> " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    int send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) {
        Document d;
        
        const string& ep = to_string (get_current_ms_epoch()); 
        const char* url = "https://api.crypto.com/v2/private/create-order";
        const string& order_price = my_toString_extended(orderPrice);
        const string& qty = my_toString_extended(quantity);
        string_toupper(side);
        
        string post_data = "{\"id\": 11,\"method\": \"private/create-order\",\"api_key\": \"" + api_key + "\",\"params\": {\"instrument_name\": \"" +
                             symbol + "\",\"side\": \"" + side + "\",\"type\": \"LIMIT\",\"price\": " + order_price + ",\"quantity\": "+ 
                             qty + "},\"nonce\": " + ep + "}";         
        const string& msg = "private/create-order11" + api_key + "instrument_name" + symbol + "price" + order_price + "quantity" + qty + "side" + side + "typeLIMIT" + ep;   
        
        const string& signature = hmac_sha256( secret_key, msg.c_str() );
        post_data.pop_back();
        post_data += ",\"sig\":\"" + signature + "\"}";                        
         
        vector <string> extra_http_header;
        extra_http_header.push_back("content-type: application/json");

        string result;
        curl_api_with_headerPD(url, result, extra_http_header , post_data , "POST");

        if ( result.size() > 0 ) {
            try {
                d.Parse(result.c_str()); 
                
                if(d.IsObject() && d.HasMember("code") && d["code"] == 0){
                    order_id = d["result"]["order_id"].GetString();
                }
                else
                    printJson(d);
                
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading send_order response " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 0;
   }
   
    int send_CancelOrder(const string& symbol){
        Document d;
        
        const string& ep = to_string (get_current_ms_epoch()); 
        const char* url = "https://api.crypto.com/v2/private/cancel-order";
        
        string post_data = "{\"id\": 11,\"method\": \"private/cancel-order\",\"api_key\": \"" + api_key + "\",\"params\": {\"instrument_name\": \"" + symbol + "\",\"order_id\": \"" + order_id + "\"},\"nonce\": " + ep + "}";         
        const string& msg = "private/cancel-order11" + api_key + "instrument_name" + symbol + "order_id" + order_id + ep;   
        
        const string& signature = hmac_sha256( secret_key, msg.c_str() );
        post_data.pop_back();
        post_data += ",\"sig\":\"" + signature + "\"}";                        
         
        vector <string> extra_http_header;
        extra_http_header.push_back("content-type: application/json");

        string result;
        curl_api_with_headerPD(url, result, extra_http_header , post_data , "POST");

        if ( result.size() > 0 ) {
            try {
                d.Parse(result.c_str()); 
                
                //printJson(d);
            		
            	} catch ( exception &e ) {
             	    const string& err = ": error reading cancel_order response " + string(e.what());
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = ": cancel_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 0;
   }
};

