

class Cryptocom : public Exchange {
    const unsigned short id = 5;
    int depth = 0;
    vector<string> v;

    void get_24Volume(){        
        Document d;
        
        try{
            string result;  
                  
            curl_api_with_header("https://api.crypto.com/v2/public/get-ticker", result);
            d.Parse(result.c_str()); 

            if(d.IsObject() && d.HasMember("code") && d["code"] == 0){
                for(auto& i : d["result"]["data"].GetArray()){
                    string s = i["i"].GetString();
                   
                    string base = s.substr(0, s.find('_'));
                    string quote = s.substr(s.find('_') + 1, s.length() - 1);
                    double v = i["vv"].GetDouble();
                        
                    coins[base][quote].volume = v;    
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_24Volume> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }       
    }

    public:
    void get_pairs(){        
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api.crypto.com/v2/public/get-instruments", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("result") && d["code"] == 0){
                for(auto& i : d["result"]["instruments"].GetArray()){     
                    string quote = i["quote_currency"].GetString();  
                    string base = i["base_currency"].GetString(); 

                    v.push_back(base + "_" + quote);

                    orderbook o = orderbook();                        
                    o.fee = {0.000713, 0.000713};                        
                    coins[base][quote] = o;
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + to_string(id) + string(e.what()) ); 
         	printJson(d);
         	return;
        }      
        
        get_24Volume();
    }

    void websocketInit_depth(){        
        Document d;
        Wss ws;
        string s, quoteAsset, baseAsset;
        unordered_map<string, string> qA;
        qA["DT"] = "USDT"; qA["TC"] = "BTC"; qA["DC"] = "USDC"; qA["RO"] = "CRO";
        
        try {   
            ws.init_http("stream.crypto.com");
            ws.init_webSocket("stream.crypto.com", "443", "/v2/market");
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            
            for(int j = 0; j < 8; j++){
                s = "{\"id\": 11,\"method\": \"subscribe\",\"params\": {\"channels\": [";
                time_t current_time; 
                
                for(int i = (v.size() / 8) * j; i < (v.size() / 8) * (j + 1); i++)
                    s += "\"ticker." + v[i] + "\",";

                time(&current_time);
                int ct = current_time;
           
                s.pop_back();
                s += "]},\"nonce\": " + to_string(ct) + "}";
                ws.write_Socket(s); 
                
                for(int j = 0; j < 10; j++){
                    ws.read_Socket();  
                    ws.buffer_clear();
                }
            }
                     
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str()); 

                if(d.IsObject() && d.HasMember("method")){
                    if(d.HasMember("result")){ 
                        s = d["result"]["instrument_name"].GetString();
                        quoteAsset = qA[s.substr(s.length() - 2)];
                        baseAsset = s.substr(0, s.length() - quoteAsset.length() - 1);

                        auto&& c = coins[baseAsset][quoteAsset];
                        
                        c.mtx->lock();
                        
                        if(d["result"]["data"][0]["k"].IsNumber()){
                            c.asks.clear();
                            c.asks[ d["result"]["data"][0]["k"].GetDouble() ] = 0;
                        }
                        
                        if(d["result"]["data"][0]["b"].IsNumber()){
                            c.bids.clear();
                            c.bids[ d["result"]["data"][0]["b"].GetDouble() ] = 0;
                        }
                        
                        c.mtx->unlock();
                    }
                    else if(d["method"] == "public/heartbeat"){
                        s = "{\"id\":" + to_string(d["id"].GetUint64()) + ",\"method\":\"public/respond-heartbeat\"}";
                        ws.write_Socket(s); 
                    }
                    else if(d["method"] != "subscribe")
                        throw exception();
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + to_string(id) + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
};

