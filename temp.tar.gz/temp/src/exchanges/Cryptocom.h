

class Cryptocom : public Exchange {
    const unsigned short id = 5;
    int depth = 0;
    vector<string> v;

    public:
    void get_exchanges(){        
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api.crypto.com/v2/public/get-instruments", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("result") && d["code"] == 0){
                for(auto& i : d["result"]["instruments"].GetArray()){     
                    string quote = i["quote_currency"].GetString();  
                    string base = i["base_currency"].GetString(); 

                    v.push_back(base + "_" + quote);

                    orderbook o = orderbook();                        
                    o.fee = {0.0, 0.00025};                        
                    coins[base][quote] = o;
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + to_string(id) + string(e.what()) ); 
         	printJson(d);
         	return;
        }      
    }

    void websocketInit_depth(){        
        Document d;
        string s, quoteAsset, baseAsset;
        unordered_map<string, string> qA;
        qA["DT"] = "USDT"; qA["TC"] = "BTC"; qA["DC"] = "USDC"; qA["RO"] = "CRO";
        
        try {   
            init_http("stream.crypto.com");
            init_webSocket("stream.crypto.com", "443", "/v2/market");
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            
            // we send in 3 parts, exchange doesn't allow all in one go
            for(int i = 0; i < 1; i++){
                s = "{\"id\": 11,\"method\": \"subscribe\",\"params\": {\"channels\": [";
                time_t current_time; 
                
                for(int j = ((int)(v.size() / 3)) * i; j < ((int)(v.size() / 3)) * (i + 1); j++)
                    s += "\"ticker." + v[j] + "\",";
                
                if(i == 2 && v.size() % 3 != 0){
                    s += "\"ticker." + v[v.size() - 1] + "\",";
                    if(v.size() % 3 == 2)
                       s += "\"ticker." + v[v.size() - 2] + "\","; 
                }
                    
                time(&current_time);
                int ct = current_time;
           
                s.pop_back();
                s += "]},\"nonce\": " + to_string(ct) + "}";
                write_Socket(s);
                
                for(int j = 0; j < 10; j++){
                    read_Socket();   
                    buffer_clear();
                }
            }
            
            v.clear();
            v.shrink_to_fit();
            s.clear();
            s.shrink_to_fit();
            
            for(int i = 0; i < depth * 3; i++){
                read_Socket();
                buffer_clear();
            }
                     
            while (true) {
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("method")){
                    if(d["method"] == "subscribe"){ 
                        s = d["result"]["instrument_name"].GetString();
                        quoteAsset = qA[s.substr(s.length() - 2)];
                        baseAsset = s.substr(0, s.length() - quoteAsset.length() - 1);

                        auto&& c = coins[baseAsset][quoteAsset];
                        
                        c.mtx->lock();
                        
                        if(d["result"]["data"][0]["k"].IsNumber()){
                            c.asks.clear();
                            c.asks[ d["result"]["data"][0]["k"].GetDouble() ] = 0;
                        }
                        
                        if(d["result"]["data"][0]["b"].IsNumber()){
                            c.bids.clear();
                            c.bids[ d["result"]["data"][0]["b"].GetDouble() ] = 0;
                        }
                        
                        c.mtx->unlock();
                    }
                    else if(d["method"] == "public/heartbeat"){
                        s = "{\"id\":" + to_string(d["id"].GetUint64()) + ",\"method\":\"public/respond-heartbeat\"}";
                        write_Socket(s); 
                    }
                    else
                        throw exception();
                }
                else
                    throw exception();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + to_string(id) + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
};

