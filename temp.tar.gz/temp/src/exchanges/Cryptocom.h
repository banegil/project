

class Cryptocom : public Exchange {
    const string id = "Cryptocom";
    const unsigned short idNum = 5;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETH_USDT";
    bool limitOrder = 0;
    
    const string api_key = "g9WyBA3iGzymsiWWS72nGj";
    const char* secret_key = "QuRRBL1hSdZLngSZyFNGeE";

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.000728, 0.000728}; // with 1200$ 0.00069
        symbol = chosenSymbol;
        symbol[symbol.find('-')] = '_'; 
        
        try{
            string result;          
            curl_api_with_header("https://api.crypto.com/v2/public/get-instruments", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("result") && d["code"] == 0){
                for(auto& i : d["result"]["instruments"].GetArray()){     
                    string quote = i["quote_currency"].GetString();  
                    string base = i["base_currency"].GetString(); 

                    if( base + "-" + quote == chosenSymbol )
                        return 1;
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }      
        return 0;
    }

    void websocketInit_depth(){        
        Wss ws;
        Document d;
        string s = "{\"id\": 11,\"method\": \"subscribe\",\"params\": {\"channels\": [\"book." + symbol + ".150\"]},\"nonce\": 1587523073344}";
        
        try {   
            ws.init_http("stream.crypto.com");
            ws.init_webSocket("stream.crypto.com", "443", "/v2/market");
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            ws.write_Socket(s);
            
            ws.read_Socket();
            ws.buffer_clear();
                     
            while (true) {
                ws.read_Socket();	
                d.Parse(ws.get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("method")){
                    if(d["method"] == "subscribe"){
                        auto&& data = d["result"]["data"][0];
                        
                        mtxAsk.lock();
                        asks.clear();
                        for(int i = 0; i < 20; i++)
                            asks[ data["asks"][i][0].GetDouble() ] = data["asks"][i][1].GetDouble();
                        mtxAsk.unlock();
                            
                        mtxBid.lock();
                        bids.clear();
                        for(int i = 0; i < 20; i++)
                            bids[ data["bids"][i][0].GetDouble() ] = data["bids"][i][1].GetDouble();
                        mtxBid.unlock();
                    
                    }
                    else if(d["method"] == "public/heartbeat"){
                        s = "{\"id\":" + to_string(d["id"].GetUint64()) + ",\"method\":\"public/respond-heartbeat\"}";
                        write_Socket(s); 
                    }
                    else
                        throw exception();
                }
                else
                    throw exception();

                ws.buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	ws.webSocket_close();
            return;
          }
    } 
    
    bool send_order(string side, const double& quantity) {	
        Document d;
        
        const string& ep = to_string (get_current_ms_epoch());
        const char* url = "https://api.crypto.com/v2/";
        
        string post_data = "";
        string msg = "{
             \"id\": 11,
             \"method\": \"private/create-order\",
             \"params\": {
               \"instrument_name\": \"ETH_CRO\",
               \"side\": \"BUY\",
               \"type\": \"MARKET\",
               \"quantity\": 1.2,
               \"client_oid\": \"my_order_0002\",
               \"time_in_force\": \"GOOD_TILL_CANCEL\",
               \"exec_inst\": \"POST_ONLY\"},
             \"nonce\": 1587846358253}";
        
        const string& signature =  hmac_sha256( secret_key, msg.c_str() );
        
        vector <string> extra_http_header;
        extra_http_header.push_back("X-ACCESS-NONCE:" + ep);
        extra_http_header.push_back("X-ACCESS-KEY:" + api_key);
        extra_http_header.push_back("X-ACCESS-SIGN:" + signature);
        
        string str_result;
        curl_api_with_headerPost( url, str_result , extra_http_header, post_data, "POST" ) ;

        if ( str_result.size() > 0 ) {
            try {
                d.Parse(result.c_str()); 
                
                printJson(d);
            		
            	} catch ( exception &e ) {
             	    const string& err = id + ": error reading send_order response " + e.what();
                    writte_err( "err.txt", err ); 
                    printJson(d);
                    return 0;
            }   
        } 
        else {
            const string& err = id + ": send_order.size() is 0";
            writte_err( "err.txt", err ); 
            return 0;
        }
        return 1;
   }
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }
    
    void set_limitOrder(){
        limitOrder = 1;
    } 
};

