

class Exchange {
   
   public:
   
   virtual void get_pairs() {}
   virtual void websocketInit_depth() {}
   virtual void websocketInit_User() {}
   virtual void send_triangular_order(string side1, string side2, string side3, string pair1, string pair2, string pair3, double quantity) {}
};
