

class Exchange {
   
   public:
   
   virtual void websocketInit_depth() {}
   virtual void websocketInit_User() {}
   virtual int send_order(const string& symbol, string side, const double& quantity, const double& orderPrice) { return 0; } 
   virtual int send_CancelOrder(const string& symbol) { return 0; }
};
