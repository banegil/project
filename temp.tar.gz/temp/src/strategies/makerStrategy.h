
#define PRICE_LOWER_BOUND_DIFF 0.00005
#define PRICE_UPPER_BOUND 0.001

#define PRICE_LOWER_BOUND_ORDER 0.0003 // buy-limit order (price_buyer)

#define QUANTITY_LOWER_BOUND 15.0
#define DECIMALS 0.01 // Exchange.get_decimalsPrice()


void balanced_assets_strat(const double& fee1, const double& fee2, const string& base, const string& quote, const double& maxMultiplier){
   
}

void static_strat(const unsigned short& exchange1, const unsigned short& exchange2, const double& fee1, const double& fee2, const string& base, const string& quote, const double& maxMultiplier){ 
    const double& price_lowerBound_order = PRICE_LOWER_BOUND_ORDER + fee1 + fee2;  
    const double& price_lowerBound_diff = PRICE_LOWER_BOUND_DIFF + fee1 + fee2; 
    const double& price_upperBound_diff = PRICE_UPPER_BOUND + fee1 + fee2;
    double price_buyer = ex[1]->bestBid_maker().first - ex[1]->bestBid_maker().first * price_lowerBound_order;
    double quantity_buyer = 0;
    double diff = 0;
    
    while(1){
        double quantity = 0;
        //const double& quantity_lowerBound = QUANTITY_LOWER_BOUND / bids_seller.begin()->first;
        
        auto&& bFuture = async(&Exchange::get_bids, ex[1]);        
        auto&& bids_seller = bFuture.get();
        auto&& itb = bids_seller.begin();
        auto&& itbEnd = bids_seller.end();
        
        diff = 1 - price_buyer / itb->first;
        
        while(diff > price_lowerBound_diff && itb != itbEnd){      
            quantity += itb->second;       
            ++itb;                                 
            diff = 1 - price_buyer / itb->first;    
        } 
        
        itb--;
        
        const bool& price_notProfitable = diff < price_lowerBound_diff;
        const bool& price_tooFar = diff > price_upperBound_diff; 
        const double& cq = QUANTITY_UPPER_BOUND / itb->first;             
        const bool& quantity_change = (quantity > cq && quantity_buyer < cq * 0.9) || (quantity < cq && quantity_buyer < quantity * 0.9);
           
        if(price_notProfitable || price_tooFar){
            if(!orderExecuted && !ex[0]->cancel_order()){
                cout << "ERROR: main.cpp cancel_order() " << ex[0]->get_id() << "\n\n";  
                return;
            }
                    
            price_buyer = bids_seller.begin()->first - bids_seller.begin()->first * price_lowerBound_order;
            my_round(quantity, maxMultiplier); 
            
            const double& balanceAntEx1 = exchangeInfo[exchange1].balance[quote] + quantity_buyer * price_buyer;
            const double& balanceAntEx2 = exchangeInfo[exchange2].balance[base] + quantity_buyer;                               
            const double& totalQuantityComp = quantity * 1.01;
            
            // if balances OK, for() in more exchanges
            /*if(balanceAntEx1 < totalQuantityComp * price_buyer){ 
                cout << " Please, deposit " + quote + " in " + ex[0]->get_id() + "\n";
                return;
            }
            
            if(balanceAntEx2 < totalQuantityComp){
                cout << " Please, deposit " + base + " in " + ex[1]->get_id() + "\n";
                return;                
            } */
            
            if(orderExecuted){
                cout << "ORDER EXECUTED\n";
                //get exchangeInfo[...]orderPrices
                this_thread::sleep_for(chrono::milliseconds(1000000));
            }
            else{  
                if(stopExecution){
                    cout << "THROW: main.cpp stopExecution\n\n";  
                    return;                    
                } 
                else{
                    quantity_buyer = quantity;

                    if(ex[0]->send_order("buy", 0.3, price_buyer, 1) == 0) {// LIMIT 
                        cout << "ERROR: main.cpp send_order() " << ex[0]->get_id() << "\n\n";  
                        return;
                    }
                    else
                        ex[0]->set_limitOrder();
                }                    
            }
                    
                 
        }           
        
        this_thread::sleep_for(chrono::milliseconds(200));
    }
}


void makerStrategy(const unsigned short& exchange1, const unsigned short& exchange2, const bool& makerStrat, const bool& balanced_assets){
    double fee1, fee2;
    
    cout << " ***  Maker strategy  ***" << endl;   
    cout << " Getting active exchanges:" << endl;  
        
    if(iniExchanges(fee1, fee2, exchange1, exchange2, makerStrat)){
        cout << " OK!" << endl << endl;                
        cout << " Starting websocket connection..." << endl;  
            
        vector<thread> ths(4);    
        ths[0] = thread (doIniWebSocket, 0);
        ths[1] = thread (doIniWebSocket, 1);
        
        auto&& aF = async(&Exchange::websocketInit_User, ex[0]);
        auto&& bF = async(&Exchange::websocketInit_User, ex[1]);

        this_thread::sleep_for(chrono::milliseconds(10000));
        cout << " OK!" << endl << endl;
        
        const string& base = chosenSymbol.substr(0, chosenSymbol.find('-'));
        const string& quote = chosenSymbol.substr(chosenSymbol.find('-') + 1, chosenSymbol.length() - 1); 
        
        const double& maxMultiplier = max(exchangeInfo[exchange1].multiplier, exchangeInfo[exchange2].multiplier);
 
        if(balanced_assets)
            balanced_assets_strat(fee1, fee2, base, quote, maxMultiplier);
        else
            static_strat(exchange1, exchange2, fee1, fee2, base, quote, maxMultiplier);

        for(int i = 0; i < 2; i++)
            ths[i].join();
    } 
}
