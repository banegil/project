

void takerStrategy(const unsigned short& exchange1, const unsigned short& exchange2, const bool& makerStrat, const bool& balanced_assets){
    double fee1, fee2;
      
    cout << " ***  Taker strategy  ***" << endl;
    cout << " Getting active exchanges:" << endl;  
        
    if(iniExchanges(fee1, fee2, exchange1, exchange2, makerStrat)){
        cout << " OK!" << endl << endl;                
        cout << " Starting websocket connection..." << endl;  
            
        vector<thread> ths(4);    
        ths[0] = thread (doIniWebSocket, 0);
        ths[1] = thread (doIniWebSocket, 1);
        
        auto&& aF = async(&Exchange::websocketInit_User, ex[0]);
        auto&& bF = async(&Exchange::websocketInit_User, ex[1]);

        this_thread::sleep_for(chrono::milliseconds(10000));
        cout << " OK!" << endl << endl;
        
        const string& base = chosenSymbol.substr(0, chosenSymbol.find('-'));
        const string& quote = chosenSymbol.substr(chosenSymbol.find('-') + 1, chosenSymbol.length() - 1); 
        
        const double& maxMultiplier = max(exchangeInfo[exchange1].multiplier, exchangeInfo[exchange2].multiplier);

        while(1){
            auto&& aFuture = async(&Exchange::get_asks, ex[0]);
            auto&& bFuture = async(&Exchange::get_bids, ex[1]);
                
            auto&& asks = aFuture.get();
            auto&& bids = bFuture.get();           

            double diff = 1 - (asks.begin()->first + asks.begin()->first * fee1) / (bids.begin()->first - bids.begin()->first * fee2); 
                    
            if(diff > MAX_DIFF){
                auto&& ita = asks.begin();
                auto&& itaEnd = asks.end();
                auto&& itb = bids.begin();
                auto&& itbEnd = bids.end();
            
                double totalQuantity = 0;
            
                while(diff > MAX_DIFF && ita != itaEnd && itb != itbEnd){            
                    const double& quantity = min(ita->second, itb->second);
                    
                    ita->second -= quantity;
                    itb->second -= quantity;
                    
                    if(ita->second  == 0)
                        ++ita; 
                    
                    if(itb->second == 0)
                        ++itb;
                        
                    totalQuantity += quantity;                   
                    diff = 1 - (ita->first + ita->first * fee1) / (itb->first - itb->first * fee2);    
                } 
                
                --ita;
                
                totalQuantity = min(totalQuantity, MAX_ORDER_QUOTE / ita->first);
                const double& totalQuantityComp = totalQuantity * 1.01;
                
                const double& x = max(exchangeInfo[exchange1].multiplier, exchangeInfo[exchange2].multiplier);
                const double& y = fmod(totalQuantity, x);
                
                const double& balanceAntEx1 = exchangeInfo[exchange1].balance[quote];
                const double& balanceAntEx2 = exchangeInfo[exchange2].balance[base];
                
                // if balances OK
                if(balanceAntEx1 < totalQuantityComp * ita->first){ 
                    cout << " Please, deposit " + quote + " in " + ex[0]->get_id() + "\n";
                    return;
                }
                
                if(balanceAntEx2 < totalQuantityComp){
                    cout << " Please, deposit " + base + " in " + ex[1]->get_id() + "\n";
                    return;                
                }
                
                if(x != y)
                    totalQuantity -= y; 
                    
                exchangeInfo[exchange1].orderPrice = -1;
                exchangeInfo[exchange2].orderPrice = -1;
                                
                auto&& f1 = async(&Exchange::send_order, ex[0], "buy", totalQuantity, 0, 0); // MARKET
                auto&& f2 = async(&Exchange::send_order, ex[1], "sell", totalQuantity, 0, 0); // MARKET
                
                // check balances OK
                while(balanceAntEx1 == exchangeInfo[exchange1].balance[quote] || balanceAntEx2 == exchangeInfo[exchange2].balance[base])
                    this_thread::sleep_for(chrono::milliseconds(50)); 
                
                // check prices OK 
                while(exchangeInfo[exchange1].orderPrice == -1 || exchangeInfo[exchange2].orderPrice == -1)
                    this_thread::sleep_for(chrono::milliseconds(50));
                    
                diff == 1 - (exchangeInfo[exchange1].orderPrice + exchangeInfo[exchange1].orderPrice * fee1) / (exchangeInfo[exchange2].orderPrice - exchangeInfo[exchange2].orderPrice * fee2);
                cout << " Order diff: " << diff * 100 << "  buy: " << exchangeInfo[exchange1].orderPrice << "  sell: " << exchangeInfo[exchange2].orderPrice << "  qty: " << totalQuantity << "\n";
                cout << " " << ex[0]->get_id() << "(buyer): " << exchangeInfo[exchange1].balance[base] <<  base << "  " << exchangeInfo[exchange1].balance[quote] << quote << "\n";
                cout << " " << ex[1]->get_id() << "(seller): " << exchangeInfo[exchange2].balance[base] <<  base << "  " << exchangeInfo[exchange2].balance[quote] << quote << "\n\n";
                
                this_thread::sleep_for(chrono::milliseconds(10000000));
            }

            this_thread::sleep_for(chrono::milliseconds(100));   
        } 


        for(int i = 0; i < 2; i++)
            ths[i].join();
    } 
}
