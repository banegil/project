
#include "Wss.h"

class Exchange {
	
	public:	
	virtual bool get_pairs() { return 0; }
	
	virtual void websocketInit_depth() {}
	
	virtual void websocketInit_User() {}
	
	virtual unsigned short send_order(string side, const double& quantity, const double& price, const bool& limit) { return 0; } // 0=error, 1=qtyMin, 2=OK
	
	virtual bool cancel_order() { return 0; }
	
	virtual bool withdrawal() { return 0; }
	
	virtual string get_id() { return ""; }
	
	virtual unsigned short get_idnum() { return -1; }
	
    virtual pair<double, unsigned short> bestAsk_taker() { return {0.0, -1}; } 
    
    virtual pair<double, unsigned short> bestBid_taker() { return {0.0, -1}; }
    
    virtual pair<double, unsigned short> bestAsk_maker() { return {0.0, -1}; }
    
    virtual pair<double, unsigned short> bestBid_maker() { return {0.0, -1}; }
	    
	virtual map<double, double> get_asks() { map<double, double> nothing; return nothing; }
	
	virtual map<double, double, greater<double>> get_bids() { map<double, double, greater<double>> nothing; return nothing; }
	
	virtual pair<double, double> get_fee() { return {1, 1}; }
	
	virtual void set_limitOrder() {}
	
    /*************************************** CURL ****************************************/
    static size_t curl_cb( void *content, size_t size, size_t nmemb, std::string *buffer ) {	
        buffer->append((char*)content, size*nmemb);
        return size*nmemb;
    }

    void curl_api( const string& url, string& str_result ) {
	    CURL* curl;
        CURLcode res;
        curl = curl_easy_init();

        if( curl ) {		    
            curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
	        curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");
	        curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
	        //mtxCurl.lock();
	        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
	        //mtxCurl.unlock();
	        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );

	        res = curl_easy_perform(curl);
	        curl_easy_cleanup(curl);

	        /* Check for errors */ 
	        if ( res != CURLE_OK ) {
		        writte_err( "err.txt", "ERROR: <curl_api_with_header> failed: " + string(curl_easy_strerror(res)) ) ;
	        } 	
        }
    }

        
    void curl_api_with_header( const char* url, string& str_result, const vector <string> &extra_http_header , const string& post_data , const string& action ) {
	    CURL* curl;
        CURLcode res;
        curl = curl_easy_init();

        if( curl ) {

            curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
	        curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");
	        curl_easy_setopt(curl, CURLOPT_URL, url );
	        mtxCurl.lock();
	        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
	        mtxCurl.unlock();
	        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );

	        if ( extra_http_header.size() > 0 ) {
		        
		        struct curl_slist *chunk = NULL;
		        for ( int i = 0 ; i < extra_http_header.size() ;i++ ) {
			        chunk = curl_slist_append(chunk, extra_http_header[i].c_str() );
		        }
		        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, chunk);
	        }

	        if ( post_data.size() > 0 || action == "POST" || action == "DELETE" ) {
			    if ( action == "DELETE" ) 
				    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, action.c_str() );
		        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data.c_str() );
		    }

	        res = curl_easy_perform(curl);
	        curl_easy_cleanup(curl);

	        /* Check for errors */ 
	        if ( res != CURLE_OK ) 
		        writte_err( "err.txt", "ERROR: <curl_api_with_headerPost> failed: " + string(curl_easy_strerror(res)) ) ;	
        }
    }
    /*************************************** CURL ****************************************/
	
};

