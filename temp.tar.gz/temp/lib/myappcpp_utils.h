
mutex mtxErr, mtxCurl;
  
inline void check_varIni(){
    if(QUANTITY == -1 || POW_CC == -1 || POW_CC_QTY == -1 || POW_CC1 == -1 || POW_CC2 == -1 || POW_CC2_QTY == -1)
        cout << "Variable init went wrong!\n";
    
    cout << "\n";        
    cout << "  QUANTITY: " << QUANTITY << "\n";
    cout << "  POW_CC: " << POW_CC << "\n";
    cout << "  POW_CC_QTY: " << POW_CC_QTY << "\n";
    cout << "  POW_CC1: " << POW_CC1 << "\n";
    cout << "  POW_CC1_QTY: " << POW_CC1_QTY << "\n";
    cout << "  POW_CC2: " << POW_CC2 << "\n";
    cout << "  POW_CC2_QTY: " << POW_CC2_QTY << "\n\n";
}  

inline long nanos(){
    long ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::high_resolution_clock::now().time_since_epoch())
            .count();
    return ns; 
}
  
string b2a_hex( char *byte_arr, int n ) {

    const static std::string HexCodes = "0123456789abcdef";
    string HexString;
    for ( int i = 0; i < n ; ++i ) {
        unsigned char BinValue = byte_arr[i];
        HexString += HexCodes[( BinValue >> 4 ) & 0x0F];
        HexString += HexCodes[BinValue & 0x0F];
    }
    return HexString;
}  
    
inline unsigned long get_current_ms_epoch( ) noexcept {
    struct timeval tv;
    gettimeofday(&tv, NULL); 

    return tv.tv_sec * 1000 + tv.tv_usec / 1000 ;

}  

inline string my_toString(const double& d) noexcept {
    ostringstream s;
    s << d;  
    return s.str();        
}

inline string my_toString_extended(const double& d) noexcept {
    ostringstream s;
    
    if(d > 1)
        s << setprecision(10) << d; // for d > 1
    else
        s << d; // for d < 1
    
    string number = s.str();
    auto&& it = number.find('e');
    string newNumber = "";
    
    if(it != std::string::npos){
        newNumber += "0.";
        const int& size = stoi( number.substr(number.length() - 2, number.length() - 1) ) - 1;

        for(int i = 0; i < size; i++)
            newNumber += "0";
        
        number.erase(remove(number.begin(), number.end(), '.'), number.end());
        newNumber += number.substr(0, number.length() - 4);
    }
    else
        newNumber = number;
        
    return newNumber;        
}

/*inline double numberDecimals(const double& d) noexcept{
   const string& s = my_toString_extended(d); 
   return s.substr(s.find('.') + 1, s.length() - 1).length();
}*/

inline void string_toupper(string& s) noexcept {
    transform(s.begin(), s.end(), s.begin(),[](unsigned char c){ return toupper(c); });
} 

inline void string_tolower(string& s) noexcept {
    transform(s.begin(), s.end(), s.begin(),[](unsigned char c){ return tolower(c); });
}

string hmac_sha256( const char *key, const char *data) {
    unsigned char* digest;
    digest = HMAC(EVP_sha256(), key, strlen(key), (unsigned char*)data, strlen(data), NULL, NULL);    
    return b2a_hex( (char *)digest, 32 );
} 

inline string hmac_sha256_2( const char *secret_key, const char *data) noexcept {
        unsigned int md_len;
        unsigned char *str = HMAC(EVP_sha256(), secret_key, strlen(secret_key), reinterpret_cast<const unsigned char *>(data), strlen(data), nullptr, &md_len);
        //signature buf afer hmac and base64
        char signature[100];
        EVP_EncodeBlock((unsigned char *) signature, str, md_len);
        const string& s = signature;
    return s;
} 
    
void writte_err(const string& file, const string& s){
    time_t now = time(0);
    char* dt = ctime(&now);
    mtxErr.lock();
    cout << dt << " " << s << '\n';
    ofstream output(file, std::ios::app);
    output << dt << " " << s << '\n';
    mtxErr.unlock();
}

void printJson(const Document& d){
    StringBuffer sb;
    PrettyWriter<StringBuffer> writer(sb);
    d.Accept(writer);
    puts(sb.GetString());
}

static size_t curl_cb( void *content, size_t size, size_t nmemb, std::string *buffer ) {	
    buffer->append((char*)content, size*nmemb);
    return size*nmemb;
}

void curl_api_with_header( const string& url, string& str_result ){
	CURL* curl;
    CURLcode res;
    curl = curl_easy_init();

    if( curl ) {		
        curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1);    
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
	    curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");
	    curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
	    mtxCurl.lock();
	    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
	    mtxCurl.unlock();
	    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );

	    res = curl_easy_perform(curl);
	    curl_easy_cleanup(curl);

	    /* Check for errors */ 
	    if ( res != CURLE_OK ) {
		    writte_err( "err.txt", "ERROR: <curl_api_with_header> failed: " + string(curl_easy_strerror(res)) ) ;
	    } 	
    }
 }
 
inline void curl_api_with_headerPD( const char* url, string &str_result, vector <string> &extra_http_header , const string &post_data , const string &action ) noexcept {
    	CURL* curl;
	    CURLcode res;
	    curl = curl_easy_init();

	    if( curl ) {
	    
            curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1);
		    curl_easy_setopt(curl, CURLOPT_URL, url );
		    mtxCurl.lock();
		    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
		    mtxCurl.unlock();
		    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );
		    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
		    curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");

		    if ( extra_http_header.size() > 0 ) {
			    
			    struct curl_slist *chunk = NULL;
			    for ( int i = 0 ; i < extra_http_header.size() ;i++ ) {
				    chunk = curl_slist_append(chunk, extra_http_header[i].c_str() );
			    }
			    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, chunk);
		    }

		    if ( post_data.size() > 0 || action == "POST" || action == "DELETE" ) {

			    if ( action == "DELETE" ) {
				    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, action.c_str() );
			    }
			    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data.c_str() );
     		}

		    res = curl_easy_perform(curl);
		    curl_easy_cleanup(curl);

		    /* Check for errors */ 
		    if ( res != CURLE_OK ) {
		        string err = curl_easy_strerror(res) ;
			    writte_err( "err.txt", "ERROR: <curl_api_with_headerPost> curl_easy_perform() failed: " + err ) ;
		    } 	
	    }
}

