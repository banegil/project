
#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"

using namespace std;
using namespace rapidjson;

mutex mtxErr;
    
inline void writte_err(const string& file, const string& s){
    time_t now = time(0);
    char* dt = ctime(&now);
    mtxErr.lock();
    cout << dt << " " << s << '\n';
    ofstream output(file, std::ios::app);
    output << dt << " " << s << '\n';
    mtxErr.unlock();
}

inline void printJson(const Document& d){
    StringBuffer sb;
    PrettyWriter<StringBuffer> writer(sb);
    d.Accept(writer);
    puts(sb.GetString());
}

static size_t curl_cb( void *content, size_t size, size_t nmemb, std::string *buffer ) {	
    buffer->append((char*)content, size*nmemb);
    return size*nmemb;
}

inline void curl_api_with_header( const string& url, string& str_result ) {
	CURL* curl;
    CURLcode res;
    curl = curl_easy_init();

    if( curl ) {		    
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
	    curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");
	    curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
	    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
	    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );

	    res = curl_easy_perform(curl);
	    curl_easy_cleanup(curl);

	    /* Check for errors */ 
	    if ( res != CURLE_OK ) {
		    writte_err( "err.txt", "ERROR: <curl_api_with_header> failed: " + string(curl_easy_strerror(res)) ) ;
	    } 	
    }
 }

