
#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"

#include <openssl/hmac.h>
#include <openssl/sha.h>
#include <openssl/md5.h>

#include <zlib.h>

using namespace std;
using namespace rapidjson;

mutex mtxErr, mtxCurl;
    
void writte_err(const string& file, const string& s) {
    time_t now = time(0);
    char* dt = ctime(&now);
    mtxErr.lock();
    cout << dt << " " << s << '\n';
    ofstream output(file, std::ios::app);
    output << dt << " " << s << '\n';
    mtxErr.unlock();
}

void printJson(const Document& d){
    StringBuffer sb;
    PrettyWriter<StringBuffer> writer(sb);
    d.Accept(writer);
    puts(sb.GetString());
}

inline string my_toString(const double& d) noexcept {
    ostringstream s;
    s << d;  
    return s.str();        
}

inline void my_round(double& z, const double& x) noexcept {
    const double& y = fmod(z, x);                 
    if(x != y)
        z -= y;      
}

inline void string_toupper(string& s) noexcept {
    transform(s.begin(), s.end(), s.begin(),[](unsigned char c){ return toupper(c); });
}

inline void string_tolower(string& s) noexcept {
    transform(s.begin(), s.end(), s.begin(),[](unsigned char c){ return tolower(c); });
}

inline unsigned long get_current_ms_epoch( ) noexcept {
    struct timeval tv;
    gettimeofday(&tv, NULL); 
    return tv.tv_sec * 1000 + tv.tv_usec / 1000 ;
}

/*inline string removeZeros(string str){
    while(str[str.length() - 1] == '0')
        str.pop_back();
    
    return str;  
}*/

 
inline string decompress_gzip(const string& str) noexcept
{
    z_stream zs;                     
    memset(&zs, 0, sizeof(zs));

    if (inflateInit2(&zs, 15 + 16) != Z_OK)
        cout << "ERROR decompressing" << endl;

    zs.next_in = (Bytef*)str.data();
    zs.avail_in = str.size();

    int ret;
    char outbuffer[32768];
    string outstring;

    do {
        zs.next_out = reinterpret_cast<Bytef*>(outbuffer);
        zs.avail_out = sizeof(outbuffer);

        ret = inflate(&zs, 0);

        if (outstring.size() < zs.total_out) {
            outstring.append(outbuffer,
                             zs.total_out - outstring.size());
        }

    } while (ret == Z_OK);

    inflateEnd(&zs);

    if (ret != Z_STREAM_END) {     
        cout << "ERROR decompressing" << endl;
    }

    return outstring;
}

inline string encode(const char *buf) noexcept {
    char *output = curl_easy_escape(curl_easy_init(), buf, 0);
    string str = output;
    if (output) 
        curl_free(output);
    return str;
}

//**************************** encrypt ****************************

string b2a_hex( char *byte_arr, int n ) {
    const static std::string HexCodes = "0123456789abcdef";
    string HexString;
    for ( int i = 0; i < n ; ++i ) {
        unsigned char BinValue = byte_arr[i];
        HexString += HexCodes[( BinValue >> 4 ) & 0x0F];
        HexString += HexCodes[BinValue & 0x0F];
    }
    return HexString;
}

inline unsigned long CRC32(const string& buffer) noexcept {
     return crc32(crc32(0L, Z_NULL, 0),(const unsigned char *)buffer.c_str(), buffer.length());
}

inline string hmac_sha256( const char *key, const char *data) noexcept {
    unsigned char* digest;
    digest = HMAC(EVP_sha256(), key, strlen(key), (unsigned char*)data, strlen(data), NULL, NULL);    
    return b2a_hex( (char *)digest, 32 );
}

inline string hmac_sha256_2( const char *secret_key, const char *data) noexcept {
        unsigned int md_len;
        unsigned char *str = HMAC(EVP_sha256(), secret_key, strlen(secret_key), reinterpret_cast<const unsigned char *>(data), strlen(data), nullptr, &md_len);
        //signature buf afer hmac and base64
        char signature[100];
        EVP_EncodeBlock((unsigned char *) signature, str, md_len);
        const string& s = signature;
    return s;
} 

inline string sha512( const char *data ) noexcept {
    unsigned char digest[64];
    SHA512_CTX sha512;
    SHA512_Init(&sha512);
    SHA512_Update(&sha512, data, strlen(data) );
    SHA512_Final(digest, &sha512);
    return b2a_hex( (char *)digest, 64 );
    
}

inline string hmac_sha512( const char *key, const char *data) noexcept {
    unsigned char* digest;
    digest = HMAC(EVP_sha512(), key, strlen(key), (unsigned char*)data, strlen(data), NULL, NULL);    
    return b2a_hex( (char *)digest, 64 );
}


//*****************************************************************






