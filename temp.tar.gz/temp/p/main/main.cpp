#include "include.h"


void ini(){      
    Binance bin;

    cout << "Starting ... " << endl;    
    auto e = async(&Binance::websocketInit_depth, &bin);       
    auto ee = async(&Binance::websocketInit_trades, &bin, bin.get_listenKey());              

    this_thread::sleep_for(chrono::milliseconds(7000));    
    cout << "OK!" << endl;
     
    auto&& p1 = pairs["btcusdc"]; 
    auto&& p2 = pairs["btcbusd"];
    auto&& p3 = pairs["usdcbusd"];
    
    bool orderOn = false;
    int contTime = 0; // max 100
    int contOrders = 0;
    double priceOrder;
    double quantity = 0.00073;
    
    while(1){ 
        auto p1bids = p1.get_bids();
        auto p2bids = p2.get_bids();
        auto p3asks = p3.get_asks();  
            
        if(orderOn){           
            if(orderNotExecuted){
                double c = (p2bids[0].first / priceOrder) / p3asks[0].first;
                double c2 = p2bids[0].first - p2bids[0].first * 0.00006;
                
                if(c < 0 || (c > 0.00006 && priceOrder < c2)){
                    bin.send_order("BTC-USDC", "", 0, 0, "CANCEL");
                    priceOrder = c2;   
                    bin.send_order( "BTC-USDC", "buy", quantity, round( priceOrder * 100.0 ) / 100.0 , "LIMIT" );     
                    contOrders += 2;           
                }
            }
            else {
                cout << "ORDER EXECUTED!" << endl;
                this_thread::sleep_for(chrono::milliseconds(2000));
                orderOn = false;   
            }            
        }        
        else{            
            orderNotExecuted = true;     
            priceOrder = p2bids[0].first - p2bids[0].first * 0.00006; // round( priceOrder * 100.0 ) / 100.0

            bin.send_order( "BTC-USDC", "buy", quantity, round( priceOrder * 100.0 ) / 100.0 , "LIMIT" );
            this_thread::sleep_for(chrono::milliseconds(1000));
            orderOn = true;
            contOrders++;
        }
        
        if(contTime % 1 == 0)
            cout << "contOrders: " << contOrders << ", contTime: " << contTime << endl;
        
        if(++contTime == 10){
            cout << "TotalOrders: " << contOrders << endl;
            contTime = 0;
        }
        
        this_thread::sleep_for(chrono::milliseconds(500));
    }
}


int main() {
    curl_global_init(CURL_GLOBAL_ALL);    
    ini();
    return 0;
}

/*
void ini(){      
    Binance bin;

    cout << "Starting ... " << endl;    
    auto e = async(&Binance::websocketInit_depth, &bin);       
    auto ee = async(&Binance::websocketInit_trades, &bin, bin.get_listenKey());              

    this_thread::sleep_for(chrono::milliseconds(7000));    
    cout << "OK!" << endl;
     
    auto&& p1 = pairs["btcusdc"]; 
    auto&& p2 = pairs["btcbusd"];
    auto&& p3 = pairs["usdcbusd"];
    
    int cont = 0; 
    double diffAverage = 0;
    double qtyAverage = 0;
    double priceOrder = 0;
    
    time_t current_time;
    time(&current_time);
    int ct = current_time;  
    while(1){
        time(&current_time);
        int ct2 = current_time;
        
        if(ct2 - ct > 10){
            ct = ct2;
            cout << "diffAverage: " << (diffAverage / cont) * 100 << ", qtyAverage: " << qtyAverage / cont << "\n";
            cont = diffAverage = qtyAverage = 0;
        }
    
        p1.mtx->lock(); p2.mtx->lock(); p3.mtx->lock();
        double c1 = (p2.bids[0].first / p1.bids[0].first) / p3.asks[0].first;
        p1.mtx->unlock(); p2.mtx->unlock(); p3.mtx->unlock();              
        
        if(c1 > 1){   
            int iA = 0, iB = 0, iC = 0;
            
            p1.mtx->lock(); p2.mtx->lock(); p3.mtx->lock();         
            auto p1B = p1.bids;
            auto p2B = p2.bids; 
            auto p3A = p3.asks;
            p1.mtx->unlock(); p2.mtx->unlock(); p3.mtx->unlock(); 
                    
            while(iA < 5 && iB < 5 && iC < 5 && (p2B[iB].first / p1B[iA].first) / p3A[iC].first > 1){
                double minimum = min(min(p2B[iB].second, p1B[iA].second), p3A[iC].second);
                
                p1B[iA].second -= minimum;
                p2B[iB].second -= minimum;
                p3A[iC].second -= minimum;
                
                if(p1B[iA].second == 0)
                    iA++;
                if(p2B[iB].second == 0)
                    iB++;
                if(p3A[iC].second == 0)
                    iC++;
                
                qtyAverage += minimum;
            }

            diffAverage += c1 - 1;            
            cont++;
        }            
                    
        this_thread::sleep_for(chrono::milliseconds(100));
    }
}
*/
