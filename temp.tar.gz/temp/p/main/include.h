
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <iostream>
#include <future>
#include <curl/curl.h>
#include <cstdio>  
#include <cstring>  
#include <cstdlib> 
#include <unordered_map>
#include <map>
#include <fstream>
#include <mutex>
#include <iomanip>
#include <chrono>
#include <thread>
#include <cmath>
#include <ctime>
#include <atomic>
#include <set>
#include <curl/curl.h>

#include "../lib/myappcpp_utils.h"

#include "../src/exchange.h"

struct tOrderbook {
    array<pair<double, double>, 5> asks;
    array<pair<double, double>, 5> bids;

    mutable mutex *mtx;
        
    public:
    tOrderbook(){
        mtx = new mutex();
    }
    
    void pushOrderbook(const Document& d){
        mtx->lock();
                
        auto&& a = d["data"]["asks"];
        auto&& b = d["data"]["bids"];
        
        for(int i = 0; i < 5; i++){
            asks[i].first = stod( a[i][0].GetString() );
            asks[i].second = stod( a[i][1].GetString() );
        }
        
        for(int i = 0; i < 5; i++){
            bids[i].first = stod( b[i][0].GetString() );
            bids[i].second = stod( b[i][1].GetString() );
        }
        
        mtx->unlock();
    }
    
    array<pair<double, double>, 5> get_asks(){
        lock_guard<mutex> lock(*mtx);
        return asks;        
    }
    
    array<pair<double, double>, 5> get_bids(){
        lock_guard<mutex> lock(*mtx);
        return bids;        
    }
};

unordered_map<string, tOrderbook> pairs;

atomic<bool> orderNotExecuted = 1, wait = 0;

#include "../src/exchanges/binance.h"










