
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

#include <sstream>
#include <ctime>
#include <exception>
#include <algorithm>

#include <ctype.h>

#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <boost/beast.hpp>
#include <boost/beast/ssl.hpp>

namespace net       = boost::asio;
namespace ssl       = net::ssl;
namespace beast     = boost::beast;
namespace http      = beast::http;
namespace websocket = beast::websocket;

using tcp      = net::ip::tcp;
using Request  = http::request<http::string_body>;
using Stream   = beast::ssl_stream<beast::tcp_stream>;
using Response = http::response<http::dynamic_body>;

class Exchange {
    // HTTP REQUEST SET 
    net::io_context ioc;
    ssl::context    ctx{ssl::context::tlsv12_client};
    tcp::resolver   resolver{ioc};
    Stream          stream{ioc, ctx};

    // WEB SOCKET SET 
    std::string        m_web_socket_host;
    std::string        m_web_socket_port;
    beast::flat_buffer buffer;
    net::io_context    ioc_webSocket;
    ssl::context       ctx_webSocket{ssl::context::tlsv12_client};
    tcp::resolver      resolver_webSocket{ioc_webSocket};
    websocket::stream<beast::ssl_stream<tcp::socket>> ws{ioc_webSocket,
                                                         ctx_webSocket};
	
	public:	
	virtual bool get_pairs() { return 0; }
	
	virtual void get_orderbook(tOrderbook& orderbook) {}
	
	virtual unsigned short get_idnum() { return -1; }
	
    virtual pair<double, unsigned short> bestAsk_taker() { return {0, 0}; }
    
    virtual pair<double, unsigned short> bestBid_taker() { return {0, 0}; }
    
    virtual pair<double, unsigned short> bestAsk_maker() { return {0, 0}; }
    
    virtual pair<double, unsigned short> bestBid_maker() { return {0, 0}; }
	
	virtual void websocketInit_depth() {}
	
	virtual string get_id() { return ""; }
	    
	virtual map<double, double> get_asks() { map<double, double> nothing; return nothing; }
	
	virtual map<double, double, greater<double>> get_bids() { map<double, double, greater<double>> nothing; return nothing; }
	
	virtual pair<double, double> get_fee() { return {1, 1}; }
	
/*************************************** CURL ****************************************/
    static size_t curl_cb( void *content, size_t size, size_t nmemb, std::string *buffer ) {	
        buffer->append((char*)content, size*nmemb);
        return size*nmemb;
    }

    void curl_api_with_header( const string& url, string& str_result ) {
	    CURL* curl;
        CURLcode res;
        curl = curl_easy_init();

        if( curl ) {		    
            curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
	        curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");
	        curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
	        //mtxCurl.lock();
	        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
	        //mtxCurl.unlock();
	        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );

	        res = curl_easy_perform(curl);
	        curl_easy_cleanup(curl);

	        /* Check for errors */ 
	        if ( res != CURLE_OK ) {
		        writte_err( "err.txt", "ERROR: <curl_api_with_header> failed: " + string(curl_easy_strerror(res)) ) ;
	        } 	
        }
    }

        
    void curl_api_with_headerPost( string &url, string &str_result, vector <string> &extra_http_header , string post_data , string action ) {
	    CURL* curl;
        CURLcode res;
        curl = curl_easy_init();

        if( curl ) {

            curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
	        curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");
	        curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
	        mtxCurl.lock();
	        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
	        mtxCurl.unlock();
	        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );

	        if ( extra_http_header.size() > 0 ) {
		        
		        struct curl_slist *chunk = NULL;
		        for ( int i = 0 ; i < extra_http_header.size() ;i++ ) {
			        chunk = curl_slist_append(chunk, extra_http_header[i].c_str() );
		        }
		        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, chunk);
	        }

	        if ( post_data.size() > 0 || action == "POST" ) 
		        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data.c_str() );

	        res = curl_easy_perform(curl);
	        curl_easy_cleanup(curl);

	        /* Check for errors */ 
	        if ( res != CURLE_OK ) 
		        writte_err( "err.txt", "ERROR: <curl_api_with_headerPost> failed: " + string(curl_easy_strerror(res)) ) ;	
        }
    }
/*************************************** CURL ****************************************/
	
/***************************     WEBSOCKET     ***************************/
    void init_http(std::string const& host)
    {
        const auto results{resolver.resolve(host, "443")};
        get_lowest_layer(stream).connect(results);
        // Set SNI Hostname (many hosts need this to handshake successfully)
        if (!SSL_set_tlsext_host_name(stream.native_handle(), host.c_str())) {
            boost::system::error_code ec{
                static_cast<int>(::ERR_get_error()),
                boost::asio::error::get_ssl_category()};
            throw boost::system::system_error{ec};
        }
        stream.handshake(ssl::stream_base::client);
    }

    void init_webSocket(std::string const& host, std::string const& port,
                        const char* p = "")
    {
        // Set SNI Hostname (many hosts need this to handshake successfully)
        if (!SSL_set_tlsext_host_name(ws.next_layer().native_handle(),
                                      host.c_str()))
            throw beast::system_error(
                beast::error_code(static_cast<int>(::ERR_get_error()),
                                  net::error::get_ssl_category()),
                "Failed to set SNI Hostname");
        //tcp::resolver::query query(host, PORT, boost::asio::ip::resolver_query_base::numeric_service);
        auto const results = resolver_webSocket.resolve(host, port); // sustituir (host, port) -> query
        net::connect(ws.next_layer().next_layer(), results.begin(),
                     results.end());
        ws.next_layer().handshake(ssl::stream_base::client);

        ws.handshake(host, p);
    }

    inline void read_Socket() { ws.read(buffer); }

    inline bool is_socket_open()
    {
        if (ws.is_open())
            return true;
        return false;
    }

    inline void write_Socket(const std::string& text) { ws.write(net::buffer(text)); }
    
    inline std::string get_socket_data()
    {
        return beast::buffers_to_string(buffer.data());
    }
    
    inline void buffer_clear() { buffer.clear(); }

    void webSocket_close() { ws.close(websocket::close_code::none); }
/***************************     WEBSOCKET     ***************************/
};

