

class Huobi : public Exchange {
    const string id = "Huobi";
    const unsigned short idNum = 8;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ethusdt";

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.0018, 0.0018}; // with 2500$ 0.0012
        symbol = chosenSymbol;  
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());  
        transform(symbol.begin(), symbol.end(), symbol.begin(),[](unsigned char c){ return tolower(c); }); 

        try{
            string result;          
            curl_api_with_header("https://api-aws.huobi.pro/v2/settings/common/symbols", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("data") && d["status"] == "ok"){
                for(auto& i : d["data"].GetArray()){
                    if(i["state"] == "online" && i["te"] == true){
                        string base = i["bc"].GetString();  
                        string quote = i["qc"].GetString(); 
                        transform(base.begin(), base.end(), base.begin(),[](unsigned char c){ return toupper(c); }); 
                        transform(quote.begin(), quote.end(), quote.begin(),[](unsigned char c){ return toupper(c); }); 
                        
                        if( base + "-" + quote == chosenSymbol )
                            return 1;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;

        try{
            string result;          
            curl_api_with_header("https://api-aws.huobi.pro/market/depth?symbol=" + symbol + "&type=step0", result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("status") && d["status"] == "ok" && d.HasMember("tick") && d["tick"].HasMember("bids")){
 
                for(auto&& i : d["tick"]["asks"].GetArray())
                    orderbook.asks[ i[0].GetDouble() ] = i[1].GetDouble();    
                    
                for(auto&& i : d["tick"]["bids"].GetArray())
                    orderbook.bids[ i[0].GetDouble() ] = i[1].GetDouble(); 
            
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }


    void websocketInit_depth(){        
        Document d;  
        string s = "{\"sub\": \"market." + symbol + ".mbp.refresh.20\",\"id\": \"id1\"}";
                
        try {
            init_http("api-aws.huobi.pro");
            init_webSocket("api-aws.huobi.pro", "443", "/ws");   
            write_Socket(s); 
            
            read_Socket();
            buffer_clear();
                         
            while (true) {
                read_Socket();	
                d.Parse(decompress_gzip(get_socket_data()).c_str());

                if(d.IsObject() && d.HasMember("tick") && d["tick"].HasMember("bids")){
                
                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["tick"]["asks"].GetArray())
                        asks[ i[0].GetDouble() ] = i[1].GetDouble();
                    mtxAsk.unlock();
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["tick"]["bids"].GetArray())
                        bids[ i[0].GetDouble() ] = i[1].GetDouble();
                    mtxBid.unlock();
                
                }
                else if(d.HasMember("ping")){
                    long l = d["ping"].GetUint64();
                    s = "{\"pong\":" + to_string(l) + "}";
                    write_Socket(s); 
                }
                else if(!d.HasMember("subbed"))
                    throw exception();              

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    }  
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }
    
    pair<double, double> get_fee() {
        return fee;
    } 
};

