

class Coinex : public Exchange {
    const string id = "Coinex";
    const unsigned short idNum = 4;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETHUSDT";

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.00128, 0.00128}; // with 3600$ 0.00112 
        symbol = chosenSymbol;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end()); 
        
        try{
            string result;          
            curl_api_with_header("https://api.coinex.com/v1/market/list", result);
            d.Parse(result.c_str());         

            if(d.HasMember("data") && d["code"] == 0 && d["message"] == "OK"){
                for(auto& i : d["data"].GetArray()){
                    string s = i.GetString();

                    if(symbol ==  s)
                        return 1;                       
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api.coinex.com/v1/market/depth?market=" + symbol + "&merge=0", result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("code") && d["code"] == 0 && d.HasMember("data") && d["data"].HasMember("asks")){
            
                for(auto&& i : d["data"]["asks"].GetArray())
                    orderbook.asks[ stod( i[0].GetString() ) ] = stod( i[1].GetString() );   
                    
                for(auto&& i : d["data"]["bids"].GetArray())
                    orderbook.bids[ stod( i[0].GetString() ) ] = stod( i[1].GetString() ); 
            
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }

    void websocketInit_depth(){
        Document d;
        string s = "{\"method\":\"depth.subscribe\",\"params\":[\"" + symbol + "\",20,\"0\",false],\"id\": 11}";
        
        try {
            init_http("socket.coinex.com");
            init_webSocket("socket.coinex.com", "443", "/");
            write_Socket(s);
            
            read_Socket();	
            buffer_clear();
                              
            while (true) {
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("method") && d["method"] == "depth.update"){

                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["params"][1]["asks"].GetArray())
                        asks[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxAsk.unlock();
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["params"][1]["bids"].GetArray())
                        bids[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxBid.unlock();
                
                }
                else
                    throw exception();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }
    
    pair<double, double> get_fee() {
        return fee;
    } 
};

