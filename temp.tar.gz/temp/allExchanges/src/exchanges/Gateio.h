

class Gateio : public Exchange {
    const string id = "Gateio";
    const unsigned short idNum = 7;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETH_USDT";

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.0012, 0.0012}; // with 15000$ 0.0006
        symbol = chosenSymbol;
        symbol[symbol.find('-')] = '_';

        try{
            string result;          
            curl_api_with_header("https://api.gateio.ws/api/v4/spot/currency_pairs", result);
            d.Parse(result.c_str()); 

            if(d.IsArray()){
                for(auto& i : d.GetArray()){
                    if(i["trade_status"] == "tradable"){
                        string base = i["base"].GetString();  
                        string quote = i["quote"].GetString();   
                        
                        if( base + "-" + quote == chosenSymbol )
                            return 1;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;

        try{
            string result;          
            curl_api_with_header("https://api.gateio.ws/api/v4/spot/order_book?currency_pair=" + symbol + "&limit=20", result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("asks")){
                
                for(auto&& i : d["asks"].GetArray())
                    orderbook.asks[ stod( i[0].GetString() ) ] = stod( i[1].GetString() );   
                    
                for(auto&& i : d["bids"].GetArray())
                    orderbook.bids[ stod( i[0].GetString() ) ] = stod( i[1].GetString() ); 
                
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }

    void websocketInit_depth(){        
        Document d;       
        time_t current_time;  
        time(&current_time);
        int ct = current_time;
        string s = "{\"time\": " + to_string(ct) + ",\"channel\": \"spot.order_book\",\"event\": \"subscribe\", \"payload\": [\"" + symbol + "\", \"20\", \"100ms\"]}";
                
        try {
            init_http("api.gateio.ws");
            init_webSocket("api.gateio.ws", "443", "/ws/v4/");            
            write_Socket(s);
                    
            read_Socket();	
            buffer_clear();
                       
            while (true) {
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("result") && d["result"].HasMember("bids")){
  
                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["result"]["asks"].GetArray())
                        asks[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxAsk.unlock();
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["result"]["bids"].GetArray())
                        bids[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxBid.unlock();
                    
                }
                else
                    throw exception();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    }  
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }
    
    pair<double, double> get_fee() {
        return fee;
    } 
};

