que se aclaren con Spot y Futures
