// websocket se desconecta a los 2 minutos, donde esta el ping en la docu?

class fBtcex : public Exchange {
    const double fee = 0.0005;
    const string id = "fBtcex";
    unordered_map<string, double> priceAskAnt, priceBidAnt;
    int depth;

    vector<string> get_pairsP(){
         vector<string> v;  
         
         for(auto& i : coins)
            for(auto& j : i.second)
                for(auto& k : j.second.asks)
                    if(k.second == id){
                        string symbol = j.first + "-" + i.first;
                        v.push_back(symbol);
                        break;
                    } 
                    
         depth = v.size();
         return v;
    }

    public:
    void get_pairs(){        
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api.btcex.com/api/v1/public/get_instruments", result);
            d.Parse(result.c_str()); 
            
            for(auto& i : d["result"].GetArray()){
                if(i["currency"] == "PERPETUAL" && i["is_active"] == true){                     
                    string quote = i["base_currency"].GetString();
                    string base = i["quote_currency"].GetString();
    
                    if( coins.find(quote) == coins.end() || (coins.find(quote) != coins.end() && coins[quote].find(base) == coins[quote].end()) ){
                        tExchange e = tExchange();
                        e.asks.insert( {0, id} );
                        coins[quote][base] = e;
                    }
                    else
                        coins[quote][base].asks.insert( {0, id} );
                }
            }

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }       
    }

    void websocketInit_depth(){        
        Document d;
        string s, quoteAsset, baseAsset;

        try {   
            init_http("api.btcex.com");
            init_webSocket("api.btcex.com", "443", "/ws/api/v1"); 
            
            for(auto& i : get_pairsP()){
                string ss = "{\"jsonrpc\" : \"2.0\",\"id\" : 1,\"method\" : \"/public/subscribe\",\"params\" : {\"channels\":[\"ticker." + i + "-PERPETUAL.raw\"]}}";
                write_Socket(ss); 
                read_Socket();
                buffer_clear();
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
            
            for(int i = 0; i < depth * 4; i++){
                read_Socket();
                buffer_clear();
            }
                      
            while (true) {
                read_Socket();	
                d.Parse(get_socket_data().c_str());
printJson(d);
                s = d["params"]["data"]["instrument_name"].GetString();
                s = s.substr(0, s.length() - 10);
                quoteAsset = s.substr(s.length() - 4, s.length() - 1);
                baseAsset = s.substr(0, s.length() - 5);
                
                auto&& c = coins[quoteAsset][baseAsset];
                auto&& pAa = priceAskAnt[s];
                auto&& pBa = priceBidAnt[s];
                
                double priceA = stod(d["params"]["data"]["best_ask_price"].GetString());
                priceA += priceA * fee;

                c.mtx->lock();
                
                if(pAa != priceA){
                    c.asks.erase( {pAa, id} );
                    c.asks.insert( {priceA, id} );
                    pAa = priceA;
                }
                
                double priceB = stod(d["params"]["data"]["best_bid_price"].GetString());
                priceB -= priceB * fee;
                
                if(pBa != priceB){
                    c.bids.erase( {pBa, id} );
                    c.bids.insert( {priceB, id} );
                    pBa = priceB;
                }
                
                c.mtx->unlock();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	//ex.webSocket_close();
            return;
          }
    } 
};

