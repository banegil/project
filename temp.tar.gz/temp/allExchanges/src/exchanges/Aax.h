

class Aax : public Exchange {
    const string id = "Aax";
    const unsigned short idNum = 0;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETHUSDT";

    public:      
    bool get_pairs(){      
        Document d;
        unordered_map<string, bool> innovation;
        innovation["AVAX"] = innovation["SAND"] = innovation["AXS"] = innovation["WAVES"] = innovation["OP"] = innovation["ICP"] = innovation["PIT"] = innovation["BICO"] = innovation["JST"] = innovation["NFT"] = innovation["SWRV"]
         = innovation["HBAR"] = innovation["EGLD"] = innovation["ZBC"] = innovation["RSR"] = innovation["API3"] = innovation["XTZ"] = innovation["GALA"] = innovation["LOOKS"] = innovation["DOT"] = innovation["UNI"]
         = innovation["ETC"] = innovation["EOS"] = innovation["DYDX"] = innovation["GRT"] = innovation["KNC"] = innovation["SNT"] = 1;
         symbol = chosenSymbol;
         symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
         
        
        try{
            string result;          
            curl_api_with_header("https://api.aax.com/v2/instruments", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("data") && d["code"] == 1 && d["message"] == "success"){
                for(auto& i : d["data"].GetArray()){
                    if(i["status"] == "enable" && i["type"] == "spot"){ // USDT & BTC                   
                        string base = i["base"].GetString();
                        string quote = i["quote"].GetString();

                        if(innovation[base])
                            fee = {0.001, 0.0015}; // cannot change
                        else
                            fee = {0.0008, 0.0012}; // with 5000$ can be 0.00096 and 0.00072     
                            
                        if( base + "-" + quote == chosenSymbol )
                            return 1;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        } 
        return 0;      
    }
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api.aax.com/v2/market/orderbook?symbol=" + symbol + "&level=20", result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("asks")){
                
                for(auto&& i : d["asks"].GetArray())
                    orderbook.asks[ stod( i[0].GetString() ) ] = stod( i[1].GetString() );   
                    
                for(auto&& i : d["bids"].GetArray())
                    orderbook.bids[ stod( i[0].GetString() ) ] = stod( i[1].GetString() ); 
                                     
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }

    void websocketInit_depth(){        
        Document d;
        string s = "{\"e\": \"subscribe\", \"stream\": [\"" + symbol + "@book_20\"]}";

        try {   
            init_http("realtime.aax.com");
            init_webSocket("realtime.aax.com", "443", "/marketdata/v2/"); // ms: 300  
            write_Socket(s);
            
            for(int i = 0; i < 2; i++){
                read_Socket();	
                buffer_clear();
            }
            
            while (true) {
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("asks")){
                                
                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["asks"].GetArray())
                        asks[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxAsk.unlock();
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["bids"].GetArray())
                        bids[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxBid.unlock();
                    
                }
                else
                    throw exception();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }

    pair<double, double> get_fee() {
        return fee;
    }      
};

