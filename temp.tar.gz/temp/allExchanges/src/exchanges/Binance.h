

class Binance : public Exchange {
    const string id = "Binance";
    const unsigned short idNum = 2;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETHUSDT";

    public:
    bool get_pairs(){        
        Document d;
        unordered_map<string, bool> q, promotionUSDT, promotionBTC;
        q["USDT"] = q["ETH"] = q["BTC"] = q["USDC"] = q["USD"] = q["EUR"] = q["DAI"] = 1;
        promotionUSDT["BUSDUSDT"] = promotionUSDT["TUSDUSDT"] = promotionUSDT["USDCUSDT"] = promotionUSDT["USDPUSDT"] = 1; 
        promotionBTC["BTCBUSD"] = promotionBTC["BTCTUSD"] = promotionBTC["BTCUSDC"] = promotionBTC["BTCUSDP"] = promotionBTC["BTCUSDT"] = 1;
        symbol = chosenSymbol;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
                
        try{
            string result;          
            curl_api_with_header("https://api1.binance.com/api/v3/exchangeInfo", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("symbols")){
                for(auto& i : d["symbols"].GetArray()){
                    if(i["status"] == "TRADING" && i["isSpotTradingAllowed"] == true){     
                        string base = i["baseAsset"].GetString();
                        string quote = i["quoteAsset"].GetString();
                        pair<double, double> p;
                
                        if(promotionUSDT[base + quote] || promotionBTC[base + quote])
                            fee = {0, 0}; 
                        else if(quote == "BUSD")
                            fee = {0, 0.00075};
                        else
                            fee = {0.00075, 0.00075}; 

                        if(base + "-" + quote == chosenSymbol)
                            return 1;
                    }
                }
            }
            else
                throw exception();
                

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api2.binance.com/api/v3/depth?symbol=" + symbol + "&limit=20", result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("bids")){
                
                for(auto&& i : d["asks"].GetArray())
                    orderbook.asks[ stod( i[0].GetString() ) ] = stod( i[1].GetString() );   
                    
                for(auto&& i : d["bids"].GetArray())
                    orderbook.bids[ stod( i[0].GetString() ) ] = stod( i[1].GetString() ); 
                
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }

    void websocketInit_depth(){        
        Document d;         
        string symbol = chosenSymbol;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        transform(symbol.begin(), symbol.end(), symbol.begin(),
        [](unsigned char c){ return tolower(c); });
        string s = "/ws/" + symbol + "@depth20@100ms";

        try {
            init_http("stream.binance.com");
            init_webSocket("stream.binance.com", "443", s.c_str());
                          
            while (true) {
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("asks")){
                                
                    mtxAsk.lock();
                    asks.clear();
                    for(auto&& i : d["asks"].GetArray())
                        asks[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxAsk.unlock();
                        
                    mtxBid.lock();
                    bids.clear();
                    for(auto&& i : d["bids"].GetArray())
                        bids[ stod(i[0].GetString()) ] = stod(i[1].GetString());
                    mtxBid.unlock();
                    
                }
                else
                    throw exception();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
    
    string get_id(){
        return id;
    } 
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }
    
    pair<double, double> get_fee() {
        return fee;
    } 
};

