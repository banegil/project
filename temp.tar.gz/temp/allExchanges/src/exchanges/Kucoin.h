

class Kucoin : public Exchange {
    const string id = "Kucoin";
    const unsigned short idNum = 9;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.0008, 0.0008};
        unordered_map<string, bool> b;
        b["1EARTH"] = b["2CRZ"] = b["ABBC"] = b["ACA"] = b["ACE"] = b["ADS"] = b["AFK"] = b["AI"] = b["AIOZ"] = b["AKT"] = b["ALBT"] = b["ALPACA"] = b["APL"] = b["ARKER"] = b["ARNM"] = b["ARRR"] = b["AURY"] = b["AUSD"] = b["AXC"] = 
        b["BASIC"] = b["BFC"] = b["BIFI"] = b["BLOK"] = b["BMON"] = b["BNC"] = b["BOA"] = b["BONDLY"] = b["BOSON"] = b["BRISE"] = b["BULL"] = b["CARD"] = b["CARR"] = b["CAS"] = b["CCD"] = b["CEEK"] = b["CERE"] = b["CEUR"] = b["CFG"] = b["CGG"] =
        b["CIRUS"] = b["CPOOL"] = b["CQT"] = b["CREDI"] = b["CSPR"] = b["CTI"] = b["CUDOS"] = b["CULT"] = b["CUSD"] = b["CWEB"] = b["CWS"] = b["DAO"] = b["DAPPX"] = b["DFI"] = b["DFYN"] = b["DG"] = b["DINO"] = b["DIVI"] = b["DMTR"] = b["DORA"] = 
        b["DPET"] = b["DPI"] = b["DPR"] = b["DREAMS"] = b["DSLA"] = b["DVPN"] = b["DYP"] = b["EDG"] = b["EFX"] = b["EGAME"] = b["ELON"] = b["EPK"] = b["EQX"] = b["EQZ"] = b["ERG"] = b["ERSDL"] = b["ETHO"] = b["EVER"] = b["FALCONS"] = b["FCD"] =
        b["FCL"] = b["FCON"] = b["FEAR"] = b["FLAME"] = b["FLY"] = b["FORM"] = b["FORWARD"] = b["FRA"] = b["FRM"] = b["FRR"] = b["FTG"] = b["GAFI"] = b["GALAX"] = b["GEEQ"] = b["GENS"] = b["GGG"] = b["GHX"] = b["GLCH"] = b["GLMR"] = 
        b["GLQ"] = b["GMEE"] = b["GMM"] =  b["GOM2"] =  b["GOVI"] =  b["H3RO3S"] =  b["HAI"] =  b["HAKA"] =  b["HAPI"] = b["HAWK"] = b["HBB"] = b["HEART"] = b["HERO"] = b["HORD"] = b["HT"] = b["HTR"] = b["HYDRA"] = b["HYVE"] =
        b["IDEA"] = b["IHC"] = b["ILA"] = b["IOI"] = b["ISP"] = b["ITAMCUBE"] = b["JAM"] = b["JUP"] = b["KARA"] = b["KCS"] = b["KDA"] = b["KDOIN"] = b["KIN"] = b["KLV"] = b["KOK"] = b["KRL"] = b["KYL"] = b["LABS"] = b["LACE"] = 
        b["LAVAX"] = b["LAYER"] = b["LIKE"] = b["LOCG"] = b["LON"] = b["LOVE"] = b["LPOOL"] = b["LSS"] = b["LTX"] = b["MAHA"] = b["MAKI"] = b["MARS4"] = b["MARSH"] = b["MASK"] = b["MATTER"] = b["MIR"] = b["MITX"] = b["MJT"] = b["MLK"] = 
        b["MNET"] = b["MNST"] = b["MODEFI"] = b["MONI"] = b["MOOV"] = b["MOVR"] = b["MSWAP"] = b["MTRG"] = b["MTS"] = b["MV"] = b["NAKA"] = b["NDAU"] = b["NEER"] = b["NGC"] = b["NGM"] = b["NHCT"] = b["NIF"] = b["NORD"] = b["NTVRK"] = b["NUM"] = 
        b["ODDZ"] = b["OLE"] = b["ONSTON"] = b["OOE"] = b["OPUL"] = b["ORAI"] = b["ORC"] = b["OUSD"] = b["OVR"] = b["PBR"] = b["PBX"] = b["PCX"] = b["PEL"] = b["PHNX"] = b["PKF"] = b["PLATO"] = b["PLD"] = b["PLGR"] = b["PLU"] = 
        b["PMON"] = b["POL"] = b["POLC"] = b["POLK"] = b["POLX"] = b["PRQ"] = b["PSL"] = b["PUNDIX"] = b["PYR"] = b["QI"] = b["QRDO"] = b["RACEFI"] = b["RANKER"] = b["RBP"] = b["REAP"] = b["REV3L"] = b["REVU"] = b["REVV"] = b["RFOX"] = 
        b["RLY"] = b["RMRK"] = b["RNDR"] = b["ROAR"] = b["ROSE"] = b["ROSN"] = b["ROUTE"] = b["RPC"] = b["SCLP"] = b["SDAO"] = b["SDN"] = b["SFUND"] = b["SHFT"] = b["SHILL"] = b["SHX"] = b["SIENNA"] = b["SIN"] = b["SKEY"] = b["SLCL"] = b["SLIM"] = 
        b["SOLR"] = b["SON"] = b["SOS"] = b["SOV"] = b["SPI"] = b["SRBP"] = b["SRK"] = b["STARLY"] = b["STC"] = b["STEPWATCH"] = b["STG"] = b["STND"] = b["STRONG"] = b["SURV"] = b["SWASH"] = b["SWINGBY"] = b["SWP"] = b["SYNR"] = b["TARA"] = 
        b["TAUM"] = b["TCP"] = b["TIDAL"] = b["TLOS"] = b["TOWER"] = b["TRADE"] = b["TRVL"] = b["TXA"] = b["UFO"] = b["UMB"] = b["UNB"] = b["UNIC"] = b["UNO"] = b["UOS"] = b["UPO"] = b["URUS"] = b["VAI"] = b["VEED"] = b["VEGA"] = 
        b["VEMP"] = b["VISION"] = b["VLX"] = b["VXV"] = b["WAL"] = b["WELL"] = b["WEMIX"] = b["WILD"] = b["WMT"] = b["WOMBAT"] = b["WOOP"] = b["WSIENNA"] = b["XAVA"] = b["XCAD"] = b["XCN"] = b["XCUR"] = b["XDC"] = b["XDEFI"] = b["XED"] = b["XHV"] = 
        b["XNL"] = b["XPRT"] = b["XSR"] = b["XTAG"] = b["XTM"] = b["XWG"] = b["YFDAI"] = b["YLD"] = b["YOP"] = b["ZCX"] = b["ZEE"] = b["ZKT"] = 1;
        unordered_map<string, bool> c;
        c["BURP"] = c["CHMB"] = c["CLH"] = c["COMB"] = c["CWAR"] = c["FT"] = c["GARI"] = c["HIBAYC"] = c["HIENS3"] = c["HIENS4"] = c["HIPUNKS"] = c["HISAND33"] = c["HOTCROSS"] = c["IXS"] = c["LITH"] = c["MELOS"] = c["MEM"] = c["MLS"] = 
        c["NWC"] = c["PDEX"] = c["PLY"] = c["VELO"] = c["VR"] = 1;

        try{
            string result;          
            curl_api_with_header("https://api.kucoin.com/api/v1/symbols", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("data") && d["code"] == "200000"){
                for(auto& i : d["data"].GetArray()){
                    if(i["enableTrading"] == true){
                        string base = i["baseCurrency"].GetString();  
                        string quote = i["quoteCurrency"].GetString(); 
                        
                        if(b.find(base) != b.end())
                            fee = {0.0016, 0.0016}; 
                        else if(c.find(base) != c.end())
                            fee = {0.0024, 0.0024};
                        
                        if( base + "-" + quote == chosenSymbol )
                            return 1;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;

        try{
            string result;          
            curl_api_with_header("https://api.kucoin.com/api/v1/market/orderbook/level2_20?symbol=" + chosenSymbol, result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("code") && d["code"] == "200000" && d.HasMember("data") && d["data"].HasMember("bids")){

                for(auto&& i : d["data"]["asks"].GetArray())
                    orderbook.asks[ stod( i[0].GetString() ) ] = stod( i[1].GetString() );   
                    
                for(auto&& i : d["data"]["bids"].GetArray())
                    orderbook.bids[ stod( i[0].GetString() ) ] = stod( i[1].GetString() ); 

            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }

    void websocketInit_depth(){        
        Document d;         
        int pingInterval;
        vector <string> v;
        string token, endpoints, result, s;
        
        string idC = "154591120590802";
        s = "https://api.kucoin.com/api/v1/bullet-public";

        curl_api_with_headerPost(s, result, v, "", "POST");
        d.Parse(result.c_str());        

        endpoints = d["data"]["instanceServers"][0]["endpoint"].GetString();
        string endpoint = endpoints.substr(6,17);
        token = d["data"]["token"].GetString();
        pingInterval = d["data"]["instanceServers"][0]["pingInterval"].GetUint64();
        pingInterval /= 1000; 
                
        try {
            init_http(endpoint);
            s = "/endpoint?token=" + token + "&[connectId=" + idC + "]";
            init_webSocket(endpoint, "443", s.c_str());
            
            read_Socket();	
            buffer_clear();
            write_Socket(R"({"id":"154591120590802","type":"ping"})");
            s = "{\"id\": 154591120590802,\"type\": \"subscribe\",\"topic\": \"/spotMarket/level2Depth50:" + chosenSymbol + "\",\"response\": false}";
            write_Socket(s);

            time_t current_time;
            time(&current_time);
            int ct = current_time;                         
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                
                if(ct2 - ct >= pingInterval - 2){
                    ct = ct2;
                    write_Socket(R"({"id":"1545910660739","type":"ping"})");
                }
            
                read_Socket();	
                d.Parse(get_socket_data().c_str());
                
                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("asks")){
                
                    mtxAsk.lock();
                    asks.clear();
                    for(int i = 0; i < 20; i++)
                        asks[ stod(d["data"]["asks"][i][0].GetString()) ] = stod(d["data"]["asks"][i][1].GetString());
                    mtxAsk.unlock();
                        
                    mtxBid.lock();
                    bids.clear();
                    for(int i = 0; i < 20; i++)
                        bids[ stod(d["data"]["bids"][i][0].GetString()) ] = stod(d["data"]["bids"][i][1].GetString());
                    mtxBid.unlock();
                
                }
                else if(!(d.HasMember("type") && d["type"] == "pong"))
                    throw exception(); 

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
    
    string get_id(){
        return id;
    } 
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }
    
    pair<double, double> get_fee() {
        return fee;
    } 
};

