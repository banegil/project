

class Cryptocom : public Exchange {
    const string id = "Cryptocom";
    const unsigned short idNum = 5;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETH_USDT";

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.000728, 0.000728}; // with 1200$ 0.00069
        symbol = chosenSymbol;
        symbol[symbol.find('-')] = '_'; 
        
        try{
            string result;          
            curl_api_with_header("https://api.crypto.com/v2/public/get-instruments", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("result") && d["code"] == 0){
                for(auto& i : d["result"]["instruments"].GetArray()){     
                    string quote = i["quote_currency"].GetString();  
                    string base = i["base_currency"].GetString(); 

                    if( base + "-" + quote == chosenSymbol )
                        return 1;
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }      
        return 0;
    }
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;

        try{
            string result;          
            curl_api_with_header("https://api.crypto.com/v2/public/get-book?instrument_name=" + symbol + "&depth=20", result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("code") && d["code"] == 0 && d.HasMember("result") && d["result"].HasMember("depth")){
                
                for(auto&& i : d["result"]["data"][0]["asks"].GetArray())
                    orderbook.asks[ i[0].GetDouble() ] = i[1].GetDouble();    
                    
                for(auto&& i : d["result"]["data"][0]["bids"].GetArray())
                    orderbook.bids[ i[0].GetDouble() ] = i[1].GetDouble();     
                
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }

    void websocketInit_depth(){        
        Document d;
        string s = "{\"id\": 11,\"method\": \"subscribe\",\"params\": {\"channels\": [\"book." + symbol + ".150\"]},\"nonce\": 1587523073344}";
        
        try {   
            init_http("stream.crypto.com");
            init_webSocket("stream.crypto.com", "443", "/v2/market");
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            write_Socket(s);
            
            read_Socket();
            buffer_clear();
                     
            while (true) {
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("method")){
                    if(d["method"] == "subscribe"){
                        auto&& data = d["result"]["data"][0];
                        
                        mtxAsk.lock();
                        asks.clear();
                        for(int i = 0; i < 20; i++)
                            asks[ data["asks"][i][0].GetDouble() ] = data["asks"][i][1].GetDouble();
                        mtxAsk.unlock();
                            
                        mtxBid.lock();
                        bids.clear();
                        for(int i = 0; i < 20; i++)
                            bids[ data["bids"][i][0].GetDouble() ] = data["bids"][i][1].GetDouble();
                        mtxBid.unlock();
                    
                    }
                    else if(d["method"] == "public/heartbeat"){
                        s = "{\"id\":" + to_string(d["id"].GetUint64()) + ",\"method\":\"public/respond-heartbeat\"}";
                        write_Socket(s); 
                    }
                    else
                        throw exception();
                }
                else
                    throw exception();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }
    
    pair<double, double> get_fee() {
        return fee;
    } 
};

