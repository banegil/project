

class Mexc : public Exchange {
    const string id = "Mexc";
    const unsigned short idNum = 10;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETHUSDT";

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.0016, 0.0016};
        symbol = chosenSymbol;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        
        try{
            string result;          
            curl_api_with_header("https://api.mexc.com/api/v3/exchangeInfo", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("symbols")){
                for(auto& i : d["symbols"].GetArray()){
                    if(i["status"] == "ENABLED" && i["isSpotTradingAllowed"] == true){                
                        string base = i["baseAsset"].GetString();
                        string quote = i["quoteAsset"].GetString();

                        if( base + "-" + quote == chosenSymbol )
                            return 1;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }       
        return 0;
    }  
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api.mexc.com/api/v3/depth?symbol=" + symbol + "&limit=20", result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("bids")){
                
                for(auto&& i : d["asks"].GetArray())
                    orderbook.asks[ stod( i[0].GetString() ) ] = stod( i[1].GetString() );   
                    
                for(auto&& i : d["bids"].GetArray())
                    orderbook.bids[ stod( i[0].GetString() ) ] = stod( i[1].GetString() ); 
                
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }

    void websocketInit_depth(){        
        Document d;
        string s = chosenSymbol;
        s[s.find('-')] = '_';
        s = "{\"op\":\"sub.depth\",\"symbol\":\"" + s + "\"}";

        try {   
            long long seqNum = 0;
            init_http("wbs.mexc.com");
            init_webSocket("wbs.mexc.com", "443", "/raw/ws"); 
            write_Socket(R"({"method":"ping"})");
            write_Socket(s); 
              
            time_t current_time;
            time(&current_time);
            int ct = current_time;          
            while (true) {
                time(&current_time);
                int ct2 = current_time;
            
                if(ct2 - ct >= 10){
                    ct = ct2;
                    write_Socket(R"({"method":"ping"})");
                }
            
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("version")){
                    if(seqNum == 0 || seqNum + 1 == stoll( d["data"]["version"].GetString() )){
                        seqNum = stoll( d["data"]["version"].GetString() );
                
                        if(d["data"].HasMember("asks")){
                            mtxAsk.lock();
                            for(auto&& i : d["data"]["asks"].GetArray()){
                                double price = stod( i["p"].GetString() );
                                double qty = stod( i["q"].GetString() );
                                
                                if(qty == 0.0)
                                    asks.erase(price);
                                else
                                    asks[price] = qty;
                            }
                            
                            if(asks.size() > 30)
                                asks.erase(prev(asks.end()));
                            
                            mtxAsk.unlock();
                        }
                        
                        if(d["data"].HasMember("bids")){
                            mtxBid.lock();
                            for(auto&& i : d["data"]["bids"].GetArray()){
                                double price = stod( i["p"].GetString() );
                                double qty = stod( i["q"].GetString() );
                                
                                if(qty == 0.0)
                                    bids.erase(price);
                                else
                                    bids[price] = qty;
                            }
                            
                            if(bids.size() > 30)
                                bids.erase(prev(bids.end()));
                            
                            mtxBid.unlock();
                        }
                    }
                    else{
                        const string& err = "<wss_depth> " + id + " Packet loss, reconnecting...";
                        writte_err( "err.txt", err ); 
                        seqNum = 0;
                        write_Socket(s);
                    }
                        
                }
                else if(d["channel"] != "pong")
                    throw exception();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }
    
    pair<double, double> get_fee() {
        return fee;
    } 
};

