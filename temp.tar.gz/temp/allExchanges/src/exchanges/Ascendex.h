

class Ascendex : public Exchange {
    const string id = "Ascendex";
    const unsigned short idNum = 1;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETH/USDT";

    public:
    bool get_pairs(){      
        Document d;
        unordered_map<string, bool> largeCap;
        largeCap["BTC"] = largeCap["ETH"] = largeCap["XRP"] = largeCap["USDT"] = largeCap["BCH"] = largeCap["LTC"] = largeCap["EOS"] = largeCap["BNB"] = largeCap["BSV"] = largeCap["XLM"] = largeCap["ADA"] = largeCap["TRX"] = largeCap["LINK"] = largeCap["HT"]
         = largeCap["OKB"] = largeCap["ATOM"] = largeCap["DASH"] = largeCap["ETC"] = largeCap["NEO"] = largeCap["XEM"] = largeCap["DOGE"] = largeCap["ZEC"] = largeCap["ALGO"] = largeCap["DOT"] = largeCap["FIL"] = largeCap["UNI"]
         = largeCap["FTT"] = 1;
        symbol = chosenSymbol;
        symbol[symbol.find('-')] = '/';         
        
        try{
            string result;          
            curl_api_with_header("https://ascendex.com/api/pro/v1/cash/products", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("data") && d["code"] == 0){
                for(auto& i : d["data"].GetArray()){
                    if(i["statusCode"] == "Normal"){          
                        string s = i["symbol"].GetString();
                        string base = s.substr(0, s.find('/'));
                        string quote = s.substr(s.find('/') + 1, s.length() - 1);
                
                        if(largeCap[base])
                            fee = {0.001, 0.001}; // with 2000$ can be 0.00075 and 0.00085
                        else
                            fee = {0.002, 0.002}; // with 2000$ can be 0.0016 and 0.0018

                        if(base + "-" + quote == chosenSymbol)
                            return 1;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://ascendex.com/api/pro/v1/depth?symbol=" + symbol, result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("code") && d["code"] == 0 && d.HasMember("data") && d["data"].HasMember("symbol")){
                
                for(auto&& i : d["data"]["data"]["asks"].GetArray())
                    orderbook.asks[ stod( i[0].GetString() ) ] = stod( i[1].GetString() ); 
                    
                for(auto&& i : d["data"]["data"]["bids"].GetArray())
                    orderbook.bids[ stod( i[0].GetString() ) ] = stod( i[1].GetString() );                
                
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }

    void websocketInit_depth(){        
        Document d;
        string s = "{ \"op\": \"sub\", \"id\": \"abc123\", \"ch\":\"depth:" + symbol + "\" }";
        
        try {
            unsigned long long seqNum = 0;
            init_http("ascendex.com");
            init_webSocket("ascendex.com", "443", "/api/pro/v2/stream");
            write_Socket(s); 

            read_Socket();
            buffer_clear();	

            while (true) {                     
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("asks")){
                    if(seqNum == 0 || seqNum + 1 == d["data"]["seqnum"].GetUint64()){
                        seqNum = d["data"]["seqnum"].GetUint64();
                    
                        mtxAsk.lock();
                        for(auto&& i : d["data"]["asks"].GetArray()){
                            double price = stod( i[0].GetString() );
                            double qty = stod( i[1].GetString() );
                            
                            if(qty == 0.0)
                                asks.erase(price);
                            else
                                asks[price] = qty;
                        }
                        mtxAsk.unlock();
                            
                        mtxBid.lock();
                        for(auto&& i : d["data"]["bids"].GetArray()){
                            double price = stod( i[0].GetString() );
                            double qty = stod( i[1].GetString() );
                            
                            if(qty == 0.0)
                                bids.erase(price);
                            else
                                bids[price] = qty;
                        }
                        mtxBid.unlock();
                    }
                    else{
                        const string& err = "<wss_depth> " + id + " Packet loss, reconnecting...";
                        writte_err( "err.txt", err ); 
                        seqNum = 0;
                        write_Socket(s);
                    }                    
                }
                else if(d.HasMember("m") && d["m"] == "ping")
                    write_Socket(R"({ "op": "pong" })");  
                else if(!(d.HasMember("m") && d["m"] == "sub"))
                    throw exception();;

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }
    
    pair<double, double> get_fee() {
        return fee;
    } 
};

