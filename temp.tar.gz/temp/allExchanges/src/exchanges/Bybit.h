

class Bybit : public Exchange {
    const string id = "Bybit";
    const unsigned short idNum = 3;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETHUSDT";

    public: 
    bool get_pairs(){        
        Document d;
        fee = {0.001, 0.001};
        symbol = chosenSymbol;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        
        try{
            string result;          
            curl_api_with_header("https://api.bytick.com/spot/v1/symbols", result);
            d.Parse(result.c_str()); 
            
            if(d.HasMember("result") && d["ret_code"] == 0 && d["ret_msg"] == "OK"){
                for(auto& i : d["result"].GetArray()){
                    if(i["showStatus"] == true){ 
                        string quote = i["quoteCurrency"].GetString();
                        string base = i["baseCurrency"].GetString(); 

                        if( base + "-" + quote == chosenSymbol )
                            return 1;
                    }
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;
    }
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://api.bybit.com/spot/quote/v1/depth?symbol=" + symbol + "&limit=20", result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("ret_code") && d["ret_code"] == 0 && d.HasMember("result") && d["result"].HasMember("bids")){
                
                for(auto&& i : d["result"]["asks"].GetArray())
                    orderbook.asks[ stod( i[0].GetString() ) ] = stod( i[1].GetString() );   
                    
                for(auto&& i : d["result"]["bids"].GetArray())
                    orderbook.bids[ stod( i[0].GetString() ) ] = stod( i[1].GetString() );
                
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }
   
    void websocketInit_depth(){        
        Document d;
        string s = "{\"topic\": \"depth\",\"event\": \"sub\",\"params\": {\"symbol\": \"" + symbol + "\",\"binary\": false}}";
        
        try {
            init_http("stream.bybit.com");
            init_webSocket("stream.bybit.com", "443", "/spot/quote/ws/v2"); // 100ms
            write_Socket(s); 

            read_Socket();	
            buffer_clear();                               

            time_t current_time;
            time(&current_time);
            int ct = current_time;                              
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                if(ct2 - ct >= 25){
                    ct = ct2;
                    write_Socket(R"({"op":"ping"})");
                }
                                           
                read_Socket();	
                d.Parse(get_socket_data().c_str());
                
                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("b")){
                                
                    mtxAsk.lock();
                    asks.clear();
                    for(int i = 0; i < 20; i++)
                        asks[ stod(d["data"]["a"][i][0].GetString()) ] = stod(d["data"]["a"][i][1].GetString());
                    mtxAsk.unlock();
                        
                    mtxBid.lock();
                    bids.clear();
                    for(int i = 0; i < 20; i++)
                        bids[ stod(d["data"]["b"][i][0].GetString()) ] = stod(d["data"]["b"][i][1].GetString());
                    mtxBid.unlock();
                    
                }
                else if (!d.HasMember("pong"))
                    throw exception();

                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }
    
    pair<double, double> get_fee() {
        return fee;
    } 
};

