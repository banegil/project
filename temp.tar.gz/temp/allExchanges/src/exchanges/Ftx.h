

class Ftx : public Exchange {
    const string id = "Ftx";
    const unsigned short idNum = 6;
    pair<double, double> fee;
    map<double, double> asks;
    map<double, double, greater<double>> bids;
    mutex mtxAsk, mtxBid;
    string symbol = "ETH/USDT";

    string scientificNotation(const double& d){
        ostringstream s;
        
        s << d;
        string ss = s.str();
        
        auto&& found = ss.find('.');

        if (found == std::string::npos)
            ss += ".0";
            
        return ss;        
    }

    unsigned long checkSum(){
        string s = "";
        
        auto&& i = asks.begin();
        auto&& j = bids.begin();  
        auto&& iEnd = asks.end();
        auto&& jEnd = bids.end(); 
             
        while(i != iEnd && j != jEnd){
            if(j != jEnd){
                s += scientificNotation(j->first) + ":" + scientificNotation(j->second) + ":";
                ++j;
            }
            
            if(i != iEnd){
                s += scientificNotation(i->first) + ":" + scientificNotation(i->second) + ":";
                ++i;
            }
        }
            
        while(i != iEnd){
            s += scientificNotation(i->first) + ":" + scientificNotation(i->second) + ":";
            ++i;
        }
        
        while(j != jEnd){
            s += scientificNotation(j->first) + ":" + scientificNotation(j->second) + ":";
            ++j;
        }
        
        s.pop_back();
        return CRC32(s);
    }

    public:
    bool get_pairs(){        
        Document d;
        fee = {0.000194, 0.000679}; // with 675$ 0 maker, with 4000$ -0.0005 maker
        symbol = chosenSymbol;
        symbol[symbol.find('-')] = '/';
        
        try{
            string result;          
            curl_api_with_header("https://ftx.com/api/markets", result);
            d.Parse(result.c_str()); 

            if(d.HasMember("result") && d["success"] == true){
                for(auto& i : d["result"].GetArray()){
                    if(i["enabled"] == true && i["futureType"].IsNull()){
                        string base = i["baseCurrency"].GetString();
                        string quote = i["quoteCurrency"].GetString();

                        if( base + "-" + quote == chosenSymbol )
                            return 1;
                    }               
                }
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_pairs> " + id + string(e.what()) ); 
         	printJson(d);
         	return 0;
        }
        return 0;       
    }
    
    void get_orderbook(tOrderbook& orderbook){
        Document d;
        
        try{
            string result;          
            curl_api_with_header("https://ftx.com/api/markets/" + symbol + "/orderbook?depth=20", result);
            d.Parse(result.c_str()); 
            
            if(d.IsObject() && d.HasMember("success") && d["success"] == true && d.HasMember("result") && d["result"].HasMember("bids")){
                
                for(auto&& i : d["result"]["asks"].GetArray())
                    orderbook.asks[ i[0].GetDouble() ] = i[1].GetDouble();    
                    
                for(auto&& i : d["result"]["bids"].GetArray())
                    orderbook.bids[ i[0].GetDouble() ] = i[1].GetDouble();                  
                
            }
            else
                throw exception();

        } catch (std::exception const& e) {
         	writte_err( "err.txt", "ERROR: <get_orderbook> " + id + string(e.what()) ); 
         	printJson(d);
         	return;
        }   
    }

    void websocketInit_depth(){        
        Document d;
        string s = "{\"op\": \"subscribe\", \"channel\": \"orderbook\", \"market\": \"" + symbol + "\"}";

        try {   
            init_http("ftx.com");
            init_webSocket("ftx.com", "443", "/ws");
            write_Socket(s);
            
            read_Socket();	
            buffer_clear();            
                  
            while (true) {
                read_Socket();	
                d.Parse(get_socket_data().c_str());

                if(d.IsObject() && d.HasMember("data") && d["data"].HasMember("bids")){
                        mtxAsk.lock();
                        for(auto&& i : d["data"]["asks"].GetArray()){
                            double price = i[0].GetDouble();
                            double qty = i[1].GetDouble();
                            
                            if(qty == 0.0)
                                asks.erase(price);
                            else
                                asks[price] = qty;
                        }
                        mtxAsk.unlock();
                            
                        mtxBid.lock();
                        for(auto&& i : d["data"]["bids"].GetArray()){
                            double price = i[0].GetDouble();
                            double qty = i[1].GetDouble();
                            
                            if(qty == 0.0)
                                bids.erase(price);
                            else
                                bids[price] = qty;
                        }
                        mtxBid.unlock();
                }
                else if(!d.HasMember("market"))
                    throw exception();
                    
                if(checkSum() != d["data"]["checksum"].GetUint64()){
                    const string& err = "<wss_depth> " + id + " Packet loss, reconnecting...";
                    writte_err( "err.txt", err );
                    
                    s = "{\"op\": \"unsubscribe\", \"channel\": \"orderbook\", \"market\": \"" + symbol + "\"}";
                    write_Socket(s);
                    s = "{\"op\": \"subscribe\", \"channel\": \"orderbook\", \"market\": \"" + symbol + "\"}";
                    write_Socket(s);
                }
                
                buffer_clear();
            }
        } catch (std::exception const& e) {
            const string& err = "ERROR: <wss_depth>  " + id + " " + string(e.what());
         	writte_err( "err.txt", err ); 
         	printJson(d);
         	webSocket_close();
            return;
          }
    } 
    
    string get_id(){
        return id;
    }
    
    unsigned short get_idnum(){
        return idNum;
    }
    
    pair<double, unsigned short> bestAsk_taker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first + asks.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestBid_taker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first - bids.begin()->first * fee.second, idNum };
    }
    
    pair<double, unsigned short> bestAsk_maker(){
        lock_guard<mutex> lock(mtxAsk);
        return { asks.begin()->first - asks.begin()->first * fee.first, idNum };
    }
    
    pair<double, unsigned short> bestBid_maker(){
        lock_guard<mutex> lock(mtxBid);
        return { bids.begin()->first + bids.begin()->first * fee.first, idNum };
    }
    
    map<double, double> get_asks() {
        lock_guard<mutex> lock(mtxAsk);
        return asks;
    }
    
    map<double, double, greater<double>> get_bids() {
        lock_guard<mutex> lock(mtxBid);
        return bids;
    }
    
    pair<double, double> get_fee() {
        return fee;
    } 
};

