
void pairExchangesTakerStrategy(multimap<double, unsigned short>& bestAsks, multimap<double, unsigned short, greater<double>>& bestBids, const array<pair<double, double>, MAX_EXCHANGES>& fees, const unsigned short& N,
                                const vector<string>& nameExchanges, unordered_map<string, pair<double, double>>& bestPairs, const array<unsigned short, MAX_EXCHANGES>& index){    

    bestAsks.clear();
    bestBids.clear();
    
    auto&& aFuture = async(loadBO_taker, ref(bestAsks), N);
    auto&& bFuture = async(loadBB_taker, ref(bestBids), N);        
    aFuture.get(); bFuture.get();
    
    double diff = 1 - bestAsks.begin()->first / bestBids.begin()->first;
    
    if(DEBUG){
        cout << "  ASKS:\n";       
        for(auto&& i = bestAsks.rbegin(); i != bestAsks.rend(); ++i)
            cout << " " << left << setw(12) << i->first << nameExchanges[i->second] << "\n";
            
        cout << "  BIDS:\n";       
        for(auto&& i : bestBids)
            cout << " " << left << setw(12) << i.first << nameExchanges[i.second] << "\n";
            
        cout << "  diff: " << diff * 100 << "%\n\n"; 
    }
    
    auto&& itA = bestAsks.begin();
    auto&& itAEnd = bestAsks.end();
    auto&& itB = bestBids.begin(); 
    auto&& itBEnd = bestBids.end();
    
    unsigned short idAsk = itA->second;
    unsigned short idBid = itB->second;
            
    if(diff > MAX_DIFF){
        set<unsigned short> exchanges;
        vector<tPairExchange> pairExchange;
    
        for(; diff > MAX_DIFF && itA != itAEnd; ++itA){
            idAsk = itA->second; 
            exchanges.insert(idAsk); 
            
            auto&& asks = ex[ index[idAsk] ]->get_asks(); 
            
            itB = bestBids.begin(); 
            itBEnd = bestBids.end();
        
            for(; diff > MAX_DIFF && itB != itBEnd; ++itB){ 
                idBid = itB->second;
                
                if(idAsk != idBid ){
                    exchanges.insert(idBid); 
                    auto&& bids = ex[ index[idBid] ]->get_bids(); 
                
                    auto&& ita = asks.begin();
                    auto&& itb = bids.begin();
                    auto&& itaEnd = asks.end();
                    auto&& itbEnd = bids.end();
                    
                    double askQtyCopy = ita->second;
                    double bidQtyCopy = itb->second;
                    double totalQuantity = 0;
                
                    while(diff > MAX_DIFF && ita != itaEnd && itb != itbEnd){            
                        double quantity = min(askQtyCopy, bidQtyCopy);
                        
                        askQtyCopy -= quantity;
                        bidQtyCopy -= quantity;
                        
                        if(askQtyCopy  == 0){
                            ++ita;
                            askQtyCopy = ita->second;
                        }    
                        
                        if(bidQtyCopy == 0){
                            ++itb;
                            bidQtyCopy = itb->second;
                        }
                            
                        totalQuantity += quantity;                   
                        diff = 1 - (ita->first + ita->first * fees[idAsk].first) / (itb->first - itb->first * fees[idBid].first);    
                    }  
                    
                    pairExchange.push_back( { idAsk, idBid, totalQuantity, 0 } );  
                }           
            }
        }
        
        // get_orderbook
        unordered_map<unsigned short, tOrderbook> orderbooks; // <idExchange, tOrderbook>
        vector<future<void>> f(exchanges.size());
        
        int contI = 0;
        for(auto&& i : exchanges)
            f[contI++] = async(&Exchange::get_orderbook, ex[ index[i] ], ref(orderbooks[i]));
        
        for(int i = 0; i < contI; i++)
            f[i].get(); 
        
        
        string best;
        double pBest = 0;    
        for(auto&& i : pairExchange){
            auto&& asks = orderbooks[i.idBuyer].asks;
            auto&& bids = orderbooks[i.idSeller].bids;
            
            /*if(DEBUG){
                cout << "  Asks: " << nameExchanges[i.idBuyer] << "\n";
                for(auto&& i = asks.rbegin(); i != asks.rend(); ++i)
                    cout << " " << left << setw(12) << i->first << i->second << "\n";
                    
                cout << "  Bids: " << nameExchanges[i.idSeller] << "\n";
                for(auto&& i : bids)
                    cout << " " << left << setw(12) << i.first << i.second << "\n";
            }*/
            
            double qty = i.qty / 2;
            
            auto&& ita = asks.begin();
            auto&& itb = bids.begin();
            auto&& itaEnd = asks.end();
            auto&& itbEnd = bids.end();  
            
            double askQtyCopy = ita->second;
            double bidQtyCopy = itb->second;     

            cout << " --------------------------------------------------------- ORDER ---------------------------------------------------------\n";
            cout << " BUY: " << left << setw(12) << nameExchanges[i.idBuyer] << "SELL: " << left << setw(12) << nameExchanges[i.idSeller] << left << setw(12) << "qty:" << "profit:\n";
                   
            while(qty != 0 && ita != itaEnd && itb != itbEnd){ 
                double quantity = min(qty, min(askQtyCopy, bidQtyCopy));           
                
                askQtyCopy -= quantity;
                bidQtyCopy -= quantity;
                qty -= quantity; 
                
                double c1 = itb->first - itb->first * fees[i.idSeller].first;
                double c2 = ita->first + ita->first * fees[i.idBuyer].first;
                double c3 = (c1 - c2) * quantity;
                i.profit += c3; 

                if(DEBUG == 1)
                    cout << " " << left << setw(17) << c2 << left << setw(18) << c1 << left << setw(12) << quantity << c3 << "$\n";
                
                if(askQtyCopy == 0){
                    ++ita;
                    askQtyCopy = ita->second;
                } 
                
                if(bidQtyCopy == 0){
                    ++itb;
                    bidQtyCopy = itb->second;
                }  
            }

            auto&& s = to_string(i.idBuyer) + "-" + to_string(i.idSeller);
            bestPairs[s].first += i.qty;
            bestPairs[s].second += i.profit;
            
            if(bestPairs[s].second > pBest){
                pBest = bestPairs[s].second;
                best = nameExchanges[i.idBuyer] + "-" + nameExchanges[i.idSeller];
            }
            
            cout << "  total: qty " << left << setw(12) << i.qty << "profit/loss " << i.profit << "$\n";
            cout << "  TOTAL: Qty " << left << setw(12) << bestPairs[s].first << "Profit/loss " << bestPairs[s].second << "$\n";
            cout << " -------------------------------------------------------------------------------------------------------------------------\n";
            
        } // for(auto&& i : pairExchange)
        
        cout << " BEST: " << best << "  PROFIT/LOSS: " << pBest << "\n\n";     
        
    } // if(diff > MAX_DIFF)
   
}



