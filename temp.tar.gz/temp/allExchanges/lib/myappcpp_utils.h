
#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"
#include <zlib.h>

using namespace std;
using namespace rapidjson;

mutex mtxErr, mtxCurl;
    
void writte_err(const string& file, const string& s) {
    time_t now = time(0);
    char* dt = ctime(&now);
    mtxErr.lock();
    cout << dt << " " << s << '\n';
    ofstream output(file, std::ios::app);
    output << dt << " " << s << '\n';
    mtxErr.unlock();
}

void printJson(const Document& d){
    StringBuffer sb;
    PrettyWriter<StringBuffer> writer(sb);
    d.Accept(writer);
    puts(sb.GetString());
}

inline string my_toString(const double& d) noexcept {
    ostringstream s;
    s << fixed << d;  
            
    return s.str();        
}

/*inline string removeZeros(string str){
    while(str[str.length() - 1] == '0')
        str.pop_back();
    
    return str;  
}*/

inline unsigned long CRC32(const string& buffer) noexcept {
     return crc32(crc32(0L, Z_NULL, 0),(const unsigned char *)buffer.c_str(), buffer.length());
}
 
inline string decompress_gzip(const string& str) noexcept
{
    z_stream zs;                     
    memset(&zs, 0, sizeof(zs));

    if (inflateInit2(&zs, 15 + 16) != Z_OK)
        cout << "ERROR decompressing" << endl;

    zs.next_in = (Bytef*)str.data();
    zs.avail_in = str.size();

    int ret;
    char outbuffer[32768];
    string outstring;

    do {
        zs.next_out = reinterpret_cast<Bytef*>(outbuffer);
        zs.avail_out = sizeof(outbuffer);

        ret = inflate(&zs, 0);

        if (outstring.size() < zs.total_out) {
            outstring.append(outbuffer,
                             zs.total_out - outstring.size());
        }

    } while (ret == Z_OK);

    inflateEnd(&zs);

    if (ret != Z_STREAM_END) {     
        cout << "ERROR decompressing" << endl;
    }

    return outstring;
}

