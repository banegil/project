
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <iostream>
#include <future>
#include <curl/curl.h>
#include <ctype.h>
#include <cstdio>  
#include <cstring>  
#include <cstdlib> 
#include <unordered_map>
#include <map>
#include <fstream>
#include <mutex>
#include <iomanip>
#include <chrono>
#include <thread>
#include <cmath>
#include <ctime>
#include <set>

#include "../lib/myappcpp_utils.h"

struct tOrderbook {
    map<double, double> asks;
    map<double, double, greater<double>> bids;
};

#include "../src/exchange.h"

#define DEBUG 1
#define MAX_DIFF 0.0001
#define MAX_EXCHANGES 12


vector<Exchange*> ex;

string chosenSymbol = "ETH-USDT";

struct tPairExchange {
    unsigned short idBuyer;
    unsigned short idSeller;
    double qty;
    double profit;
};

// Exchanges
#include "../src/exchanges/Aax.h"
#include "../src/exchanges/Ascendex.h"
#include "../src/exchanges/Binance.h"
#include "../src/exchanges/Bybit.h"
#include "../src/exchanges/Coinex.h"
#include "../src/exchanges/Cryptocom.h"
#include "../src/exchanges/Ftx.h"
#include "../src/exchanges/Gateio.h"
#include "../src/exchanges/Huobi.h"
#include "../src/exchanges/Kucoin.h"
#include "../src/exchanges/Mexc.h"
#include "../src/exchanges/Okx.h"


void loadBO_taker(multimap<double, unsigned short>& asks, const int& N){
    for(int i = 0; i < N; i++){    
        auto&& bbo = ex[i]->bestAsk_taker();   
        if(bbo.first > 0)
            asks.insert(bbo); 
    } 
}

void loadBB_taker(multimap<double, unsigned short, greater<double>>& bids, const int& N){
    for(int i = 0; i < N; i++){    
        auto&& bbo = ex[i]->bestBid_taker();   
        if(bbo.first > 0)
            bids.insert(bbo); 
    }   
}

void loadBO_maker(multimap<double, unsigned short>& asks, const int& N){
    for(int i = 0; i < N; i++){    
        auto&& bbo = ex[i]->bestAsk_maker();   
        if(bbo.first > 0)
            asks.insert(bbo); 
    } 
}

void loadBB_maker(multimap<double, unsigned short, greater<double>>& bids, const int& N){
    for(int i = 0; i < N; i++){    
        auto&& bbo = ex[i]->bestBid_maker();   
        if(bbo.first > 0)
            bids.insert(bbo); 
    }   
}

// Strategies
#include "../src/strategies/pairExchangesTaker.h"

void doIniWebSocket(int i){
    ex[i]->websocketInit_depth();
}

void iniExchanges(array<pair<double, double>, MAX_EXCHANGES>& fees, array<unsigned short, MAX_EXCHANGES>& index){
    
    ex.push_back( new Aax() );
    ex.push_back( new Ascendex() );
    ex.push_back( new Binance() );
    ex.push_back( new Bybit() );
    ex.push_back( new Coinex() );
    ex.push_back( new Cryptocom() );
    ex.push_back( new Ftx() );
    ex.push_back( new Gateio() );
    ex.push_back( new Huobi() );
    ex.push_back( new Kucoin() );
    ex.push_back( new Mexc() );
    ex.push_back( new Okx() );
    
    for(int i = 0; i < ex.size(); i++){
        if(!ex[i]->get_pairs()){
            delete (ex[i]);
            ex.erase(ex.begin() + i);
            i--;
        }
        else{
            index[ex[i]->get_idnum()] = i;
            fees[ex[i]->get_idnum()] = ex[i]->get_fee();
            cout << " " << ex[i]->get_id() << endl;
        }
    }
    

    ex.resize(ex.size());
    ex.shrink_to_fit();
}











