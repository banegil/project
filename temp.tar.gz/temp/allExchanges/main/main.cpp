#include "include.h"



void ini(){  
    multimap<double, unsigned short> asks; // <minAsk, idExchange>
    multimap<double, unsigned short, greater<double>> bids; // <maxBid, idExchange>
    array<pair<double, double>, MAX_EXCHANGES> fees;
    unordered_map<string, pair<double, double>> bestPairs; // <idExchange + "-" + idExchange, <qty, profit>>
    array<unsigned short, MAX_EXCHANGES> index;
      
    cout << "  Getting active exchanges:" << endl;  
    iniExchanges(fees, index);
    int N = ex.size();
    cout << "  OK!" << endl << endl;
        
        long long minimum = 10000000000;
        while(1){
            unordered_map<unsigned short, tOrderbook> orderbooks; // <idExchange, tOrderbook>
            for(int i = 0; i < N; i++){
                    auto start = std::chrono::high_resolution_clock::now();
                ex[i]->get_orderbook(orderbooks[i]);
            		auto elapsed = std::chrono::high_resolution_clock::now() - start;
                    long long microseconds = std::chrono::duration_cast<std::chrono::milliseconds>(
                            elapsed).count();
                    cout << "ms: " << microseconds << " " << ex[i]->get_id() << endl;
                    minimum = min(microseconds, minimum);
            }
            cout << "minimum" << minimum << endl << endl;
        }

                
    /*cout << "  Starting websocket connection..." << endl;  
        
    vector<thread> ths(N);    
    for(int i = 0; i < N; i++) 
        ths[i] = thread (doIniWebSocket, i);

    this_thread::sleep_for(chrono::milliseconds(10000));
    cout << "  OK!" << endl << endl;
    
    vector<string> nameExchanges(MAX_EXCHANGES);
    if(DEBUG){        
        nameExchanges[0] = "Aax"; nameExchanges[1] = "Ascendex"; nameExchanges[2] = "Binance"; nameExchanges[3] = "Bybit"; nameExchanges[4] = "Coinex"; nameExchanges[5] = "Cryptocom"; nameExchanges[6] = "Ftx"; 
        nameExchanges[7] = "Gateio"; nameExchanges[8] = "Huobi"; nameExchanges[9] = "Kucoin"; nameExchanges[10] = "Mexc"; nameExchanges[11] = "Okx"; 
    }
    else{
        nameExchanges.resize(0);
        nameExchanges.shrink_to_fit();
    }
      
    
    while(1){  
            
        pairExchangesTakerStrategy(asks, bids, fees, N, nameExchanges, bestPairs, index);       
        
        this_thread::sleep_for(chrono::milliseconds(1000));
    }
    
    for(int i = 0; i < N; i++)
        ths[i].join();*/
}


int main() {
    cout << "\n";
    cout << "     .d8888. d8888b.  .d88b.  d888888b  .d8b.  d8888b. d8888b.   \n";
    cout << "     88'  YP 88  `8D .8P  Y8. `~~88~~' d8' `8b 88  `8D 88  `8D   \n";
    cout << "     `8bo.   88oodD' 88    88    88    88ooo88 88oobY' 88oooY'   \n";
    cout << "       `Y8b. 88~~~   88    88    88    88~~~88 88`8b   88~~~b.   \n";
    cout << "     db   8D 88      `8b  d8'    88    88   88 88 `88. 88   8D   \n";
    cout << "     `8888Y' 88       `Y88P'     YP    YP   YP 88   YD Y8888P'   \n\n\n";
                                                          
                                                          
                                                          
                                                                                                                    
    cout << "               **** Spot-Arbitrage (SIMULATION) ****\n\n";
    //cout << " Insert pair e.g.(ETH-USDT): ";
    //cin >> chosenSymbol;
    /*cout << " DEBUG mode? (yes/no): ";
    string debug;
    cin >> debug;
    if(debug == "y" || debug == "yes") {
        DEBUG = 1;
        cout << " Choose time interval in milliseconds: ";
        cin >> WAIT;
    }*/
    cout << '\n';

    curl_global_init(CURL_GLOBAL_ALL);    
    ini();
    return 0;
}
