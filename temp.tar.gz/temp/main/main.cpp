#include "include.h"


void ini(){      
    Bybit bin; 

    cout << "Starting ... " << endl;    

    auto e = async(&Bybit::websocketInit_depth, &bin);       
    auto ee = async(&Bybit::websocketInit_User, &bin);              

    this_thread::sleep_for(chrono::milliseconds(7000));    
    cout << "OK!" << endl;
     
    auto&& p1 = pairs[cc]; 
    auto&& p2 = pairs[cc1];
    auto&& p3 = pairs[cc2];
    
    double quantity = QUANTITY;
    bool exit = 0;
           
    auto p2bids = p2.get_bids();
    auto p1bids = p1.get_bids();
    auto p3asks = p3.get_asks();
    
    while(!exit){
        if(p1bids[0].first > 0 && p2bids[0].first > 0 && p3asks[0].first > 0)
            exit = 1;
            
        this_thread::sleep_for(chrono::milliseconds(500));
        p1bids = p1.get_bids();
        p2bids = p2.get_bids();
        p3asks = p3.get_asks(); 
        this_thread::sleep_for(chrono::milliseconds(500));
    } 
    
    while(1){ 
        p1bids = p1.get_bids();
        p2bids = p2.get_bids();
        p3asks = p3.get_asks();  

        const double& c = ((1 / priceOrder) * p2bids[0].first) / p3asks[0].first;
        const double& bestBid = p1bids[0].first;
        const bool& ahead = priceOrder < bestBid && c >= ORDER_BOUND;
    
        if(c < LOWER_BOUND || c > UPPER_BOUND || ahead){ 
            priceOrder = p2bids[0].first - p2bids[0].first * ORDER_BOUND;

            if(ok == 1){
                cout << "EXTECUTED!" << endl;
                this_thread::sleep_for(chrono::milliseconds(1000));
                priceOrder = PRICE;
                quantity_global = QUANTITY;
                ok = 0;
            }
            else{
                bin.send_CancelOrder();
                const double& rr= bin.send_order(cc,"buy", quantity_global, round(priceOrder * POW_CC) / POW_CC ); // LIMIT 
                if(rr == 12136.0){
                    quantity_global = QUANTITY;
                    bin.send_order(cc,"buy", quantity_global, round(priceOrder * POW_CC) / POW_CC ); // LIMIT 
                }    
                
                if(rr > 0.0)
                    cout << cc << endl;
            }   
        }
        
        if(ok)
            priceOrder = PRICE;
        
        this_thread::sleep_for(chrono::milliseconds(500));
    }
}


int main() {
    curl_global_init(CURL_GLOBAL_ALL);    
    ini();
    return 0;
}

/*
void ini(){      
    Binance bin;

    cout << "Starting ... " << endl;    
    auto e = async(&Binance::websocketInit_depth, &bin);       
    auto ee = async(&Binance::websocketInit_trades, &bin, bin.get_listenKey());              

    this_thread::sleep_for(chrono::milliseconds(7000));    
    cout << "OK!" << endl;
     
    auto&& p1 = pairs["btcusdc"]; 
    auto&& p2 = pairs["btcbusd"];
    auto&& p3 = pairs["usdcbusd"];
    
    int cont = 0; 
    double diffAverage = 0;
    double qtyAverage = 0;
    double priceOrder = 0;
    
    time_t current_time;
    time(&current_time);
    int ct = current_time;  
    while(1){
        time(&current_time);
        int ct2 = current_time;
        
        if(ct2 - ct > 10){
            ct = ct2;
            cout << "diffAverage: " << (diffAverage / cont) * 100 << ", qtyAverage: " << qtyAverage / cont << "\n";
            cont = diffAverage = qtyAverage = 0;
        }
    
        p1.mtx->lock(); p2.mtx->lock(); p3.mtx->lock();
        double c1 = (p2.bids[0].first / p1.bids[0].first) / p3.asks[0].first;
        p1.mtx->unlock(); p2.mtx->unlock(); p3.mtx->unlock();              
        
        if(c1 > 1){   
            int iA = 0, iB = 0, iC = 0;
            
            p1.mtx->lock(); p2.mtx->lock(); p3.mtx->lock();         
            auto p1B = p1.bids;
            auto p2B = p2.bids; 
            auto p3A = p3.asks;
            p1.mtx->unlock(); p2.mtx->unlock(); p3.mtx->unlock(); 
                    
            while(iA < 5 && iB < 5 && iC < 5 && (p2B[iB].first / p1B[iA].first) / p3A[iC].first > 1){
                double minimum = min(min(p2B[iB].second, p1B[iA].second), p3A[iC].second);
                
                p1B[iA].second -= minimum;
                p2B[iB].second -= minimum;
                p3A[iC].second -= minimum;
                
                if(p1B[iA].second == 0)
                    iA++;
                if(p2B[iB].second == 0)
                    iB++;
                if(p3A[iC].second == 0)
                    iC++;
                
                qtyAverage += minimum;
            }

            diffAverage += c1 - 1;            
            cont++;
        }            
                    
        this_thread::sleep_for(chrono::milliseconds(100));
    }
}
*/
