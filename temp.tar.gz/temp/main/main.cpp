#include "include.h"


void ini(const unsigned short& option, const unsigned short& test){  

    cout << " Starting ... " << endl;                 
    exchange_chosen->get_pairs();
    auto f = async(&Exchange::websocketInit_depth, exchange_chosen);
    future<void> f2;
    if(test == 2)
        f2 = async(&Exchange::websocketInit_User, exchange_chosen);
    
    this_thread::sleep_for(chrono::milliseconds(5000));    
    cout << " OK!" << endl << endl;
    
    // Just for test
    /*for(auto& i: coins)
        for(auto& j: i.second)
            cout << i.first << "-" << j.first << endl;*/
    
    if(option == 1) { // Taker
        while(1){        
        // iterate through baseAsset coin->first: BTC, ETH, DOT ...    
        for(auto& coin : coins){ 
            // iterate through a NxN matrix(top right triangle) of pairs of each coin: BTC has BTC/USDT, BTC/BUSD ...
            auto i = coin.second.begin();
            // i->first and j->first are quoteAsset (e.g. /USDT and /BUSD)
            for(auto it = ++coin.second.begin(); it != coin.second.end(); ++it, ++i){
                for(auto j = it; j != coin.second.end(); ++j){
                    // Just for test: cout << coin.first << "-" << i->first << "  " << coin.first << "-" << j->first << "  " << i->first << "-" << j->first << endl; 
                    if(1){
                                                                                  
                        // if BUSD/USDT exist
                        if(coins.find(i->first) != coins.end() && coins[i->first].find(j->first) != coins[i->first].end()){
                            bool done = 1;
                            i->second.mtx->lock();
                            j->second.mtx->lock();
                            coins[i->first][j->first].mtx->lock();
                            
                            // We check buy-market BTC/BUSD, sell-market BTC/USDT, buy-market BUSD/USDT
                            if(i->second.asks.size() > 0 && j->second.bids.size() > 0 && coins[i->first][j->first].asks.size() > 0){
                                double diff = ( ( (j->second.bids.begin()->first - j->second.bids.begin()->first * j->second.fee.second) / (i->second.asks.begin()->first + i->second.asks.begin()->first * i->second.fee.second) ) ) 
                                                / (coins[i->first][j->first].asks.begin()->first + coins[i->first][j->first].asks.begin()->first * coins[i->first][j->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){ 
                                    if(test == 2){   
                                        double quantity = min(i->second.asks.begin()->second, j->second.bids.begin()->second) * coins[coin.first]["USDT"].bids.begin()->first;                           
                                        if(quantity > MIN_QUANTITY){
                                            quantity = min(quantity, MAX_QUANTITY);
                                            auto&& f3 = async(&Exchange::send_triangular_order, exchange_chosen, "buy", "sell", "buy", coin.first + "-" + i->first, coin.first + "-" + j->first, i->first + "-" + j->first, quantity);
                                        }
                                    }
                                
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  A.Pairs: buy " << coin.first << "-" << i->first << " sell "
                                                             << coin.first << "-" << j->first << " buy "
                                                             << i->first   << "-" << j->first << " \n";
                                    done = 0;
                                }
                            }
                            
                            
                            // We check sell-market BTC/BUSD, buy-market BTC/USDT, sell-market BUSD/USDT
                            if(done && i->second.bids.size() > 0 && j->second.asks.size() > 0 && coins[i->first][j->first].bids.size() > 0){
                                double diff = ( ( (i->second.bids.begin()->first - i->second.bids.begin()->first  * i->second.fee.second) / (j->second.asks.begin()->first + j->second.asks.begin()->first * j->second.fee.second) ) ) 
                                                * (coins[i->first][j->first].bids.begin()->first - coins[i->first][j->first].bids.begin()->first * coins[i->first][j->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    if(test == 2){   
                                        double quantity = min(i->second.bids.begin()->second, j->second.asks.begin()->second) * coins[coin.first]["USDT"].bids.begin()->first;                           
                                        if(quantity > MIN_QUANTITY){
                                            quantity = min(quantity, MAX_QUANTITY);
                                            auto&& f3 = async(&Exchange::send_triangular_order, exchange_chosen, "buy", "sell", "sell", coin.first + "-" + j->first, coin.first + "-" + i->first, i->first + "-" + j->first, quantity);
                                        }
                                    }
                                
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  A.Pairs: buy " << coin.first << "-" << j->first << " sell "
                                                              << coin.first << "-" << i->first << " sell "
                                                              << i->first   << "-" << j->first << "\n";
                                }                           
                            }
                            
                            coins[i->first][j->first].mtx->unlock();
                            j->second.mtx->unlock();
                            i->second.mtx->unlock();
                        }
                        // if BUSD/USDT doesn't exist, try to reverse to USDT/BUSD, all the code above is just for de 3º pair coins[j->first][i->first]
                        else if(coins.find(j->first) != coins.end() && coins[j->first].find(i->first) != coins[j->first].end()){
                            bool done = 1;
                            i->second.mtx->lock();
                            j->second.mtx->lock();
                            coins[j->first][i->first].mtx->lock();
                            
                            // We check buy-market BTC/BUSD, sell-market BTC/USDT, sell-market USDT/BUSD
                            if(i->second.asks.size() > 0 && j->second.bids.size() > 0 && coins[j->first][i->first].bids.size() > 0){
                                double diff = ( ( (j->second.bids.begin()->first - j->second.bids.begin()->first * j->second.fee.second) / (i->second.asks.begin()->first + i->second.asks.begin()->first * i->second.fee.second) ) ) 
                                                * (coins[j->first][i->first].bids.begin()->first - coins[j->first][i->first].bids.begin()->first * coins[j->first][i->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    if(test == 2){   
                                        double quantity = min(i->second.asks.begin()->second, j->second.bids.begin()->second) * coins[coin.first]["USDT"].bids.begin()->first;                           
                                        if(quantity > MIN_QUANTITY){
                                            quantity = min(quantity, MAX_QUANTITY);
                                            auto&& f3 = async(&Exchange::send_triangular_order, exchange_chosen, "buy", "sell", "sell", coin.first + "-" + i->first, coin.first + "-" + j->first, j->first + "-" + i->first, quantity);
                                        }
                                    }
                                
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  B.Pairs: buy " << coin.first << "-" << i->first << " sell "
                                                             << coin.first << "-" << j->first << " sell "
                                                             << j->first   << "-" << i->first << "\n";
                                    done = 0;
                                }
                            }
                            
                            // We check sell-market BTC/BUSD, buy-market BTC/USDT, buy-market USDT/BUSD
                            if(done && i->second.bids.size() > 0 && j->second.asks.size() > 0 && coins[j->first][i->first].asks.size() > 0){
                                double diff = ( ( (i->second.bids.begin()->first - i->second.bids.begin()->first * i->second.fee.second) / (j->second.asks.begin()->first + j->second.asks.begin()->first * j->second.fee.second) ) ) 
                                                / (coins[j->first][i->first].asks.begin()->first + coins[j->first][i->first].asks.begin()->first * coins[j->first][i->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    if(test == 2){   
                                        double quantity = min(i->second.bids.begin()->second, j->second.asks.begin()->second) * coins[coin.first]["USDT"].bids.begin()->first;                           
                                        if(quantity > MIN_QUANTITY){
                                            quantity = min(quantity, MAX_QUANTITY);
                                            auto&& f3 = async(&Exchange::send_triangular_order, exchange_chosen, "buy", "sell", "buy", coin.first + "-" + j->first, coin.first + "-" + i->first, j->first + "-" + i->first, quantity);
                                        }
                                    }
                                
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  B.Pairs: buy " << coin.first << "-" << j->first << " sell "
                                                              << coin.first << "-" << i->first << " buy "
                                                              << j->first   << "-" << i->first << "\n";
                                }                           
                            }
                            
                            coins[j->first][i->first].mtx->unlock();
                            j->second.mtx->unlock();
                            i->second.mtx->unlock();
                        }
                    }
                    /*else
                        cout << " PROBLEM: " << coin.first << "-USDT doesn't exist, try BUSD or check it out\n";*/
                }
            }
        }
        cout << endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(WAIT));
        }
    }
    else{ // Maker
        while(1){        
            // iterate through baseAsset coin->first: BTC, ETH, DOT ...    
            for(auto& coin : coins){ 
                // iterate through a NxN matrix(top right triangle) of pairs of each coin: BTC has BTC/USDT, BTC/BUSD ...
                auto i = coin.second.begin();
                // i->first and j->first are quoteAsset (e.g. /USDT and /BUSD)
                for(auto it = ++coin.second.begin(); it != coin.second.end(); ++it, ++i){
                    for(auto j = it; j != coin.second.end(); ++j){
                        // Just for test: cout << coin.first << "-" << i->first << "  " << coin.first << "-" << j->first << "  " << i->first << "-" << j->first << endl;
                        
                        // if BUSD/USDT exist
                        if(coins.find(i->first) != coins.end() && coins[i->first].find(j->first) != coins[i->first].end()){
                            bool done = 1;
                            i->second.mtx->lock();
                            j->second.mtx->lock();
                            coins[i->first][j->first].mtx->lock();
                            
                            // We check buy-limit BTC/BUSD, sell-market BTC/USDT, buy-market BUSD/USDT
                            if(i->second.bids.size() > 0 && i->second.volume > VOLUME && j->second.bids.size() > 0 && coins[i->first][j->first].asks.size() > 0){
                                double diff = ( ( (j->second.bids.begin()->first - j->second.bids.begin()->first * j->second.fee.second) / (i->second.bids.begin()->first + i->second.bids.begin()->first * i->second.fee.first) ) ) 
                                                / (coins[i->first][j->first].asks.begin()->first + coins[i->first][j->first].asks.begin()->first * coins[i->first][j->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  A.Pairs: buy-limit " << coin.first << "-" << i->first << "(v: " << i->second.volume << ") sell-market "
                                                             << coin.first << "-" << j->first << " buy-market "
                                                             << i->first   << "-" << j->first << " \n";
                                    done = 0;
                                }
                            }
                            
                            // We check buy-market BTC/BUSD, sell-limit BTC/USDT, buy-market BUSD/USDT
                            /*if(i->second.asks.size() > 0 && j->second.asks.size() > 0 && j->second.volume > VOLUME && coins[i->first][j->first].asks.size() > 0){
                                double diff = ( ( (j->second.asks.begin()->first - j->second.asks.begin()->first * j->second.fee.first) / (i->second.asks.begin()->first + i->second.asks.begin()->first * i->second.fee.second) ) ) 
                                                / (coins[i->first][j->first].asks.begin()->first + coins[i->first][j->first].asks.begin()->first * coins[i->first][j->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  A.Pairs: buy-market " << coin.first << "-" << i->first << " sell-limit "
                                                             << coin.first << "-" << j->first << "(v: " << j->second.volume << ") buy-market "
                                                             << i->first   << "-" << j->first << "\n";
                                    done = 0;
                                }
                            }
                            
                            
                            // We check sell-limit BTC/BUSD, buy-market BTC/USDT, sell-market BUSD/USDT
                            if(done && i->second.asks.size() > 0 && i->second.volume > VOLUME && j->second.asks.size() > 0 && coins[i->first][j->first].bids.size() > 0){
                                double diff = ( ( (i->second.asks.begin()->first - i->second.asks.begin()->first  * i->second.fee.first) / (j->second.asks.begin()->first + j->second.asks.begin()->first * j->second.fee.second) ) ) 
                                                * (coins[i->first][j->first].bids.begin()->first - coins[i->first][j->first].bids.begin()->first * coins[i->first][j->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  A.Pairs: buy-market " << coin.first << "-" << j->first << " sell-limit "
                                                              << coin.first << "-" << i->first << "(v: " << i->second.volume << ") sell-market "
                                                              << i->first   << "-" << j->first << "\n";
                                }                           
                            }*/
                            
                           // We check sell-market BTC/BUSD, buy-limit BTC/USDT, sell-market BUSD/USDT
                            if(done && i->second.bids.size() > 0 && j->second.bids.size() > 0 && j->second.volume > VOLUME && coins[i->first][j->first].bids.size() > 0){
                                double diff = ( ( (i->second.bids.begin()->first - i->second.bids.begin()->first * i->second.fee.second) / (j->second.bids.begin()->first + j->second.bids.begin()->first * j->second.fee.first) ) ) 
                                                * (coins[i->first][j->first].bids.begin()->first - coins[i->first][j->first].bids.begin()->first * coins[i->first][j->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  A.Pairs: buy-limit " << coin.first << "-" << j->first << "(v: " << j->second.volume << ") sell-market "
                                                              << coin.first << "-" << i->first << " sell-market "
                                                              << i->first   << "-" << j->first << "\n";
                                }                           
                            }
                            
                            coins[i->first][j->first].mtx->unlock();
                            j->second.mtx->unlock();
                            i->second.mtx->unlock();
                        }
                        // if BUSD/USDT doesn't exist, try to reverse to USDT/BUSD, all the code above is just for de 3º pair coins[j->first][i->first]
                        else if(coins.find(j->first) != coins.end() && coins[j->first].find(i->first) != coins[j->first].end()){
                            bool done = 1;
                            i->second.mtx->lock();
                            j->second.mtx->lock();
                            coins[j->first][i->first].mtx->lock();
                            
                            // We check buy-limit BTC/BUSD, sell-market BTC/USDT, sell-market USDT/BUSD
                            if(i->second.bids.size() > 0 && i->second.volume > VOLUME && j->second.bids.size() > 0 && coins[j->first][i->first].bids.size() > 0){
                                double diff = ( ( (j->second.bids.begin()->first - j->second.bids.begin()->first * j->second.fee.second) / (i->second.bids.begin()->first + i->second.bids.begin()->first * i->second.fee.first) ) ) 
                                                * (coins[j->first][i->first].bids.begin()->first - coins[j->first][i->first].bids.begin()->first * coins[j->first][i->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  B.Pairs: buy-limit " << coin.first << "-" << i->first << "(v: " << i->second.volume << ") sell-market "
                                                             << coin.first << "-" << j->first << " sell-market "
                                                             << j->first   << "-" << i->first << "\n";
                                    done = 0;
                                }
                            }
                            
                            // We check buy-market BTC/BUSD, sell-limit BTC/USDT, sell-market USDT/BUSD
                            /*if(i->second.asks.size() > 0 && j->second.asks.size() > 0 && j->second.volume > VOLUME && coins[j->first][i->first].bids.size() > 0){
                                double diff = ( ( (j->second.asks.begin()->first - j->second.asks.begin()->first * j->second.fee.first) / (i->second.asks.begin()->first + i->second.asks.begin()->first * i->second.fee.second) ) ) 
                                                * (coins[j->first][i->first].bids.begin()->first - coins[j->first][i->first].bids.begin()->first * coins[j->first][i->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  B.Pairs: buy-market " << coin.first << "-" << i->first << " sell-limit "
                                                             << coin.first << "-" << j->first << "(v: " << j->second.volume << ") sell-market "
                                                             << j->first   << "-" << i->first << "\n";
                                    done = 0;
                                }
                            }
                            
                            
                            // We check sell-limit BTC/BUSD, buy-market BTC/USDT, buy-market USDT/BUSD
                            if(done && i->second.asks.size() > 0 && i->second.volume > VOLUME && j->second.asks.size() > 0 && coins[j->first][i->first].asks.size() > 0){
                                double diff = ( ( (i->second.asks.begin()->first - i->second.asks.begin()->first  * i->second.fee.first) / (j->second.asks.begin()->first + j->second.asks.begin()->first * j->second.fee.second) ) ) 
                                                / (coins[j->first][i->first].asks.begin()->first + coins[j->first][i->first].asks.begin()->first * coins[j->first][i->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  B.Pairs: buy-market " << coin.first << "-" << j->first << " sell-limit "
                                                              << coin.first << "-" << i->first << "(v: " << i->second.volume << ") buy-market "
                                                              << j->first   << "-" << i->first << "\n";
                                }                           
                            }*/
                            
                            // We check sell-market BTC/BUSD, buy-limit BTC/USDT, buy-market USDT/BUSD
                            if(done && i->second.bids.size() > 0 && j->second.bids.size() > 0 && j->second.volume > VOLUME && coins[j->first][i->first].asks.size() > 0){
                                double diff = ( ( (i->second.bids.begin()->first - i->second.bids.begin()->first * i->second.fee.second) / (j->second.bids.begin()->first + j->second.bids.begin()->first * j->second.fee.first) ) ) 
                                                / (coins[j->first][i->first].asks.begin()->first + coins[j->first][i->first].asks.begin()->first * coins[j->first][i->first].fee.second);
                                // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                                if(diff > MAX_DIFFERENCE){
                                    cout << " diff: " << left << setw(12) << (diff - 1) * 100 << "  B.Pairs: buy-limit " << coin.first << "-" << j->first << "(v: " << j->second.volume << ") sell-market "
                                                              << coin.first << "-" << i->first << " buy-market "
                                                              << j->first   << "-" << i->first << "\n";
                                }                           
                            }
                            
                            coins[j->first][i->first].mtx->unlock();
                            j->second.mtx->unlock();
                            i->second.mtx->unlock();
                        }
                    }
                }
            }
            cout << endl;
            std::this_thread::sleep_for(std::chrono::milliseconds(WAIT));
        }
    }

}


bool chooseExchange(unsigned short& option, unsigned short& test){
    unsigned short number;

    cout << " Exchanges:\n";
    cout << "  1.Binance\n";
    cout << "  2.Bitget\n";
    cout << "  3.Bybit\n";
    cout << "  4.Cryptocom\n";
    cout << "  5.Ftx\n";
    cout << "  6.Mexc\n";
    cout << "\n";
    cout << " Choose: ";
    cin >> number;
    
    cout << " Choose 1.Test or 2.Real: ";
    cin >> test;
    if(test == 2){
        string yes;
        cout << " YOU ARE CHOOSING REAL APPLICATION, ARE YOU SURE?: ";
        cin >> yes;
        
        if(yes != "y")
            return false;
            
        option = 1;
    }
    else{
        cout << " Choose 1.Taker or 2.Maker: ";
        cin >> option;
        if(option < 1 || option > 2){
            cout << " Choose a valid option\n";
            return false;
        }
    }
    cout << "\n";
    
    cout << " ************************************\n";    
    if(number == 1){
        exchange_chosen = new Binance();
        cout << "               Binance\n";
    }
    else if(number == 2){
        exchange_chosen = new Bitget();
        cout << "               Bitget\n";
    }
    else if(number == 3){
        exchange_chosen = new Bybit();
        cout << "               Bybit\n";
    }
    else if(number == 4){
        exchange_chosen = new Cryptocom();
        cout << "               Cryptocom\n";
    }
    else if(number == 5){
        exchange_chosen = new Ftx();
        cout << "               Ftx\n";
    }
    else if(number == 6){
        exchange_chosen = new Mexc();
        cout << "               Mexc\n";
    }
    else{
        cout << " Choose a valid number\n";
        return false;
    }    
    cout << " ************************************\n";

    return true;
}

int main() {

    cout << "   _        _                         _                             _        " << endl;
    cout << "  | |      (_)                       | |                           | |       " << endl;
    cout << "  | |_ _ __ _  __ _ _ __   __ _ _   _| | __ _ _ __ ______ __ _ _ __| |__     " << endl;
    cout << "  | __| '__| |/ _` | '_ . / _` | | | | |/ _` | '__|____../ _` | '__| '_ .    " << endl;
    cout << "  | |_| |  | | (_| | | | | (_| | |_| | | (_| | |        | (_| | |  | |_) |   " << endl;
    cout << "  ..__|_|  |_|.__,_|_| |_|.__, |.__,_|_|.__,_|_|         .__,_|_|  |_.__/    " << endl;
    cout << "                           __/ |                                             " << endl;
    cout << "                          |___/                                               \n\n\n";

    cout << "          **** Spot-IntraExchange SIMULATION & REAL(Taker) ****\n\n";
    
    unsigned short option, test;
    if(chooseExchange(option, test)){
        curl_global_init(CURL_GLOBAL_ALL);    
        ini(option, test);
    }

    return 0;
}




