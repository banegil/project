#include "include.h"



void ini(const unsigned short& exchange1, const unsigned short& exchange2, const bool& makerStrat, const bool& balanced_assets){  
    if(makerStrat)
        makerStrategy(exchange1, exchange2, makerStrat, balanced_assets);
    else
        takerStrategy(exchange1, exchange2, makerStrat, balanced_assets);
}


int main() {
    unsigned short exchange1, exchange2;
    bool makerStrat = 1;

    cout << "\n";
    cout << "     .d8888. d8888b.  .d88b.  d888888b  .d8b.  d8888b. d8888b.   \n";
    cout << "     88'  YP 88  `8D .8P  Y8. `~~88~~' d8' `8b 88  `8D 88  `8D   \n";
    cout << "     `8bo.   88oodD' 88    88    88    88ooo88 88oobY' 88oooY'   \n";
    cout << "       `Y8b. 88~~~   88    88    88    88~~~88 88`8b   88~~~b.   \n";
    cout << "     db   8D 88      `8b  d8'    88    88   88 88 `88. 88   8D   \n";
    cout << "     `8888Y' 88       `Y88P'     YP    YP   YP 88   YD Y8888P'   \n\n\n";
                                                          
                                                          
                                                          
                                                                                                                    
    cout << "                  **** Spot-Arbitrage (REAL) ****\n\n";
    cout << " Insert pair e.g.(ETH-USDT): ";
    cin >> chosenSymbol;
    cout << endl;
    cout << " Choose exchanges: " << endl;
    cout << "  Exchange1: ";
    cin >> exchange1;
    cout << "  Exchange2: ";
    cin >> exchange2;
    cout << endl << endl;
    /*cout << " Choose 0.Taker-Strategy or 1.Maker-Strategy: ";
    cin >> makerStrat;
    cout << endl << endl;*/

    bool balanced_assets = 0;
    bestExchange = 3;

    curl_global_init(CURL_GLOBAL_ALL);    
    ini(exchange1, exchange2, makerStrat, balanced_assets);
    return 0;
}
