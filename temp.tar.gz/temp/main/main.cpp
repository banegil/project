#include "include.h"


void ini(){      
    Bybit bin;
    bin.get_exchanges();  

    cout << "Starting ... " << endl;          
    auto e = async(&Bybit::websocketInit_depth, &bin);              
    cout << "OK!" << endl;
    
    // Just for test
    /*for(auto& i: coins)
        for(auto& j: i.second)
            cout << i.first << "-" << j.first << endl;*/
    
    while(1){        
        // iterate through baseAsset coin->first: BTC, ETH, DOT ...    
        for(auto& coin : coins){ 
            // iterate through a NxN matrix(top right triangle) of pairs of each coin: BTC has BTC/USDT, BTC/BUSD ...
            auto i = coin.second.begin();
            // i->first and j->first are quoteAsset (e.g. /USDT and /BUSD)
            for(auto it = ++coin.second.begin(); it != coin.second.end(); ++it, ++i){
                for(auto j = it; j != coin.second.end(); ++j){
                    // Just for test: cout << coin.first << "-" << i->first << "  " << coin.first << "-" << j->first << "  " << i->first << "-" << j->first << endl;
                    
                    // if BUSD/USDT exist
                    if(coins.find(i->first) != coins.end() && coins[i->first].find(j->first) != coins[i->first].end()){
                        bool done = 1;
                        i->second.mtx->lock();
                        j->second.mtx->lock();
                        coins[i->first][j->first].mtx->lock();
                        
                        // We check buy BTC/USDT, sell BTC/BUSD, buy USDT/BUSD
                        if(i->second.bids.size() > 0 && j->second.bids.size() > 0 && coins[i->first][j->first].bids.size() > 0){
                            double diff = ( ( 1 / i->second.bids.begin()->first ) * (j->second.bids.begin()->first - j->second.bids.begin()->first * j->second.fee.second) ) 
                                            / (coins[i->first][j->first].bids.begin()->first);
                            // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                            if(diff > MAX_DIFFERENCE && diff < 10){
                                cout << "A. Pairs: buy " << coin.first << "-" << i->first << " sell "
                                                         << coin.first << "-" << j->first << " buy "
                                                         << i->first   << "-" << j->first << "\n";
                                cout << "difference: " << (diff - 1) * 100 << "%\n";
                                done = 0;
                            }
                        }
                        
                        // We check sell BTC/USDT, buy BTC/BUSD, sell USDT/BUSD
                        if(done && i->second.asks.size() > 0 && j->second.asks.size() > 0 && coins[i->first][j->first].asks.size() > 0){
                            double diff = ( ( 1 / (j->second.asks.begin()->first + j->second.asks.begin()->first * j->second.fee.second) ) * i->second.asks.begin()->first ) 
                                            * (coins[i->first][j->first].asks.begin()->first);
                            // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                            if(diff > MAX_DIFFERENCE && diff < 10){
                                cout << "A. Pairs: sell " << coin.first << "-" << i->first << " buy "
                                                          << coin.first << "-" << j->first << " sell "
                                                          << i->first   << "-" << j->first << "\n";
                                cout << "difference: " << (diff - 1) * 100 << "%\n";
                            }                           
                        }
                        
                        coins[i->first][j->first].mtx->unlock();
                        j->second.mtx->unlock();
                        i->second.mtx->unlock();
                    }
                    // if BUSD/USDT doesn't exist, try to reverse to USDT/BUSD
                    else if(coins.find(j->first) != coins.end() && coins[j->first].find(i->first) != coins[j->first].end()){
                        bool done = 1;
                        i->second.mtx->lock();
                        j->second.mtx->lock();
                        coins[j->first][i->first].mtx->lock();
                        
                        // We check sell BTC/USDT, buy BTC/BUSD, buy BUSD/USDT
                        if(i->second.bids.size() > 0 && j->second.asks.size() > 0 && coins[j->first][i->first].bids.size() > 0){
                            double diff = ( ( 1 / (j->second.asks.begin()->first + j->second.asks.begin()->first * j->second.fee.second) ) * i->second.asks.begin()->first ) 
                                            / (coins[i->first][j->first].bids.begin()->first);
                            // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                            if(diff > MAX_DIFFERENCE && diff < 10){
                                cout << "B. Pairs: buy " << coin.first << "-" << j->first << " sell "
                                                          << coin.first << "-" << i->first << " buy "
                                                          << j->first   << "-" << i->first << "\n";
                                cout << "difference: " << (diff - 1) * 100 << "%\n";
                                done = 0;
                            }
                        }
                        
                        // We check buy BTC/USDT, sell BTC/BUSD, sell USDT/BUSD
                        if(done && i->second.bids.size() > 0 && j->second.bids.size() > 0 && coins[j->first][i->first].asks.size() > 0){
                            // AQUI HACE FALTA COMPARAR EL ORDERBOOK ENTERO, NO SOLO EL PRIMER BID/ASK
                            double diff = ( ( 1 / i->second.bids.begin()->first ) * (j->second.bids.begin()->first - j->second.bids.begin()->first * j->second.fee.second) ) 
                                            * (coins[i->first][j->first].asks.begin()->first);
                            if(diff > MAX_DIFFERENCE && diff < 10){
                                cout << "B. Pairs: sell "  << coin.first << "-" << j->first << " buy "
                                                          << coin.first << "-" << i->first << " sell "
                                                          << j->first   << "-" << i->first << "\n";
                                cout << "difference: " << (diff - 1) * 100 << "%\n";
                            }                          
                        }
                        
                        coins[j->first][i->first].mtx->unlock();
                        j->second.mtx->unlock();
                        i->second.mtx->unlock();
                    }
                }
            }
        }
        
        std::this_thread::sleep_for(std::chrono::milliseconds(WAIT));
    }
}


int main() {
    curl_global_init(CURL_GLOBAL_ALL);    
    ini();
    return 0;
}
