#include "include.h"


void ini(){      
    Bybit bin; 

    cout << " Starting ... " << endl;    

    auto e = async(&Bybit::websocketInit_depth, &bin);       
    auto ee = async(&Bybit::websocketInit_User, &bin);              

    this_thread::sleep_for(chrono::milliseconds(7000));    
    cout << " OK!" << endl;
     
    auto&& p1 = pairs[cc]; 
    auto&& p2 = pairs[cc1];
    auto&& p3 = pairs[cc2];
    
    double quantity = QUANTITY;
    bool exit = 0;
           
    auto p2bids = p2.get_bids();
    auto p1bids = p1.get_bids();
    auto p3asks = p3.get_asks();
    
    while(!exit){
        if(p1bids[0].first > 0 && p2bids[0].first > 0 && p3asks[0].first > 0)
            exit = 1;
            
        this_thread::sleep_for(chrono::milliseconds(500));
        p1bids = p1.get_bids();
        p2bids = p2.get_bids();
        p3asks = p3.get_asks(); 
        this_thread::sleep_for(chrono::milliseconds(500));
    } 
    
    while(1){ 
        p1bids = p1.get_bids();
        p2bids = p2.get_bids();
        p3asks = p3.get_asks();  

        const double& calc = p2bids[0].first - p2bids[0].first * ORDER_BOUND;
        const double& c = (p2bids[0].first / priceOrder) / p3asks[0].first;
        const bool& ahead = priceOrder < p1bids[0].first && calc >= p1bids[0].first;
    
        if(c < LOWER_BOUND || c > UPPER_BOUND || ahead){ 
            priceOrder = calc;

            if(ok == 1){
                cout << "EXTECUTED!" << endl;
                this_thread::sleep_for(chrono::milliseconds(500));
                priceOrder = PRICE;
                quantity_global = QUANTITY;
                ok = 0;
            }
            else{
                bin.send_CancelOrder();
                this_thread::sleep_for(chrono::milliseconds(1));
                const int& ret = bin.send_order(cc,"buy", quantity_global, round(priceOrder * POW_CC) / POW_CC ); // LIMIT 
                
                if(ret > 0){
                    cout << cc << endl;
                    
                    if(ret == 12136){
                        quantity_global = QUANTITY;
                        bin.send_order(cc,"buy", quantity_global, round(priceOrder * POW_CC) / POW_CC ); // LIMIT 
                    }    
                }
            }   
        }
        
        if(ok)
            priceOrder = PRICE;
        
        this_thread::sleep_for(chrono::milliseconds(400));
    }
}

bool choosePairs(){
    int number;

    cout << " Total pairs:\n";
    cout << "  1.buy-limit BIT/DAI sell-market BIT/USDT buy-market DAI/USDT\n";
    cout << "  2.buy-limit BTC/USDC sell-market BTC/USDT buy-market USDC/USDT\n";
    cout << "\n";
    cout << " Choose: ";
    cin >> number;
    cout << "\n";
    
    if(number == 1){
        cc = "BITDAI";
        cc1 = "BITUSDT";
        cc2 = "DAIUSDT";
    
        PRICE = 1; 
        QUANTITY = 40;
        LOWER_BOUND = 1.001;
        ORDER_BOUND = 0.0015;
        UPPER_BOUND = 1.002;
        POW_CC = 10000.0;
        POW_CC1 = 10000.0;
        POW_CC2 = 10000.0;
        POW_CC2_QTY = 100.0;
    }
    else if(number == 2){
        cc = "BTCUSDC";
        cc1 = "BTCUSDT";
        cc2 = "USDCUSDT";
    
        PRICE = 30000; 
        QUANTITY = 0.001;
        LOWER_BOUND = 1.0;
        ORDER_BOUND = 0.0003;
        UPPER_BOUND = 1.001;
        POW_CC = 100.0;
        POW_CC1 = 100.0;
        POW_CC2 = 10000.0;
        POW_CC2_QTY = 100.0;        
    }
    else{
        cout << " Choose a valid number\n";
        return false;
    }
    
    priceOrder = PRICE;
    quantity_global = QUANTITY;
    
    return true;    
}

int main() {
    cout << "   _        _                         _                             _        " << endl;
    cout << "  | |      (_)                       | |                           | |       " << endl;
    cout << "  | |_ _ __ _  __ _ _ __   __ _ _   _| | __ _ _ __ ______ __ _ _ __| |__     " << endl;
    cout << "  | __| '__| |/ _` | '_ . / _` | | | | |/ _` | '__|______/ _` | '__| '_ .    " << endl;
    cout << "  | |_| |  | | (_| | | | | (_| | |_| | | (_| | |        | (_| | |  | |_) |   " << endl;
    cout << "   .__|_|  |_|.__,_|_| |_|.__, |.__,_|_|.__,_|_|         .__,_|_|  |_.__/    " << endl;
    cout << "                           __/ |                                             " << endl;
    cout << "                          |___/                                               \n\n\n";

    cout << "                  **** Spot-IntraExchange (REAL) ****\n\n";

    if(choosePairs()){
        curl_global_init(CURL_GLOBAL_ALL);    
        ini();
    }
    return 0;
}
