#include "include.h"


void ini(){      
    Bybit bin; 

    cout << "Starting ... " << endl;    

    auto e = async(&Bybit::websocketInit_depth, &bin);       
    auto ee = async(&Bybit::websocketInit_User, &bin);              

    this_thread::sleep_for(chrono::milliseconds(7000));    
    cout << "OK!" << endl;
     
    auto&& p1 = pairs[cc]; 
    auto&& p2 = pairs[cc1];
    auto&& p3 = pairs[cc2];
    
    auto p2bids = p2.get_bids();
    
    double priceOrder = p2bids[0].first - p2bids[0].first * 0.001;
    double quantity = 40000; 
    bin.send_order(cc,"buy", quantity, priceOrder); // LIMIT  
    
    while(1){ 
        auto p1bids = p1.get_bids();
        p2bids = p2.get_bids();
        auto p3asks = p3.get_asks();  
        
        double const& c = ((1 / priceOrder) * p2bids[0].first) / p3asks[0].first;
        
        if(c < 1.0001 || c > 1.002){
            bin.send_CancelOrder();  
            priceOrder = p2bids[0].first - p2bids[0].first * 0.001;
            
            if(!orderExecuted){
                bin.send_order(cc,"buy", quantity, priceOrder); // LIMIT    
            }  
            else{
                cout << "EXTECUTED!\n";
                bin.send_CancelOrder(); 
                this_thread::sleep_for(chrono::milliseconds(500000)); 
            }    
        }
        
        this_thread::sleep_for(chrono::milliseconds(200));
    }
}


int main() {
    curl_global_init(CURL_GLOBAL_ALL);    
    ini();
    return 0;
}

/*
void ini(){      
    Binance bin;

    cout << "Starting ... " << endl;    
    auto e = async(&Binance::websocketInit_depth, &bin);       
    auto ee = async(&Binance::websocketInit_trades, &bin, bin.get_listenKey());              

    this_thread::sleep_for(chrono::milliseconds(7000));    
    cout << "OK!" << endl;
     
    auto&& p1 = pairs["btcusdc"]; 
    auto&& p2 = pairs["btcbusd"];
    auto&& p3 = pairs["usdcbusd"];
    
    int cont = 0; 
    double diffAverage = 0;
    double qtyAverage = 0;
    double priceOrder = 0;
    
    time_t current_time;
    time(&current_time);
    int ct = current_time;  
    while(1){
        time(&current_time);
        int ct2 = current_time;
        
        if(ct2 - ct > 10){
            ct = ct2;
            cout << "diffAverage: " << (diffAverage / cont) * 100 << ", qtyAverage: " << qtyAverage / cont << "\n";
            cont = diffAverage = qtyAverage = 0;
        }
    
        p1.mtx->lock(); p2.mtx->lock(); p3.mtx->lock();
        double c1 = (p2.bids[0].first / p1.bids[0].first) / p3.asks[0].first;
        p1.mtx->unlock(); p2.mtx->unlock(); p3.mtx->unlock();              
        
        if(c1 > 1){   
            int iA = 0, iB = 0, iC = 0;
            
            p1.mtx->lock(); p2.mtx->lock(); p3.mtx->lock();         
            auto p1B = p1.bids;
            auto p2B = p2.bids; 
            auto p3A = p3.asks;
            p1.mtx->unlock(); p2.mtx->unlock(); p3.mtx->unlock(); 
                    
            while(iA < 5 && iB < 5 && iC < 5 && (p2B[iB].first / p1B[iA].first) / p3A[iC].first > 1){
                double minimum = min(min(p2B[iB].second, p1B[iA].second), p3A[iC].second);
                
                p1B[iA].second -= minimum;
                p2B[iB].second -= minimum;
                p3A[iC].second -= minimum;
                
                if(p1B[iA].second == 0)
                    iA++;
                if(p2B[iB].second == 0)
                    iB++;
                if(p3A[iC].second == 0)
                    iC++;
                
                qtyAverage += minimum;
            }

            diffAverage += c1 - 1;            
            cont++;
        }            
                    
        this_thread::sleep_for(chrono::milliseconds(100));
    }
}
*/
