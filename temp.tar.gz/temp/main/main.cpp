#include "include.h"



void ini(const unsigned short& number, const unsigned short& test){    
        
    cout << " Starting ... " << endl;   
    exchange_chosen->getInfo();
    check_varIni();
          
    auto&& f = async(&Exchange::websocketInit_depth, exchange_chosen);
    this_thread::sleep_for(chrono::milliseconds(5000));  
    future<void> f2;
    if(test != 1)
        f2 = async(&Exchange::websocketInit_User, exchange_chosen);
    
    string ccw = cc;
    string cc1w = cc1; 
    string cc2w = cc2;
    
    if(number == 1){ // Binance
        string_tolower(ccw);
        string_tolower(cc1w);
        string_tolower(cc2w);
    }
    
    auto&& p1 = pairs[ccw]; 
    auto&& p2 = pairs[cc1w];
    auto&& p3 = pairs[cc2w];   
       
    auto o1t = ORDER1 ? p1.get_asks() : p1.get_bids(); 
    auto o2t = ORDER1 ? p2.get_asks() : p2.get_bids();   
    auto o3t = ORDER3 ? p3.get_asks() : p3.get_bids(); 
        
    bool exit = 0;
    while(!exit){
        if(o1t[0].first > 0 && o2t[0].first > 0 && o3t[0].first > 0)
            exit = 1;
            
        this_thread::sleep_for(chrono::milliseconds(500));
        o1t = ORDER1 ? p1.get_asks() : p1.get_bids(); 
        o2t = ORDER1 ? p2.get_asks() : p2.get_bids();   
        o3t = ORDER3 ? p3.get_asks() : p3.get_bids();
        this_thread::sleep_for(chrono::milliseconds(500));
    } 
    
    this_thread::sleep_for(chrono::milliseconds(2000)); 
    cout << " OK!" << endl;

    priceOrder = ORDER1 ? pairs[ccw].get_bid() : pairs[ccw].get_ask();
    quantity_global = QUANTITY; 
    const double fee1 = pairs[ccw].fees.first;
    const double fee2 = pairs[cc1w].fees.second;
    const double fee3 = pairs[cc2w].fees.second;
    
    while(1){ 
        auto o1 = ORDER1 ? p1.get_asks() : p1.get_bids(); 
        auto o2 = ORDER1 ? p2.get_asks() : p2.get_bids();   
        auto o3 = ORDER3 ? p3.get_asks() : p3.get_bids();  
        
        double price1 = ORDER1 ? o1[0].first - o1[0].first * fee1 : o1[0].first + o1[0].first * fee1;
        const double& price2 = ORDER1 ? o2[0].first + o2[0].first * fee2 : o2[0].first - o2[0].first * fee2;
        const double& price3 = ORDER3 ? o3[0].first + o3[0].first * fee3 : o3[0].first - o3[0].first * fee3;
        
        const double& c = ORDER3 ? (price2 / priceOrder) / price3  : (price2 / priceOrder) * price3 ;

        if(test == 1){
            priceOrder = price1;
            cout << (c - 1) * 100 << "\n"; // first cout is trash
        }
        else{    
            price1 = round(price1 * POW_CC) / POW_CC;    
            double calc = ORDER3 ? price2 / price3  : price2 * price3 ; 
            calc = ORDER1 ? calc + calc * ORDER_BOUND : calc - calc * ORDER_BOUND;
            calc = round(calc * POW_CC) / POW_CC;
            const bool& ahead = ORDER1 ? priceOrder > price1 && calc <= price1 : priceOrder < price1 && calc >= price1;
            
            /*cout << "c: " << c << "\n";            
            cout << "calc: " << calc << "\n";
            cout << "priceOrder: " << priceOrder << "\n";
            cout << "price1: " << price1 << "\n";
            cout << "ahead: " << ahead << "\n\n";*/
            
            if(c < LOWER_BOUND || ahead){ 
                priceOrder = min(calc, price1 + 1 / POW_CC);

                double check_again = ORDER3 ? (price2 / priceOrder) / price3 : (price2 / priceOrder) * price3;
                while(!ahead && check_again < LOWER_BOUND){                    
                    priceOrder = priceOrder - 1 / POW_CC;                
                    check_again = ORDER3 ? (price2 / priceOrder) / price3  : (price2 / priceOrder) * price3;
                }

                if(ok == 1){
                    cout << "EXTECUTED!" << endl;
                    this_thread::sleep_for(chrono::milliseconds(500));
                    priceOrder = ORDER1 ? pairs[ccw].get_bid() : pairs[ccw].get_ask();
                    quantity_global = QUANTITY;
                    ok = 0;
                }
                else{
                    exchange_chosen->send_CancelOrder(cc); // check cancel, otherwise you take the risk of N orders
                    if(quantity_global == 0)
                        ok = 1;
                    else
                        exchange_chosen->send_order(cc, type_order1, round(quantity_global * POW_CC_QTY) / POW_CC_QTY, priceOrder ); // LIMIT 
                }   
            }
            
            if(ok)
                priceOrder = ORDER1 ? pairs[ccw].get_bid() : pairs[ccw].get_ask();
                
            if(FAIL){
                f = async(&Exchange::websocketInit_depth, exchange_chosen);
                f2 = async(&Exchange::websocketInit_User, exchange_chosen); 
                this_thread::sleep_for(chrono::milliseconds(7000)); 
                FAIL = 0; 
            }
        }
        
        this_thread::sleep_for(chrono::milliseconds(WAIT));
    } 
}


bool chooseExchange(unsigned short& number, unsigned short& test){
    cout << " Exchanges:\n";
    cout << "  1.Binance\n";
    cout << "  2.Bitget\n";
    cout << "  3.Bybit\n";
    cout << "  4.Cryptocom\n";
    cout << "  5.Ftx\n";
    cout << "  6.Mexc\n";
    cout << "\n";
    cout << " Choose: ";
    cin >> number;

    cout << " Choose 1.Test or 2.Real: ";
    cin >> test;
    if(test == 2){
        string yes;
        cout << " YOU ARE CHOOSING REAL APPLICATION, ARE YOU SURE? :";
        cin >> yes;
        
        if(yes != "y")
            return false;
    }
    cout << "\n";

    cout << " **************************************\n";    
    if(number == 1){
        exchange_chosen = new Binance();
        cout << "               Binance\n";
    }
    else if(number == 2){
        exchange_chosen = new Bitget();
        cout << "                Bitget\n";
    }
    else if(number == 3){
        exchange_chosen = new Bybit();
        cout << "                Bybit\n";
    }
    else if(number == 4){
        exchange_chosen = new Cryptocom();
        cout << "              Cryptocom\n";
    }
    else if(number == 5){
        exchange_chosen = new Ftx();
        cout << "                Ftx\n";
    }
    else if(number == 6){
        exchange_chosen = new Mexc();
        cout << "                Mexc\n";
    }
    else{
        cout << " Choose a valid number\n";
        return false;
    }    
    cout << "    " << setw(9) << left << cc << "  " << setw(9) << left << cc1 << "  " << cc2 << "\n";
    cout << " **************************************\n";
    
    /*cout << " LOWER_BOUND = ";
    cin >> LOWER_BOUND;
    cout << " ORDER_BOUND = ";
    cin >> ORDER_BOUND;
    //cout << " ORDER1 = ";
    //cin >> ORDER1;
    cout << " ORDER3(0 == sell & 1 == buy) = ";
    cin >> ORDER3;
    cout << " CC = ";
    cin >> cc;
    cout << " CC1 = ";
    cin >> cc1;
    cout << " CC2 = ";
    cin >> cc2;
    cout << "\n";
    
    string_toupper(cc);
    string_toupper(cc1);
    string_toupper(cc2);*/
    
    if(ORDER1){
        type_order1 = "sell";
        type_order2 = "buy";  
    }
    else{
        type_order1 = "buy";
        type_order2 = "sell";
    }

    type_order3 = ORDER3 ? "buy" : "sell";
    
    //exchange_chosen->websocketInit_User();
    //exchange_chosen->getInfo();
    //exchange_chosen->send_order("ETH_USDT", "buy", 0.01, 1200);
    //cin >> number;
    //exchange_chosen->send_CancelOrder("ETH_USDT");
    //check_varIni();

    return true;
}

int main() {
    cout << "   _        _                         _                             _        " << endl;
    cout << "  | |      (_)                       | |                           | |       " << endl;
    cout << "  | |_ _ __ _  __ _ _ __   __ _ _   _| | __ _ _ __ ______ __ _ _ __| |__     " << endl;
    cout << "  | __| '__| |/ _` | '_ . / _` | | | | |/ _` | '__|____../ _` | '__| '_ .    " << endl;
    cout << "  | |_| |  | | (_| | | | | (_| | |_| | | (_| | |        | (_| | |  | |_) |   " << endl;
    cout << "  ..__|_|  |_|.__,_|_| |_|.__, |.__,_|_|.__,_|_|         .__,_|_|  |_.__/    " << endl;
    cout << "                           __/ |                                             " << endl;
    cout << "                          |___/                                               \n\n\n";

    cout << "           **** Spot-IntraExchange SIMULATION & REAL(maker) ****\n\n";

    unsigned short number, test;
    if(chooseExchange(number, test)){
        curl_global_init(CURL_GLOBAL_ALL);    
        ini(number, test);
    }
    
    return 0;
}
