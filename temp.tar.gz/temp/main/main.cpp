#include "include.h"


void takerStrategy(const bool& order1, const bool& order3, const unsigned short& test){
     cout << "This is the takerStrategy, still not implemented...\n";
}


void makerStrategy(const bool& order1, const bool& order3, const unsigned short& test){
    pair<double, double> fees = exchange_chosen->get_fees();

    cout << " Starting ... " << endl;                 
    auto&& f = async(&Exchange::websocketInit_depth, exchange_chosen);
    future<void> f2;
    if(test != 1)
        f2 = async(&Exchange::websocketInit_User, exchange_chosen);
    
    this_thread::sleep_for(chrono::milliseconds(5000));    
    cout << " OK!" << endl;
    
    auto&& p1 = pairs[cc]; 
    auto&& p2 = pairs[cc1];
    auto&& p3 = pairs[cc2];   
       
    auto o1t = order1 ? p1.get_asks() : p1.get_bids(); 
    auto o2t = order1 ? p2.get_asks() : p2.get_bids();   
    auto o3t = order3 ? p3.get_asks() : p3.get_bids(); 
        
    bool exit = 0;
    while(!exit){
        if(o1t[0].first > 0 && o2t[0].first > 0 && o3t[0].first > 0)
            exit = 1;
            
        this_thread::sleep_for(chrono::milliseconds(500));
        o1t = order1 ? p1.get_asks() : p1.get_bids(); 
        o2t = order1 ? p2.get_asks() : p2.get_bids();   
        o3t = order3 ? p3.get_asks() : p3.get_bids();
        this_thread::sleep_for(chrono::milliseconds(500));
    } 
    
    double p = PRICE;
    priceOrder = PRICE;
    quantity_global = QUANTITY; 
    while(1){ 
        auto&& o1 = order1 ? p1.get_asks() : p1.get_bids(); 
        auto&& o2 = order1 ? p2.get_asks() : p2.get_bids();   
        auto&& o3 = order3 ? p3.get_asks() : p3.get_bids();  
        
        const double& price1 = order1 ? o1[0].first - o1[0].first * fees.first : o1[0].first + o1[0].first * fees.first;
        const double& price2 = order1 ? o2[0].first + o2[0].first * fees.second : o2[0].first - o2[0].first * fees.second;
        const double& price3 = order3 ? o3[0].first + o3[0].first * fees.second : o3[0].first - o3[0].first * fees.second;;
        
        const double& c = order3 ? (price2 / priceOrder) / price3  : (price2 / priceOrder) * price3 ;

        if(test == 1){
            priceOrder = price1;
            cout << (c - 1) * 100 << "\n"; // first cout is trash
        }
        else{        
            double calc = order3 ? price2 / price3  : price2 * price3 ; 
            calc = order1 ? calc + calc * ORDER_BOUND : calc - calc * ORDER_BOUND;
            const bool& ahead = order1 ? p > price1 && calc <= price1 : p < price1 && calc >= price1;
                        
            //cout << "calc: " << calc << "\n";
            //cout << "c: " << c << "\n";
            
            if(c < LOWER_BOUND || c > UPPER_BOUND || ahead){ 
                priceOrder = calc;

                if(ok == 1){
                    cout << "EXTECUTED!" << endl;
                    this_thread::sleep_for(chrono::milliseconds(500));
                    priceOrder = PRICE;
                    quantity_global = QUANTITY;
                    ok = 0;
                }
                else{
                    exchange_chosen->send_CancelOrder(cc); // check cancel, otherwise you take the risk of N orders
                    exchange_chosen->send_order(cc, type_order1, quantity_global, round(priceOrder * POW_CC) / POW_CC ); // LIMIT 
                                   
                    p = round(priceOrder * POW_CC) / POW_CC;
                }   
            }
            
            if(ok)
                priceOrder = PRICE;
                
            if(FAIL){
                f = async(&Exchange::websocketInit_depth, exchange_chosen);
                f2 = async(&Exchange::websocketInit_User, exchange_chosen); 
                this_thread::sleep_for(chrono::milliseconds(7000)); 
                FAIL = 0; 
            }
        }
        
        this_thread::sleep_for(chrono::milliseconds(WAIT));
    } 
}


void ini(const unsigned short& number, const unsigned short& option, const unsigned short& test){            
    bool order1 = 0, order2 = 0, order3 = 1; // 0 == bid & 1 == ask
     
    if(option == 1)
        takerStrategy(0, 1, test); // asks, bids, asks 
    else
        makerStrategy(ORDER1, ORDER3, test); // bids, bids, asks
}


bool chooseExchange(unsigned short& number, unsigned short& option, unsigned short& test){
    cout << " Exchanges:\n";
    cout << "  1.Binance\n";
    cout << "  2.Bitget\n";
    cout << "  3.Bybit\n";
    cout << "  4.Mexc\n";
    cout << "\n";
    cout << " Choose: ";
    cin >> number;
    
    cout << " Choose 1.Taker or 2.Maker: ";
    cin >> option;
    cout << " Choose 1.Test or 2.Real: ";
    cin >> test;
    cout << "\n";
    
    /*if(number == 1)
        exchange_chosen = new Binance();*/
    if(number == 2)
        exchange_chosen = new Bitget();
    else if(number == 3)
        exchange_chosen = new Bybit();
    else if(number == 4)
        exchange_chosen = new Mexc();
    else{
        cout << " Choose a valid number\n";
        return false;
    }
    
    if(option < 1 || option > 2){
        cout << " Choose a valid option\n";
        return false;
    }
    
    if(ORDER1){
        type_order1 = "sell";
        type_order2 = "buy";  
    }
    else{
        type_order1 = "buy";
        type_order2 = "sell";
    }

    type_order3 = ORDER3 ? "buy" : "sell";
    
    cout << " LOWER_BOUND = ";
    cin >> LOWER_BOUND;
    cout << " ORDER_BOUND = ";
    cin >> ORDER_BOUND;

    return true;
}

int main() {
    cout << "   _        _                         _                             _        " << endl;
    cout << "  | |      (_)                       | |                           | |       " << endl;
    cout << "  | |_ _ __ _  __ _ _ __   __ _ _   _| | __ _ _ __ ______ __ _ _ __| |__     " << endl;
    cout << "  | __| '__| |/ _` | '_ . / _` | | | | |/ _` | '__|_____./ _` | '__| '_ .    " << endl;
    cout << "  | |_| |  | | (_| | | | | (_| | |_| | | (_| | |        | (_| | |  | |_) |   " << endl;
    cout << "  ..__|_|  |_|.__,_|_| |_|.__, |.__,_|_|.__,_|_|         .__,_|_|  |_.__/    " << endl;
    cout << "                           __/ |                                             " << endl;
    cout << "                          |___/                                               \n\n\n";

    cout << "                  **** Spot-IntraExchange (REAL) ****\n\n";

    unsigned short number, option, test;
    if(chooseExchange(number, option, test)){
        curl_global_init(CURL_GLOBAL_ALL);    
        ini(number, option, test);
    }
    
    return 0;
}
