
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <iostream>
#include <future>
#include <curl/curl.h>
#include <cstdio>  
#include <cstring>  
#include <cstdlib> 
#include <unordered_map>
#include <map>
#include <fstream>
#include <mutex>
#include <iomanip>
#include <chrono>
#include <thread>
#include <cmath>
#include <ctime>
#include <atomic>
#include <set>
#include <curl/curl.h>
#include <algorithm>

#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"

#include <openssl/hmac.h>
#include <openssl/sha.h>

using namespace std;
using namespace rapidjson;

//*************  USER_MODIFICATION ******************
string cc = "SHIT_USDT";
string cc1 = "SHIT_USDC";
string cc2 = "USDC_USDT";
atomic<bool> ORDER1 = 0; // 0 == buy-limit, sell & 1 == sell-limit, buy
atomic<bool> ORDER3 = 0; // 0 == sell & 1 == buy
//*************  USER_MODIFICATION ******************

double LOWER_BOUND = 1.0005;
double ORDER_BOUND = 0.001;
double UPPER_BOUND = 1.0015;
int WAIT = 500;
string type_order1, type_order2, type_order3;

double PRICE = -1;
double QUANTITY = -1;
double POW_CC = -1;
double POW_CC1 = -1;
double POW_CC2 = -1;
double POW_CC2_QTY = -1;

#include "../lib/myappcpp_utils.h"
#include "../src/Wss.h"

atomic<double> priceOrder, quantity_global;

struct tOrderbook {
    array<pair<double, double>, 5> asks;
    array<pair<double, double>, 5> bids;
    double price = -1;

    mutable mutex *mtx;
        
    public:
    tOrderbook(){
        mtx = new mutex();
    }
    
    array<pair<double, double>, 5> get_asks(){
        lock_guard<mutex> lock(*mtx);
        return asks;        
    }
    
    array<pair<double, double>, 5> get_bids(){
        lock_guard<mutex> lock(*mtx);
        return bids;        
    }
    
    double get_bid(){
        lock_guard<mutex> lock(*mtx);
        return bids.begin()->first * 0.995;
    }
    
    double get_ask(){
        lock_guard<mutex> lock(*mtx);
        return asks.begin()->first * 1.005;
    }
};

unordered_map<string, tOrderbook> pairs;
atomic<bool> orderExecuted = 0, ok = 0, FAIL = 0;

#include "../src/Exchange.h"
//#include "../src/exchanges/Binance.h"
#include "../src/exchanges/Bitget.h"
#include "../src/exchanges/Bybit.h"
#include "../src/exchanges/Mexc.h"

Exchange* exchange_chosen;










