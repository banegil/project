
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <iostream>
#include <future>
#include <curl/curl.h>
#include <ctype.h>
#include <cstdio>  
#include <cstring>  
#include <cstdlib> 
#include <unordered_map>
#include <map>
#include <fstream>
#include <mutex>
#include <iomanip>
#include <chrono>
#include <thread>
#include <cmath>
#include <ctime>
#include <set>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <sstream>
#include <ctime>
#include <exception>
#include <algorithm>

#include <ctype.h>

#include "../lib/myappcpp_utils.h"
#include "../src/exchange.h"

#define MAX_DIFF 0.0005
#define MAX_ORDER_QUOTE 20
#define QUANTITY_UPPER_BOUND 50.0
#define MAX_EXCHANGES 11

string chosenSymbol = "ETH-USDT";

struct tExchange {
    unordered_map<string, double> balance; // <asset, balance>
    double orderPrice;
    double multiplier;

    mutable mutex *mtx;
        
    public:
    tExchange(){
        mtx = new mutex();
    }
};

unordered_map<unsigned short, tExchange> exchangeInfo; // <idExchange, <asset, tExchange>>
atomic<bool> stopExecution = false, orderExecuted = false;
atomic<unsigned short> bestExchange;
array<unsigned short, MAX_EXCHANGES> Index; 
vector<Exchange*> ex(2);



// Exchanges
#include "../src/exchanges/Aax.h"
#include "../src/exchanges/Ascendex.h"
#include "../src/exchanges/Binance.h"
#include "../src/exchanges/Bybit.h"
#include "../src/exchanges/Coinex.h"
//#include "../src/exchanges/Cryptocom.h"
#include "../src/exchanges/Ftx.h"
#include "../src/exchanges/Gateio.h"
#include "../src/exchanges/Huobi.h"
#include "../src/exchanges/Kucoin.h"
#include "../src/exchanges/Mexc.h"
#include "../src/exchanges/Okx.h"



    
void doIniWebSocket(int i){
    ex[i]->websocketInit_depth();
}

bool iniExchanges(double& fee1, double& fee2, const unsigned short& exchange1, const unsigned short& exchange2, const bool& makerStrat){
    unsigned short i = 0, cont = 0;
    exchangeInfo[exchange1] = tExchange();
    exchangeInfo[exchange2] = tExchange();
    
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Aax();
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Ascendex();
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Binance();
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Bybit();
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Coinex();
    //if(cont++ == exchange1 || cont - 1 == exchange2)
        //ex[i++] = new Cryptocom();
        cont++;
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Ftx();
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Gateio();
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Huobi();
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Kucoin();
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Mexc();
    if(cont++ == exchange1 || cont - 1 == exchange2)
        ex[i++] = new Okx();


    for(i = 0; i < ex.size(); i++){
        if(ex[i]->get_pairs()){
            
            Index[ ex[i]->get_idnum() ] = i;
            
            if(makerStrat){ // makerStrategy
                if(ex[i]->get_idnum() == exchange1)
                    fee1 = ex[i]->get_fee().first;
                else
                    fee2 = ex[i]->get_fee().second;
            }
            else{ // takerStrategy   
                if(ex[i]->get_idnum() == exchange1)
                    fee1 = ex[i]->get_fee().first;
                else
                    fee2 = ex[i]->get_fee().first;                
            }
       
            cout << "  " << ex[i]->get_id() << endl;
        }
    } 
    
    if(ex.size() == 2 && ex[0]->get_idnum() == exchange2){
        swap(ex[0], ex[1]);
        Index[exchange1] = 0;
        Index[exchange2] = 1;
    }
    
    return ex.size() == 2;   
}

// Strategies
#include "../src/strategies/makerStrategy.h"
#include "../src/strategies/takerStrategy.h"



