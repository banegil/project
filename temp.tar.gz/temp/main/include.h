
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <iostream>
#include <future>
#include <curl/curl.h>
#include <cstdio>  
#include <cstring>  
#include <cstdlib> 
#include <unordered_map>
#include <map>
#include <fstream>
#include <mutex>
#include <iomanip>
#include <chrono>
#include <thread>
#include <cmath>
#include <ctime>
#include <atomic>
#include <set>
#include <curl/curl.h>
#include <algorithm>

#define WAIT 2000
#define VOLUME 100000
#define MIN_QUANTITY 11.0
#define MAX_QUANTITY 20.0
const double MAX_DIFFERENCE = 1.0001;

#include "../lib/myappcpp_utils.h"

#include "../src/Wss.h"
#include "../src/Exchange.h"

struct orderInfo {
    bool second_order_executed;
    string side2;
    string pair2;
    string side3;
    string pair3;
};

struct orderbook {
    map<double, double, greater<double>> bids; 
    map<double, double> asks; // <price, quantity>
    pair<double, double> fee; // <makerFee, takerFee>
    mutex *mtx;
    double volume = 0.0;
    
    public:
    orderbook(){
        mtx = new mutex();
    }
    
    pair<double, double> get_ask(){
        lock_guard<mutex> lock(*mtx);
        return *asks.begin();
    }
    
    pair<double, double> get_bid(){
        lock_guard<mutex> lock(*mtx);
        return *asks.begin();
    }
};

typedef unordered_map<string, orderbook> tPairs;
unordered_map<string, tPairs> coins;

#include "../src/exchanges/Binance.h"
#include "../src/exchanges/Bitget.h"
#include "../src/exchanges/Bybit.h"
#include "../src/exchanges/Cryptocom.h"
#include "../src/exchanges/Ftx.h"
#include "../src/exchanges/Mexc.h"

Exchange* exchange_chosen;








