
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <iostream>
#include <future>
#include <curl/curl.h>
#include <cstdio>  
#include <cstring>  
#include <cstdlib> 
#include <unordered_map>
#include <map>
#include <fstream>
#include <mutex>
#include <iomanip>
#include <chrono>
#include <thread>
#include <cmath>
#include <ctime>
#include <atomic>
#include <set>
#include <curl/curl.h>
#include <algorithm>

#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"

#include <openssl/hmac.h>
#include <openssl/sha.h>

using namespace std;
using namespace rapidjson;

//**************  USER_MODIFICATION *******************
string cc = "ETH-USDC";
string cc1 = "ETH-USDT";
string cc2 = "USDC-USDT";
bool ORDER1 = 0; // 0 == buy-limit, sell & 1 == sell-limit, buy
bool ORDER3 = 1; // 0 == sell & 1 == buy
double LOWER_BOUND = 1.0001;
double ORDER_BOUND = 0.0006; // MIDDLE_ORDER -> ORDER_BOUND / 2
int WAIT = 500;
//**************  USER_MODIFICATION *******************


string type_order1, type_order2, type_order3;

double QUANTITY = 0;
double POW_CC = 0;
double POW_CC_QTY = 0;
double POW_CC1 = 0;
double POW_CC1_QTY = 0;
double POW_CC2 = 0;
double POW_CC2_QTY = 0;

#include "../lib/myappcpp_utils.h"
#include "../src/Wss.h"

atomic<double> priceOrder, quantity_global;

struct tOrderbook {
    array<pair<double, double>, 5> asks;
    array<pair<double, double>, 5> bids;
    pair<double, double> fees;
    double price = -1;

    mutable mutex *mtx;
        
    public:
    tOrderbook(){
        mtx = new mutex();
    }
    
    array<pair<double, double>, 5> get_asks(){
        lock_guard<mutex> lock(*mtx);
        return asks;        
    }
    
    array<pair<double, double>, 5> get_bids(){
        lock_guard<mutex> lock(*mtx);
        return bids;        
    }
    
    double get_bid(){
        lock_guard<mutex> lock(*mtx);
        return bids.begin()->first * 0.999;
    }
    
    double get_ask(){
        lock_guard<mutex> lock(*mtx);
        return asks.begin()->first * 1.001;
    }
};

unordered_map<string, tOrderbook> pairs;
atomic<bool> orderExecuted = 0, ok = 0, FAIL = 0;

#include "../src/Exchange.h"
#include "../src/exchanges/Binance.h"
#include "../src/exchanges/Bitget.h"
#include "../src/exchanges/Bybit.h"
#include "../src/exchanges/Cryptocom.h"
#include "../src/exchanges/Ftx.h"
#include "../src/exchanges/Mexc.h"

Exchange* exchange_chosen;










