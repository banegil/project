
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <iostream>
#include <future>
#include <curl/curl.h>
#include <cstdio>  
#include <cstring>  
#include <cstdlib> 
#include <unordered_map>
#include <map>
#include <fstream>
#include <mutex>
#include <iomanip>
#include <chrono>
#include <thread>
#include <cmath>
#include <ctime>
#include <atomic>
#include <set>
#include <curl/curl.h>

#define WAIT 5000
const double MAX_DIFFERENCE = 1;

#include "../lib/myappcpp_utils.h"

#include "../src/exchange.h"

struct orderbook {
    map<double, double, greater<double>> bids; 
    map<double, double> asks; // <price, quantity>
    pair<double, double> fee; // <makerFee, takerFee>
    mutex *mtx;
    
    public:
    orderbook(){
        mtx = new mutex();
    }
};

typedef unordered_map<string, orderbook> tPairs;
unordered_map<string, tPairs> coins;

#include "../src/exchanges/bybit.h"
#include "../src/exchanges/binance.h"
#include "../src/exchanges/Cryptocom.h"










