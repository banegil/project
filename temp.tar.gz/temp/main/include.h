
#include <unistd.h>
#include <string>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <iostream>
#include <future>
#include <curl/curl.h>
#include <cstdio>  
#include <cstring>  
#include <cstdlib> 
#include <unordered_map>
#include <map>
#include <fstream>
#include <mutex>
#include <iomanip>
#include <chrono>
#include <thread>
#include <cmath>
#include <ctime>
#include <atomic>
#include <set>
#include <curl/curl.h>
#include <algorithm>

#include "../lib/myappcpp_utils.h"
#include "../src/Wss.h"


string cc = "BTCUSDC";
string cc1 = "BTCUSDT";
string cc2 = "USDCUSDT";


//*******************************
double PRICE = 30000; // alway upper best buy, pretty upper
double QUANTITY = 0.001;
double LOWER_BOUND = 1.0;
double ORDER_BOUND = 0.0003;
double UPPER_BOUND = 1.001;
double POW_CC = 100.0;
double POW_CC1 = 100.0;
double POW_CC2 = 10000.0;
double POW_CC2_QTY = 10000.0;
//*******************************

atomic<double> priceOrder = PRICE, quantity_global = QUANTITY;

struct tOrderbook {
    array<pair<double, double>, 5> asks;
    array<pair<double, double>, 5> bids;
    double price = -1;

    mutable mutex *mtx;
        
    public:
    tOrderbook(){
        mtx = new mutex();
    }

    void pushOrderbook(const Document& d){
        mtx->lock();
                
        auto&& a = d["data"]["a"];
        auto&& b = d["data"]["b"];
        
        for(int i = 0; i < 5; i++){
            asks[i].first = stod( a[i][0].GetString() );
            asks[i].second = stod( a[i][1].GetString() );
        }
        
        for(int i = 0; i < 5; i++){
            bids[i].first = stod( b[i][0].GetString() );
            bids[i].second = stod( b[i][1].GetString() );
        }
        
        mtx->unlock();
    }    
        
    
    //binance
    /*void pushOrderbook(const Document& d){
        mtx->lock();
                
        auto&& a = d["data"]["asks"];
        auto&& b = d["data"]["bids"];
        
        for(int i = 0; i < 5; i++){
            asks[i].first = stod( a[i][0].GetString() );
            asks[i].second = stod( a[i][1].GetString() );
        }
        
        for(int i = 0; i < 5; i++){
            bids[i].first = stod( b[i][0].GetString() );
            bids[i].second = stod( b[i][1].GetString() );
        }
        
        mtx->unlock();
    }*/
    
    array<pair<double, double>, 5> get_asks(){
        lock_guard<mutex> lock(*mtx);
        return asks;        
    }
    
    array<pair<double, double>, 5> get_bids(){
        lock_guard<mutex> lock(*mtx);
        return bids;        
    }
    
    double get_bid(){
        lock_guard<mutex> lock(*mtx);
        return bids.begin()->first - bids.begin()->first * 0.01;
    }
    
    double get_ask(){
        lock_guard<mutex> lock(*mtx);
        return asks.begin()->first;
    }
};

unordered_map<string, tOrderbook> pairs;

atomic<bool> orderExecuted = 0, ok = 0;

//#include "../src/exchanges/binance.h"
#include "../src/exchanges/bybit.h"










