
#include <map>
#include <vector>
#include <string>


#include "../src/myappcpp.h"
#include "../src/myappcpp_websocket.h"
#include "../src/myappcpp.h"
#include <json/json.h>


using namespace std;

map < string, map <double,double> >  depthCache;


int main() {
	

	return 0;
}
