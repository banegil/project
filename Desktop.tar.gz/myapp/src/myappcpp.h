
#ifndef MYAPPCPP_H
#define MYAPPCPP_H


#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

#include <iostream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <exception>

#include <curl/curl.h>
#include <json/json.h>

#include "myappcpp_logger.h"
#include "myappcpp_utils.h"


using namespace std;

class MyappCPP {

	string api_key;
	string secret_key;
	CURL* curl;

	
	public:

    //---------------------------------
    void 
    init( string &api_key, string &secret_key ) 
    {
	    curl_global_init(CURL_GLOBAL_DEFAULT);
	    curl = curl_easy_init();
	    api_key = api_key;
	    secret_key = secret_key;
    }


    void
    cleanup()
    {
	    curl_easy_cleanup(curl);
	    curl_global_cleanup();
    }




    void 
    get_depth( 
        string& url, 
	    int limit, 
	    Json::Value &json_result ) 
    {	
	    string str_result;
	    curl_api( url, str_result ) ;

	    if ( str_result.size() > 0 ) {
		    
		    try {
			    Json::Reader reader;
			    json_result.clear();	
	        		reader.parse( str_result , json_result );
	        		
		    } catch ( exception &e ) {
		     	MyappCPP_logger::write_log( "<get_depth> Error ! %s", e.what() ); 
		    }   
	    
	    } else {
		    MyappCPP_logger::write_log( "<get_depth> Failed to get anything." ) ;
	    }
    }




    //--------------------
    //Start user data stream (API-KEY)

    /*void 
    start_userDataStream( Json::Value &json_result ) 
    {	
	    MyappCPP_logger::write_log( "<start_userDataStream>" ) ;

	    if ( api_key.size() == 0 ) {
		    MyappCPP_logger::write_log( "<start_userDataStream> API Key has not been set." ) ;
		    return ;
	    }


	    string url(BINANCE_HOST);
	    url += "/api/v1/userDataStream";

	    vector <string> extra_http_header;
	    string header_chunk("X-MBX-APIKEY: ");
	    

	    header_chunk.append( api_key );
	    extra_http_header.push_back(header_chunk);

	    MyappCPP_logger::write_log( "<start_userDataStream> url = |%s|" , url.c_str() ) ;
	    
	    string action = "POST";
	    string post_data = "";

	    string str_result;
	    curl_api_with_header( url, str_result , extra_http_header , post_data , action ) ;

	    if ( str_result.size() > 0 ) {
		    
		    try {
			    Json::Reader reader;
			    json_result.clear();	
			    reader.parse( str_result , json_result );
	        		
	        	} catch ( exception &e ) {
		     	MyappCPP_logger::write_log( "<start_userDataStream> Error ! %s", e.what() ); 
		    }   
		    MyappCPP_logger::write_log( "<start_userDataStream> Done." ) ;
	    
	    } else {
		    MyappCPP_logger::write_log( "<start_userDataStream> Failed to get anything." ) ;
	    }

	    MyappCPP_logger::write_log( "<start_userDataStream> Done.\n" ) ;

    }




    //--------------------
    //Keepalive user data stream (API-KEY)
    void 
    keep_userDataStream( const char *listenKey ) 
    {	
	    MyappCPP_logger::write_log( "<keep_userDataStream>" ) ;

	    if ( api_key.size() == 0 ) {
		    MyappCPP_logger::write_log( "<keep_userDataStream> API Key has not been set." ) ;
		    return ;
	    }


	    string url(BINANCE_HOST);
	    url += "/api/v1/userDataStream";

	    vector <string> extra_http_header;
	    string header_chunk("X-MBX-APIKEY: ");
	    

	    header_chunk.append( api_key );
	    extra_http_header.push_back(header_chunk);

	    string action = "PUT";
	    string post_data("listenKey=");
	    post_data.append( listenKey );

	    MyappCPP_logger::write_log( "<keep_userDataStream> url = |%s|, post_data = |%s|" , url.c_str() , post_data.c_str() ) ;
	    
	    string str_result;
	    curl_api_with_header( url, str_result , extra_http_header , post_data , action ) ;

	    if ( str_result.size() > 0 ) {
		    
		    MyappCPP_logger::write_log( "<keep_userDataStream> Done." ) ;
	    
	    } else {
		    MyappCPP_logger::write_log( "<keep_userDataStream> Failed to get anything." ) ;
	    }

	    MyappCPP_logger::write_log( "<keep_userDataStream> Done.\n" ) ;

    }





    //--------------------
    //Keepalive user data stream (API-KEY)
    void 
    close_userDataStream( const char *listenKey ) 
    {	
	    MyappCPP_logger::write_log( "<close_userDataStream>" ) ;

	    if ( api_key.size() == 0 ) {
		    MyappCPP_logger::write_log( "<close_userDataStream> API Key has not been set." ) ;
		    return ;
	    }


	    string url(BINANCE_HOST);
	    url += "/api/v1/userDataStream";

	    vector <string> extra_http_header;
	    string header_chunk("X-MBX-APIKEY: ");
	    

	    header_chunk.append( api_key );
	    extra_http_header.push_back(header_chunk);

	    string action = "DELETE";
	    string post_data("listenKey=");
	    post_data.append( listenKey );

	    MyappCPP_logger::write_log( "<close_userDataStream> url = |%s|, post_data = |%s|" , url.c_str() , post_data.c_str() ) ;
	    
	    string str_result;
	    curl_api_with_header( url, str_result , extra_http_header , post_data , action ) ;

	    if ( str_result.size() > 0 ) {
		    
		    MyappCPP_logger::write_log( "<close_userDataStream> Done." ) ;
	    
	    } else {
		    MyappCPP_logger::write_log( "<close_userDataStream> Failed to get anything." ) ;
	    }

	    MyappCPP_logger::write_log( "<close_userDataStream> Done.\n" ) ;

    }*/



    //-----------------
    // Curl's callback
    static size_t 
    curl_cb( void *content, size_t size, size_t nmemb, std::string *buffer ) 
    {	
	    buffer->append((char*)content, size*nmemb);
	    return size*nmemb;
    }




    //--------------------------------------------------
    void 
    curl_api( string &url, string &result_json ) {
	    vector <string> v;
	    string action = "GET";
	    string post_data = "";
	    curl_api_with_header( url , result_json , v, post_data , action );	
    } 



    //--------------------
    // Do the curl
    void 
    curl_api_with_header( string &url, string &str_result, vector <string> &extra_http_header , string &post_data , string &action ) 
    {
	    CURLcode res;

	    if( curl ) {

		    curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
		    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_cb);
		    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &str_result );
		    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
		    curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip");

		    if ( extra_http_header.size() > 0 ) {
			    
			    struct curl_slist *chunk = NULL;
			    for ( int i = 0 ; i < extra_http_header.size() ;i++ ) {
				    chunk = curl_slist_append(chunk, extra_http_header[i].c_str() );
			    }
			    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, chunk);
		    }

		    if ( post_data.size() > 0 || action == "POST" || action == "PUT" || action == "DELETE" ) {

			    if ( action == "PUT" || action == "DELETE" ) {
				    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, action.c_str() );
			    }
			    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data.c_str() );
     		}

		    res = curl_easy_perform(curl);

		    /* Check for errors */ 
		    if ( res != CURLE_OK ) {
			    MyappCPP_logger::write_log( "<curl_api> curl_easy_perform() failed: %s" , curl_easy_strerror(res) ) ;
		    } 	

	    }

    }

};


#endif
