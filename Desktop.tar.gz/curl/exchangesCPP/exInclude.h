
#define MAX_EXCHANGES 1
#define BINANCE_DEPTH 100

// ********************************EXCHANGES URLS***********************************
vector<string> urls = {
    "https://api.binance.com/api/v3/depth?symbol=XVSUSDT" // Binance
};
// ********************************EXCHANGES ERRORS*********************************
int actExErr = 0;
vector<int> exErr(MAX_EXCHANGES);
void handle_errorEx(const int& id, const string& s){
    cout << s << '\n';
    // deleting exchange from list
    mtxErr.lock();
    exErr[actExErr] = id;
    actExErr++;
    mtxErr.unlock();
}
// ********************************PRICES COMPARATOR********************************
struct prc{
    vector<pair<float,float>> v;
    int id;
};
struct prcAsk{
    bool operator()(const prc& a, const prc& b){
        return a.v[0].first < b.v[0].first
            || (a.v[0].first == b.v[0].first && a.v[0].second > b.v[0].second);
    }
};
struct prcBid{
    bool operator()(const prc& a, const prc& b){
        return a.v[0].first > b.v[0].first
            || (a.v[0].first == b.v[0].first && a.v[0].second > b.v[0].second);
    }
};
priority_queue<prc,vector<prc>,prcAsk> asks; // min ask possible
priority_queue<prc,vector<prc>,prcBid> bids; // max bid possible
//**********************************************************************************
