#include "exInclude.h"

//----------------------------------EXCHANGES PARSER----------------------------------

void binanceParser(const int& id, const unique_ptr<string>& httpData){
    Json::Value jsonData;
    Json::Reader jsonReader;
         
    if (jsonReader.parse(*httpData.get(), jsonData)) {
        if(jsonData.isMember("lastUpdateId")){
            int i = 0;
            vector<pair<float,float>> v1(BINANCE_DEPTH); // price, quantity
            vector<pair<float,float>> v2(BINANCE_DEPTH); // price, quantity
            for(auto it : jsonData["asks"]){
                v1[i].first = stof(it[0].asString());
                v1[i].second = stof(it[1].asString());
                i++;
            }
            i = 0;
            for(auto it : jsonData["bids"]){
                v2[i].first = stof(it[0].asString());
                v2[i].second = stof(it[1].asString());
                i++;
            }
            mtxCmp.lock();
                asks.push({ v1, id });
                bids.push({ v2, id });
            mtxCmp.unlock();
        }
        else if(jsonData.isMember("code")) 
            handle_errorEx(id, "Binance ERROR, code: " + jsonData["code"].asString() + ", msg: " + jsonData["msg"].asString());
        else 
            handle_errorEx(id, "1.Error reading Binance Json");
    }
    else
        handle_errorEx(id, "2.Error reading Binance Json");

}

void kukoinParser(const int& id, const unique_ptr<string>& httpData){

}

void parser(const int& id, const unique_ptr<string>& data) {
    switch(id) {
        case 0:  binanceParser(id, data);
                 break;
        case 1:  kukoinParser(id, data);
                 break;
        default: 
                 break;
    }
}

//----------------------------------EXCHANGES INI-------------------------------------

void exchangesIni(vector<pair<int,string>>& v, const string& cryptoPair){
    int id = 0;
    string trash;
    
    ifstream in("cryptosTXT/XVS.txt");
    auto cinbuf = cin.rdbuf(in.rdbuf());
    
    while(id != -1){
        cin >> id;
        if(id != -1){
            cin >> trash;
            v.push_back({ id, urls[id] });
        }
    }

    cin.rdbuf(cinbuf);
}


