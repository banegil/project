
#define MAX_TIMEOUT 1000

//----------------------------------CURL----------------------------------

static size_t callback(const char* in, size_t size, size_t num, string* out) {
    const size_t totalBytes(size * num);
    out->append(in, totalBytes);
    return totalBytes;
}

void doSomething(const pair<int,string>& ex) {
    CURL* curl = curl_easy_init();

    curl_easy_setopt(curl, CURLOPT_URL, ex.second.c_str());
    curl_easy_setopt(curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, MAX_TIMEOUT);

    long httpCode(0);
    unique_ptr<string> httpData(new string());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, httpData.get());

    CURLcode res = curl_easy_perform(curl);
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    curl_easy_cleanup(curl);
    
    if(CURLE_OK == res && httpCode == 200)
        parser(ex.first, httpData); // exchanges.h
    else {
        if(CURLE_OK != res)
            cout << "Timeout on Exchange " << ex.first << '\n';
        else
            handle_errorEx(ex.first, "Error httpCode: " + to_string(httpCode) + " on Exchange " + to_string(ex.first));
    }
}
