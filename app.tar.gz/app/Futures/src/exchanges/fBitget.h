

class fBitget: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "bg_d50fccdac7db6fea17237ea056a92bd6";
    string secret_key = "284a4f4144eec29df43aa7e34fc0022099cc9490ba402f769b8571e5bef37a81";
    string passphrase = "mySecretKey";
    
    public:
    fBitget(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> > depthCache;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.bitget.com/api/mix/v1/market/depth?symbol=" + symbol + "_UMCBL&limit=50";
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();    	
         	
         	mtxDepth.lock();
         	
         	depth.clear();                  
            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	            double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	            double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            } 
	        mtxDepth.unlock();
	        
	        depthCache = depth;
	        if(depthCache.empty())
	            throw exception();

	        } catch (std::exception const& e) {
            depth.clear();
            depthCache.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return depthCache;
      }
      return depthCache;
    }
   
    void wesbsocketInit_depth(string symbol){  
    try{
        time_t current_time;
        init_http("ws.bitget.com");
        long ts = 0, ts2;
        
        string symbol2 = symbol;
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        init_webSocket("ws.bitget.com", "443", "/mix/v1/stream");
        string s = "{\"op\":\"subscribe\",\"args\":[{\"instType\":\"mc\",\"channel\":\"books\",\"instId\":\"" + symbol + "\"}]}";
        write_Socket(s);
        Json::Reader reader;
        Json::Value result;
        read_Socket();	
        buffer_clear();

        time(&current_time);
        int ct = current_time;
        int ct3 = ct;
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            int ct4 = ct2;
            Json::Reader reader;
            Json::Value result;
            read_Socket();	
	        reader.parse( get_socket_data() , result );
            buffer_clear();             
            
            if(ct4 - ct3 > 20){
                ct4 = ct4;
                s = "{\"op\":\"ping\"}";
                write_Socket(s);            
            }
            
            if(ct2 - ct > 5){ 
                ct = ct2;
                std::async (&fBitget::curl_depth, this, symbol2);
            }
            
            mtxDepth.lock();
            
            ts2 = atof( result["data"][0]["ts"].asString().c_str() );
            if(ts2 >= ts){
                ts = ts2;
            
                for ( int i = 0 ; i < result["data"][0]["asks"].size(); i++ ) {
                    double price = atof( result["data"][0]["asks"][i][0].asString().c_str() );
                    double qty   = atof( result["data"][0]["asks"][i][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                }
                for ( int i = 0 ; i < result["data"][0]["bids"].size(); i++ ) {
                    double price = atof( result["data"][0]["bids"][i][0].asString().c_str() );
                    double qty   = atof( result["data"][0]["bids"][i][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }
            }
            
            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    bool send_order( string symbol, string side, double quantity, double price, bool open ) {	
       /* Json::Value json_result;
        string err;

        string ep = to_string (get_current_ms_epoch());

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url("https://api.bitget.com/api/mix/v1/order/placeOrder");
        string action = "POST";
        
        string post_data = "{\"symbol\":\"BTCUSDT_UMCBL\",\"marginCoin\":\"USDT\",\"size\":\"8\",\"side\":\"open_long\",\"orderType\":\"market\"}";
        string msg = ep + action + "/api/mix/v1/order/placeOrder";
        
        string signature =  base64_encode(hmac_sha256( secret_key.c_str(), msg.c_str() ));
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="ACCESS-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "ACCESS-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "ACCESS-TIMESTAMP:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "ACCESS-PASSPHRASE:";
        header_chunk.append( passphrase );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = get_id() + ": error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    return false;
            }   
        } 
        else {
            err = get_id() + ": order.size() is 0";
            writte_log(err);
            return false;
        }*/
        return true;
    }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
