

class fCoinex: public Exchange {
    mutex mtxDepth, mtxCurl, mtxW;
    map < string, map <double,double> >  depth, depthCache;
    string api_key = "7406D75A527449D68B932B5C18B1ECEA";
    string api_secret = "EF500ABB2303F42E0E84C4A55309618A745CAE5BC7B6E7FD";
    int num = 0;
    
    public:
    fCoinex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void wesbsocketInit_depth(string symbol){
    try{
        time_t current_time;
        init_http("perpetual.coinex.com");
        long ts = 0;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        init_webSocket("perpetual.coinex.com", "443", "/");
        string s = "{\"method\":\"depth.subscribe\",\"params\":[\"" + symbol + "\",20,\"0\",true],\"id\": 11}";
        write_Socket(s);
        Json::Reader reader;
	    Json::Value json_result;
        read_Socket();	
	    reader.parse( get_socket_data() , json_result );
        buffer_clear();
        
        time(&current_time);
        int ct = current_time;
        while (true) {
            Json::Reader reader;
	        Json::Value json_result;
            time(&current_time);
            int ct2 = current_time;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();

            if(ct2 - ct > TIME_REFRESH){ 
                ct = ct2;
                s = "{\"method\":\"depth.query\",\"params\":[\"" + symbol + "\",20,\"0.01\"],\"id\":15}";
                mtxW.lock();
                write_Socket(s);  
                mtxW.unlock();                
            }

            mtxDepth.lock();

            if(json_result["method"].asString() == "depth.update"){
                if(json_result["params"][1]["time"].asInt64() >= ts){
                    ts = json_result["params"][1]["time"].asInt64();
                    for ( int i = 0 ; i < json_result["params"][1]["asks"].size() ; i++ ) {
                        double price = atof( json_result["params"][1]["asks"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["params"][1]["asks"][i][1].asString().c_str());
                        if ( qty == 0.0 )
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
                    }
                    for ( int i = 0 ; i < json_result["params"][1]["bids"].size() ; i++ ) {
                        double price = atof( json_result["params"][1]["bids"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["params"][1]["bids"][i][1].asString().c_str());
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
                    }
                }
            }
            else{
                ts = json_result["result"]["time"].asInt64();
                depth.clear();
                for ( int i = 0 ; i < json_result["result"]["asks"].size() ; i++ ) {
                    double price = atof( json_result["result"]["asks"][i][0].asString().c_str());
                    double qty 	 = atof( json_result["result"]["asks"][i][1].asString().c_str());
                    if ( qty == 0.0 )
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                }
                for ( int i = 0 ; i < json_result["result"]["bids"].size() ; i++ ) {
                    double price = atof( json_result["result"]["bids"][i][0].asString().c_str());
                    double qty 	 = atof( json_result["result"]["bids"][i][1].asString().c_str());
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }
                depthCache = depth;
                num = 1;
            }

            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    bool send_order( string symbol, string side, double quantity, double price, bool open ) {
        Json::Value json_result;
        string err;

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url = "https://api.coinex.com/v1/order/market";
        string action = "POST";	
        string ep = to_string (get_current_ms_epoch());
        string post_data = "{\"access_id\":\"" + api_key + "\",\"amount\":\"" + to_string(quantity) + "\",\"market\":\"" + symbol + "\",\"timestamp\":" + ep + ",\"type\":\"" + side + "\",\"tonce\":" + ep + "}";
        string msg = "access_id=" + api_key + "&amount=" + to_string(quantity) + "&market=" + symbol + "&timestamp=" + ep + "&tonce=" + ep + "&type=" + side + "&secret_key=" + api_secret;
        string signature = md5(msg);
        string_toupper(signature);
        
        vector <string> extra_http_header;
        string header_chunk="User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="authorization:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Coinex: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    return false;
            }   
        } 
        else {
            err = "Coinex: order.size() is 0";
            writte_log(err);
            return false;
        }
        return false;
    }
   
    map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }

    map < string, map <double,double> > curl_depth(string symbol){
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string  s = "{\"method\":\"depth.query\",\"params\":[\"" + symbol + "\",50,\"0\"],\"id\":15}";
        mtxW.lock();
        write_Socket(s);
        mtxW.unlock();
        num = 0;
        while(num == 0){std::this_thread::sleep_for(std::chrono::microseconds(1));}
        return depthCache;
    }
};
