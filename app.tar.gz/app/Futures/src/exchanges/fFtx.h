
class fFtx: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "AdIMZbPwsjtn1q2gZemf59_rLSyGBJyoPu-q7u_M";
    string secret_key = "oXLsT0qNrh7KHlSNGtUOayPpNa23222rMINvk15E";
    
    public:
    fFtx(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        symbol = symbol.substr(0, symbol.find('-'));
        string s = "https://ftx.com/api/markets/" + symbol + "-PERP/orderbook?depth=100";
        map < string, map <double,double> > depthCache;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	
            mtxDepth.lock();
            
            depth.clear();    
	        for ( int i = 0 ; i < result["result"]["asks"].size(); i++ ) {
		        double price = atof( result["result"]["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["result"]["asks"][i][1].asString().c_str() );
		        depth["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["result"]["bids"].size() ; i++ ) {
		        double price = atof( result["result"]["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["result"]["bids"][i][1].asString().c_str() );
		        depth["bids"][price] = qty;
	        }

	        mtxDepth.unlock();
	        
	        depthCache = depth;
	        if(depthCache.empty())
	            throw exception();
	    
            } catch (std::exception const& e) {
            depthCache.clear();
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return depthCache;
      }
      return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
    try{
        string symbol2 = symbol;
        time_t current_time;
        init_http("ftx.com");
        long ts = 0, ts2;
        
        symbol = symbol.substr(0, symbol.find('-'));
        init_webSocket("ftx.com", "443", "/ws");
        string s = "{\"op\": \"subscribe\", \"channel\": \"ticker\", \"market\": \"" + symbol + "-PERP\"}";
        write_Socket(s);
        s = "{\"op\": \"subscribe\", \"channel\": \"orderbook\", \"market\": \"" + symbol + "-PERP\"}";
        write_Socket(s);
        Json::Reader reader;
        Json::Value result;
        for(int i = 0; i < 2; i++){
            read_Socket();	
            buffer_clear();
        }

        time(&current_time);
        int ct = current_time;
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            Json::Reader reader;
            Json::Value result;
            read_Socket();	
	        reader.parse( get_socket_data() , result );
            buffer_clear();
            
            if(ct2 - ct > 5){ 
                ct = ct2;
                std::async (&fFtx::curl_depth, this, symbol2);
            }
            
            mtxDepth.lock();

            ts2 = result["data"]["time"].asDouble() * 10000000;
            if(ts2 >= ts){
                ts = ts2;
                if(result["channel"].asString() == "ticker"){
	                double price = atof( result["data"]["ask"].asString().c_str() );
	                double qty   = atof( result["data"]["askSize"].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
	                price = atof( result["data"]["bid"].asString().c_str() );
	                qty   = atof( result["data"]["bidSize"].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }
                else if(result["channel"].asString() == "orderbook"){
                
                    for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	                    double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	                    double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
                    }
                    for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	                    double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	                    double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
                    }              
                }
                else
                    throw exception();   
            } 
            
            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    bool send_order( string symbol, string side, double quantity, double price, bool open ) {	
        Json::Value json_result;
        string err;
        string ep = to_string (get_current_ms_epoch());

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url("https://ftx.com/api/orders");
        string action = "POST";
        
        string_toupper(side);
        string post_data = "{\"market\": \"BTC-PERP\", \"side\": \"buy\", \"price\": 8500, \"size\": 1, \"type\": \"limit\", \"reduceOnly\": false, \"ioc\": false, \"postOnly\": false, \"clientId\": null}";
        string msg = ep + action + "/api/orders" + post_data;
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );

        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="FTX-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "FTX-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "FTX-TS:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = get_id() + ": error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    return false;
            }   
        } 
        else {
            err = get_id() + ": order.size() is 0";
            writte_log(err);
            return false;
        }
        return true;
    }
    
    void withdraw( string symbol, string address, double amount, string network ) {
        /*Json::Value json_result;
        string err;

        string ep = to_string (get_current_ms_epoch());

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url("https://ftx.com/api/wallet/withdrawals");
        string action = "POST";
        
        string_toupper(side);
        string post_data = "{\"coin\": \"USDTBEAR\",\"size\": 20.2,\"address\": \"0x83a127952d266A6eA306c40Ac62A4a70668FE3BE\",\"tag\": null,\"password\": \"my_withdrawal_password\",\"code\": 152823}";
        string msg = ep + action + "/wallet/withdrawals";
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="FTX-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "FTX-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "FTX-TS:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = get_id() + ": error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = get_id() + ": order.size() is 0";
            writte_log(err);
        }*/
    }
   
    map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }
};
