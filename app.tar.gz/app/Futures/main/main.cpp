#include "include.h"

#define DEBUG 2
#define WAIT 1000

bool openPos(map < string, int > index){
    auto itA = minAsks_open.begin();
    auto itB = maxBids_open.begin();
    auto ita = itA->second.second.begin();
    auto itb = itB->second.second.begin();
    string iC = itA->second.first;
    string iV = itB->second.first;
    vector<pair<string, double>> ordersBuy, ordersSell; // exchange, quantity
   
    double diff = 1 - itA->first / itB->first;
    if(diff > 0.0001 && iV != iC) {       
        
        while(diff > 0.0001 && iV != iC && itA != minAsks_open.end() && itB != maxBids_open.end()){      
            double totalQuantity = 0, price_qty = 0;
            bool which1, which2; 
            
            while( diff > 0.0001 && ita != itA->second.second.end() && itb != itB->second.second.end() ){
                double quantity = min(ita->second, itb->second);
                ita->second -= quantity;
                itb->second -= quantity;
                
                totalQuantity += quantity;
                price_qty += ita->first * quantity;
                
                which1 = which2 = 0;
                if(ita->second  == 0){
                    ita++;
                    which1 = 1;
                }    
                if(itb->second == 0){
                    itb++;
                    which2 = 1;
                }
                
                diff = (1 - (  (ita->first + ita->first * comission[iC]) 
                             / (itb->first - itb->first * comission[iV]) ) ); 
            }
            

            if(price_qty > 10 && price_qty < 50000) {
                if(price_qty > 600)
                    totalQuantity = 600 / price_qty;
                else
                    totalQuantity *= 0.9;
                
                bool check = 0;
                for(int i = 0; i < ordersBuy.size(); i++) 
                    if(iC == ordersBuy[i].first) {
                        ordersBuy[i].second += totalQuantity;
                        check = 1;
                    }
                
                if(!check)                        
                    ordersBuy.push_back(pair<string, double>(iC, totalQuantity));
                
                check = 0;    
                for(int i = 0; i < ordersSell.size(); i++) 
                    if(iV == ordersSell[i].first) {
                        ordersSell[i].second += totalQuantity;
                        check = 1;
                    }
                                     
                if(!check)  
                    ordersSell.push_back(pair<string, double>(iV, totalQuantity)); 
            }
            
            if(which1) {
                itA++;
                ita = itA->second.second.begin();
                iC = itA->second.first;
            }
            if(which2){
                itB++;
                itb = itB->second.second.begin();
                iV = itB->second.first;
            }
            
            diff = 1 - itA->first / itB->first ;                         
        }
        
        // open LONG & SHORT
        if(!ordersBuy.empty()) {
            vector<future<bool>> vFutBuy(ordersBuy.size()), vFutSell(ordersSell.size());
            
            int contBuy = 0, contSell = 0; 
            for (auto& x: ordersBuy) 
                vFutBuy[contBuy++] = std::async (&Exchange::send_order, ex[index[x.first]], symba, "buy", x.second, 0, 1);
            for (auto& x: ordersSell) 
                vFutSell[contSell++] = std::async (&Exchange::send_order, ex[index[x.first]], symba, "sell", x.second, 0, 1);
                 
            cout << '\n';
            if(1)
                cout << "--------------------------------------------------MULTIPLE OPEN ORDER----------------------------------------------------\n\n";   
            else
                cout << "---------------------------------------------------SINGLE OPEN ORDER-----------------------------------------------------\n\n";                            

            cout << "----------------------------------------------------------------------------------------------------------------------\n\n";
        }
    }
    return true;
}

bool closePos(map < string, int > index){    
    vector<pair<string, double>> ordersBuy, ordersSell; // exchange, quantity
        
    for(auto itSellers = openPositions.begin(); itSellers != openPositions.end(); itSellers++){ 
        string iC = itSellers->first;
        auto ita = asks_close[iC].begin();
        auto itaEnd = asks_close[iC].end();
                 
        for(auto itBuyers = openPositions[iC].begin(); itBuyers != openPositions[iC].end(); itBuyers++){
            string iV = itBuyers->first;
            auto itb = bids_close[iV].begin(); 
            auto itbEnd = bids_close[iV].end();     
            double diff = 1 - ita->first / itb->first;
                
            if(diff > itBuyers->second.first){            
                double totalQuantity = 0, averageAsk = 0, averageBid = 0;
                   
                while( diff > itBuyers->second.first && ita != itaEnd && itb != itbEnd ){
                    double quantity = min(ita->second, itb->second);
                    ita->second -= quantity;
                    ita->second -= quantity;
                    
                    totalQuantity += quantity;
                    averageAsk += ita->first * quantity;
                    averageBid += itb->first * quantity;
                    
                    if(ita->second == 0)
                        ita++;
                    if(ita->second == 0){
                        bids_close[iV].erase(itb);
                        itb = bids_close[iV].begin();
                    }
                    
                    diff = (1 - (  (ita->first + ita->first * comission[iC]) 
                                 / (itb->first - itb->first * comission[iV]) ) ); 
                }                
                
                double price_qty = averageAsk;
                averageAsk /= totalQuantity;
                averageBid /= totalQuantity;
                
                if(price_qty > 10 && averageAsk / averageBid > itBuyers->second.first) {                       
                    bool check = 0;
                    
                    if(price_qty > 600)
                        totalQuantity = 600 / price_qty;
                    else
                        totalQuantity *= 0.9;
                        
                    for(int i = 0; i < ordersBuy.size(); i++) 
                        if(iC == ordersBuy[i].first) {
                            ordersBuy[i].second += totalQuantity;
                            check = 1;
                        }
                    
                    if(!check)                        
                        ordersBuy.push_back(pair<string, double>(iC, totalQuantity));
                    
                    check = 0;    
                    for(int i = 0; i < ordersSell.size(); i++) 
                        if(iV == ordersSell[i].first) {
                            ordersSell[i].second += totalQuantity;
                            check = 1;
                        }
                                                 
                    if(!check)  
                        ordersSell.push_back(pair<string, double>(iV, totalQuantity)); 
                }                                          
            }             
        }
    }   
        
    // close LONG & SHORT
    if(!ordersBuy.empty()) {
        vector<future<bool>> vFutBuy(ordersBuy.size()), vFutSell(ordersSell.size());
        
        int contBuy = 0, contSell = 0; 
        for (auto& x: ordersBuy) 
            vFutBuy[contBuy++] = std::async (&Exchange::send_order, ex[index[x.first]], symba, "buy", x.second, 0, 0);
        for (auto& x: ordersSell) 
            vFutSell[contSell++] = std::async (&Exchange::send_order, ex[index[x.first]], symba, "sell", x.second, 0, 0);
             
        cout << '\n';
        if(1)
            cout << "--------------------------------------------------MULTIPLE CLOSE ORDER----------------------------------------------------\n\n";   
        else
            cout << "---------------------------------------------------SINGLE CLOSE ORDER-----------------------------------------------------\n\n";                            

        cout << "----------------------------------------------------------------------------------------------------------------------\n\n";
    }
    
    return true;
}

void init(string symbol, vector<bool> v, const int n){  
    vector<bool> vD(n, 1);
    ex.resize(n);
    map < string, int > index;
    
    ini(comission, index, v);
        
    vector<thread> ths(n);    
    for(int i = 0; i < n; i++) 
        ths[i] = thread (doSomething, i, symbol);

    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    
    while(1){}
    
    map < string, map <double,double> > depth;
    map <double,double,greater<double > > bidsmap;
    unordered_map <string, bool> bannedLong, bannedShort;
    while(1){
        minAsks_open.clear(); asks_close.clear();
        maxBids_open.clear(); bids_close.clear();

        for(int i = 0; i < n; i++) {
            if(vD[i]) {
                depth = ex[i]->get_socketDepth();    
                string id = ex[i]->get_id();
                if(id.back() != '-'){                
                    if(depth["asks"].size() > 0){        
                        if(bannedLong[id])
                            asks_close[id] = depth["asks"];                       
                        else       
                            minAsks_open.insert( pair< double, pair < string, map <double,double> > >(depth["asks"].begin()->first + depth["asks"].begin()->first  * comission[id],
                                                 pair< string, map <double,double> >(id, depth["asks"])) );
                    }
                    
                    if(depth["bids"].size() > 0 ){
                        if(bannedShort[id])
                            bids_close[id].insert(depth["bids"].begin(), depth["bids"].end());                      
                        else {
                            bidsmap.clear();
                            bidsmap.insert(depth["bids"].begin(), depth["bids"].end());
                            auto it = depth["bids"].end(); --it;
                            maxBids_open.insert( pair< double, pair < string, map <double,double,greater<double > > > >(it->first - it->first * comission[id],
                                                 pair < string, map <double,double,greater<double > > >(id, bidsmap)) );
                        }
                    }
                }
                else
                    v[i] = 0;
            }
        }        
        
        future<bool> f1 = std::async (openPos, index);
        future<bool> f2 = std::async (closePos, index);
        
        f1.get(); f2.get();
    }
    
    for(int i = 0; i < n; i++)
        ths[i].join();
}

int main() {
    vector<bool> v(MAX_EXCHANGES);
    int num = 0;
    
    if(vCandidates(symba, v, num))
        init(symba, v, num);
    else
        cout << "Symbol not supported!" << endl;
    return 0;
}
