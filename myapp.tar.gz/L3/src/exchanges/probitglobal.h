

class Probitglobal: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "88ac915f891ffd76";
    string secret_key = "59c8dbf83c21022742009f0b01e96de2";
    string accessToken = "";
    
    public:
    Probitglobal(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        string s = "https://api.probit.com/api/exchange/v1/order_book?market_id=" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	
         	mtxDepth.lock();
         	
         	depth.clear(); 
     		for  ( int i = 0 ; i < result["data"].size() ; i++ ) {
     	        double price = atof( result["data"][i]["price"].asString().c_str() );
	            double qty   = atof( result["data"][i]["quantity"].asString().c_str() );
     		    if(result["data"][i]["side"].asString() == "sell")
	                depth["asks"][price] = qty;
	            else
	                depth["bids"][price] = qty;
            }
	        
            mtxDepth.unlock();
        
       } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){ 
        time_t current_time; 
        int i;
        string j;
        init_http("api.probit.com");
        int timestamp = 0;
        curl_depth(symbol);
        int expire = getToken() - 30;
        
        try {
            init_webSocket("api.probit.com", "443", "/api/exchange/v1/ws");
            string s = "{\"type\":\"subscribe\",\"channel\":\"marketdata\",\"market_id\":\"" + symbol + "\",\"interval\":100,\"filter\":[\"order_books_l0\"]}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
	        read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();
            
            if(json_result.isMember("order_books_l0")){	
         		for  ( int i = 0 ; i < json_result["order_books_l0"].size() ; i++ ) {
         	        double price = atof( json_result["order_books_l0"][i]["price"].asString().c_str() );
		            double qty   = atof( json_result["order_books_l0"][i]["quantity"].asString().c_str() );
         		    if(json_result["order_books_l0"][i]["side"].asString() == "sell")
		                depth["asks"][price] = qty;
		            else
		                depth["bids"][price] = qty;
	            }
	        }
	        else
	            cout << "ERROR" << endl;

            time(&current_time);
            int ct = current_time;
            int ct3 = ct;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                int ct4 = ct2;
                Json::Reader reader;
			    Json::Value json_result;
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                if(ct4 - ct3 > expire){ 
                    ct3 = ct4;
                    expire = getToken() - 30;
                }
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (launch::async, &Probitglobal::curl_depth, this, symbol);
                }
                
                mtxDepth.lock();

                if(json_result.isMember("order_books_l0")){	
             		for  ( int i = 0 ; i < json_result["order_books_l0"].size() ; i++ ) {
             	        double price = atof( json_result["order_books_l0"][i]["price"].asString().c_str() );
	                    double qty   = atof( json_result["order_books_l0"][i]["quantity"].asString().c_str() );
             		    if(json_result["order_books_l0"][i]["side"].asString() == "sell") {
             		        if ( qty == 0.0 ) 
		                        depth["asks"].erase(price);
	                        else 
		                        depth["asks"][price] = qty;
	                    }
	                    else {
	                        if ( qty == 0.0 )
		                        depth["bids"].erase(price);
                            else 
		                        depth["bids"][price] = qty;
	                    }
                    }
                }
                else
                    writte_log( "ERROR: <wss_depth> Probitglobal: " + symbol );
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        Json::Value json_result;
        string err;

        string url("https://api.probit.com/api/exchange/v1/new_order");
        string action = "POST";
        
        string post_data = "{\"market_id\":\"" + symbol + "\",\"type\":\"limit\",\"side\":\"" + side + "\",\"time_in_force\":\"gtc\",\"limit_price\":\"3772.4\",\"quantity\":\"" + to_string(quantity) + "\"}";

        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Authorization: Bearer " + accessToken;
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Binance: send_order(), error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Binance: send_order(), order.size() is 0";
            writte_log(err);
        }
    }
    
    void withdraw( string coin, string address, double amount, string network ) {	
        Json::Value json_result;
        string err;

        string url("https://api.probit.com/api/exchange/v1/withdrawal");
        string action = "POST";
        
        string post_data = "{\"currency_id\":\"" + coin + "\",\"address\":\"" + address + "\",\"destination_tag\":\"\",\"amount\":\"" + to_string(amount) + "\"}";

        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Authorization: Bearer " + accessToken;
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Binance: send_order(), error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Binance: send_order(), order.size() is 0";
            writte_log(err);
        }
    }
    
    int getToken(){
        Json::Value json_result;
        string err;
        int expires = 0;

        string url("https://accounts.probit.com/token");
        string action = "POST";
        
        string post_data = "{\"grant_type\":\"client_credentials\"}";
        string auth = "Basic " + base64_encode(api_key + ":" + secret_key);

        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Authorization: " + auth;
        extra_http_header.push_back(header_chunk);

        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            accessToken = json_result["access_token"].asString();
	            expires = json_result["expires_in"].asUInt64(); 
            		
            	} catch ( exception &e ) {
             	    err = "Probitglobal: getToken(), error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Probitglobal: getToken(), is 0";
            writte_log(err);
        }
        
        return expires;
    }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
