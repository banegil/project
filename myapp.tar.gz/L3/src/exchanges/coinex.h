

class Coinex: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "A91DDF24854643F9881B02FF476F2891";
    string api_secret = "7BD4DF45A4C871B86BDE2F58FEBDC72342EF3B4FFFC39381";
    
    public:
    Coinex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.coinex.com/v1/market/depth?market=" + symbol + "&merge=0";
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	
            mtxDepth.lock(); 
         	
         	depth.clear(); 
            for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
	            double price = atof( result["data"]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
	            double price = atof( result["data"]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	            
            mtxDepth.unlock();
        
        } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){
        int i, lastUpdateId = 0;
        time_t current_time;
        init_http("socket.coinex.com");
        string symbol2 = symbol;
        int timestamp = 0;
        
        try {
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            init_webSocket("socket.coinex.com", "443", "/");
            string s = "{\"method\":\"depth.subscribe\",\"params\":[\"" + symbol + "\",50,\"0.01\",true],\"id\": 11}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();
            
            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
			    reader.parse( get_socket_data() , json_result );
                buffer_clear();

                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (launch::async, &Coinex::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();

                if(json_result.isMember("params")){
             	        if(json_result["params"][1].isMember("asks")){
                            for ( i = 0 ; i < json_result["params"][1]["asks"].size() ; i++ ) {
                                double price = atof( json_result["params"][1]["asks"][i][0].asString().c_str());
                                double qty 	 = atof( json_result["params"][1]["asks"][i][1].asString().c_str());
                                if ( qty == 0.0 )
                                    depth["asks"].erase(price);
                                else 
                                    depth["asks"][price] = qty;
                            }
                        }
                        if(json_result["params"][1].isMember("bids")){
                            for ( i = 0 ; i < json_result["params"][1]["bids"].size() ; i++ ) {
                                double price = atof( json_result["params"][1]["bids"][i][0].asString().c_str());
                                double qty 	 = atof( json_result["params"][1]["bids"][i][1].asString().c_str());
                                if ( qty == 0.0 ) 
                                    depth["bids"].erase(price);
                                else 
                                    depth["bids"][price] = qty;
                            }
                        }
                }
                else
                    writte_log( "ERROR: <wss_depth> Coinex: " + symbol );

                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {
        Json::Value json_result;
        string err;

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url = "https://api.coinex.com/v1/order/market";
        string action = "POST";	
        string ep = to_string (get_current_ms_epoch());
        string post_data = "{\"access_id\":\"" + api_key + "\",\"amount\":\"" + to_string(quantity) + "\",\"market\":\"" + symbol + "\",\"tonce\":" + ep + ",\"type\":\"" + side + "\"}";
        string msg = "access_id=" + api_key + "&amount=" + to_string(quantity) + "&market=" + symbol + "&tonce=" + ep + "&type=" + side + "&secret_key=" + api_secret;
        string signature = md5(msg);
        string_toupper(signature);
        
        vector <string> extra_http_header;
        string header_chunk="User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="authorization:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Coinex: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Coinex: order.size() is 0";
            writte_log(err);
        }
    }
    
    void withdraw( string coin, string address, double amount, string network ) {
        Json::Value json_result;
        string err;
          string ep = to_string (get_current_ms_epoch());      
        string url = "https://api.coinex.com/v1/balance/coin/withdraw";
        string action = "POST";	

        string post_data = "{\"access_id\":\"" + api_key + "\",\"actual_amount\":\"" + to_string(amount) + "\",\"coin_address\":\"" + address + "\",\"coin_type\":\"" + coin + "\",\"smart_contract_name\":\"" + network + "\",\"tonce\":" + ep + ",\"transfer_method\":\"onchain\"}";
        string msg = "access_id=" + api_key + "&actual_amount=" + to_string(amount) + "&coin_address=" + address + "&coin_type=" + coin + "&smart_contract_name=" + network + "&tonce=" + ep + "&transfer_method=onchain&secret_key=" + api_secret;
        string signature = md5(msg);
        string_toupper(signature);

        vector <string> extra_http_header;
        string header_chunk="User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="authorization:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Coinex: error reading withdraw response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Coinex: withdraw.size() is 0";
            writte_log(err);
        }
    }
   
    map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }

    map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }
};
