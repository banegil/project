


class Hitbtc: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "7sr5Qs59PwrL0_Au_1lLKXNOJlBPfU_R";
    string secret_key = "fsG2cxoqVCgxYZmju1EMRXTp9lK3jqpE";
    
    public:
    Hitbtc(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    
    void curl_depth(string symbol){
        Json::Value result; 
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.hitbtc.com/api/3/public/orderbook/" + symbol;
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	
         	mtxDepth.lock();
         	
         	depth.clear(); 
            for ( int i = 0 ; i < result["ask"].size(); i++ ) {
	            double price = atof( result["ask"][i][0].asString().c_str() );
	            double qty   = atof( result["ask"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["bid"].size() ; i++ ) {
	            double price = atof( result["bid"][i][0].asString().c_str() );
	            double qty   = atof( result["bid"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	        
            mtxDepth.unlock();
        
      } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time; 
        init_http("api.hitbtc.com");
        curl_depth(symbol);
        string symbol2 = symbol;
        int timestamp = 0;
        
        try {
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            init_webSocket("api.hitbtc.com", "443", "/api/3/ws/public");
            string s = "{\"method\": \"subscribe\",\"ch\": \"orderbook/D20/100ms\",\"params\": {\"symbols\": [\"" + symbol + "\"]},\"id\": 123}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;
            read_Socket();	
            reader.parse( get_socket_data() , result );
            buffer_clear();

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (launch::async, &Hitbtc::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();

             	if(result.isMember("data") && result["data"].isMember(symbol)){	
             	    int ts = json_result["data"][symbol]["t"].asUInt64();
             	    if(ts > timestamp){
             	        timestamp = ts;
             	        
                        for ( int i = 0 ; i < result["data"][symbol]["a"].size(); i++ ) {
	                        double price = atof( result["data"][symbol]["a"][i][0].asString().c_str() );
	                        double qty   = atof( result["data"][symbol]["a"][i][1].asString().c_str() );
                            if ( qty == 0.0 ) 
                                depth["asks"].erase(price);
                            else 
                                depth["asks"][price] = qty;
                        }
                        for  ( int i = 0 ; i < result["data"][symbol]["b"].size() ; i++ ) {
	                        double price = atof( result["data"][symbol]["b"][i][0].asString().c_str() );
	                        double qty   = atof( result["data"][symbol]["b"][i][1].asString().c_str() );
                            if ( qty == 0.0 ) 
                                depth["bids"].erase(price);
                            else 
                                depth["bids"][price] = qty;
                        }
                    }
                }
                else
                    writte_log( "ERROR: <wss_depth> Hitbtc: " + symbol );
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        Json::Value json_result;
        string err;

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string ep = to_string (get_current_ms_epoch());

        string url("https://api.hitbtc.com/api/3/spot/order");
        string action = "POST";
        
        string_toupper(side);
        string msg = action + "/api/3/spot/order{\"symbol\":\"" + symbol + "\",\"side\":\"" + side + "\",\"quantity\":\"" + to_string(quantity) + "\",\"price\":\"" + to_string(price) + "\"}" + ep;
        string post_data = "{\"symbol\":\"ETHBTC\",\"side\":\"sell\",\"quantity\":\"0.063\",\"price\":\"0.046016\"}";
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        string base = base64_encode(api_key + ":" + signature + ":" + ep);
                
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Authorization: HS256 " + base;
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Hitbtc: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Hitbtc: order.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
