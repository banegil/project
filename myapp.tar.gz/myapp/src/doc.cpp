
#include "exchange.h"

class Poloniex: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Poloniex(const int& id, string &api_key, string &secret_key) : Exchange(id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '_';
        string s = "https://poloniex.com/public?command=returnOrderBook&currencyPair=" + symbol + "&depth=50";
        get_curl(s, result);
     	
     	if(result.isMember("asks") && result.isMember("bids")){	
	        for ( int i = 0 ; i < result["asks"].size(); i++ ) {
		        double price = atof( result["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["asks"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
		        double price = atof( result["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["bids"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        cout << "ERROR" << endl;
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){
        int i;
        string j;
        depth = curl_depth(symbol);
        init_http("api2.poloniex.com");
        
        try {
            symbol[symbol.find('-')] = '_';
            init_webSocket("api2.poloniex.com", "443", "/");
            string s = "{\"command\": \"subscribe\", \"channel\": \"" + symbol + "\"}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
		    for(int i = 0; i < 2; i++){
		        read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
		    }

            while (true) {
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                mtxDepth.lock();
                
                if(json_result[0].asUInt64() != 1010){
                    if(json_result[2][0][1].asUInt64() == 1){
                        double price = atof( json_result[2][0][2].asString().c_str());
                        double qty 	 = atof( json_result[2][0][3].asString().c_str());
                        if ( qty == 0.0 ) {
                            depth["bids"].erase(price);
                        } else {
                            depth["bids"][price] = qty;
                        }
                    }
                    if(json_result[2][0][1].asUInt64() == 0){
                        double price = atof( json_result[2][0][2].asString().c_str());
                        double qty 	 = atof( json_result[2][0][3].asString().c_str());
                        if ( qty == 0.0 ) {
                            depth["asks"].erase(price);
                        } else {
                            depth["asks"][price] = qty;
                        }
                    }
                }
                
                while(50 < depth["bids"].size())
                    depth["bids"].erase( prev( depth["bids"].end() ) );
                while(50 < depth["asks"].size())
                    depth["asks"].erase( prev( depth["asks"].end() ) );
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
            cout << "ERROR: " << e.what() << endl;
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};

int main(){
string g = "Ubguygb", m="Ugbuig";
    Poloniex e(1, g, m);
    //e.curl_depth("USDT-ETH");
    e.wesbsocketInit_depth("BTC-ETH"); 
}
