

class Bithumb: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Bithumb(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '_';
        string s = "https://api.bithumb.com/public/orderbook/" + symbol;
        get_curl(s, result);
     	
     	if(result.isMember("data") && result["data"].isMember("asks")){	
	        for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
		        double price = atof( result["data"]["asks"][i]["price"].asString().c_str() );
		        double qty   = atof( result["data"]["asks"][i]["quantity"].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
		        double price = atof( result["data"]["bids"][i]["price"].asString().c_str() );
		        double qty   = atof( result["data"]["bids"][i]["quantity"].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Bithumb: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
        depth = curl_depth(symbol);
        init_http("pubwss.bithumb.com");
        
        try {
            symbol[symbol.find('-')] = '_';
            init_webSocket("pubwss.bithumb.com", "443",  "/pub/ws");
            string s = "{\"type\":\"orderbookdepth\", \"symbols\":[\"" + symbol + "\"]}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;
            for(int i = 0; i < 2; i++){
                read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
            }

            while (true) {
                read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
                
                mtxDepth.lock();

                if(result.isMember("content") && result["content"].isMember("list")){	
	                for ( int i = 0 ; i < result["content"]["list"].size(); i++ ) {
		                double price = atof( result["content"]["list"][i]["price"].asString().c_str() );
		                double qty   = atof( result["content"]["list"][i]["quantity"].asString().c_str() );
		                if(result["content"]["list"][i]["orderType"].asString() == "ask") {
		                    if ( qty == 0.0 ) 
			                    depth["asks"].erase(price);
		                    else 
			                    depth["asks"][price] = qty;
			            }
			            else {
			                if ( qty == 0.0 ) 
			                    depth["bids"].erase(price);
		                    else 
			                    depth["bids"][price] = qty; 
			            }
	                }
	            }
	            else {
                    writte_log( "ERROR: <wss_depth> Bithumb: " + symbol );
                }
                    
                while(100 < depth["bids"].size())
                    depth["bids"].erase( depth["bids"].begin() );
                while(100 < depth["asks"].size())
                    depth["asks"].erase( prev( depth["asks"].end() ) );
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
