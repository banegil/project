

class Ascendex: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Ascendex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '/';
        string s = "https://ascendex.com/api/pro/v1/depth?symbol=" + symbol;
        get_curl(s, result);
     	
     	if(result.isMember("data") && result["data"].isMember("data") && result["data"]["data"].isMember("asks")){	
	        for ( int i = 0 ; i < result["data"]["data"]["asks"].size(); i++ ) {
		        double price = atof( result["data"]["data"]["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["data"]["data"]["asks"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["data"]["data"]["bids"].size() ; i++ ) {
		        double price = atof( result["data"]["data"]["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["data"]["data"]["bids"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Ascendex: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        depth = curl_depth(symbol);
        init_http("ascendex.com");
        
        try {
            string symbol2 = symbol;
            symbol[symbol.find('-')] = '/';
            init_webSocket("ascendex.com", "443", "/api/pro/v2/stream");
            string s = "{ \"op\": \"sub\", \"id\": \"abc123\", \"ch\":\"depth:" + symbol + "\" }";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;
		    for(int i = 0; i < 4; i++){
		        read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
		    }

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
			    Json::Value json_result;
                read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
                
                mtxDepth.lock();

                if(ct2 - ct >= 5){
                    ct = ct2;
                    depth.clear();
                    depth = curl_depth(symbol2);
                }
                else {
                    if(result.isMember("data") && result["data"].isMember("asks")){	
	                    for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
		                    double price = atof( result["data"]["asks"][i][0].asString().c_str() );
		                    double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
	                        if ( qty == 0.0 ) 
		                        depth["asks"].erase(price);
	                        else 
		                        depth["asks"][price] = qty;
	                    }
	                    for ( int i = 0 ; i < result["data"]["bids"].size(); i++ ) {
		                    double price = atof( result["data"]["bids"][i][0].asString().c_str() );
		                    double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
	                        if ( qty == 0.0 ) 
		                        depth["bids"].erase(price);
	                        else 
		                        depth["bids"][price] = qty;
	                    }
	                }
	                else {
                        write_Socket(R"({ "op": "pong" })");
                        if(!result.isMember("m"))
                            writte_log( "ERROR: <wss_depth> Aax: " + symbol );
                    }
                }
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
