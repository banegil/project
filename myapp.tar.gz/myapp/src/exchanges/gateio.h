

class Gateio: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Gateio(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '_';
        string s = "https://api.gateio.ws/api/v4/spot/order_book?currency_pair=" + symbol + "&limit=50";
        get_curl(s, result);
     	
     	if(result.isMember("asks") && result.isMember("bids")){	
	        for ( int i = 0 ; i < result["asks"].size(); i++ ) {
		        double price = atof( result["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["asks"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
		        double price = atof( result["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["bids"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Gateio: " + symbol ); 

	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time; 
        int i, lastUpdateId = 0;
        init_http("ws.gate.io");
        
        try {
            string symbol2 = symbol;
            symbol[symbol.find('-')] = '_';
            init_webSocket("ws.gate.io", "443", "/v3");
            string s = "{\"id\":12312, \"method\":\"depth.subscribe\", \"params\":[\"" + symbol + "\", 30, \"0.0001\"]}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();
            
            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
			    reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                mtxDepth.lock();
               
                if(ct2 - ct >= 5){
                    ct = ct2;
                    depth.clear();
                    depth = curl_depth(symbol2);
                }               
                else {
                    if(json_result["params"][1].isMember("bids")){
                        for ( i = 0 ; i < json_result["params"][1]["bids"].size() ; i++ ) {
                            double price = atof( json_result["params"][1]["bids"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["params"][1]["bids"][i][1].asString().c_str());
                            if ( qty == 0.0 ) {
                                depth["bids"].erase(price);
                            } else {
                                depth["bids"][price] = qty;
                            }
                        }
                    }
                    if(json_result["params"][1].isMember("asks")){
                        for ( i = 0 ; i < json_result["params"][1]["asks"].size() ; i++ ) {
                            double price = atof( json_result["params"][1]["asks"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["params"][1]["asks"][i][1].asString().c_str());
                            if ( qty == 0.0 ) {
                                depth["asks"].erase(price);
                            } else {
                                depth["asks"][price] = qty;
                            }
                        }
                    }
                }
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
