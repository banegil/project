


class Kukoin: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Kukoin(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        string s = "https://api.kucoin.com/api/v1/market/orderbook/level2_100?symbol=" + symbol;
        get_curl(s, result);
        
        if(result.isMember("asks") && result.isMember("bids")){
	        for ( int i = 0 ; i < result["asks"].size(); i++ ) {
		        double price = atof( result["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["asks"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
		        double price = atof( result["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["bids"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Kukoin: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time;
        int i, pingInterval, lastUpdateId = 0;
        string token, endpoints;
        string idC = "1545910660740";
        string s = "https://api.kucoin.com/api/v1/bullet-public";
        Json::Value result;
        post_curl(s, result, "");
        endpoints = result["data"]["instanceServers"][0]["endpoint"].asString();
        string endpoint = endpoints.substr(6,17);
        token = result["data"]["token"].asString();
        pingInterval = result["data"]["instanceServers"][0]["pingInterval"].asUInt64();
        pingInterval /= 1000;
        init_http(endpoint);

        try {
            s = "/endpoint?token=" + token + "&[connectId=" + idC + "]";
            init_webSocket(endpoint, "443", s.c_str());
            Json::Reader reader;
		    Json::Value json_result;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();
            write_Socket(R"({"id":"1545910590801","type":"ping"})");
            s = "{\"id\": 1545910660740,\"type\": \"subscribe\",\"topic\": \"/spotMarket/level2Depth50:" + symbol + "\",\"response\": true}";
            write_Socket(s);
            
            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                if(ct2 - ct >= pingInterval - 1){
                    ct = ct2;
                    write_Socket(R"({"id":"1545910590801","type":"ping"})");
                }
                
                Json::Reader reader;
			    Json::Value json_result;
                read_Socket();	
			    reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                if(json_result.isMember("data") && json_result["data"].isMember("bids")){
	                int new_updateId  = json_result["data"]["timestamp"].asInt64();
	                
	                if ( new_updateId > lastUpdateId ) {
	                    mtxDepth.lock();
		                for ( i = 0 ; i < json_result["data"]["bids"].size() ; i++ ) {
			                double price = atof( json_result["data"]["bids"][i][0].asString().c_str());
			                double qty 	 = atof( json_result["data"]["bids"][i][1].asString().c_str());
			                if ( qty == 0.0 ) {
				                depth["bids"].erase(price);
			                } else {
				                depth["bids"][price] = qty;
			                }
		                }
		                for ( i = 0 ; i < json_result["data"]["asks"].size() ; i++ ) {
			                double price = atof( json_result["data"]["asks"][i][0].asString().c_str());
			                double qty 	 = atof( json_result["data"]["asks"][i][1].asString().c_str());
			                if ( qty == 0.0 ) {
				                depth["asks"].erase(price);
			                } else {
				                depth["asks"][price] = qty;
			                }
		                }
		                mtxDepth.unlock();		
		                lastUpdateId = new_updateId;
	                }
	             }
	             
	            while(100 < depth["bids"].size())
                    depth["bids"].erase( depth["bids"].begin() );
                while(100 < depth["asks"].size())
                    depth["asks"].erase( prev( depth["asks"].end() ) );
            }
            webSocket_close();
        } catch (std::exception const& e) {
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
