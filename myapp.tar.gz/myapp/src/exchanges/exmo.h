

class Exmo: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Exmo(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '_';
        string s = "pair=" + symbol + "&limit=100";
        string s2 = "https://api.exmo.com/v1.1/order_book";
        post_curl(s2, result, s);
     	
     	if(result.isMember(symbol) && result[symbol].isMember("ask")){	
	        for ( int i = 0 ; i < result[symbol]["ask"].size(); i++ ) {
		        double price = atof( result[symbol]["ask"][i][0].asString().c_str() );
		        double qty   = atof( result[symbol]["ask"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result[symbol]["bid"].size() ; i++ ) {
		        double price = atof( result[symbol]["bid"][i][0].asString().c_str() );
		        double qty   = atof( result[symbol]["bid"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Exmo: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){ 
        time_t current_time;  
        init_http("ws-api.exmo.com");
                
        try {
            string symbol2 = symbol;
            init_webSocket("ws-api.exmo.com", "443", "/v1/public");
            symbol[symbol.find('-')] = '_';
            string s = "{\"id\": 1, \"method\": \"subscribe\",\"topics\": [\"spot/order_book_updates:" + symbol + "\"]}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;
		    for(int i = 0; i < 2; i++){
		        read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
		    }

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
                
                mtxDepth.lock();

                if(ct2 - ct >= 5){
                    ct = ct2;
                    depth.clear();
                    depth = curl_depth(symbol2);
                }
                else {
                 	if(result.isMember("data") && result["data"].isMember("ask")){	
	                    for ( int i = 0 ; i < result["data"]["ask"].size(); i++ ) {
		                    double price = atof( result["data"]["ask"][i][0].asString().c_str() );
		                    double qty   = atof( result["data"]["ask"][i][1].asString().c_str() );
                            if ( qty == 0.0 ) 
                                depth["asks"].erase(price);
                            else 
                                depth["asks"][price] = qty;
	                    }
	                    for  ( int i = 0 ; i < result["data"]["bid"].size() ; i++ ) {
		                    double price = atof( result["data"]["bid"][i][0].asString().c_str() );
		                    double qty   = atof( result["data"]["bid"][i][1].asString().c_str() );
                            if ( qty == 0.0 ) 
                                depth["bids"].erase(price);
                            else 
                                depth["bids"][price] = qty;
	                    }
	                }
	                else 
	                    writte_log( "ERROR: <wss_depth> Exmo: " + symbol );
	            }
	            
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
