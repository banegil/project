

class Bitmart: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Bitmart(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    
    map < string, map <double,double> > curl_depth(string symbol){
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '_';
        string s = "https://api-cloud.bitmart.com/spot/v1/symbols/book?symbol=" + symbol + "&precision=6";
        get_curl(s, result);
     	
     	if(result.isMember("data") && result["data"].isMember("buys")){	
	        for ( int i = 0 ; i < result["data"]["buys"].size(); i++ ) {
		        double price = atof( result["data"]["buys"][i]["price"].asString().c_str() );
		        double qty   = atof( result["data"]["buys"][i]["amount"].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["data"]["sells"].size() ; i++ ) {
		        double price = atof( result["data"]["sells"][i]["price"].asString().c_str() );
		        double qty   = atof( result["data"]["sells"][i]["amount"].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Bitmart: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        init_http("ws-manager-compress.bitmart.com");
        
        try {
            symbol[symbol.find('-')] = '_';
            init_webSocket("ws-manager-compress.bitmart.com", "443", "/api?protocol=1.1");
            string s = "{\"op\": \"subscribe\", \"args\": [\"spot/depth20:" + symbol + "\"]}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;
	        read_Socket();	

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                if(ct2 - ct >= 17){
                    ct = ct2;
                    write_Socket(R"({"ping"})");
                }
                read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
                
                mtxDepth.lock();

             	if(result.isMember("data") && result["data"][0].isMember("asks")){	
	                for ( int i = 0 ; i < result["data"][0]["asks"].size(); i++ ) {
		                double price = atof( result["data"][0]["asks"][i][0].asString().c_str() );
		                double qty   = atof( result["data"][0]["asks"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
	                }
	                for  ( int i = 0 ; i < result["data"][0]["bids"].size() ; i++ ) {
		                double price = atof( result["data"][0]["bids"][i][0].asString().c_str() );
		                double qty   = atof( result["data"][0]["bids"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
	                }
	            }
	            else
	                writte_log( "ERROR: <wss_depth> Bitmart: " + symbol );
                    
                while(50 < depth["bids"].size())
                    depth["bids"].erase( depth["bids"].begin() );
                while(50 < depth["asks"].size())
                    depth["asks"].erase( prev( depth["asks"].end() ) );
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
