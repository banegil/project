

class Digifinex: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    string api_key = "945d77d49c21eb";
    string secret_key = "94f36bd0f99f29bc2fe47ab6af5f4291879b2cc896";
    
    public:
    Digifinex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '_';
        transform(symbol.begin(), symbol.end(), symbol.begin(),
        [](unsigned char c){ return tolower(c); });
        string s = "https://openapi.digifinex.com/v3/order_book?symbol=" + symbol + "&limit=100";
        get_curl(s, result);
     	
     	if(result.isMember("asks")){	
	        for ( int i = 0 ; i < result["asks"].size(); i++ ) {
		        double price = atof( result["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["asks"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
		        double price = atof( result["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["bids"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Digifinex: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        init_http("openapi.digifinex.com");
        			    Json::Value json_result;
        try {
            string symbol2 = symbol;
            symbol[symbol.find('-')] = '_';
            init_webSocket("openapi.digifinex.com", "443",  "/ws/v1/");
            string s = "{\"id\":12312, \"method\":\"depth.subscribe\", \"params\":[\"" + symbol + "\"]}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;
		    for(int i = 0; i < 2; i++){
	            read_Socket();	
	            s = decompress_deflate(get_socket_data());
		        reader.parse( s , result );
                buffer_clear();
            }
            

            time(&current_time);
            int ct = current_time;
            int ct3 = ct;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                int ct4 = ct2;
                Json::Reader reader;
                read_Socket();	
		        s = decompress_deflate(get_socket_data());
		        reader.parse( s , json_result );
                buffer_clear();
                
                if(ct4 - ct3 >= 50){
                    ct3 = ct4;
                    s = "{\"id\":12312, \"method\":\"depth.subscribe\", \"params\":[\"" + symbol + "\"]}";
                    write_Socket(s);
                }
                
                mtxDepth.lock();

                if(ct2 - ct >= 70){
                    ct = ct2;
                    depth.clear();
                    depth = curl_depth(symbol2);
                }
                else {
                    if(json_result.isMember("params") && json_result["params"][1].isMember("asks")){	
	                    for ( int i = 0 ; i < json_result["params"][1]["asks"].size(); i++ ) {
		                    double price = atof( json_result["params"][1]["asks"][i][0].asString().c_str() );
		                    double qty   = atof( json_result["params"][1]["asks"][i][1].asString().c_str() );
		                    if ( qty == 0.0 ) 
			                    depth["asks"].erase(price);
		                    else 
			                    depth["asks"][price] = qty;
	                    }
	                    for  ( int i = 0 ; i < json_result["params"][1]["bids"].size() ; i++ ) {
		                    double price = atof( json_result["params"][1]["bids"][i][0].asString().c_str() );
		                    double qty   = atof( json_result["params"][1]["bids"][i][1].asString().c_str() );
		                    if ( qty == 0.0 ) 
			                    depth["bids"].erase(price);
		                    else 
			                    depth["bids"][price] = qty;
		                }
	                }
                }
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {
        time_t current_time;	
        Json::Value json_result;
        string err;

        int t = time(&current_time);
        string ep = to_string (t);
        symbol[symbol.find('-')] = '_';
        transform(symbol.begin(), symbol.end(), symbol.begin(),
        [](unsigned char c){ return tolower(c); });

        string url("https://openapi.digifinex.com/v3/spot/order/new?");
        string action = "POST";
        
        string msg = "market=spot&symbol=" + symbol + "&type=" + side + "_market&amount=" + to_string(quantity);
        string post_data = msg;
        
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/x-www-form-urlencoded";
        extra_http_header.push_back(header_chunk);
        header_chunk="ACCESS-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "ACCESS-TIMESTAMP:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "ACCESS-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Digifinex: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Digifinex: order.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
