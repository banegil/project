

class Probitglobal: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Probitglobal(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        string s = "https://api.probit.com/api/exchange/v1/order_book?market_id=" + symbol;
        get_curl(s, result);
     	
     	if(result.isMember("data") && result["data"][0].isMember("price")){	
     		for  ( int i = 0 ; i < result["data"].size() ; i++ ) {
     	        double price = atof( result["data"][i]["price"].asString().c_str() );
		        double qty   = atof( result["data"][i]["quantity"].asString().c_str() );
     		    if(result["data"][i]["side"].asString() == "sell")
		            depthCache["asks"][price] = qty;
		        else
		            depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Probitglobal: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
        int i;
        string j;
        init_http("api.probit.com");
        
        try {
            init_webSocket("api.probit.com", "443", "/api/exchange/v1/ws");
            string s = "{\"type\":\"subscribe\",\"channel\":\"marketdata\",\"market_id\":\"" + symbol + "\",\"interval\":100,\"filter\":[\"order_books_l0\"]}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
	        read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();
            
            if(json_result.isMember("order_books_l0")){	
         		for  ( int i = 0 ; i < json_result["order_books_l0"].size() ; i++ ) {
         	        double price = atof( json_result["order_books_l0"][i]["price"].asString().c_str() );
		            double qty   = atof( json_result["order_books_l0"][i]["quantity"].asString().c_str() );
         		    if(json_result["order_books_l0"][i]["side"].asString() == "sell")
		                depth["asks"][price] = qty;
		            else
		                depth["bids"][price] = qty;
	            }
	        }
	        else
	            cout << "ERROR" << endl;

            while (true) {
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                mtxDepth.lock();

                if(json_result.isMember("order_books_l0")){	
             		for  ( int i = 0 ; i < json_result["order_books_l0"].size() ; i++ ) {
             	        double price = atof( json_result["order_books_l0"][i]["price"].asString().c_str() );
		                double qty   = atof( json_result["order_books_l0"][i]["quantity"].asString().c_str() );
             		    if(json_result["order_books_l0"][i]["side"].asString() == "sell") {
             		        if ( qty == 0.0 ) 
			                    depth["asks"].erase(price);
		                    else 
			                    depth["asks"][price] = qty;
		                }
		                else {
		                    if ( qty == 0.0 )
			                    depth["bids"].erase(price);
                            else 
			                    depth["bids"][price] = qty;
		                }
	                }
	            }
	            else
	                writte_log( "ERROR: <wss_depth> Probitglobal: " + symbol );
                    
                while(100 < depth["bids"].size())
                    depth["bids"].erase( depth["bids"].begin() );
                while(100 < depth["asks"].size())
                    depth["asks"].erase( prev( depth["asks"].end() ) );
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
