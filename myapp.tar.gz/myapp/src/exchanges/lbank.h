


class Lbank: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Lbank(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '_';
        transform(symbol.begin(), symbol.end(), symbol.begin(),
        [](unsigned char c){ return tolower(c); });
        string s = "https://api.lbkex.com/v2/depth.do?symbol=" + symbol + "&size=20";
        get_curl(s, result);
     	
     	if(result.isMember("data") && result["data"].isMember("bids")){	
	        for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
		        double price = atof( result["data"]["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["data"]["bids"].size() ; i++ ) {
		        double price = atof( result["data"]["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Lbank: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){
        int i;
        string j;
        depth = curl_depth(symbol);
        init_http("www.lbkex.net");
        
        try {
            symbol[symbol.find('-')] = '_';
            transform(symbol.begin(), symbol.end(), symbol.begin(),
            [](unsigned char c){ return tolower(c); });
            init_webSocket("www.lbkex.net", "443", "/ws/V2/");
            string s = "{\"action\":\"subscribe\",\"subscribe\":\"incrdepth\",\"pair\":\"" + symbol + "\"}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
            
            while (true) {
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                mtxDepth.lock();
                
                if(json_result.isMember("depth")){
                    if(json_result["depth"].isMember("bids")){
                        for ( i = 0 ; i < json_result["depth"]["bids"].size() ; i++ ) {
                            double price = atof( json_result["depth"]["bids"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["depth"]["bids"][i][1].asString().c_str());
                            if ( qty == 0.0 ) {
                                depth["bids"].erase(price);
                            } else {
                                depth["bids"][price] = qty;
                            }
                        }
                    }
                    if(json_result["tick"].isMember("asks")){
                        for ( i = 0 ; i < json_result["depth"]["asks"].size() ; i++ ) {
                            double price = atof( json_result["depth"]["asks"][i][0].asString().c_str());
                            double qty 	 = atof( json_result["depth"]["asks"][i][1].asString().c_str());
                            if ( qty == 0.0 ) {
                                depth["asks"].erase(price);
                            } else {
                                depth["asks"][price] = qty;
                            }
                        }
                    }
                }
                else {
                    j = json_result["ping"].asString();
                    s = "{\"pong\": " + j + "}";
                    write_Socket(s);
                }
                    
                while(100 < depth["bids"].size())
                    depth["bids"].erase( depth["bids"].begin() );
                while(100 < depth["asks"].size())
                    depth["asks"].erase( prev( depth["asks"].end() ) );
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
