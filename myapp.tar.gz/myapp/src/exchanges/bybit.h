

class Bybit: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Bybit(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.bybit.com/v2/public/orderBook/L2?symbol=" + symbol;
        get_curl(s, result);
     	
     	if(result.isMember("result") && result["result"][0].isMember("price")){	
     		for  ( int i = 0 ; i < 25 ; i++ ) {
		        double price = atof( result["result"][i]["price"].asString().c_str() );
		        double qty   = atof( result["result"][i]["size"].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	        for ( int i = 25 ; i < 50 ; i++ ) {
		        double price = atof( result["result"][i]["price"].asString().c_str() );
		        double qty   = atof( result["result"][i]["size"].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Bybit: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        int i;
        string j;
        init_http("stream.bybit.com");
        
        try {
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            init_webSocket("stream.bybit.com", "443", "/realtime");
            string s = "{\"op\": \"subscribe\", \"args\": [\"orderBookL2_25." + symbol + "\"]}";
            write_Socket(s);
            write_Socket(R"({"op":"ping"})");
            Json::Reader reader;
		    Json::Value json_result;
	        read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();
		    
         	if(json_result.isMember("data") && json_result["data"][0].isMember("price")){	
         		for  ( int i = 0 ; i < 25 ; i++ ) {
		            double price = atof( json_result["data"][i]["price"].asString().c_str() );
		            double qty   = atof( json_result["data"][i]["size"].asString().c_str() );
		            depth["bids"][price] = qty;
	            }
	            for ( int i = 25 ; i < 50 ; i++ ) {
		            double price = atof( json_result["data"][i]["price"].asString().c_str() );
		            double qty   = atof( json_result["data"][i]["size"].asString().c_str() );
		            depth["asks"][price] = qty;
	            }
	        }

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                if(ct2 - ct >= 28){
                    ct = ct2;
                    write_Socket(R"({"op":"ping"})");
                }
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                mtxDepth.lock();

             	if(json_result.isMember("data") && json_result["data"].isMember("delete")) {	
             		for  ( int i = 0 ; i < json_result["data"]["delete"].size() ; i++ ) {
             		    double price = atof ( json_result["data"]["delete"][i]["price"].asString().c_str() );
             		    if(json_result["data"]["delete"][i]["side"].asString() == "Buy")
				            depth["bids"].erase(price);
				        else 
				            depth["asks"].erase(price);
	                }
	                for  ( int i = 0 ; i < json_result["data"]["insert"].size() ; i++ ) {
		                double price = atof( json_result["data"]["insert"][i]["price"].asString().c_str() );
		                double qty   = atof( json_result["data"]["insert"][i]["size"].asString().c_str() );
		                if(json_result["data"]["insert"][i]["side"].asString() == "Buy")
				            depth["bids"][price] = qty;
				        else
				            depth["asks"][price] = qty;
	                }
	                for  ( int i = 0 ; i < json_result["data"]["update"].size() ; i++ ) {
		                double price = atof( json_result["data"]["update"][i]["price"].asString().c_str() );
		                double qty   = atof( json_result["data"]["update"][i]["size"].asString().c_str() );
		                if(json_result["data"]["update"][i]["side"].asString() == "Buy")
				            depth["bids"][price] = qty;
				        else
				            depth["asks"][price] = qty;
	                }
	            }
                
                while(25 < depth["bids"].size())
                    depth["bids"].erase( depth["bids"].begin() );
                while(25 < depth["asks"].size())
                    depth["asks"].erase( prev( depth["asks"].end() ) );
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
