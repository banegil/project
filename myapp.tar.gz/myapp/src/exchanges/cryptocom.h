

class Cryptocom: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Cryptocom(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '_';
        string s = "https://api.crypto.com/v2/public/get-book?instrument_name=" + symbol + "&depth=100";
        get_curl(s, result);
     	
     	if(result.isMember("result") && result["result"].isMember("data") && result["result"]["data"][0].isMember("asks")){	
	        for ( int i = 0 ; i < result["result"]["data"][0]["asks"].size(); i++ ) {
		        double price = atof( result["result"]["data"][0]["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["result"]["data"][0]["asks"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["result"]["data"][0]["bids"].size() ; i++ ) {
		        double price = atof( result["result"]["data"][0]["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["result"]["data"][0]["bids"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Cryptocom: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
        int i;
        string j;
        time_t current_time; 
        init_http("stream.crypto.com");
        
        try {
            symbol[symbol.find('-')] = '_';
            init_webSocket("stream.crypto.com", "443",  "/v2/market");
            string s = "{\"id\": 11,\"method\": \"subscribe\",\"params\": {\"channels\": [\"book." + symbol + ".150\"]},\"nonce\": 1587523073344}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
	        read_Socket();	
	        reader.parse( get_socket_data() , json_result );
            buffer_clear();

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                mtxDepth.lock();

                if(json_result.isMember("result")){	
                
                    if(ct2 - ct >= 70){
                        ct = ct2;
                        depth.clear();
                    }
                
             		for  ( int i = 0 ; i < json_result["result"]["data"][0]["asks"].size() ; i++ ) {
             	        double price = atof( json_result["result"]["data"][0]["asks"][i][0].asString().c_str() );
		                double qty   = atof( json_result["result"]["data"][0]["asks"][i][1].asString().c_str() );
             		    if ( qty == 0.0 ) 
			                depth["asks"].erase(price);
		                else 
			                depth["asks"][price] = qty;
	                }
	                for  ( int i = 0 ; i < json_result["result"]["data"][0]["bids"].size() ; i++ ) {
             	        double price = atof( json_result["result"]["data"][0]["bids"][i][0].asString().c_str() );
		                double qty   = atof( json_result["result"]["data"][0]["bids"][i][1].asString().c_str() );
             		    if ( qty == 0.0 ) 
			                depth["bids"].erase(price);
		                else 
			                depth["bids"][price] = qty;
	                }
	            }
	            else {
                    write_Socket(R"({"id": 1587523073344,"method": "public/respond-heartbeat"})"); 
                    if(!json_result.isMember("id"))
                        writte_log( "ERROR: <wss_depth> Cryptocom: " + symbol );
                }
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};

