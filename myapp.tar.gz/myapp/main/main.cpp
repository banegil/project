#include <map>
#include "include.h"

#include <chrono>
#include <thread>

#define MAX_EXCHANGES 24
using namespace std;


bool map_compare (map < string, map <double,double> > const &lhs, map < string, map <double,double> > const &rhs) {
    return lhs.size() == rhs.size()
        && std::equal(lhs.begin(), lhs.end(),
                      rhs.begin());
}

void doSomething(Exchange* ex, string symbol){
    ex->wesbsocketInit_depth(symbol);
}

void wss_init(string symbol, vector<bool> v, const int& n){  
    int i = 0;
    double profit = 0;
    vector<bool> vD(n, 1);
    vector<Exchange*> ex(n);
    vector < map < string, map <double,double> > > depth(n), depthCheck(n);
    map < double, pair < string, map <double,double> > > minAsks;
    map < double, pair < string, map <double,double,greater<double > > >, greater<double> > maxBids;
    time_t current_time; 
    map < string, double > comission;
    
    Aax aax(0.001, "aax", "", "");
    comission["aax"] = 0.001;
    if(v[i])
        ex[i++] = &aax;
    Ascendex ascendex(0.001, "ascendex", "", "");
    comission["ascendex"] = 0.001;
    if(v[i])
        ex[i++] = &ascendex;
    Binance binance(0.001, "binance", "", "");
    comission["binance"] = 0.001;
    if(v[i])
        ex[i++] = &binance;
    Bitfinex bitfinex(0.002, "bitfinex", "", "");
    comission["bitfinex"] = 0.002;
    if(v[i])
        ex[i++] = &bitfinex;
    Bithumb bithumb(0.0025, "bithumb", "", "");
    comission["bithumb"] = 0.0025;
    if(v[i])
        ex[i++] = &bithumb;
    Bitmart bitmart(0.00225, "bitmart", "", "");
    comission["bitmart"] = 0.00225;
    if(v[i])
        ex[i++] = &bitmart;
    Bitstamp bitstamp(0.0025, "bitstamp", "", "");
    comission["bitstamp"] = 0.0025;
    if(v[i])
        ex[i++] = &bitstamp;
    Bitvavo bitvavo(0.002, "bitvavo", "", "");
    comission["bitvavo"] = 0.002;
    if(v[i])
        ex[i++] = &bitvavo;
    Bybit bybit(0.001, "bybit", "", "");
    comission["bybit"] = 0.001;
    if(v[i])
        ex[i++] = &bybit;
    Coinex coinex(0.002, "coinex", "", "");
    comission["coinex"] = 0.002;
    if(v[i])
    ex[i++] = &coinex;
    Cryptocom cryptocom(0.0025, "cryptocom", "", "");
    comission["cryptocom"] = 0.0025;
    if(v[i])
        ex[i++] = &cryptocom;
    Digifinex digifinex(0.002, "digifinex", "", "");
    comission["digifinex"] = 0.002;
    if(v[i])
        ex[i++] = &digifinex;
    Exmo exmo(0.0026, "exmo", "", "");
    comission["exmo"] = 0.0026;
    if(v[i])
        ex[i++] = &exmo;
    Fmfw fmfw(0.002, "fmfw", "", "");
    comission["fmfw"] = 0.002;
    if(v[i])
        ex[i++] = &fmfw;
    Gateio gateio(0.002, "gateio", "", "");
    comission["gateio"] = 0.002;
    if(v[i])
        ex[i++] = &gateio;
    Gemini gemini(0.0025, "gemini", "", "");
    comission["gemini"] = 0.0025;
    if(v[i])
        ex[i++] = &gemini;
    Hitbtc hitbtc(0.002, "hitbtc", "", "");
    comission["hitbtc"] = 0.002;
    if(v[i])
        ex[i++] = &hitbtc;
    Huobi huobi(0.002, "huobi", "", "");
    comission["huobi"] = 0.002;
    if(v[i])
        ex[i++] = &huobi;
    Kraken kraken(0.0016, "kraken", "", "");
    comission["kraken"] = 0.0016;
    if(v[i])
        ex[i++] = &kraken;
    Kukoin kukoin(0.001, "kukoin", "", "");
    comission["kukoin"] = 0.001;
    if(v[i])
        ex[i++] = &kukoin;
    Lbank lbank(0.001, "lbank", "", "");
    comission["lbank"] = 0.001;
    if(v[i])
        ex[i++] = &lbank;
    Mexc mexc(0.002, "mexc", "", "");
    comission["mexc"] = 0.002;
    if(v[i])
        ex[i++] = &mexc;
    Poloniex poloniex(0.0012, "poloniex", "", "");
    comission["poloniex"] = 0.0012;
    if(v[i])
        ex[i++] = &poloniex;
    Probitglobal probitglobal(0.002, "probitglobal", "", "");
    comission["probitglobal"] = 0.002;
    if(v[i])
        ex[i++] = &probitglobal;
  
    for(i = 0; i < n; i++)
        if(v[i])
            thread(doSomething , ex[i], symbol); 
       
    std::this_thread::sleep_for(std::chrono::milliseconds(6000));
       
    time(&current_time);
    int ct = current_time;
    for(i = 0; i < n; i++)
        depth[i] = ex[i]->get_socketDepth();
    depthCheck = depth;
    
    while(1){
        time(&current_time);
        int ct2 = current_time;
        if(ct2 - ct >= 10){
            ct = ct2;
            for(i = 0; i < n; i++) {
                if(map_compare(depth[i], depthCheck[i])){
                    writte_log( "ERROR: <wss_init> connection finished, main.cpp: exchange " + ex[i]->get_id() );
                    //depth.erase(depth.begin() + i);
                    //depthCheck.erase(depthCheck.begin() + i);
                    vD[i] = 0;
                }
                else
                    depthCheck[i] = depth[i];
            }
        }
        
        for(i = 0; i < n; i++) {
            if(vD[i]) {
                depth[i] = ex[i]->get_socketDepth();
                auto it = depth[i]["bids"].end(); --it;
                minAsks[depth[i]["asks"].begin()->first].first = ex[i]->get_id();
                minAsks[depth[i]["asks"].begin()->first].second = depth[i]["asks"];
                maxBids[it->first].first = ex[i]->get_id();
                maxBids[it->first].second.insert(depth[i]["bids"].begin(), depth[i]["bids"].end());
            }
        }
        
        auto itAsk = minAsks.begin();
        auto itBid = maxBids.begin();
        while(itAsk != minAsks.end() && itBid != maxBids.end() && itAsk->first + itAsk->first * comission[itAsk->second.first]
                < itBid->first - itBid->first * comission[itBid->second.first]){
                
            auto it1 = itAsk->second.second.begin();
            auto it2 = itBid->second.second.begin();
            
            while(it1 != itAsk->second.second.end() && it2 != itBid->second.second.end() && it1->first + it1->first * comission[itAsk->second.first]
                    < it2->first - it2->first * comission[itBid->second.first]){
                double quantity = min(it1->second, it2->second);
                profit += (quantity * (it2->first - it2->first * comission[itBid->second.first])) - (quantity * (it1->first + it1->first * comission[itAsk->second.first]));
                it1->second -= quantity;
                it2->second -= quantity;
                
                string prft = "Buy:" + itAsk->second.first + " Sell: " + itBid->second.first  + " Profit: " + to_string(profit); 
                writte_arb(prft);
                
                if(it1->second == 0)
                    it1++;
                if(it2->second == 0)
                    it2++;
            }
            
            if(it1->second == 0)
                itAsk++;
            if(it2->second == 0)
                itBid++;
        }
        
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

int main() {
    vector<bool> v = { 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0 };
    wss_init("QNT-USDT", v, 10);
    
    //depth = binance.get_socketDepth();
    
    /*int c = 0, cont = 0;
    for(const auto& i : depth){
        if(c == 0)
            cout << "ASKS:\n";
        else
            cout << "BIDS:\n"; 
        c++;    
        cont = 0;
        for(const auto& j : i.second){
            cont++;
            cout << "p: " << j.first << " q: " << j.second << '\n'; 
        }
    }*/   

	return 0;
}
