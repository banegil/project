#include <map>
#include "include.h"

#include <chrono>
#include <thread>
#include <future> 

#define MAX_EXCHANGES 22
using namespace std;

enum { AAX, ASCENDEX, BINANCE, BITFINEX, BITSTAMP, BITVAVO, BYBIT, COINEX, CRYPTOCOM, DIGIFINEX, EXMO, FMFW, GATEIO, GEMINI, HITBTC, HUOBI, KRAKEN, KUCOIN, LBANK, MEXC, POLONIEX, PROBITGLOBAL };

vector<Exchange*> ex;

bool map_compare (map < string, map <double,double> > const &lhs, map < string, map <double,double> > const &rhs) {
    return lhs.size() == rhs.size()
        && std::equal(lhs.begin(), lhs.end(),
                      rhs.begin());
}

void doSomething(int i, string symbol){
    ex[i]->wesbsocketInit_depth(symbol);
}

void wss_init(string symbol, vector<bool> v, const int& n){  
    int i = 0, cont = 0;
    double profit = 0;
    time_t current_time; 
    vector<bool> vD(n, 1);
    ex.resize(n);
    vector < map < string, map <double,double> > > depth(n), depthCheck(n);
    map < string, double > comission;
    
    Aax aax(0.001, "aax", "", "");
    comission["aax"] = 0.001;
    if(v[i++])
        ex[cont++] = &aax;
    Ascendex ascendex(0.001, "ascendex", "", "");
    comission["ascendex"] = 0.001;
    if(v[i++])
        ex[cont++] = &ascendex;
    Binance binance(0.001, "binance", "", "");
    comission["binance"] = 0.001;
    if(v[i++])
        ex[cont++] = &binance;
    Bitfinex bitfinex(0.002, "bitfinex", "", "");
    comission["bitfinex"] = 0.002;
    if(v[i++])
        ex[cont++] = &bitfinex;
    Bitstamp bitstamp(0.0025, "bitstamp", "", "");
    comission["bitstamp"] = 0.0025;
    if(v[i++])
        ex[cont++] = &bitstamp;
    Bitvavo bitvavo(0.002, "bitvavo", "", "");
    comission["bitvavo"] = 0.002;
    if(v[i++])
        ex[cont++] = &bitvavo;
    Bybit bybit(0.001, "bybit", "", "");
    comission["bybit"] = 0.001;
    if(v[i++])
        ex[cont++] = &bybit;
    Coinex coinex(0.002, "coinex", "", "");
    comission["coinex"] = 0.002;
    if(v[i++])
        ex[cont++] = &coinex;
    Cryptocom cryptocom(0.0025, "cryptocom", "", "");
    comission["cryptocom"] = 0.0025;
    if(v[i++])
        ex[cont++] = &cryptocom;
    Digifinex digifinex(0.002, "digifinex", "", "");
    comission["digifinex"] = 0.002;
    if(v[i++])
        ex[cont++] = &digifinex;
    Exmo exmo(0.0026, "exmo", "", "");
    comission["exmo"] = 0.0026;
    if(v[i++])
        ex[cont++] = &exmo;
    Fmfw fmfw(0.002, "fmfw", "", "");
    comission["fmfw"] = 0.002;
    if(v[i++])
        ex[cont++] = &fmfw;
    Gateio gateio(0.002, "gateio", "", "");
    comission["gateio"] = 0.002;
    if(v[i++])
        ex[cont++] = &gateio;
    Gemini gemini(0.0025, "gemini", "", "");
    comission["gemini"] = 0.0025;
    if(v[i++])
        ex[cont++] = &gemini;
    Hitbtc hitbtc(0.002, "hitbtc", "", "");
    comission["hitbtc"] = 0.002;
    if(v[i++])
        ex[cont++] = &hitbtc;
    Huobi huobi(0.002, "huobi", "", "");
    comission["huobi"] = 0.002;
    if(v[i++])
        ex[cont++] = &huobi;
    Kraken kraken(0.0016, "kraken", "", "");
    comission["kraken"] = 0.0016;
    if(v[i++])
        ex[cont++] = &kraken;
    Kukoin kukoin(0.001, "kukoin", "", "");
    comission["kukoin"] = 0.001;
    if(v[i++])
        ex[cont++] = &kukoin;
    Lbank lbank(0.001, "lbank", "", "");
    comission["lbank"] = 0.001;
    if(v[i++])
        ex[cont++] = &lbank;
    Mexc mexc(0.002, "mexc", "", "");
    comission["mexc"] = 0.002;
    if(v[i++])
        ex[cont++] = &mexc;
    Poloniex poloniex(0.0012, "poloniex", "", "");
    comission["poloniex"] = 0.0012;
    if(v[i++])
        ex[cont++] = &poloniex;
    Probitglobal probitglobal(0.002, "probitglobal", "", "");
    comission["probitglobal"] = 0.002;
    if(v[i++])
        ex[cont++] = &probitglobal;
        
    vector<thread> ths(n);    
    for(i = 0; i < n; i++) 
        ths[i] = thread (doSomething, i, symbol);

    std::this_thread::sleep_for(std::chrono::milliseconds(3000));
    
    time(&current_time);
    int ct = current_time;
    for(i = 0; i < n; i++)
        depth[i] = ex[i]->get_socketDepth();
    depthCheck = depth;
    
    double profp = 0;
    while(1){
        map < double, pair < string, map <double,double> > > minAsks;
        map < double, pair < string, map <double,double,greater<double > > >, greater<double> > maxBids;
        time(&current_time);
        int ct2 = current_time;
        /*if(ct2 - ct >= 35){
            ct = ct2;
            for(i = 0; i < n; i++) {
                if(map_compare(depth[i], depthCheck[i])){
                    writte_log( "ERROR: <wss_init> connection finished, main.cpp: exchange " + ex[i]->get_id() );
                    //depth.erase(depth.begin() + i);
                    //depthCheck.erase(depthCheck.begin() + i);
                    //vD[i] = 0;
                }
                else
                    depthCheck[i] = depth[i];
            }
        }*/
        
        for(i = 0; i < n; i++) {
            if(vD[i]) {
                depth[i] = ex[i]->get_socketDepth();
                if(!depth[i]["bids"].empty()) {
                    auto it = depth[i]["bids"].end(); --it;
                    minAsks[depth[i]["asks"].begin()->first].first = ex[i]->get_id();
                    minAsks[depth[i]["asks"].begin()->first].second = depth[i]["asks"];
                    maxBids[it->first].first = ex[i]->get_id();
                    maxBids[it->first].second.insert(depth[i]["asks"].begin(), depth[i]["asks"].end());
                }
                else{
                    string err = "ERROR: depth[] map is empty! in exchange " + ex[i]->get_id();
                    writte_log(err);
                    vD[i] = 0;
                }
            }
        }
        
        cout << "ASKS:" << endl;
        for(auto ita = minAsks.begin(); ita != minAsks.end(); ++ita)
            cout << ita->first << " in exchange " << minAsks[ita->first].first << endl;
        cout << "BIDS:" << endl;
        for(auto itb = maxBids.begin(); itb != maxBids.end(); ++itb)
            cout << itb->first << " in exchange " << maxBids[itb->first].first << endl;
        double prof = (1 - ( minAsks.begin()->first / maxBids.begin()->first )) * 100;
        cout << prof << endl;
        if(prof > 0.2 && prof != profp) {
            string arb = "PROFIT:" + to_string(prof);
            writte_arb(arb);
            profp = prof;
        }
        /*auto itAsk = minAsks.begin();
        auto itBid = maxBids.begin();
        while(itAsk != minAsks.end() && itBid != maxBids.end() && itAsk->first + itAsk->first * comission[itAsk->second.first]
                < itBid->first - itBid->first * comission[itBid->second.first]){
                
            auto it1 = itAsk->second.second.begin();
            auto it2 = itBid->second.second.begin();
            
            while(it1 != itAsk->second.second.end() && it2 != itBid->second.second.end() && it1->first + it1->first * comission[itAsk->second.first]
                    < it2->first - it2->first * comission[itBid->second.first]){
                double quantity = min(it1->second, it2->second);
                profit += (quantity * (it2->first - it2->first * comission[itBid->second.first])) - (quantity * (it1->first + it1->first * comission[itAsk->second.first]));
                it1->second -= quantity;
                it2->second -= quantity;
                
                string prft = "Buy:" + itAsk->second.first + " Sell: " + itBid->second.first  + " Profit: " + to_string(profit); 
                writte_arb(prft);
                
                if(it1->second == 0)
                    it1++;
                if(it2->second == 0)
                    it2++;
            }
            
            if(it1->second == 0)
                itAsk++;
            if(it2->second == 0)
                itBid++;
        }*/
        
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
    
    for(i = 0; i < n; i++)
        ths[i].join();
}

void vCandidates(vector<bool>& v) {
    v[AAX] = 0;
    v[ASCENDEX] = 0;
    v[BINANCE] = 0;
    v[BITFINEX] = 0;
    v[BITSTAMP] = 0;
    v[BITVAVO] = 0;
    v[BYBIT] = 0;
    v[COINEX] = 0;
    v[CRYPTOCOM] = 0;
    v[DIGIFINEX] = 0;
    v[EXMO] = 0;
    v[FMFW] = 0;
    v[GATEIO] = 0;
    v[GEMINI] = 0;
    v[HITBTC] = 0;
    v[HUOBI] = 0;
    v[KRAKEN] = 0;
    v[KUCOIN] = 0;
    v[LBANK] = 1;
    v[MEXC] = 0;
    v[POLONIEX] = 0;
    v[PROBITGLOBAL] = 0;
}

int main() {
    vector<bool> v(MAX_EXCHANGES);
    
    vCandidates(v);
    wss_init("ETH-USDT", v, 1);

	return 0;
}
