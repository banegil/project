
#include <map>
#include <vector>
#include <string>

#include "../src/exchange.h"
//#include Los demas exhanges.h
#include <json/json.h>


using namespace std;

map < string, map <double,double> >  depthCache;

void socketSubscribe(int id){
    
}

int main() {
	

	return 0;
}
