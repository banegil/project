class Whitebit: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    Whitebit(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value json_result; 
        symbol[symbol.find('-')] = '_';
        string s = "https://whitebit.com/api/v4/public/orderbook/" + symbol + "?depth=100";
        
        try{
            mtxCurl.lock();
            get_curl(s, json_result);
            mtxCurl.unlock();

            mtxDepth.lock();
         		 
         	depth.clear(); 	    
            for ( int i = 0 ; i < json_result["asks"].size(); i++ ) {
	            double price = atof( json_result["asks"][i][0].asString().c_str() );
	            double qty   = atof( json_result["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < json_result["bids"].size() ; i++ ) {
	            double price = atof( json_result["bids"][i][0].asString().c_str() );
	            double qty   = atof( json_result["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	     
	        mtxDepth.unlock();
	    
	   } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << json_result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){  
        Json::Value json_result;
        time_t current_time;
        symbol[symbol.find('-')] = '_';
        init_http("api.whitebit.com");
        string symbol2 = symbol;
        
        try {
            Json::Reader reader;
		    Json::Value json_result;
            init_webSocket("api.whitebit.com", "443", "/ws");
            string s = "{\"id\":12,\"method\":\"depth_subscribe\",\"params\":[\"" + symbol + "\",20,\"0\",true]}";
            write_Socket(s);
	        read_Socket();	
	        buffer_clear();

            time(&current_time);
            int ct = current_time;
            int ct3 = ct;
            while (true) {
                Json::Reader reader;
		        json_result.clear();
                time(&current_time);
                int ct2 = current_time;
                int ct4 = ct2;
                if(ct2 - ct >= 25){
                    ct = ct2;
                    write_Socket(R"({"id":0,"method":"ping","params":[]})");
                }
                read_Socket();	
	            reader.parse( get_socket_data() , json_result );
                buffer_clear();
 
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&Whitebit::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();

             	if(json_result["method"].asString() == "depth_update"){
                    
                 	for ( int i = 0 ; i < json_result["params"][1]["asks"].size() ; i++ ) {
                        double price = atof( json_result["params"][1]["asks"][i][0].asString().c_str() );
                        double qty   = atof( json_result["params"][1]["asks"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
                    } 
                          
             		for  ( int i = 0 ; i < json_result["params"][1]["bids"].size() ; i++ ) {
                        double price = atof( json_result["params"][1]["bids"][i][0].asString().c_str() );
                        double qty   = atof( json_result["params"][1]["bids"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;                      
                    }
                }
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                set_id();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
	         	writte_log( err ); 
            return;
          }
    }
    
    double get_minQty(string symbol){
        Json::Value json_result;
        symbol[symbol.find('-')] = '_';  
        string s = "https://whitebit.com/api/v2/public/markets"; 
        double minQty = 0;
        int i = 0;

        try{        
            get_curl(s, json_result);

            while(minQty == 0 && i < json_result["result"].size())
                if(json_result["result"][i++]["name"].asString() == symbol)
                    minQty = atof( json_result["result"][i - 1]["minAmount"].asString().c_str() );
            
            if(minQty != 0)
                cout << get_id() << '\n';
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in set_minQty ";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }
        return minQty;
    }
   
    map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }

    map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
    }
};
