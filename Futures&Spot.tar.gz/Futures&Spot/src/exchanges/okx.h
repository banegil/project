class Okx: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "1812f049-54fb-41d9-af7f-c80115974d0b";
    string secret_key = "EFCC34619BC3A9C49900BA7A6BE2C574";
    
    public:
    Okx(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        string s = "https://aws.okx.com/api/v5/market/books?instId=" + symbol + "&sz=100";
        
        try{
            mtxCurl.lock();
            get_curl(s, result);
            mtxCurl.unlock();
         	
            mtxDepth.lock();
         		 
         	depth.clear(); 	    
            for ( int i = 0 ; i < result["data"][0]["asks"].size(); i++ ) {
	            double price = atof( result["data"][0]["asks"][i][0].asString().c_str() );
	            double qty   = atof( result["data"][0]["asks"][i][1].asString().c_str() );
	            depth["asks"][price] = qty;
            }
            for  ( int i = 0 ; i < result["data"][0]["bids"].size() ; i++ ) {
	            double price = atof( result["data"][0]["bids"][i][0].asString().c_str() );
	            double qty   = atof( result["data"][0]["bids"][i][1].asString().c_str() );
	            depth["bids"][price] = qty;
            }
	     
	        mtxDepth.unlock();
	    
	  } catch (std::exception const& e) {
            depth.clear();
            string err = "ERROR: <curl_depth> " + get_id() + ": " + symbol + " " + e.what();
         	writte_log( err ); 
         	cout << result << '\n';
        return;
      }
    }
    
    void wesbsocketInit_depth(string symbol){  
        time_t current_time;
        init_http("wsaws.okx.com");
        long ts = 0, ts2;
        string symbol2 = symbol;
        
        try {
            init_webSocket("wsaws.okx.com", "443", "/ws/v5/public");
            string s = "{\"op\":\"subscribe\",\"args\":[{\"channel\":\"books50-l2-tbt\",\"instId\":\"" + symbol + "\"}]}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
		    for(int i = 0; i < 2; i++){
                read_Socket();	
                buffer_clear();
            }

            time(&current_time);
            int ct = current_time;
            while (true) {
                Json::Reader reader;
		        Json::Value json_result;
                time(&current_time);
                int ct2 = current_time;
                read_Socket();	
	            reader.parse( get_socket_data() , json_result );
                buffer_clear();

                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&Okx::curl_depth, this, symbol2);
                }

                mtxDepth.lock();

                ts2 = atof( json_result["data"][0]["ts"].asString().c_str() );
                if(ts2 >= ts){
                    ts = ts2;
                 	      
             	    for  ( int i = 0 ; i < json_result["data"][0]["bids"].size() ; i++ ) {
                        double price = atof( json_result["data"][0]["bids"][i][0].asString().c_str() );
                        double qty   = atof( json_result["data"][0]["bids"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["bids"].erase(price);
                        else 
                            depth["bids"][price] = qty;
                            
                    }
                    for ( int i = 0 ; i < json_result["data"][0]["asks"].size() ; i++ ) {
                        double price = atof( json_result["data"][0]["asks"][i][0].asString().c_str() );
                        double qty   = atof( json_result["data"][0]["asks"][i][1].asString().c_str() );
                        if ( qty == 0.0 ) 
                            depth["asks"].erase(price);
                        else 
                            depth["asks"][price] = qty;
                    }
                }
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                set_id();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
	         	writte_log( err );
	         	//cout << json_result << endl; 
            return;
          }
    }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        Json::Value json_result;
        string err;
        time_t now;
        time(&now);
        char buf[sizeof "2011-10-08T07:07:09Z"];
        strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", gmtime(&now));
        string ep = buf;
        string url("https://aws.okex.com/api/v5/trade/order");
        string action = "POST";

        string post_data = "{\"instId\":\"" + symbol + "\",\"tdMode\":\"cash\",\"side\":\"" + side + "\",\"ordType\":\"limit\",\"px\":\"" + to_string(price) + "\",\"sz\":\"" + to_string(quantity) + "\"}";        
        string msg = ep + action + "/api/v5/trade/order" + post_data;
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="OK-ACCESS-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "OK-ACCESS-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "OK-ACCESS-TIMESTAMP:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "OK-ACCESS-PASSPHRASE: .Unbuitretraidor1.";
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Okx: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Okx: order.size() is 0";
            writte_log(err);
        }
    }
    
    void withdraw( string coin, string address, double amount, string network ) {	
        Json::Value json_result;
        string err;
        time_t now;
        time(&now);
        char buf[sizeof "2011-10-08T07:07:09Z"];
        strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", gmtime(&now));
        string ep = buf;
        string url("https://aws.okex.com/api/v5/asset/withdrawal");
        string action = "POST";
   
        string post_data = "{\"amt\":\"1\",\"fee\":\"0.0005\",\"dest\":\"4\",\"ccy\":\"BTC\",\"chain\":\"BTC-Bitcoin\",\"toAddr\":\"17DKe3kkkkiiiiTvAKKi2vMPbm1Bz3CMKw\"}";        
        string msg = ep + action + "/api/v5/asset/withdrawal" + post_data;
        string signature =  hmac_sha256h( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="OK-ACCESS-KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "OK-ACCESS-SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "OK-ACCESS-TIMESTAMP:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "OK-ACCESS-PASSPHRASE: .Unbuitretraidor1.";
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
                Json::Reader reader;
                json_result.clear();	
                reader.parse( str_result , json_result );
                cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Okx: error reading withdraw response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Okx: withdraw.size() is 0";
            writte_log(err);
        }
    }
    
    double get_minQty(string symbol){
        Json::Value json_result; 
        string s = "https://aws.okx.com/api/v5/public/instruments?instType=SPOT"; 
        int i = 0;
        double minQty = 0;

        try{        
            get_curl(s, json_result);

            if(json_result["code"].asString() == "0")
                while(i < json_result["data"].size())
                    if(json_result["data"][i++]["instId"].asString() == symbol)
                        minQty = atof( json_result["data"][i - 1]["minSz"].asString().c_str() );

            if(minQty != 0)
                cout << get_id() << '\n';
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in set_minQty ";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }
        return minQty;
    }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
