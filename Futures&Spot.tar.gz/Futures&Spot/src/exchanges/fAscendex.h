

class fAscendex: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "qdB0DS6HQfSHvD5pa46MVR85hD1RhYDj";
    string secret_key = "WXfHJkkNMovwJkftXnijTuF8FuwB8ecfQ9cCiJVCIQCa4uzjYwMkIH4hAdVEbgSL";
    
    public:
    fAscendex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
   
    void wesbsocketInit_depth(string symbol){  
    try{
        time_t current_time;
        init_http("ascendex.com");
        pair<double,double> a, b;
        long ts = 0;
        
        symbol = symbol.substr(0, symbol.find('-'));
        init_webSocket("ascendex.com", "443", "/api/pro/v2/stream");
        string s = "{ \"op\": \"sub\",\"ch\":\"depth:" + symbol + "-PERP\" }";
        write_Socket(s);
        s = "{ \"op\": \"sub\",\"ch\":\"bbo:" + symbol + "-PERP\" }";
        write_Socket(s);
        Json::Reader reader;
        Json::Value result;
	    for(int i = 0; i < 3; i++){
	        read_Socket();	
	        reader.parse( get_socket_data() , result );
            buffer_clear();
	    }

        time(&current_time);
        int ct = current_time;
        while (true) {
            time(&current_time);
            int ct2 = current_time;
            Json::Reader reader;
            Json::Value result;
            read_Socket();	
	        reader.parse( get_socket_data() , result );
            buffer_clear();

            mtxDepth.lock();                

            if(result["m"].asString() == "bbo" && result["data"]["ts"].asInt64() >= ts){
                ts = result["data"]["ts"].asInt64();
    	        a.first = atof( result["data"]["ask"][0].asString().c_str() );
                a.second = atof( result["data"]["ask"][1].asString().c_str() );
                
                if ( a.second == 0.0 ) 
                    depth["asks"].erase(a.first);
                else 
                    depth["asks"][a.first] = a.second;
                b.first = atof( result["data"]["bid"][0].asString().c_str() );
                b.second = atof( result["data"]["bid"][1].asString().c_str() );
                if ( b.second == 0.0 ) 
                    depth["bids"].erase(b.first);
                else 
                    depth["bids"][b.first] = b.second;
            }                
            else if(result["m"].asString() == "depth"){	
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    depth.clear();
                }
                
                for ( int i = 0 ; i < result["data"]["asks"].size(); i++ ) {
                    double price = atof( result["data"]["asks"][i][0].asString().c_str() );
                    double qty   = atof( result["data"]["asks"][i][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["asks"].erase(price);
                    else 
                        depth["asks"][price] = qty;
                }
                for ( int i = 0 ; i < result["data"]["bids"].size(); i++ ) {
                    double price = atof( result["data"]["bids"][i][0].asString().c_str() );
                    double qty   = atof( result["data"]["bids"][i][1].asString().c_str() );
                    if ( qty == 0.0 ) 
                        depth["bids"].erase(price);
                    else 
                        depth["bids"][price] = qty;
                }
                
                if(result["data"]["ts"].asInt64() < ts){
                    depth["asks"][a.first] = a.second;
                    depth["bids"][b.first] = b.second;
                }
                ts = result["data"]["ts"].asInt64();
            }
            else if(result["m"].asString() == "ping")
                write_Socket(R"({ "op": "pong" })");   
            
            mtxDepth.unlock();
        }
        webSocket_close();
        }
                catch (std::exception const& e) {
            set_id();
            string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
 	        writte_log( err ); 
 	        return;
        }
   }
   
    double send_order( string symbol, string side, double quantity, bool open ) {	
        Json::Value json_result;
        double price = -1;
        
        string ep = to_string (get_current_ms_epoch());
        symbol = symbol.substr(0, symbol.find('-'));
        string url("https://ascendex.com/2/api/pro/v2/futures/order");
        string action = "POST";
        
        string msg = ep + "+v2/futures/order";
        string post_data  = "{\"time\":" + ep + ",\"symbol\":\"" + symbol + "-PERP\",\"orderQty\":\"" + to_string(quantity) + "\",\"orderType\":\"Market\",\"side\":\"" + side + "\"";
        if(open)
            post_data += "}";            
        else 
            post_data += ",\"execInst\":\"ReduceOnly\"}";
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="x-auth-key:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "x-auth-signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "x-auth-timestamp:" + ep;
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            
	            if(json_result.isMember("data") && json_result["data"].isMember("meta") && json_result["data"]["meta"]["respInst"].asString() == "DONE")
	                price = atof( json_result["data"]["order"]["avgFilledPx"].asString().c_str() );
	                
	            if(price <= 0)
	                throw exception();
            		
            	} catch ( exception &e ) {
             	    string err = get_id() + ": error reading send_order response, ";
             	    err.append( e.what() );
                    writte_log(err);
                    cout << json_result << endl;
                    return -1;
            }   
        } 
        else {
            string err = "Ascendex: order.size() is 0";
            writte_log(err);
            return -1;
        }
        return price;
   }
   
    double get_minQty(string symbol){
        Json::Value json_result;
        symbol = symbol.substr(0, symbol.find('-'));
        symbol += "-PERP";
        string s = "https://ascendex.com/api/pro/v2/futures/contract"; 
        double minQty = 0; 
        int i = 0;

        try{        
            get_curl(s, json_result);

            if(json_result["code"].asInt64() == 0)
                while(i < json_result["data"].size())             
                    if(json_result["data"][i++]["symbol"] == symbol)
                        minQty = atof( json_result["data"][i - 1]["lotSizeFilter"]["minQty"].asString().c_str() );  
                
            if(minQty != 0)
                cout << get_id() << '\n';
                
        }  catch ( exception &e ) {
     	    string err = get_id() + ": error in get_minQty ";
     	    err.append( e.what() );
            writte_log(err);            
            cout << json_result << endl;
            return -1;
        }
        return minQty;
    }
    
    bool set_leverage( string symbol ) {	
        Json::Value json_result;
        int leverage = 0;
        
        string ep = to_string (get_current_ms_epoch());
        symbol = symbol.substr(0, symbol.find('-'));
        string url("https://ascendex.com/2/api/pro/v2/futures/leverage");
        string action = "POST";
        
        string msg = ep + "+v2/futures/leverage";
        string post_data  = "{\"symbol\":\"" + symbol + "-PERP\",\"leverage\":" + to_string(LEVERAGE) + "}";
        string signature =  hmac_sha256( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="x-auth-key:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "x-auth-signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        header_chunk = "x-auth-timestamp:" + ep;
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        try {
            Json::Reader reader;
            json_result.clear();	
            reader.parse( str_result , json_result );
            
            if(json_result["code"].asInt64() == 0)
                leverage = json_result["data"]["leverage"].asInt64();
                
            if(leverage != LEVERAGE)
                throw exception();
        		
        	} catch ( exception &e ) {
         	    string err = get_id() + ": error set_leverage response, ";
         	    err.append( e.what() );
                writte_log(err);
                cout << json_result << endl;
                return 0;
        }   
        return 1;
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > curl_depth(string symbol){
        map < string, map <double,double> > d;
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
