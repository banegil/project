
#include "../lib/myappcpp_logger.h"
#include "../lib/myappcpp_utils.h"

#include "../src/exchange.h"
#include "../src/exchanges/fAax.h"
#include "../src/exchanges/fAscendex.h"
#include "../src/exchanges/fBinance.h"
#include "../src/exchanges/fBitfinex.h"
#include "../src/exchanges/fBitget.h"
#include "../src/exchanges/fBybit.h"
#include "../src/exchanges/fCoinex.h"
#include "../src/exchanges/fCryptocom.h"
#include "../src/exchanges/fDelta.h"
#include "../src/exchanges/fFtx.h"
#include "../src/exchanges/fGateio.h"
#include "../src/exchanges/fHuobi.h"
#include "../src/exchanges/fKucoin.h"
#include "../src/exchanges/fMexc.h"
#include "../src/exchanges/fOkx.h"
#include "../src/exchanges/fPhemex.h"

#include "../src/exchanges/aax.h"
#include "../src/exchanges/ascendex.h"
#include "../src/exchanges/binance.h"
#include "../src/exchanges/bitget.h"
#include "../src/exchanges/bybit.h"
#include "../src/exchanges/coinex.h"
#include "../src/exchanges/cryptocom.h"
#include "../src/exchanges/exmo.h"
#include "../src/exchanges/fmfw.h"
#include "../src/exchanges/ftx.h"
#include "../src/exchanges/gateio.h"
#include "../src/exchanges/hitbtc.h"
#include "../src/exchanges/huobi.h"
#include "../src/exchanges/kucoin.h"
#include "../src/exchanges/lbank.h"
#include "../src/exchanges/nominex.h"
#include "../src/exchanges/okx.h"
#include "../src/exchanges/poloniex.h"
#include "../src/exchanges/whitebit.h"

#define MAX_EXCHANGES 2

using namespace std;

vector<Exchange*> ex(MAX_EXCHANGES);
bool mtxOrder = 1;
map < string, double > comission, minQtyMap;
unordered_map < string, bool > bannedLong, bannedShort;
unordered_map < string, unordered_map < string, pair< double, double > > > openPositions;
unordered_map < string, map <double,double> > asks_close;
unordered_map < string, map <double,double,greater<double> > >  bids_close;
multimap < double, pair < string, map <double,double> > > minAsks_open; 
multimap < double, pair < string, map <double,double,greater<double> > >, greater<double> > maxBids_open;

string symba = "TRX-USDT";

void doSomething(int i, string symbol){
    ex[i]->wesbsocketInit_depth(symbol);
}

void ini(){
    int cont = 0;
    
    // Futures
    
    /*comission["fAax"] = 0.0006;
    ex[cont++] = new fAax(0.0006, "fAax", "", "");
    
    comission["fAscendex"] = 0.0006;
    ex[cont++] = new fAscendex(0.0006, "fAscendex", "", "");
    
    comission["fBinance"] = 0.000414;
    ex[cont++] = new fBinance(0.000414, "fBinance", "", "");
        
    comission["fBitfinex"] = 0.00130;
    ex[cont++] = new fBitfinex(0.00130, "fBitfinex", "", "");

    comission["fBitget"] = 0.0012;
    ex[cont++] = new fBitget(0.0012, "fBitget", "", "");

    comission["fBybit"] = 0.0006;
    ex[cont++] = new fBybit(0.0006, "fBybit", "", "");

    comission["fCoinex"] = 0.0005;
    ex[cont++] = new fCoinex(0.0005, "fCoinex", "", "");

    /*comission["fCryptocom"] = 0.00112;
    ex[cont++] = new fCryptocom(0.00112, "fCryptocom", "", "");

    comission["fDelta"] = 0.00075;
    ex[cont++] = new fDelta(0.00075, "fDelta", "", "");

    comission["fFtx"] = 0.0007;
    ex[cont++] = new fFtx(0.0007, "fFtx", "", "");*/

    comission["fGateio"] = 0.0005;
    ex[cont++] = new fGateio(0.0005, "fGateio", "", "");

    /*comission["fHuobi"] = 0.0005;
    ex[cont++] = new fHuobi(0.0005, "fHuobi", "", "");*/

    comission["fKucoin"] = 0.0006;
    ex[cont++] = new fKucoin(0.0006, "fKucoin", "", "");

    /*comission["fMexc"] = 0.0006;
    ex[cont++] = new fMexc(0.0006, "fMexc", "", "");

    comission["fOkx"] = 0.0005;
    ex[cont++] = new fOkx(0.0005, "fOkx", "", "");

    comission["fPhemex"] = 0.0015;
    ex[cont++] = new fPhemex(0.0015, "fPhemex", "", "");

    
    // Spot
    comission["aax"] = 0.0012;
    ex[cont++] = new Aax(0.0012, "aax", "", "");

    comission["ascendex"] = 0.001;
    ex[cont++] = new Ascendex(0.001, "ascendex", "", "");

    comission["binance"] = 0.00075;
    ex[cont++] = new Binance(0.00075, "binance", "", "");

    comission["bybit"] = 0.001;
    ex[cont++] = new Bybit(0.001, "bybit", "", "");

    comission["coinex"] = 0.00112;
    ex[cont++] = new Coinex(0.00112, "coinex", "", "");

    comission["cryptocom"] = 0.0032;
    ex[cont++] = new Cryptocom(0.0032, "cryptocom", "", "");

    comission["exmo"] = 0.0003;
    ex[cont++] = new Exmo(0.0003, "exmo", "", "");

    comission["fmfw"] = 0.005;
    ex[cont++] = new Fmfw(0.005, "fmfw", "", "");

    comission["gateio"] = 0.0006;
    ex[cont++] = new Gateio(0.0006, "gateio", "", "");

    comission["hitbtc"] = 0.002;
    ex[cont++] = new Hitbtc(0.002, "hitbtc", "", "");

    comission["huobi"] = 0.002;
    ex[cont++] = new Huobi(0.002, "huobi", "", "");

    comission["kucoin"] = 0.0008;
    ex[cont++] = new Kucoin(0.0008, "kucoin", "", "");

    comission["lbank"] = 0.001;
    ex[cont++] = new Lbank(0.001, "lbank", "", "");

    comission["nominex"] = 0.0005;
    ex[cont++] = new Nominex(0.0005, "nominex", "", "");

    /*comission["okx"] = 0.0006;
    ex[cont++] = new Okx(0.0006, "okx", "", "");

    comission["poloniex"] = 0.000875;
    ex[cont++] = new Poloniex(0.000875, "poloniex", "", "");

    comission["whitebit"] = 0.001;
    ex[cont++] = new Whitebit(0.001, "whitebit", "", "");*/
}
